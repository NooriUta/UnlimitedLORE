package studio.seer.heimdall.lore;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;

/**
 * SPRINT_UXR_S7A_NEWS/S7A-04: черта «прочитано до сюда» — на сервере, одна
 * общая (§8, решение 07.11 п.12). Не тает: сдвигается только действием
 * пользователя (PUT), никаких счётчиков и уведомлений.
 *
 * <p>Тип {@link #TYPE} заводит шаг V70 {@code news_read_mark} реестра
 * {@code LoreSchemaMigrations} — DDL берётся отсюда, {@link #SCHEMA_SQL}.
 * Выпущенный шаг неизменяем: правка этого списка меняет checksum V70 и роняет
 * старт (дрейф-гард) — нужна правка схемы → новый шаг.
 *
 * <p>Пока шаг не накатан (или хранилище недоступно), чтение и запись честно
 * отвечают {@code state=unavailable} с причиной, а не «черты нет» — пустое и
 * недоступное не смешиваются (S7A-07).
 */
final class LoreNewsReadMarkStore {

    private static final org.jboss.logging.Logger LOG = org.jboss.logging.Logger.getLogger(LoreNewsReadMarkStore.class);

    static final String TYPE = "LoreNewsReadMark";
    static final String SHARED = "shared";

    static final List<String> SCHEMA_SQL = List.of(
        "CREATE VERTEX TYPE " + TYPE + " IF NOT EXISTS",
        "CREATE PROPERTY " + TYPE + ".mark_id IF NOT EXISTS STRING",
        "CREATE PROPERTY " + TYPE + ".mark_at IF NOT EXISTS STRING",
        "CREATE PROPERTY " + TYPE + ".updated_at IF NOT EXISTS STRING",
        "CREATE PROPERTY " + TYPE + ".updated_by IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON " + TYPE + " (mark_id) UNIQUE");

    /** ok — черта есть; none — черты ещё не ставили; unavailable — хранилище недоступно. */
    record State(String state, Instant at, String error) {
        Map<String, Object> toMap() {
            Map<String, Object> m = new java.util.LinkedHashMap<>();
            m.put("state", state);
            m.put("at", at == null ? null : at.toString());
            if (error != null) m.put("error", error);
            return m;
        }
    }

    private final BiFunction<String, Map<String, Object>, List<Map<String, Object>>> query;
    private final BiConsumer<String, Map<String, Object>> command;

    LoreNewsReadMarkStore(BiFunction<String, Map<String, Object>, List<Map<String, Object>>> query,
                          BiConsumer<String, Map<String, Object>> command) {
        this.query = query;
        this.command = command;
    }

    State get() {
        try {
            List<Map<String, Object>> rows = query.apply(
                "SELECT mark_at FROM " + TYPE + " WHERE mark_id = :id", Map.of("id", SHARED));
            if (rows == null || rows.isEmpty() || rows.get(0).get("mark_at") == null) return new State("none", null, null); // ревью 10.11, B3: имя из контракта kit (ok | none | unavailable)
            Instant at = LoreNewsV2Collector.instant(rows.get(0).get("mark_at"));
            return at == null ? new State("unavailable", null, "mark_at не разобран: " + rows.get(0).get("mark_at"))
                : new State("ok", at, null);
        } catch (Exception e) {
            // Владелица 14.11.2026: «Received: Bad Request, status code 400» без ответа базы — корень не
            // установить. Причина с телом ответа БД — и в ответ, и в лог (заголовки не читаются).
            String why = LoreUpstream.detail(e);
            LOG.warnf("[LORE NEWS] черта «прочитано»: %s", why);
            return new State("unavailable", null, why);
        }
    }

    /** Сдвиг черты действием пользователя. Черту назад не двигаем молча — это тоже действие, но явное. */
    // Владелица 14.11.2026 «Черта «прочитано» недоступна … 400». Ответ ArcadeDB (live-тест CI): «SQL syntax error …
    // mismatched input ','» на запятой перед «updated_by = :by» — BY ключевое слово SQL, параметр :by не
    // разбирается (:now в других запросах работает — первая гипотеза про него была неверной). Имена без ключевых слов.
    State set(Instant at, String by) {
        try {
            command.accept("UPDATE " + TYPE + " SET mark_id = :markId, mark_at = :markAt, updated_at = :touchedAt, updated_by = :touchedBy "
                    + "UPSERT WHERE mark_id = :markId",
                Map.of("markId", SHARED, "markAt", at.toString(), "touchedAt", Instant.now().toString(), "touchedBy", by == null ? "unknown" : by));
            return get();
        } catch (Exception e) {
            // Владелица 14.11.2026: «Received: Bad Request, status code 400» без ответа базы — корень не
            // установить. Причина с телом ответа БД — и в ответ, и в лог (заголовки не читаются).
            String why = LoreUpstream.detail(e);
            LOG.warnf("[LORE NEWS] черта «прочитано»: %s", why);
            return new State("unavailable", null, why);
        }
    }
}
