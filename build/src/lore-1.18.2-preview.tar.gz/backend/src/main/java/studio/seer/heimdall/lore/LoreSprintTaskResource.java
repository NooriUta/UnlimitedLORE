package studio.seer.heimdall.lore;

import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;
import studio.seer.heimdall.bench.MartQuery;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Sprint/task/phase write endpoints (create, edit, phase attach, sprint/PR
 * refs, sprint↔project/component links, task↔component links, sprint deps),
 * split out of AidaLoreResource (B2). The generic status dispatch (including
 * sprint plan-field edits via /lore/sprint/plan) lives in LoreStatusResource,
 * not here. Shares infra via LoreResourceBase.
 */
@Path("/lore")
public class LoreSprintTaskResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreSprintTaskResource.class);

    @jakarta.inject.Inject
    LoreHashStamper hashStamper; // SV-10: content_hash на открытой Hist-строке после записи тел

    // ADR-LORE-013 (task/move) reuses LoreStatusResource's SCD2 transition + task
    // carry-forward helpers to cancel the source task — see updateScd2Status's
    // Javadoc for why those are package-private instead of duplicated here.
    @Inject
    LoreStatusResource statusResource;

    // MD-05: task_link rel=pr заводил KnowPR одним ключом и не дотягивал данные — корень PR без заголовка
    // для PR, влитых мимо моста. Теперь после записи — дотяжка из Forgejo (как у мержа и release_link).
    @Inject
    ForgejoBridge forgejo;

    public record SprintRefsRequest(String sprint_id, List<Integer> pr_numbers,
        String git_project, String repo_url, Boolean replace) {}
    // priority moved to SprintPlanRequest/POST /lore/sprint/plan — it's SCD2-tracked
    // (lives on KnowSprintHist), unlike the vertex-only fields below.
    // no_release_required: sprints that never ship a versioned release (docs-only,
    // research spikes, internal tooling) — excluded from deploy-lag/unreleased-burn
    // metrics in LoreAnalytics, which would otherwise flag them as perpetually overdue.
    public record SprintUpdateRequest(String sprint_id, String name, String outcome_md,
        String context_md, String plan_id, Double effort_days, Boolean no_release_required,
        String context_append, String outcome_append, Boolean unplanned_intentional,
        // ADR-LORE-047 A3: версия записи паспорта (record.version); не совпала — 409 VERSION_CONFLICT.
        String expected_version) {}
    // author/executor/reviewer_agent (ADR-LORE-014 §4): free-text identity of who
    // owns/does/accepts the task — on the vertex, not Hist (see LoreSchemaInitializer
    // comment for why: immune to the note_md/effort_days carry-forward bug class).
    // task_type (ADR-LORE-015, T14): defaults to "dev" when omitted — a vertex-only
    // field like author/executor/reviewer_agent above, so no carry-forward concern.
    // work_class (ADR-LORE-022): ЗАЧЕМ-ось (uc|jtd|enb), ортогональна task_type
    // (КАК-ось); vertex-only — как task_type, carry-forward не касается.
    // effort_days (05.11.2026): то же поле, что пишет task/edit, — задача рождается
    // с оценкой, без второго вызова и без упрёка чекера качества «missing: effort_days».
    public record TaskCreateRequest(String sprint_id, String task_id, String title, String note_md,
        String phase_uid, String author_agent, String executor_agent, String reviewer_agent,
        String task_type, String work_class, String uc_id, Double effort_days, Double actual_days,
        Boolean bookkeeping,
        // MDL-11: статус при создании обязателен (TaskCreateStatus); раньше поля не было и статус выбрасывался.
        String status) {}
    // effort_days: fractional, granular to the hour (1 day = 8 working hours,
    // so the smallest meaningful increment is 0.125). Was Integer — too coarse
    // to estimate sub-day tasks.
    public record TaskEditRequest(String task_uid, String title, String note_md, Double effort_days,
        String work_class, String uc_id,
        String author_agent, String executor_agent, String reviewer_agent, String task_type,
        Double actual_days, Boolean bookkeeping, String note_append, java.util.Map<String, Object> expected,
        // ADR-LORE-047 A3: версия записи паспорта (record.version); не совпала — 409 VERSION_CONFLICT.
        String expected_version) {}
    // quality — вердикт линтера полноты (WorkQuality). Поле добавочное: старые
    // клиенты его игнорируют, новые видят, чего не хватает, СРАЗУ после записи,
    // а не когда кто-то откроет срез гигиены через неделю.
    // quality — компактная форма (WorkQuality.compact): «x из y» плюс ТОЛЬКО
    // непройденное. Полный список выдавал пройденные и непройденные проверки
    // одинаково, и пропуск тонул среди пройденного — ответ task_new читают
    // чаще всех, поэтому здесь это стоило дороже всего.
    public record TaskWriteResponse(boolean ok, String task_uid, String task_id, Integer order_index,
        java.util.Map<String, Object> quality) {}
    // MCP-PHASES (SPRINT_LORE_MCP_GAPS_2): sprint phases write-path
    public record PhaseCreateRequest(String sprint_id, String phase_key, String name, Integer order_index,
        String summary_md) {}
    public record PhaseWriteResponse(boolean ok, String phase_uid, String phase_id,
        Integer order_index, boolean created, WorkQuality.Result quality) {}
    public record TaskPhaseRequest(String task_uid, String phase_uid, String action) {}

    public record SprintCreateRequest(String sprint_id, String name, String status,
        String plan_id, String priority, String outcome_md, String context_md, String git_project) {}

    // ── Write-path: create sprint directly ───────────────────────────────────

    @POST
    @Path("sprint/create")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createSprint(SprintCreateRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.sprint_id() == null || req.sprint_id().isBlank()) {
            return badParams("sprint_id required");
        }
        if (!SAFE_ID.matcher(req.sprint_id()).matches()) {
            return badParams("sprint_id contains illegal characters");
        }
        // Спринт без статуса — начальный статус по модели (sprint.status.initial; 16.11.2026 «в беклог»,
        // правило владелицы 19.11.2026). Раньше — «todo», который писался «📋 PLANNED».
        final CreateDefaultStatus.Pick statusPick = CreateDefaultStatus.pick("sprint", req.status());
        String status = statusPick.value();
        if (!PLAN_STATUSES.contains(status)) {
            return badParams("status must be one of: " + PLAN_STATUSES);
        }
        try {
            LoreIngestService.CreateSprintResult r = ingestService.createSprint(
                req.sprint_id(), req.name(), status, req.plan_id(), req.priority(), req.outcome_md(), req.context_md(),
                changeAuthor());
            // ADR-LORE-017 §Решение 2: sprint_new gets the same optional project param
            // release_new/release_link/sprint_link(rel:"project") already have — brings
            // Tier-1 write coverage in line, no separate call needed for the common case
            // of creating a sprint that already belongs to a known repo.
            if (req.git_project() != null && !req.git_project().isBlank()) {
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE BELONGS_TO_PROJECT " +
                    "FROM (SELECT FROM KnowSprint WHERE sprint_id=:sid) " +
                    "TO   (SELECT FROM KnowGitProject WHERE slug=:gp) IF NOT EXISTS",
                    Map.of("sid", req.sprint_id(), "gp", req.git_project()))).await().indefinitely();
            }
            hashStamper.stampOpenHist("KnowSprintHist", "KnowSprint", "sprint_id", req.sprint_id());
            java.util.LinkedHashMap<String, Object> out = new java.util.LinkedHashMap<>();
            out.put("ok", true);
            out.put("sprint_id", r.sprintId());
            out.put("created", r.created());
            // DS-7: у существующего спринта приоритет — ревизия плана (SCD2), а не
            // поле создания. Молча проглотить его значило бы снова ok:true без записи.
            if (!r.created() && req.priority() != null && !req.priority().isBlank()) {
                out.put("priority_hint", "спринт уже существует: priority здесь в историю не записан — "
                    + "меняйте через sprint_plan_set (SCD2-ревизия плана)");
            }
            // MD-AUTOLINK (spec:SPEC-LORE-MD-INLINE-REF §7): упоминания в текстах → рёбра авто-пар.
            if (req.context_md() != null || req.outcome_md() != null)
                out.put("mentions", autoLinkMentions("sprint", req.sprint_id(), false, req.context_md(), req.outcome_md()));
            out.put("quality", WorkQuality.compact(sprintQuality(req.sprint_id())));
            if (r.created()) CreateDefaultStatus.report(out, statusPick); // правило владелицы 19.11.2026: подстановка видна
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE SPRINT CREATE] %s: %s", req.sprint_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── Write-path: create / edit a task ────────────────────────────────────

    @jakarta.inject.Inject
    TaskRoleService roleService;

    /**
     * Присланные роли — рёбрами, с ответом по каждой (TR-05, ADR-LORE-043).
     *
     * <p>Поля author/executor/reviewer_agent больше не пишутся. Если бы мы
     * просто перестали их сохранять и промолчали, вызывающий получил бы
     * ok:true на «указал исполнителя», а исполнителя бы не было — потеря,
     * неотличимая от того, что его и не указывали. Поэтому каждая присланная
     * роль проходит через ту же точку записи, что и отдельный вызов, и её исход
     * попадает в ответ.
     *
     * <p>Отказ по одной роли НЕ отменяет создание задачи: задача уже записана,
     * а роль — отдельный факт. Но и молчания о нём нет: в ответе стоит noop с
     * причиной.
     */
    private Map<String, Object> applyRoles(String taskUid, String author, String executor, String reviewer) {
        Map<String, Object> out = new LinkedHashMap<>();
        record Pair(String role, String identity) {}
        for (Pair pr : List.of(new Pair(TaskRole.AUTHOR, author),
                               new Pair(TaskRole.EXECUTOR, executor),
                               new Pair(TaskRole.REVIEWER, reviewer))) {
            if (pr.identity() == null || pr.identity().isBlank()) continue;
            TaskRoleService.Result r = roleService.apply(new TaskRoleService.RoleRequest(
                taskUid, pr.role(), pr.identity(), null, null, null, null));
            out.put(pr.role(), r.body());
        }
        return out;
    }

    /**
     * Назначение роли на задаче (ADR-LORE-042, TR-04/TR-06).
     *
     * <p>Отдельный вызов, а не поле в {@code task_new}, потому что назначение —
     * не свойство задачи, а СОБЫТИЕ: у него своя дата, свой прежний держатель и
     * своя причина смены. Поля author/executor/reviewer_agent пока пишутся
     * по-прежнему: обе правды живут рядом, пока не сойдутся, и снятие полей —
     * отдельный последний шаг, а не побочный эффект этого.
     *
     * <p>Отказ отдаётся как {@code 400} с телом по ADR-LORE-043: {@code outcome}
     * называет произошедшее, {@code reason} — почему. Молчаливого {@code ok:true}
     * на неприменённом назначении здесь быть не может.
     */
    /**
     * Кого можно поставить на роль этой задачи (TR-07).
     *
     * <p>Отдаётся ТЕМ ЖЕ методом, которым проверяет запись, — иначе форма
     * предлагала бы один список, а отказ называл другой, и расхождение
     * обнаружилось бы только в момент отказа. Одна правда о кандидатах, а не
     * две согласуемые вручную.
     *
     * <p>Пустой список — содержательный ответ, а не отсутствие данных: он
     * означает, что в проекте задачи нет ни одной роли, и чинится это в
     * админке, а не выбором другого имени. Поэтому он приходит с признаком,
     * который форме есть что показать.
     */
    @jakarta.ws.rs.GET
    @Path("task/role-candidates")
    @Produces(MediaType.APPLICATION_JSON)
    @io.smallrye.common.annotation.Blocking
    public Response taskRoleCandidates(@jakarta.ws.rs.QueryParam("task_uid") String taskUid,
                                       @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (taskUid == null || taskUid.isBlank()) return badParams("task_uid required");
        java.util.List<String> people = roleService.peopleOfTaskProject(taskUid);
        java.util.List<String> agents = roleService.declaredAgents();
        return noStore(Response.ok(Map.of(
            "task_uid", taskUid,
            "people", people,
            "agents", agents,
            "project_has_roles", !people.isEmpty())));
    }

    @POST
    @Path("task/role")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @io.smallrye.common.annotation.Blocking
    public Response setTaskRole(TaskRoleService.RoleRequest req,
                                @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        TaskRoleService.Result r = roleService.apply(req);
        return noStore(r.applied()
            ? Response.ok(r.body())
            : Response.status(Response.Status.BAD_REQUEST).entity(r.body()));
    }

    @POST
    @Path("task")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    // @Blocking: гейт ролей для агента спрашивает граф синхронно, а без
    // аннотации метод исполняется на event loop, где блокирующий вызов падает
    // с «current thread cannot be blocked». Реактивная цепочка ниже от этого не
    // меняется — меняется поток, на котором она собирается.
    @io.smallrye.common.annotation.Blocking
    public Uni<Response> createTask(TaskCreateRequest req, @HeaderParam("X-Seer-Role") String role,
                                    @jakarta.ws.rs.QueryParam("mode") String mode) {
        if (!enabled) return Uni.createFrom().item(disabled());
        requireAdmin(role);
        // MT-MCP-TRUTH п.1: задача создаётся INSERT-ом, и занятый код и так даёт 409 TASK_ID_TAKEN
        // со свободным кодом; здесь режим только проверяется на допустимость (create|upsert), чтобы
        // клиент слал одинаковый ?mode=create на все четыре пути создания.
        Response badMode = modeError(mode);
        if (badMode != null) return Uni.createFrom().item(badMode);
        if (req == null || req.sprint_id() == null || req.task_id() == null
                || req.title() == null || req.title().isBlank()) {
            return Uni.createFrom().item(badParams("sprint_id, task_id, title required"));
        }
        // MDL-11: статус не назван — первый статус (бэклог); статус, требующий причины или доказательства, — через status_set.
        final String statusRefusal = TaskCreateStatus.refuse(req.status());
        if (statusRefusal != null)
            return Uni.createFrom().item(noStore(Response.status(Response.Status.BAD_REQUEST)
                .entity(new LoreError("STATUS_NOT_FOR_CREATE", statusRefusal))));
        final String createStatusRaw = TaskCreateStatus.raw(req.status());
        if (!SAFE_ID.matcher(req.sprint_id()).matches() || !SAFE_ID.matcher(req.task_id()).matches()) {
            return Uni.createFrom().item(badParams("sprint_id / task_id contain illegal characters"));
        }
        final ChangeAuthor by = changeAuthor(); // S2-12: снят до асинхронной цепочки
        // Решение владельца 30.08.2026: агент не создаёт задачу без ролей —
        // отказ, а не запись с пропуском. Проверка стоит ДО первой команды в
        // базу: иначе задача легла бы, а отказ пришёл после, и «не создана»
        // было бы неправдой.
        //
        // Только для агентов. Человек заводит задачу в форме, видя список, и
        // законно может не знать исполнителя в момент создания. У агента этого
        // случая нет: он пишет из сценария, где обе роли известны.
        if (callerAgentScope() != null) {
            String refuse = roleService.refuseCreateForAgent(
                req.sprint_id(), req.author_agent(), req.executor_agent());
            if (refuse != null) {
                return Uni.createFrom().item(noStore(Response.status(Response.Status.BAD_REQUEST)
                    .entity(Map.of("ok", false, "outcome", LoreOutcome.NOOP, "reason", refuse))));
            }
        }
        if (req.phase_uid() != null && !SAFE_ID.matcher(req.phase_uid()).matches()) {
            return Uni.createFrom().item(badParams("phase_uid contains illegal characters"));
        }
        // ADR-LORE-022: work_class — закрытый канон (uc|jtd|enb), null легален (D3).
        if (req.work_class() != null && !req.work_class().isBlank()
                && !java.util.List.of("uc", "jtd", "enb").contains(req.work_class())) {
            return Uni.createFrom().item(badParams("work_class must be uc|jtd|enb (or omitted)"));
        }
        // MT-SPRINT-DONE-GUARD — до первой записи: «не создана» должно быть правдой.
        String closed = closedSprintRefusalFor(req.sprint_id());
        if (closed != null) return Uni.createFrom().item(badParams(closed));
        String full = fullSprintRefusalFor(req.sprint_id());
        if (full != null) return Uni.createFrom().item(badParams(full));
        if (req.effort_days() != null && (req.effort_days().isNaN() || req.effort_days() < 0)) {
            return Uni.createFrom().item(badParams("effort_days must be a non-negative number of person-days (or omitted)"));
        }
        if (req.actual_days() != null && (req.actual_days().isNaN() || req.actual_days() < 0)) {
            return Uni.createFrom().item(badParams("actual_days must be a non-negative number of person-days (or omitted)"));
        }
        final String sid   = req.sprint_id();
        final String tid   = req.task_id();
        final String uid   = sid + "/" + tid;
        final String title = req.title().trim();
        final String note  = req.note_md();
        final String phase = req.phase_uid();
        final String now   = Instant.now().toString();
        final String nsid  = UUID.randomUUID().toString();

        // MCP-PHASES: a phase must exist and belong to THIS sprint (phase_uid = "<sprint>/PHASE_x")
        if (phase != null && !phase.startsWith(sid + "/")) {
            return Uni.createFrom().item(badParams(
                "phase_uid must belong to sprint " + sid + " (got: " + phase + ")"));
        }

        // order_index = max existing for this sprint + 1 (tasks keyed task_uid = "<sprint>/<id>").
        // Exact-prefix match via substring, NOT LIKE: '_' in sprint ids is a LIKE wildcard
        // ("any one char"), so LIKE :prefix could count same-shaped uids from OTHER sprints.
        String prefix = sid + "/";
        MartQuery maxQ = new MartQuery("sql",
            "SELECT max(order_index) AS mx FROM KnowTask WHERE task_uid.substring(0, :plen) = :prefix",
            Map.of("prefix", prefix, "plen", prefix.length()), -1);

        return client.query(db, basicAuth(), maxQ)
            .chain(res -> {
                List<Map<String, Object>> rows = res.result() != null ? res.result() : List.of();
                Object mxRaw = rows.isEmpty() ? null : rows.get(0).get("mx");
                final int order = (mxRaw instanceof Number n ? n.intValue() : 0) + 1;

                // A1: one atomic sqlscript. ArcadeDB runs all statements in a single
                // implicit transaction, so a mid-sequence failure rolls the whole
                // create back — no orphan KnowTask left without its HAS_STATE hist
                // row. A later statement also sees rows inserted by an earlier one in
                // the same script, so the HAS_STATE edge resolves reliably (this used
                // to need separate commands + careful ordering).
                // note_md lives on the hist row: tasks_of_sprint / tasks_of_phase read
                // it via out('HAS_STATE')[note_md IS NOT NULL].note_md[0], not the vertex.
                final String taskType = (req.task_type() == null || req.task_type().isBlank())
                    ? "dev" : req.task_type();
                final String workClass = (req.work_class() == null || req.work_class().isBlank())
                    ? null : req.work_class(); // null легален (D3: не каждая задача несёт класс)
                StringBuilder script = new StringBuilder()
                    .append("INSERT INTO KnowTask SET task_uid = :uid, task_id = :tid, title = :title, ")
                    .append("note_md = :note, effort_days = :eff, order_index = :oi, src = 'manual', task_type = :tt, work_class = :wc, actual_days = :act, bookkeeping = :bk;")
                    .append("CREATE EDGE PART_OF FROM (SELECT FROM KnowTask WHERE task_uid = :uid) ")
                    .append("TO (SELECT FROM KnowSprint WHERE sprint_id = :sid);")
                    .append("INSERT INTO KnowTaskHist SET state_uid = :nsid, status_raw = :st0, ")
                    .append("valid_from = :now, note_md = :note, effort_days = :eff").append(ChangeAuthor.SET_SQL).append(";")
                    .append("CREATE EDGE HAS_STATE FROM (SELECT FROM KnowTask WHERE task_uid = :uid) ")
                    .append("TO (SELECT FROM KnowTaskHist WHERE state_uid = :nsid AND in('HAS_STATE').size() = 0);");
                Map<String, Object> p = mapOfNullable("uid", uid, "tid", tid, "title", title,
                    "note", note, "oi", order, "sid", sid, "nsid", nsid, "now", now, "tt", taskType, "wc", workClass,
                    "eff", req.effort_days(), "act", req.actual_days(),
                    "bk", req.bookkeeping() != null && req.bookkeeping());
                p.put("st0", createStatusRaw);
                by.bind(p);
                // MCP-PHASES: optional task → phase attachment (tasks_of_phase reads outE('IN_PHASE')[valid_to IS NULL].inV())
                if (phase != null) {
                    script.append("CREATE EDGE IN_PHASE FROM (SELECT FROM KnowTask WHERE task_uid = :uid) ")
                          .append("TO (SELECT FROM KnowPhase WHERE phase_uid = :puid) SET valid_from = :now;");
                    p.put("puid", phase);
                }
                // PL-14 (D16): uc-задача обязана нести REALIZES. Ребро создаётся В ТОМ
                // ЖЕ sqlscript, что и сама задача, — атомарно с ней. Раньше связка была
                // ВТОРЫМ вызовом со стороны сценария (uc_link rel="task"), и между
                // двумя вызовами задача успевала пожить без ребра: дисциплина держалась
                // на внимательности и advisory-слайсе unlinked_uc_tasks. Теперь либо
                // создаётся и задача, и связка, либо не создаётся ничего.
                if (req.uc_id() != null && !req.uc_id().isBlank()) {
                    script.append("CREATE EDGE REALIZES FROM (SELECT FROM KnowTask WHERE task_uid = :uid) ")
                          .append("TO (SELECT FROM KnowUseCase WHERE uc_id = :ucid);");
                    p.put("ucid", req.uc_id());
                }
                // Запись хеша уходит на рабочий пул: она блокирующая, а колбэк
                // исполняется на потоке, отдавшем элемент, то есть на event loop.
                // Иначе `stampOpenHist` падает с «current thread cannot be blocked»
                // и гасится собственным catch: content_hash остаётся пустым при
                // успешном ответе, и reconcile перестаёт видеть дрейф.
                Uni<Response> write = writeClient.command(db, basicAuth(),
                        new LoreCommandClient.LoreCommand("sqlscript", script.toString(), p))
                    .chain(__ -> Uni.createFrom().item(() -> {
                            hashStamper.stampOpenHist("KnowTaskHist", "KnowTask", "task_uid", uid);
                            // Роли — РЕБРОМ, и ответ говорит, что с каждой стало
                            // (TR-05 + ADR-LORE-043). Молча проглотить присланную
                            // роль было бы худшим из исходов: поле больше не
                            // пишется, и «указал исполнителя» без ребра означало бы
                            // потерю, неотличимую от того, что его не указывали.
                            Map<String, Object> body = new LinkedHashMap<>();
                            body.put("ok", true);
                            body.put("task_uid", uid);
                            // MDL-11: в каком статусе родилась задача и назвал ли его создающий.
                            body.put("status", createStatusRaw);
                            body.put("status_defaulted", TaskCreateStatus.defaulted(req.status()));
                            CreateDefaultStatus.report(body, CreateDefaultStatus.pick("task", req.status())); // правило 19.11
                            body.put("task_id", tid);
                            body.put("order_index", order);
                            body.put("quality", WorkQuality.compact(taskQuality(uid)));
                            // MT-CAL-CLASS-REQUIRED (D5): класс не задан — явная подсказка, не отказ.
                            Map<String, Object> wcWarn = workClassWarning(workClass);
                            if (wcWarn != null) body.put("warning", wcWarn);
                            Map<String, Object> roles = applyRoles(uid,
                                req.author_agent(), req.executor_agent(), req.reviewer_agent());
                            if (!roles.isEmpty()) body.put("roles", roles);
                            // MD-AUTOLINK: упоминания в теле задачи → TAGGED_WITH к компоненту.
                            if (note != null) body.put("mentions", taskMentions(uid, note));
                            return noStore(Response.ok(body));
                        })
                        .runSubscriptionOn(io.smallrye.mutiny.infrastructure.Infrastructure.getDefaultWorkerPool()));

                // Сценарий проверяем ДО записи, а не после. CREATE EDGE в пустой TO —
                // тихий no-op: задача создалась бы, ребра не было бы, ответ пришёл бы
                // ok:true. Здесь несуществующий uc_id — отказ 400, и задача не
                // создаётся вовсе: «атомарно» обязано означать и это тоже.
                final String ucId = req.uc_id();
                if (ucId != null && !ucId.isBlank()) {
                    return client.query(db, basicAuth(), new MartQuery("sql",
                            "SELECT uc_id FROM KnowUseCase WHERE uc_id = :ucid", Map.of("ucid", ucId), 1))
                        .chain(ucRes -> (ucRes.result() == null || ucRes.result().isEmpty())
                            ? Uni.createFrom().item(badParams("uc_id «" + ucId + "» не найден — "
                                + "REALIZES создать не из чего; заведите сценарий через /lore/uc"))
                            : write);
                }
                return write;
            })
            .onFailure().recoverWithUni(ex -> {
                // SE-17: 409 здесь — уникальный индекс отверг дубль task_uid, а не
                // сбой СУБД. Отдавать его как 502 LORE_UPSTREAM значило звать
                // повторить тот же вызов. Отказ называет допустимое (ADR-LORE-043
                // §3): код занят — вот следующий свободный.
                if (isConflict(ex)) {
                    return client.query(db, basicAuth(), new MartQuery("sql",
                            "SELECT task_id FROM KnowTask WHERE out('PART_OF').sprint_id[0] = :sid",
                            Map.of("sid", sid), -1))
                        .map(r -> {
                            List<String> ids = new java.util.ArrayList<>();
                            if (r.result() != null) for (Map<String, Object> row : r.result())
                                if (row.get("task_id") != null) ids.add(row.get("task_id").toString());
                            return taskIdTaken(sid, tid, nextFreeTaskId(tid, ids));
                        })
                        .onFailure().recoverWithItem(e2 -> taskIdTaken(sid, tid, null));
                }
                LOG.warnf("[LORE TASK CREATE] %s: %s", uid, ex.getMessage());
                return Uni.createFrom().item(noStore(Response.status(Response.Status.BAD_GATEWAY)
                    .entity(LoreUpstream.error(ex))));
            });
    }

    /** Канон класса работы ADR-LORE-022 — порядок как в подсказке. */
    static final List<String> WORK_CLASSES = List.of("uc", "jtd", "enb");

    /**
     * MT-CAL-CLASS-REQUIRED, решение владелицы 14.11.2026 (D5 «подсказка»): задача без work_class
     * создаётся (отказа нет), но ответ несёт отдельное поле {@code warning} — заметнее строки в
     * quality.missing: что не задано, какие значения допустимы и чем дописать. Класс задан — null.
     */
    static Map<String, Object> workClassWarning(String workClass) {
        if (workClass != null && !workClass.isBlank()) return null;
        Map<String, Object> w = new LinkedHashMap<>();
        w.put("code", "WORK_CLASS_MISSING");
        w.put("field", "work_class");
        w.put("allowed", WORK_CLASSES);
        w.put("detail", "задача создана без класса работы — без него не работают калибровка и правила вех. "
            + "Допустимо: uc — реализует сценарий, jtd — вспомогательная работа, enb — обеспечивающая (enabler); "
            + "допишите task_set work_class=uc|jtd|enb");
        return w;
    }

    private Response taskIdTaken(String sid, String tid, String suggested) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("error", "TASK_ID_TAKEN");
        body.put("detail", "код " + tid + " в спринте " + sid + " уже занят"
            + (suggested != null ? " — свободный: " + suggested : ""));
        body.put("task_id", tid);
        if (suggested != null) body.put("suggested_task_id", suggested);
        return noStore(Response.status(Response.Status.CONFLICT).entity(body));
    }

    /** Отказ СУБД с кодом 409 — нарушение уникальности, а не сбой. */
    static boolean isConflict(Throwable e) {
        return e instanceof jakarta.ws.rs.WebApplicationException w
            && w.getResponse() != null && w.getResponse().getStatus() == 409;
    }

    /**
     * Следующий свободный код в ряду занятого: тот же префикс, номер на единицу
     * больше максимального среди кодов этого префикса, ширина цифр — как у
     * занятого (T03 → T07). У кода без номера — суффикс «-N», которого ещё нет.
     */
    static String nextFreeTaskId(String taken, List<String> existing) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(.*?)(\\d+)$").matcher(taken);
        if (m.matches()) {
            String prefix = m.group(1);
            int width = m.group(2).length();
            int max = Integer.parseInt(m.group(2));
            for (String id : existing) {
                java.util.regex.Matcher e = java.util.regex.Pattern.compile("^" + java.util.regex.Pattern.quote(prefix) + "(\\d+)$").matcher(id);
                if (e.matches()) max = Math.max(max, Integer.parseInt(e.group(1)));
            }
            return prefix + String.format("%0" + width + "d", max + 1);
        }
        int n = 2;
        while (existing.contains(taken + "-" + n)) n++;
        return taken + "-" + n;
    }

    // ── Линтер полноты: вердикт в ответе на запись ───────────────────────────
    //
    // Четыре поля забывались раз за разом — статус, компонент, оценка, проект, —
    // и напоминал о них ЧЕЛОВЕК. Слайсы гигиены ловят часть, но постфактум и
    // только если кто-то откроет срез: к тому моменту контекст записи утерян.
    // Здесь вердикт возвращается в момент записи, когда автор ещё может дописать.
    //
    // Проба ЧИТАЮЩАЯ и обёрнута в catch: сам линтер — вспомогательная функция,
    // и его отказ не имеет права превратить успешную запись в ошибку. Не смогли
    // собрать факты — вердикта в ответе просто нет (null), и это честнее, чем
    // вердикт, посчитанный по недособранным фактам.
    //
    // Блокирующий вызов допустим только там, откуда он зовётся: в createTask и
    // editTask — внутри блока на рабочем пуле (рядом со stampOpenHist), в
    // sprint-путях — из синхронного метода.
    @jakarta.inject.Inject
    LoreQualityFacts qualityFacts;

    private WorkQuality.Result taskQuality(String uid) {
        return qualityFacts.forOne(LoreQualityFacts.Kind.TASK, uid);
    }

    private WorkQuality.Result sprintQuality(String sid) {
        return qualityFacts.forOne(LoreQualityFacts.Kind.SPRINT, sid);
    }

    // ── ADR-LORE-013: move a task between sprints (cancel + recreate) ────────
    // Creates a fresh copy in the target sprint (title/note_md/effort_days +
    // TAGGED_WITH component links, status carried from the source — none → BACKLOG) and cancels the source
    // (stays as a ❌ tombstone in the old sprint, note carried forward per #88).
    // No PK re-key / SCD2 surgery — reuses the create + status write paths.
    public record TaskMoveRequest(String task_uid, String target_sprint_id, String new_task_id) {}

    /**
     * MT-TASK-MV-HISTORY (Völva 05.11.2026): перенос задачи создавал новую с историей
     * «📋 PLANNED» — статус терялся, его восстанавливали руками у каждой перенесённой
     * задачи. Переносится статус открытой строки истории.
     *
     * <p>MT-MCP-TRUTH Б5 (MDL-11, ST-08): статуса нет — первый статус задачи, бэклог ({@link TaskCreateStatus#DEFAULT}),
     * как при создании без статуса; прежний PLANNED выдумывал «запланирована» для задачи, о которой это неизвестно.
     */
    static String carriedStatus(Object statusRaw) {
        String v = statusRaw == null ? null : String.valueOf(statusRaw).strip();
        return (v == null || v.isEmpty()) ? TaskCreateStatus.raw(null) : v;
    }

    /**
     * MT-SPRINT-DONE-GUARD (владелец 05.11.2026): в закрытый (done/cancelled) спринт
     * задачу не заводят и не переносят. В Völva два DONE-спринта держали 11 открытых
     * задач: task_new брал sprint_id строкой и статус не смотрел, агент выбирал спринт
     * «по смыслу». Отказ, а не предупреждение — предупреждение рядом с ok:true агент
     * проглатывает. status_set задач закрытого спринта НЕ запрещается: унаследованное
     * должно оставаться чинимым. Нет строки статуса — не отказ («не знаем» ≠ «закрыт»).
     *
     * @return текст отказа или null
     */
    static String closedSprintRefusal(String sprintId, String statusRaw, Object since) {
        if (statusRaw == null || statusRaw.isBlank()) return null;
        String canon = LoreStatusVocabulary.classify(statusRaw);
        if (!"done".equals(canon) && !"cancelled".equals(canon)) return null;
        return "спринт " + sprintId + " закрыт (статус «" + statusRaw.strip() + "»"
            + (since != null ? ", с " + since : "") + ") — задачи в закрытый спринт не заводят и не переносят. "
            + "Выберите открытый спринт (срез sprints со status) или заведите новый; если работа "
            + "правда продолжает этот спринт — сначала переоткройте его status_set, осознанно.";
    }

    /**
     * Владелица 21.11.2026: «внеси в ограничение добавки новых задач в спринт наличие в спринте 35 задач — у нас
     * пухнут мега спринты». Предел задач спринта; отменённые не считаются (это не нагрузка спринта), задача без
     * строки статуса — считается («не знаем статус» ≠ «её нет»). Касается только ДОБАВЛЕНИЯ (заведение и перенос
     * в спринт); правка и смена статуса уже лежащих задач не запрещаются.
     */
    static final int SPRINT_TASK_LIMIT = 35;

    /** @return текст отказа или null; statuses — status_raw открытых строк истории задач спринта. */
    static String fullSprintRefusal(String sprintId, java.util.List<String> statuses) {
        long n = statuses.stream()
            .filter(st -> st == null || st.isBlank() || !"cancelled".equals(LoreStatusVocabulary.classify(st)))
            .count();
        if (n < SPRINT_TASK_LIMIT) return null;
        return "в спринте " + sprintId + " уже " + n + " задач (предел " + SPRINT_TASK_LIMIT + ", отменённые не в счёт) — "
            + "новые задачи в него не заводят и не переносят: спринт распух. Заведите новый спринт под эту работу "
            + "(sprint_new / entity_upsert type=sprint) или закройте/отмените лишнее в этом.";
    }

    /** Подсчёт задач спринта по префиксу task_uid; отказ или null. Блокирующий — звать только с @Blocking/worker. */
    private String fullSprintRefusalFor(String sprintId) {
        String prefix = sprintId + "/";
        List<Map<String, Object>> rows = ingestService.queryPublic(
            "SELECT out('HAS_STATE')[valid_to IS NULL].status_raw[0] AS st FROM KnowTask "
            + "WHERE task_uid.substring(0, :plen) = :prefix", Map.of("plen", prefix.length(), "prefix", prefix));
        java.util.List<String> st = new java.util.ArrayList<>(rows.size());
        for (Map<String, Object> r : rows) st.add(r.get("st") == null ? null : String.valueOf(r.get("st")));
        return fullSprintRefusal(sprintId, st);
    }

    /** Статус ОТКРЫТОЙ строки истории спринта; отказ или null. Блокирующий — звать только с @Blocking/worker. */
    private String closedSprintRefusalFor(String sprintId) {
        List<Map<String, Object>> st = ingestService.queryPublic(
            "SELECT out('HAS_STATE')[valid_to IS NULL].status_raw[0] AS st, "
            + "out('HAS_STATE')[valid_to IS NULL].valid_from[0] AS since "
            + "FROM KnowSprint WHERE sprint_id=:s LIMIT 1", Map.of("s", sprintId));
        if (st.isEmpty()) return null;   // «спринт не найден» решают существующие проверки
        Object raw = st.get(0).get("st");
        return closedSprintRefusal(sprintId, raw == null ? null : String.valueOf(raw), st.get(0).get("since"));
    }

    @POST
    @Path("task/move")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response moveTask(TaskMoveRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.task_uid() == null || req.task_uid().isBlank()
                || req.target_sprint_id() == null || req.target_sprint_id().isBlank())
            return badParams("task_uid and target_sprint_id required");
        if (!SAFE_ID.matcher(req.target_sprint_id()).matches()
                || (req.new_task_id() != null && !req.new_task_id().isBlank()
                    && !SAFE_ID.matcher(req.new_task_id()).matches()))
            return badParams("target_sprint_id / new_task_id contain illegal characters");
        final String oldUid = req.task_uid();
        final String targetSid = req.target_sprint_id();
        final String now = Instant.now().toString();
        final String nsid = UUID.randomUUID().toString();   // new task's PLANNED hist
        final String cnsid = UUID.randomUUID().toString();  // source's CANCELLED hist
        final ChangeAuthor by = changeAuthor();             // S2-12: автор обеих версий
        try {
            List<Map<String, Object>> src = ingestService.queryPublic(
                "SELECT task_id, title, task_type, " +
                "out('HAS_STATE')[note_md IS NOT NULL].note_md[0]         AS note_md, " +
                "out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0] AS effort_days, " +
                "out('TAGGED_WITH').component_id AS components, " +
                // MT-TASK-MV-HISTORY: статус ОТКРЫТОЙ строки истории переезжает вместе с задачей
                "out('HAS_STATE')[valid_to IS NULL].status_raw[0] AS status_raw " +
                "FROM KnowTask WHERE task_uid=:u LIMIT 1", Map.of("u", oldUid));
            if (src.isEmpty()) return badParams("task not found: " + oldUid);
            if (ingestService.queryPublic("SELECT sprint_id FROM KnowSprint WHERE sprint_id=:s LIMIT 1",
                    Map.of("s", targetSid)).isEmpty())
                return badParams("target sprint not found: " + targetSid);
            String closedMv = closedSprintRefusalFor(targetSid);
            if (closedMv != null) return badParams(closedMv);
            String fullMv = fullSprintRefusalFor(targetSid);
            if (fullMv != null) return badParams(fullMv);
            Map<String, Object> s = src.get(0);
            String title    = (String) s.get("title");
            String note     = (String) s.get("note_md");
            Object effort   = s.get("effort_days");
            // ADR-LORE-013 amendment: task_type (T00) is a plain vertex field — carried like title.
            // PU-17: роли — НЕ строки вершины (после TR-05 они пусты), а рёбра ROLE_HELD_BY;
            // их переносит roleService.copyOpenRoles после создания новой задачи.
            String taskType = (String) s.get("task_type");
            List<?> comps = s.get("components") instanceof List<?> l ? l : List.of();
            final String carriedStatus = carriedStatus(s.get("status_raw"));

            // Resolve a collision-free task_id in the target sprint.
            String wantTid = (req.new_task_id() != null && !req.new_task_id().isBlank())
                ? req.new_task_id() : (String) s.get("task_id");
            String tid = wantTid;
            for (int k = 2; taskExists(targetSid + "/" + tid); k++) tid = wantTid + "_" + k;
            final String newUid = targetSid + "/" + tid;

            String prefix = targetSid + "/";
            List<Map<String, Object>> mx = ingestService.queryPublic(
                "SELECT max(order_index) AS mx FROM KnowTask WHERE task_uid.substring(0, :plen) = :prefix",
                Map.of("prefix", prefix, "plen", prefix.length()));
            int order = (!mx.isEmpty() && mx.get(0).get("mx") instanceof Number n ? n.intValue() : 0) + 1;

            // Create the new task (mirrors createTask's atomic sqlscript).
            StringBuilder script = new StringBuilder()
                .append("INSERT INTO KnowTask SET task_uid=:uid, task_id=:tid, title=:title, note_md=:note, order_index=:oi, src='manual', ")
                .append("task_type=:tt;")
                .append("CREATE EDGE PART_OF FROM (SELECT FROM KnowTask WHERE task_uid=:uid) TO (SELECT FROM KnowSprint WHERE sprint_id=:sid);")
                .append("INSERT INTO KnowTaskHist SET state_uid=:nsid, status_raw=:st, valid_from=:now, note_md=:note")
                .append(effort != null ? ", effort_days=:eff" : "")
                .append(ChangeAuthor.SET_SQL).append(";")
                .append("CREATE EDGE HAS_STATE FROM (SELECT FROM KnowTask WHERE task_uid=:uid) TO (SELECT FROM KnowTaskHist WHERE state_uid = :nsid AND in('HAS_STATE').size() = 0);");
            Map<String, Object> p = mapOfNullable("uid", newUid, "tid", tid, "title", title,
                "note", note, "oi", order, "sid", targetSid, "nsid", nsid, "now", now,
                "tt", taskType, "st", carriedStatus);
            if (effort != null) p.put("eff", effort);
            by.bind(p);
            for (Object c : comps) {
                if (c == null) continue;
                script.append(String.format(
                    "CREATE EDGE TAGGED_WITH FROM (SELECT FROM KnowTask WHERE task_uid='%s') TO (SELECT FROM LoreComponent WHERE component_id='%s');",
                    newUid, c));
            }
            writeClient.command(db, basicAuth(),
                new LoreCommandClient.LoreCommand("sqlscript", script.toString(), p)).await().indefinitely();
            // PU-17: роли переезжают рёбрами — до отмены источника, чтобы сбой не оставил задачу без ролей молча.
            final int rolesMoved = roleService.copyOpenRoles(oldUid, newUid);

            // Cancel the source — reuse the /lore/status flip + #88 note carry-forward.
            Map<String, Object> carry = statusResource.readTaskHistCarryFields(oldUid).await().indefinitely();
            var resp = statusResource.updateScd2Status("task", "KnowTask", "KnowTaskHist", "task_uid",
                oldUid, "cancelled", now, cnsid, by).await().indefinitely();
            if (resp.getStatus() < 300) {
                statusResource.restoreTaskHistFields(cnsid, (String) carry.get("note_md"),
                    carry.get("effort_days") == null ? null : ((Number) carry.get("effort_days")).doubleValue())
                    .await().indefinitely();
            } else {
                LOG.warnf("[LORE TASK MOVE] %s created as %s but source cancel returned %d",
                    oldUid, newUid, resp.getStatus());
            }
            boolean tidChanged = !tid.equals(s.get("task_id"));
            return noStore(Response.ok(Map.of("ok", true,
                "old_task_uid", oldUid, "new_task_uid", newUid,
                "task_id_changed", tidChanged, "new_task_id", tid, "status", carriedStatus,
                "roles_moved", rolesMoved)));
        } catch (Exception e) {
            LOG.warnf("[LORE TASK MOVE] %s → %s: %s", oldUid, targetSid, e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    private boolean taskExists(String taskUid) {
        return !ingestService.queryPublic(
            "SELECT task_uid FROM KnowTask WHERE task_uid=:u LIMIT 1", Map.of("u", taskUid)).isEmpty();
    }

    // ── Write-path: sprint phases (MCP-PHASES, SPRINT_LORE_MCP_GAPS_2) ────────
    // Read side already exists (phases_of_sprint / tasks_of_phase, LoreSlices): KnowPhase
    // { phase_uid = "<sprint>/PHASE_<KEY>", phase_id = "Фаза <KEY>", order_index }
    // + PART_OF → KnowSprint + HAS_STATE → KnowPhaseHist; task → phase via IN_PHASE.

    @POST
    @Path("phase")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Uni<Response> createPhase(PhaseCreateRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return Uni.createFrom().item(disabled());
        requireAdmin(role);
        if (req == null || req.sprint_id() == null || req.phase_key() == null || req.phase_key().isBlank()) {
            return Uni.createFrom().item(badParams("sprint_id, phase_key required"));
        }
        final ChangeAuthor by = changeAuthor(); // S2-12: снят до асинхронной цепочки
        final String key = req.phase_key().trim().toUpperCase();
        if (!SAFE_ID.matcher(req.sprint_id()).matches()
                || !key.matches("[A-Z0-9_\\-]{1,20}")) {
            return Uni.createFrom().item(badParams(
                "sprint_id / phase_key contain illegal characters (key: A-Z, 0-9, _, -)"));
        }
        final String sid     = req.sprint_id();
        final String uid     = sid + "/PHASE_" + key;
        final String display = "Фаза " + key;
        final String name    = req.name();
        final String summary = req.summary_md();
        final String now     = Instant.now().toString();
        final String nsid    = UUID.randomUUID().toString();

        MartQuery existingQ = new MartQuery("sql",
            "SELECT phase_uid, order_index FROM KnowPhase WHERE phase_uid = :uid LIMIT 1",
            Map.of("uid", uid), -1);

        return client.query(db, basicAuth(), existingQ)
            .chain(res -> {
                List<Map<String, Object>> rows = res.result() != null ? res.result() : List.of();
                if (!rows.isEmpty()) {   // idempotent: phase already registered
                    Object oi = rows.get(0).get("order_index");
                    Integer oiv = oi instanceof Number n ? n.intValue() : null;
                    return Uni.createFrom().item(noStore(Response.ok(new PhaseWriteResponse(
                        true, uid, display, oiv, false,
                        WorkQuality.evaluatePhase(name, summary, oiv)))));
                }
                MartQuery sprintQ = new MartQuery("sql",
                    "SELECT sprint_id FROM KnowSprint WHERE sprint_id = :sid LIMIT 1",
                    Map.of("sid", sid), -1);
                return client.query(db, basicAuth(), sprintQ).chain(sres -> {
                    if (sres.result() == null || sres.result().isEmpty()) {
                        return Uni.createFrom().item(badParams("sprint not found: " + sid));
                    }
                    // order_index: explicit or max+1 among this sprint's phases (substring, not LIKE —
                    // same '_'-wildcard pitfall as createTask)
                    String prefix = sid + "/";
                    MartQuery maxQ = new MartQuery("sql",
                        "SELECT max(order_index) AS mx FROM KnowPhase WHERE phase_uid.substring(0, :plen) = :prefix",
                        Map.of("prefix", prefix, "plen", prefix.length()), -1);
                    return client.query(db, basicAuth(), maxQ).chain(mres -> {
                        List<Map<String, Object>> mrows = mres.result() != null ? mres.result() : List.of();
                        Object mxRaw = mrows.isEmpty() ? null : mrows.get(0).get("mx");
                        final int order = req.order_index() != null ? req.order_index()
                            : (mxRaw instanceof Number n ? n.intValue() : 0) + 1;
                        // A1: atomic sqlscript — a partial failure leaves no KnowPhase
                        // without its PART_OF/HAS_STATE edges.
                        String script =
                            "INSERT INTO KnowPhase SET phase_uid = :uid, phase_id = :pid, " + ModelSchemaAdapter.titleSet("name") + ", " +
                            "summary_md = :summary, order_index = :oi, src = 'manual';" +
                            "CREATE EDGE PART_OF FROM (SELECT FROM KnowPhase WHERE phase_uid = :uid) " +
                            "TO (SELECT FROM KnowSprint WHERE sprint_id = :sid);" +
                            "INSERT INTO KnowPhaseHist SET state_uid = :nsid, status_raw = '" + CreateDefaultStatus.phaseRaw() + "', " + // первый статус (16.11.2026)
                            "valid_from = :now" + ChangeAuthor.SET_SQL + ";" +
                            "CREATE EDGE HAS_STATE FROM (SELECT FROM KnowPhase WHERE phase_uid = :uid) " +
                            "TO (SELECT FROM KnowPhaseHist WHERE state_uid = :nsid AND in('HAS_STATE').size() = 0);";
                        Map<String, Object> p = mapOfNullable("uid", uid, "pid", display, "name", name,
                            "summary", summary, "oi", order, "sid", sid, "nsid", nsid, "now", now);
                        by.bind(p);
                        return writeClient.command(db, basicAuth(),
                                new LoreCommandClient.LoreCommand("sqlscript", script, p))
                            .map(__ -> noStore(Response.ok(new PhaseWriteResponse(true, uid, display, order, true,
                                WorkQuality.evaluatePhase(name, summary, order)))));
                    });
                });
            })
            .onFailure().recoverWithItem(ex -> {
                LOG.warnf("[LORE PHASE CREATE] %s: %s", uid, ex.getMessage());
                return noStore(Response.status(Response.Status.BAD_GATEWAY)
                    .entity(LoreUpstream.error(ex)));
            });
    }

    @POST
    @Path("task/phase")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkTaskPhase(TaskPhaseRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.task_uid() == null)
            return badParams("task_uid required");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        if (req.phase_uid() == null && !remove)
            return badParams("phase_uid required for action=add (omit only with action=remove to detach all)");
        if (!SAFE_ID.matcher(req.task_uid()).matches()
                || (req.phase_uid() != null && !SAFE_ID.matcher(req.phase_uid()).matches()))
            return badParams("ids contain illegal characters");
        try {
            if (ingestService.queryPublic(
                    "SELECT task_uid FROM KnowTask WHERE task_uid=:t LIMIT 1",
                    Map.of("t", req.task_uid())).isEmpty())
                return badParams("task not found: " + req.task_uid());
            if (req.phase_uid() != null && ingestService.queryPublic(
                    "SELECT phase_uid FROM KnowPhase WHERE phase_uid=:p LIMIT 1",
                    Map.of("p", req.phase_uid())).isEmpty())
                return badParams("phase not found: " + req.phase_uid());
            // task and phase must share the sprint prefix ("SPRINT_X/…")
            if (req.phase_uid() != null) {
                String taskSprint  = req.task_uid().substring(0, Math.max(0, req.task_uid().indexOf('/')));
                String phaseSprint = req.phase_uid().substring(0, Math.max(0, req.phase_uid().indexOf('/')));
                if (!taskSprint.equals(phaseSprint))
                    return badParams("task and phase belong to different sprints: "
                        + taskSprint + " vs " + phaseSprint);
            }
            if (remove) {
                String where = req.phase_uid() != null
                    ? "@out.task_uid=:t AND @in.phase_uid=:p"
                    : "@out.task_uid=:t";
                Map<String, Object> params = req.phase_uid() != null
                    ? Map.of("t", req.task_uid(), "p", req.phase_uid())
                    : Map.of("t", req.task_uid());
                // MDL-02: IN_PHASE историчная — снятие закрывает ребро (valid_to), а не стирает его.
                deleteEdges("IN_PHASE", where, params);
            } else {
                List<Map<String, Object>> existing = ingestService.queryPublic(
                    "SELECT @rid FROM IN_PHASE WHERE @out.task_uid=:t AND @in.phase_uid=:p AND valid_to IS NULL",
                    Map.of("t", req.task_uid(), "p", req.phase_uid()));
                if (existing.isEmpty()) {
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        String.format(
                            "CREATE EDGE IN_PHASE FROM (SELECT FROM KnowTask WHERE task_uid='%s') " +
                            "TO (SELECT FROM KnowPhase WHERE phase_uid='%s') SET valid_from = '%s'",
                            req.task_uid(), req.phase_uid(), Instant.now()),
                        null)).await().indefinitely();
                }
            }
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true);
            out.put("task_uid", req.task_uid());
            out.put("phase_uid", req.phase_uid());
            out.put("action", remove ? "removed" : "added");
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE TASK PHASE] %s / %s: %s", req.task_uid(), req.phase_uid(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    @POST
    @Path("task/edit/batch")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editTaskBatch(List<TaskEditRequest> reqs, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (reqs == null || reqs.isEmpty()) return badParams("tasks array required");
        int updated = 0;
        List<String> errors = new java.util.ArrayList<>();
        Map<String, Object> mentions = new LinkedHashMap<>();
        final ChangeAuthor batchAuthor = changeAuthor();
        for (TaskEditRequest req : reqs) {
            if (req == null || req.task_uid() == null || req.title() == null || req.title().isBlank()) {
                errors.add("skipped (missing task_uid or title): " + req); continue;
            }
            if (!SAFE_ID.matcher(req.task_uid()).matches()) {
                errors.add("skipped (illegal task_uid): " + req.task_uid()); continue;
            }
            if (req.actual_days() != null && (req.actual_days().isNaN() || req.actual_days() < 0)) {
                errors.add("skipped (actual_days must be non-negative): " + req.task_uid()); continue;
            }
            String appendRefusal = appendConflict("note_md", req.note_md(), "note_append", req.note_append());
            if (appendRefusal != null) { errors.add("skipped (" + req.task_uid() + "): " + appendRefusal); continue; }
            if (req.expected() != null && !req.expected().isEmpty()) {
                // S2-09: «было» не совпало — пункт пропускается с CONFLICT, остальные идут.
                Response c = taskExpectedConflict(req.task_uid(), req.expected());
                if (c != null) {
                    errors.add("skipped (CONFLICT): " + ((Map<?, ?>) c.getEntity()).get("detail"));
                    continue;
                }
            }
            {
                // Дописка тоже пишет заметку — открытая строка истории нужна и ей.
                String noteProbe = req.note_md() != null ? req.note_md() : req.note_append();
                Integer open = (noteProbe != null || req.effort_days() != null)
                    ? openStateRows(req.task_uid(), noteProbe, req.effort_days()).await().indefinitely() : 1;
                String refusal = noOpenStateRefusal(req.task_uid(), noteProbe, req.effort_days(), open);
                if (refusal != null) { errors.add("skipped (NO_OPEN_STATE): " + refusal); continue; }
            }
            try {
                // MT-NOTE-APPEND: дописка читает текущую заметку (открытая строка истории,
                // иначе вершина) и пишет склейку — вызывающему не нужно передавать всё поле.
                String note = req.note_append() != null
                    ? appendText(currentTaskNote(req.task_uid()), req.note_append())
                    : req.note_md();
                // MT-MCP-TRUTH Б11: пункт с несуществующей задачей — ошибка пункта, а не «updated»
                if (WriteCount.missed(writeClient.command(db, basicAuth(),
                    taskVertexUpdate(req.task_uid(), req.title(), note, req.effort_days(), req.actual_days(), req.bookkeeping(),
                        req.author_agent(), req.executor_agent(), req.reviewer_agent(), req.task_type(), req.work_class()))
                    .await().indefinitely())) {
                    errors.add("skipped (NOT_FOUND): задача " + req.task_uid() + " не найдена — ни одна строка не изменена");
                    continue;
                }
                writeTaskHist(req.task_uid(), note, req.effort_days(), batchAuthor);
                if (note != null)
                    hashStamper.stampOpenHist("KnowTaskHist", "KnowTask", "task_uid", req.task_uid());
                relinkRealizes(req.task_uid(), req.uc_id());
                // Роли ребром и в пакетной правке: иначе пакет молча терял бы то,
                // что одиночная правка записывает.
                applyRoles(req.task_uid(), req.author_agent(), req.executor_agent(), req.reviewer_agent());
                updated++;
            } catch (Exception e) {
                errors.add(req.task_uid() + ": " + e.getMessage());
                continue;
            }
            // MD-AUTOLINK: после записи и вне её try — сбой автосвязи не делает пункт ошибкой.
            String mentionText = taskNoteMentionText(req.note_md(), req.note_append());
            if (mentionText != null) mentions.put(req.task_uid(), taskMentions(req.task_uid(), mentionText));
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("ok", errors.isEmpty()); out.put("updated", updated);
        if (!errors.isEmpty()) out.put("errors", errors);
        // Пакет: блок mentions — по task_uid, у каждого {added, unchanged, skipped}.
        if (!mentions.isEmpty()) out.put("mentions", mentions);
        return noStore(Response.ok(out));
    }

    /**
     * PL-14 (D16): переподвесить REALIZES задачи на указанный сценарий.
     *
     * Ребро одно: задача реализует один сценарий. Поэтому сначала снимаются все
     * существующие исходящие REALIZES, потом создаётся новое — иначе правка
     * «перепривязать к другому UC» оставила бы задачу висеть на обоих сразу, и
     * вычислитель готовности посчитал бы её дважды.
     *
     * `uc_id == null` — «не трогать» (частичная правка), а не «отвязать»:
     * task_set вызывается с одним-двумя полями, и null там означает отсутствие
     * намерения. Явная отвязка — пустая строка.
     */
    private Uni<Object> relinkRealizesUni(String uid, String ucId) {
        if (ucId == null) return Uni.createFrom().item(new Object());
        // DELETE EDGE в ArcadeDB 26.7.2 отсутствует в грамматике целиком
        // (перепроверено 2026-07-21) — снимаем через expand(outE) + DELETE FROM.
        Uni<?> drop = writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
            "DELETE FROM (SELECT expand(outE('REALIZES')) FROM KnowTask WHERE task_uid=:u)",
            Map.of("u", uid)));
        if (ucId.isBlank()) return drop.map(__ -> new Object());
        return drop.chain(__ -> writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "CREATE EDGE REALIZES FROM (SELECT FROM KnowTask WHERE task_uid=:u) " +
                "TO (SELECT FROM KnowUseCase WHERE uc_id=:c) IF NOT EXISTS",
                Map.of("u", uid, "c", ucId))))
            .map(__ -> new Object());
    }

    /** Блокирующий вариант для batch-пути: там метод и так не реактивный. */
    private void relinkRealizes(String uid, String ucId) {
        if (ucId == null) return;
        relinkRealizesUni(uid, ucId).await().indefinitely();
    }

    /**
     * MT-MCP-TRUTH Б6 (06.11.2026): замер прода — у 24 задач нет открытой строки
     * истории (единственная закрыта). task_set с note_md/effort_days писал вершину,
     * зеркало в историю не находило строку, ответ был ok:true, а срезы, читающие
     * открытую строку, правку не показывали. Правка полей вершины (title, тип,
     * класс) открытой строки не требует. null — писать можно.
     */
    static String noOpenStateRefusal(String uid, String noteMd, Double effortDays, int openRows) {
        if (noteMd == null && effortDays == null) return null;
        if (openRows > 0) return null;
        return "у задачи " + uid + " нет открытой строки истории: note_md/effort_days легли бы только на "
            + "вершину, а срезы читают их из истории — правка была бы невидима при ok:true. "
            + "Сначала status_set (откроет строку текущим статусом), затем повтори task_set.";
    }

    /** Число открытых строк истории задачи; спрашивается только если правке нужна история. */
    private Uni<Integer> openStateRows(String uid, String noteMd, Double effortDays) {
        if (noteMd == null && effortDays == null) return Uni.createFrom().item(1);
        return writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "SELECT out('HAS_STATE')[valid_to IS NULL].size() AS n FROM KnowTask WHERE task_uid = :u",
                Map.of("u", uid)))
            .map(r -> r.result() instanceof java.util.List<?> rows && !rows.isEmpty()
                    && rows.get(0) instanceof Map<?, ?> m && m.get("n") instanceof Number n ? n.intValue() : 1);
    }

    /**
     * Dynamic vertex update for task edits — LH-44: only SET fields actually supplied,
     * so a title-only edit never wipes note_md/effort_days denormalised on the vertex
     * (the UI reads the hist row, but the vertex copy must stay consistent too).
     */
    static LoreCommandClient.LoreCommand taskVertexUpdate(
            String uid, String title, String noteMd, Double effortDays, Double actualDays, Boolean bookkeeping,
            String authorAgent, String executorAgent, String reviewerAgent, String taskType,
            String workClass) {
        StringBuilder sql = new StringBuilder("UPDATE KnowTask SET title = :title");
        Map<String, Object> p = new java.util.HashMap<>();
        p.put("uid", uid);
        p.put("title", title.trim());
        if (noteMd != null)     { sql.append(", note_md = :note");     p.put("note", noteMd); }
        if (effortDays != null) { sql.append(", effort_days = :eff");  p.put("eff", effortDays); }
        // MT-CAL-ACTUAL: факт — только на вершине (как work_class), без Hist: он не
        // версионируется, и carry-forward при смене статуса его не касается.
        if (actualDays != null) { sql.append(", actual_days = :act");  p.put("act", actualDays); }
        // MT-CAL-BOOKKEEPING: «запись задним числом» — вершина, null = не трогать, false снимает.
        if (bookkeeping != null) { sql.append(", bookkeeping = :bk");  p.put("bk", bookkeeping); }
        // author/executor/reviewer_agent (ADR-LORE-014 §4) and task_type (ADR-LORE-015,
        // T14) — vertex fields, only touched when supplied so a title-only edit never
        // wipes an existing owner/type.
        // Роли БОЛЬШЕ НЕ ПОЛЯ (TR-05). Записываются ребром ROLE_HELD_BY через
        // TaskRoleService — там же, где живут правила: кандидаты из графа, смена
        // закрывает прежнее ребро, вердикт только у ревьюера. Писать их здесь
        // значило бы завести вторую точку записи с другими правилами.
        // work_class (ADR-LORE-022): вторая ось, vertex-only; трогаем только когда передана.
        if (workClass != null)     { sql.append(", work_class = :wc");           p.put("wc", workClass); }
        if (taskType      != null) { sql.append(", task_type = :tt");            p.put("tt", taskType); }
        // S4-04 (свежесть, вопрос №49): правка на месте (заметка, название, поля вершины)
        // версию SCD2 не открывает — её момент живёт отметкой на вершине; changed_at
        // срезов берёт максимум из открытой версии и updated_at (LoreChangedAt).
        sql.append(", updated_at = :upd");
        p.put("upd", java.time.Instant.now().toString());
        sql.append(" WHERE task_uid = :uid");
        return new LoreCommandClient.LoreCommand("sql", sql.toString(), p);
    }

    /**
     * Mirror note_md / effort_days onto a task's OPEN history row (KnowTaskHist,
     * valid_to IS NULL) — the row the tasks_of_sprint / tasks_of_phase slices read.
     * Only fields actually supplied (non-null) are written, so a title-only edit
     * never wipes an existing note or effort. No-op (passthrough) when both are null.
     */
    private Uni<LoreCommandClient.LoreCommandResult> mirrorTaskHist(
            String uid, String noteMd, Double effortDays) {
        StringBuilder set = new StringBuilder();
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("uid", uid);
        if (noteMd != null)     { set.append("note_md = :note, ");     p.put("note", noteMd); }
        if (effortDays != null) { set.append("effort_days = :eff, ");  p.put("eff", effortDays); }
        if (set.length() == 0) return Uni.createFrom().item(new LoreCommandClient.LoreCommandResult(null));
        return writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
            "UPDATE KnowTaskHist SET " + set.substring(0, set.length() - 2) +
            " WHERE in('HAS_STATE').task_uid CONTAINS :uid AND valid_to IS NULL", p));
    }

    /**
     * MT-NOTE-APPEND п.3 (вариант А, D-2026-NOTE-APPEND-IS-WORTH-FIXING): заметка в историю.
     * Изменилась — НОВАЯ версия SCD2 (копия открытой строки с новым текстом, статус тот же),
     * чтобы прежний текст остался в истории и правку можно было откатить. Тот же текст или нет
     * открытой версии — прежнее зеркало на месте (оно же пишет effort_days без заметки).
     * Блокирующий — только с рабочего пула. Соседняя запись закрыла версию — 409.
     */
    private void writeTaskHist(String uid, String note, Double effortDays, ChangeAuthor author) {
        if (note != null) {
            Map<String, Object> texts = new LinkedHashMap<>();
            texts.put("note_md", note);
            if (effortDays != null) texts.put("effort_days", effortDays);
            StatusHistoryService.Outcome o = StatusHistoryService.textVersion(statusDb(), "task", uid, texts, author);
            if (o instanceof StatusHistoryService.Outcome.Conflict c)
                throw new Scd2Guard.ConflictException(c.detail(), c.current());
            if (o instanceof StatusHistoryService.Outcome.Ok) return;
        }
        // MT-MCP-TRUTH Б11: открытой строки нет (её закрыли между пробой и записью) — правка истории не легла
        if (WriteCount.missed(mirrorTaskHist(uid, note, effortDays).await().indefinitely()))
            throw new WriteCount.MissedException(WriteCount.conflict("NO_OPEN_STATE", "task", uid,
                "у задачи " + uid + " нет открытой строки истории: note_md/effort_days легли только на вершину, "
                    + "срезы их не покажут. Сначала status_set (откроет строку), затем повтори task_set."));
    }

    @POST
    @Path("task/edit")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Uni<Response> editTask(TaskEditRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return Uni.createFrom().item(disabled());
        requireAdmin(role);
        if (req == null || req.task_uid() == null
                || req.title() == null || req.title().isBlank()) {
            return Uni.createFrom().item(badParams("task_uid and title required"));
        }
        if (!SAFE_ID.matcher(req.task_uid()).matches()) {
            return Uni.createFrom().item(badParams("task_uid contains illegal characters"));
        }
        if (req.actual_days() != null && (req.actual_days().isNaN() || req.actual_days() < 0)) {
            return Uni.createFrom().item(badParams("actual_days must be a non-negative number of person-days"));
        }
        final String uid = req.task_uid();
        // S2-12: автор версии (правка текста открывает версию) — из токена, до асинхронной цепочки.
        final ChangeAuthor author = changeAuthor();
        String appendRefusal = appendConflict("note_md", req.note_md(), "note_append", req.note_append());
        if (appendRefusal != null) return Uni.createFrom().item(badParams(appendRefusal));
        // MT-NOTE-APPEND: текущая заметка читается, если её трогают — и для дописки,
        // и чтобы вернуть прежнее значение в ответе (п.2: до того, как оно исчезнет).
        final boolean touchesNote = req.note_md() != null || req.note_append() != null;
        final String[] previous = new String[1];
        final String[] note = new String[1];
        // MT-MCP-TRUTH Б6: заметка/оценка обязаны лечь в ОТКРЫТУЮ строку истории;
        // её нет — отказ до записи, а не ok:true при невидимой правке. Дописка — тоже запись заметки.
        final String noteProbe = req.note_md() != null ? req.note_md() : req.note_append();
        // S2-09: «было» (expected) названо и не совпало с текущим — 409 до любой записи.
        // ADR-LORE-047 A3: expected_version — та же проверка «до записи», по версии записи.
        final boolean checksExpected = req.expected() != null && !req.expected().isEmpty();
        final boolean checksVersion = req.expected_version() != null && !req.expected_version().isBlank();
        Uni<Response> pre = (!checksExpected && !checksVersion)
            ? Uni.createFrom().nullItem()
            : Uni.createFrom().item(() -> {
                    Response v = checksVersion ? versionConflict("task", uid, req.expected_version()) : null;
                    return v != null ? v : checksExpected ? taskExpectedConflict(uid, req.expected()) : null;
                })
                .runSubscriptionOn(io.smallrye.mutiny.infrastructure.Infrastructure.getDefaultWorkerPool());
        return pre.chain(conflict -> conflict != null ? Uni.createFrom().item(conflict) :
            openStateRows(uid, noteProbe, req.effort_days()).chain(openRows -> {
        String refusal = noOpenStateRefusal(uid, noteProbe, req.effort_days(), openRows);
        if (refusal != null) return Uni.createFrom().item(noStore(Response.status(Response.Status.CONFLICT)
            .entity(new LoreError("NO_OPEN_STATE", refusal))));
        return Uni.createFrom().item(() -> {
                if (touchesNote) previous[0] = currentTaskNote(uid);
                note[0] = req.note_append() != null ? appendText(previous[0], req.note_append()) : req.note_md();
                return Boolean.TRUE;
            })
            .runSubscriptionOn(io.smallrye.mutiny.infrastructure.Infrastructure.getDefaultWorkerPool())
            .chain(__ -> writeClient.command(db, basicAuth(),
                taskVertexUpdate(uid, req.title(), note[0], req.effort_days(), req.actual_days(), req.bookkeeping(),
                    req.author_agent(), req.executor_agent(), req.reviewer_agent(), req.task_type(), req.work_class()))
                // MT-MCP-TRUTH Б11: правка несуществующей задачи — 404, а не ok:true (UPDATE задел 0 строк)
                .map(r -> WriteCount.requireHit(r, "task", uid, "правка задачи (task_set)")))
            // The vertex note_md/effort_days above are denormalisations the UI never reads.
            // tasks_of_sprint / tasks_of_phase read BOTH from the open KnowTaskHist row
            // (out('HAS_STATE')[…][0]); mirror the write there too — only for fields that
            // were actually supplied, so a title-only edit never wipes note/effort.
            // MT-NOTE-APPEND п.3: изменённая заметка — новая версия SCD2 (writeTaskHist).
            .chain(__ -> Uni.createFrom().item(() -> { writeTaskHist(uid, note[0], req.effort_days(), author); return Boolean.TRUE; })
                .runSubscriptionOn(io.smallrye.mutiny.infrastructure.Infrastructure.getDefaultWorkerPool()))
            // Переподвес REALIZES идёт ЦЕПОЧКОЙ, а не блокирующим вызовом внутри
            // map: этот путь реактивный, и await на IO-потоке даёт 502.
            .chain(__ -> relinkRealizesUni(uid, req.uc_id()))
            // Запись хеша БЛОКИРУЮЩАЯ, а колбэк map исполняется на том потоке,
            // который отдал элемент, то есть на event loop. Комментарий выше
            // фиксирует ровно этот урок для REALIZES; к хешу его не применили,
            // и `stampOpenHist` падал с «current thread cannot be blocked»,
            // а собственный catch гасил ошибку. Итог: content_hash не
            // записывался, а на нём стоит обнаружение дрейфа в reconcile.
            // Приём тот же, что в LoreStatusResource: уйти на рабочий пул.
            .chain(__ -> Uni.createFrom().item(() -> {
                    if (note[0] != null)
                        hashStamper.stampOpenHist("KnowTaskHist", "KnowTask", "task_uid", uid);
                    Map<String, Object> body = new LinkedHashMap<>();
                    body.put("ok", true);
                    body.put("task_uid", uid);
                    // MT-NOTE-APPEND п.2: прежняя заметка — в ответ; null = её не было.
                    if (touchesNote) {
                        Map<String, Object> prev = new LinkedHashMap<>();
                        prev.put("note_md", previous[0]);
                        body.put("previous", prev);
                        if (req.note_append() != null) body.put("note_mode", "appended");
                    }
                    body.put("quality", WorkQuality.compact(taskQuality(uid)));
                    // Роли — ребром, исход по каждой в ответе (TR-05).
                    Map<String, Object> roles = applyRoles(uid,
                        req.author_agent(), req.executor_agent(), req.reviewer_agent());
                    if (!roles.isEmpty()) body.put("roles", roles);
                    // MD-AUTOLINK: для note_append разбирается только дописанное.
                    String mentionText = taskNoteMentionText(req.note_md(), req.note_append());
                    if (mentionText != null) body.put("mentions", taskMentions(uid, mentionText));
                    return noStore(Response.ok(body));
                })
                .runSubscriptionOn(io.smallrye.mutiny.infrastructure.Infrastructure.getDefaultWorkerPool()))
            .onFailure().recoverWithItem(ex -> {
                LOG.warnf("[LORE TASK EDIT] %s: %s", uid, ex.getMessage());
                if (ex instanceof WriteCount.MissedException me) return me.response();
                if (ex instanceof Scd2Guard.ConflictException ce) return ce.response();
                if (Scd2Guard.isConcurrentModification(ex))
                    return Scd2Guard.conflict("task '" + uid + "': concurrent write to the same version — re-read and retry", Map.of());
                return noStore(Response.status(Response.Status.BAD_GATEWAY)
                    .entity(LoreUpstream.error(ex)));
            });
        }));
    }

    // ── Write-path: append PR numbers to open KnowSprintHist.pr_refs ───────────

    @POST
    @Path("sprint/refs")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateSprintRefs(SprintRefsRequest req,
                                     @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.sprint_id() == null || req.sprint_id().isBlank())
            return badParams("sprint_id required");
        if (!SAFE_ID.matcher(req.sprint_id()).matches())
            return badParams("sprint_id contains illegal characters");
        if (req.pr_numbers() == null || req.pr_numbers().isEmpty())
            return badParams("pr_numbers required");

        // RM-P7: репозиторий НАСЛЕДУЕТСЯ от спринта, а не подставляется монорепо.
        //
        // Здесь из него собирается адрес PR, и молчаливое «NooriUta/AIDA» давало
        // ссылку в чужой репозиторий: она открывается, ведёт на существующий PR с
        // тем же номером и потому не выглядит ошибкой. Спринт свой репозиторий
        // знает — спрашивать его правильнее, чем угадывать.
        //
        // Ноль или несколько проектов у спринта — отказ, а не выбор первого:
        // «у спринта два репозитория» и «у спринта один» это разные положения,
        // и брать [0] значило бы решать за вызывающего молча.
        String gp = (req.git_project() != null && !req.git_project().isBlank())
            ? req.git_project().trim() : sprintProject(req.sprint_id());
        if (gp == null && (req.repo_url() == null || req.repo_url().isBlank()))
            return badParams("git_project required: у спринта " + req.sprint_id()
                + " не ровно один репозиторий, а из него собирается адрес PR. "
                + "Передайте git_project или repo_url явно — умолчание на монорепозиторий снято (RM-P7).");
        String base = (req.repo_url() != null && !req.repo_url().isBlank())
            ? req.repo_url().replaceAll("/+$", "")
            : "https://github.com/" + gp + "/pull";

        try {
            // Read current pr_refs from the open hist row.
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> rows = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "SELECT @rid, pr_refs FROM KnowSprintHist " +
                    "WHERE in('HAS_STATE').sprint_id CONTAINS :sid AND valid_to IS NULL",
                    Map.of("sid", req.sprint_id()))).await().indefinitely().result();

            if (rows == null || rows.isEmpty())
                return noStore(Response.status(Response.Status.NOT_FOUND)
                    .entity(new LoreError("NOT_FOUND", "no open hist row for sprint: " + req.sprint_id())));

            // pr_refs is a markdown string; build the new entries and append —
            // unless replace=true, which discards whatever was there before
            // (for fixing a wrong git_project/repo_url baked into earlier
            // entries, since there's no per-entry edit otherwise).
            boolean replace = Boolean.TRUE.equals(req.replace());
            String existing = "";
            if (!replace) {
                Object raw = rows.get(0).get("pr_refs");
                if (raw != null) existing = raw.toString().trim();
            }
            String rid = rows.get(0).get("@rid").toString();

            StringBuilder sb = new StringBuilder(existing);
            int added = 0;
            for (Integer n : req.pr_numbers()) {
                String link = "[#" + n + "](" + base + "/" + n + ")";
                if (!existing.contains(link)) {
                    if (!sb.isEmpty() && !sb.toString().endsWith(" ")) sb.append(" ");
                    sb.append(link);
                    added++;
                }
            }
            String updated = sb.toString().trim();
            // MT-MCP-TRUTH Б11: строку прочитали по @rid, но записать в неё не вышло (удалена между чтением и записью)
            if (WriteCount.missed(writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "UPDATE " + rid + " SET pr_refs = :refs",
                    Map.of("refs", updated))).await().indefinitely()))
                return WriteCount.conflict("STALE_VERSION", "sprint", req.sprint_id(),
                    "открытая строка истории спринта исчезла между чтением и записью — pr_refs не записаны; перечитайте и повторите");

            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true); out.put("sprint_id", req.sprint_id());
            out.put("added", added); out.put("pr_refs", updated);
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE SPRINT REFS] %s: %s", req.sprint_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    /**
     * MT-NOTE-APPEND п.4: context_md/outcome_md спринта — на ОТКРЫТУЮ строку истории, оба поля
     * целиком (то, что стало на вершине). Строку читают хэш (LoreHashStamper) и перенос тел при
     * смене статуса (LoreStatusResource.SPRINT_PLAN_FIELDS).
     */
    static LoreCommandClient.LoreCommand sprintHistMirror(String sprintId, String contextMd, String outcomeMd) {
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("sid", sprintId);
        p.put("ctx", contextMd);
        p.put("outcome", outcomeMd);
        return new LoreCommandClient.LoreCommand("sql",
            "UPDATE KnowSprintHist SET context_md = :ctx, outcome_md = :outcome"
            + " WHERE in('HAS_STATE').sprint_id CONTAINS :sid AND valid_to IS NULL", p);
    }

    // ── MT-NOTE-APPEND (06.11.2026): дописывание вместо перезаписи целиком ──
    //
    // note_md / context_md / outcome_md заменялись только целиком; прежней версии
    // нет нигде, опечатка при перезаписи необратима. Владелица: «все мучаются с
    // этим перезаписываниями». decision:D-2026-NOTE-APPEND-IS-WORTH-FIXING.

    /**
     * Текущая заметка задачи: открытая строка истории (её читают срезы), иначе вершина.
     * Блокирующий — вызывать только с рабочего пула.
     */
    private String currentTaskNote(String uid) {
        List<Map<String, Object>> rows = ingestService.queryPublic(
            "SELECT out('HAS_STATE')[valid_to IS NULL].note_md[0] AS hn, note_md AS vn FROM KnowTask WHERE task_uid=:u",
            Map.of("u", uid));
        if (rows.isEmpty()) return null;
        Object hn = rows.get(0).get("hn");
        Object vn = rows.get(0).get("vn");
        if (hn != null && !String.valueOf(hn).isBlank()) return String.valueOf(hn);
        return vn == null ? null : String.valueOf(vn);
    }

    /**
     * S2-09: сверка «было» (expected) с текущим состоянием задачи. Ключи: title,
     * note_md, effort_days, actual_days, status (+ любые поля вершины). Заметка и
     * оценка — с открытой строки истории (их читают срезы), иначе с вершины.
     * Возвращает 409 CONFLICT с текущим состоянием или null. Блокирующий — с рабочего пула.
     */
    Response taskExpectedConflict(String uid, Map<String, Object> expected) {
        List<Map<String, Object>> rows = ingestService.queryPublic(
            "SELECT title, note_md AS vn, effort_days AS ve, actual_days, task_type, work_class, " +
            "out('HAS_STATE')[valid_to IS NULL].note_md[0] AS hn, " +
            "out('HAS_STATE')[valid_to IS NULL].effort_days[0] AS he, " +
            "out('HAS_STATE')[valid_to IS NULL].status_raw[0] AS status_raw " +
            "FROM KnowTask WHERE task_uid=:u", Map.of("u", uid));
        if (rows.isEmpty()) return null; // неизвестная задача — пусть обычный путь скажет своё
        Map<String, Object> r = rows.get(0);
        Map<String, Object> cur = new LinkedHashMap<>();
        cur.put("title", r.get("title"));
        Object hn = r.get("hn");
        cur.put("note_md", hn != null && !String.valueOf(hn).isBlank() ? hn : r.get("vn"));
        cur.put("effort_days", r.get("he") != null ? r.get("he") : r.get("ve"));
        cur.put("actual_days", r.get("actual_days"));
        cur.put("task_type", r.get("task_type"));
        cur.put("work_class", r.get("work_class"));
        cur.put("status_raw", r.get("status_raw"));
        String mismatch = Scd2Guard.firstMismatch(expected, cur);
        if (mismatch == null) return null;
        return Scd2Guard.conflict("task '" + uid + "': expected " + mismatch + " = '" + expected.get(mismatch)
            + "' does not match the current value — re-read and retry", cur);
    }

    /**
     * MD-AUTOLINK (spec:SPEC-LORE-MD-INLINE-REF §7): какой текст заметки разбирать на упоминания.
     * Дописка — только добавленная часть (прежняя уже разбиралась при своей записи); поле
     * целиком — само поле; заметку не трогали — null, автосвязей нет.
     */
    static String taskNoteMentionText(String noteMd, String noteAppend) {
        return noteAppend != null ? noteAppend : noteMd;
    }

    /**
     * Автосвязи задачи по упоминаниям в заметке (задача → компонент, TAGGED_WITH). Сбой не
     * роняет уже сделанную запись: вместо блока — {@code {error}}. Блокирующий — с рабочего пула.
     */
    private Map<String, Object> taskMentions(String uid, String text) {
        try {
            return autoLinkMentions("task", uid, false, text);
        } catch (Exception e) {
            LOG.warnf("[LORE TASK MENTIONS] %s: %s", uid, e.getMessage());
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("error", LoreUpstream.detail(e));
            return m;
        }
    }

    /** Дописка: пустое поле — запись; иначе прежнее (без хвостовых пустот) + пустая строка + новое. */
    static String appendText(String current, String addition) {
        if (current == null || current.isBlank()) return addition;
        return current.stripTrailing() + "\n\n" + addition;
    }

    /** Поле целиком и дописка в одном вызове — отказ, а не угадывание, что из двух имелось в виду. */
    static String appendConflict(String fullName, String full, String appendName, String append) {
        if (full == null || append == null) return null;
        return "передано и " + fullName + " (заменить целиком), и " + appendName
            + " (дописать в конец) — выберите одно: что из двух имелось в виду, сервер не угадывает";
    }

    // ── Write-path: update KnowSprint vertex fields ──────────────────────────

    @POST
    @Path("sprint/update")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateSprint(SprintUpdateRequest req,
                                 @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.sprint_id() == null || req.sprint_id().isBlank())
            return badParams("sprint_id required");
        if (!SAFE_ID.matcher(req.sprint_id()).matches())
            return badParams("sprint_id contains illegal characters");
        String conflict = appendConflict("context_md", req.context_md(), "context_append", req.context_append());
        if (conflict == null) conflict = appendConflict("outcome_md", req.outcome_md(), "outcome_append", req.outcome_append());
        if (conflict != null) return badParams(conflict);
        Response stale = versionConflict("sprint", req.sprint_id(), req.expected_version());
        if (stale != null) return stale;
        // MT-NOTE-APPEND п.2: прежние значения текстов — в ответ, до того как они исчезнут.
        Map<String, Object> previous = new LinkedHashMap<>();
        String contextNew = req.context_md();
        String outcomeNew = req.outcome_md();
        // Тексты, какими они станут на вершине, — для зеркала на открытую строку истории.
        String[] finalTexts = null;
        if (req.context_md() != null || req.outcome_md() != null || req.context_append() != null || req.outcome_append() != null) {
            List<Map<String, Object>> cur = ingestService.queryPublic(
                "SELECT COALESCE(out('HAS_STATE')[valid_to IS NULL].context_md[0], context_md) AS context_md, COALESCE(out('HAS_STATE')[valid_to IS NULL].outcome_md[0], outcome_md) AS outcome_md FROM KnowSprint WHERE sprint_id=:s", Map.of("s", req.sprint_id()));
            if (cur.isEmpty()) return badParams("sprint not found: " + req.sprint_id());
            String ctx0 = cur.get(0).get("context_md") == null ? null : String.valueOf(cur.get(0).get("context_md"));
            String out0 = cur.get(0).get("outcome_md") == null ? null : String.valueOf(cur.get(0).get("outcome_md"));
            if (req.context_append() != null) contextNew = appendText(ctx0, req.context_append());
            if (req.outcome_append() != null) outcomeNew = appendText(out0, req.outcome_append());
            if (contextNew != null) previous.put("context_md", ctx0);
            if (outcomeNew != null) previous.put("outcome_md", out0);
            finalTexts = new String[]{contextNew != null ? contextNew : ctx0, outcomeNew != null ? outcomeNew : out0};
        }
        StringBuilder sb = new StringBuilder("UPDATE KnowSprint SET ");
        Map<String, Object> p = new LinkedHashMap<>();
        if (req.name()       != null) { sb.append(ModelSchemaAdapter.titleSet("name")).append(", ");           p.put("name",       req.name()); }
        if (outcomeNew != null) { sb.append("outcome_md=:outcome, ");  p.put("outcome",    outcomeNew); }
        if (contextNew != null) { sb.append("context_md=:ctx, ");      p.put("ctx",        contextNew); }
        if (req.plan_id()    != null) { sb.append("plan_id=:plan_id, ");     p.put("plan_id",    req.plan_id()); }
        if (req.effort_days()!= null) { sb.append("effort_days=:effort, ");  p.put("effort",     req.effort_days()); }
        if (req.no_release_required() != null) { sb.append("no_release_required=:nrr, "); p.put("nrr", req.no_release_required()); }
        // RM-U6: «вне плана намеренно» — флаг вершины, как no_release_required (история не нужна).
        if (req.unplanned_intentional() != null) { sb.append("unplanned_intentional=:ui, "); p.put("ui", req.unplanned_intentional()); }
        // trim() is load-bearing: the base StringBuilder is seeded with a
        // trailing space ("...SET "), so when zero fields are appended the
        // regex below (which only strips a trailing comma) leaves that space
        // in place and this equals-check against the untrimmed literal never
        // matched — the empty SET clause then reached ArcadeDB as invalid SQL
        // and came back as a 500 wrapped into our own 502.
        String set = sb.toString().replaceAll(",\\s*$", "").trim();
        if (set.equals("UPDATE KnowSprint SET"))
            return badParams("at least one field required");
        // Аудит времени 10.11 (класс S4-04): поля вершины спринта версию SCD2 не открывают —
        // момент правки на вершине; changed_at среза sprints — максимум с открытой версией.
        set = set + ", updated_at=:upd";
        p.put("upd", java.time.Instant.now().toString());
        p.put("sid", req.sprint_id());
        try {
            // MT-MCP-TRUTH Б11: правка несуществующего спринта — 404, а не ok:true
            if (WriteCount.missed(writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    set + " WHERE sprint_id=:sid", p)).await().indefinitely()))
                return WriteCount.notFound("sprint", req.sprint_id(), "правка спринта (sprint_set)");
            // MT-NOTE-APPEND п.4 (+ основа п.3): тела — и на открытую строку истории, затем хэш.
            // Без этого content_hash спринта считался по пустым полям строки (одинаков при любом
            // тексте), а смена статуса переносила на новую версию null вместо текста.
            // MT-NOTE-APPEND п.3 (вариант А): изменённый текст — НОВАЯ версия SCD2 (копия открытой
            // строки, статус тот же), прежний текст остаётся в истории. Тот же текст или нет
            // открытой версии — прежнее зеркало на месте.
            if (finalTexts != null) {
                Map<String, Object> texts = new LinkedHashMap<>();
                texts.put("context_md", finalTexts[0]);
                texts.put("outcome_md", finalTexts[1]);
                StatusHistoryService.Outcome tv = StatusHistoryService.textVersion(statusDb(), "sprint", req.sprint_id(),
                    texts, changeAuthor());
                if (tv instanceof StatusHistoryService.Outcome.Conflict c)
                    return Scd2Guard.conflict(c.detail() + " (sprint vertex already updated; repeat the call)", c.current());
                // MT-MCP-TRUTH Б11: зеркало не нашло открытую строку — тексты легли только на вершину
                if (!(tv instanceof StatusHistoryService.Outcome.Ok)
                        && WriteCount.missed(writeClient.command(db, basicAuth(), sprintHistMirror(req.sprint_id(), finalTexts[0], finalTexts[1]))
                            .await().indefinitely()))
                    return WriteCount.conflict("NO_OPEN_STATE", "sprint", req.sprint_id(),
                        "у спринта " + req.sprint_id() + " нет открытой строки истории: context_md/outcome_md легли только "
                            + "на вершину (sprint vertex already updated), история их не хранит. Откройте строку сменой статуса "
                            + "(status_set) и повторите правку.");
                hashStamper.stampOpenHist("KnowSprintHist", "KnowSprint", "sprint_id", req.sprint_id());
            }
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true); out.put("sprint_id", req.sprint_id());
            if (!previous.isEmpty()) out.put("previous", previous);
            // MD-AUTOLINK (spec:SPEC-LORE-MD-INLINE-REF §7): упоминания в записанных текстах
            // (для *_append — весь новый текст) → рёбра авто-пар (спринт → компонент).
            if (contextNew != null || outcomeNew != null)
                out.put("mentions", autoLinkMentions("sprint", req.sprint_id(), false, contextNew, outcomeNew));
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE SPRINT UPDATE] %s: %s", req.sprint_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // NB SPRINT_PLANITEM_RETIRE: removed POST /lore/sprint/track (setSprintTrack)
    // and POST /lore/plan-item/milestone (updatePlanItemMilestone). Both targeted
    // PlanItem, which is being retired — track_id is a plain SCD2-tracked field
    // set via POST /lore/sprint/plan (planned_milestone_id was too, until it was
    // later retired in favor of the TARGETS_MILESTONE edge — see linkSprintMilestone
    // in LoreMilestoneResource). setSprintTrack was additionally dead code: it
    // queried a nonexistent type `KnowPlanItem` (schema only ever had `PlanItem`)
    // and a nonexistent property `represents_sprint` on PlanItem (that was only
    // ever a slice-level SQL alias) — it could never actually create the
    // ON_TRACK edge it claimed to. updatePlanItemMilestone had zero frontend
    // callers (confirmed by repo-wide grep before removal).

    // ── Write-path: link sprint ↔ project ────────────────────────────────────

    public record SprintProjectRequest(String sprint_id, String git_project, String action) {}

    @POST
    @Path("sprint/project")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkSprintProject(SprintProjectRequest req,
                                      @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.sprint_id() == null || req.git_project() == null)
            return badParams("sprint_id and git_project required");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            if (remove) {
                // DELETE EDGE doesn't work in ArcadeDB — SELECT @rid + DELETE FROM
                List<Map<String, Object>> edges = ingestService.queryPublic(
                    "SELECT @rid FROM BELONGS_TO_PROJECT WHERE @out.sprint_id=:sid AND @in.slug=:gp",
                    Map.of("sid", req.sprint_id(), "gp", req.git_project()));
                for (Map<String, Object> e : edges) {
                    String rid = e.get("@rid").toString();
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM BELONGS_TO_PROJECT WHERE @rid=" + rid, null)).await().indefinitely();
                }
            } else {
                // Idempotent: create edge only if not already linked
                List<Map<String, Object>> existing = ingestService.queryPublic(
                    "SELECT out('BELONGS_TO_PROJECT').slug AS gps FROM KnowSprint WHERE sprint_id=:sid",
                    Map.of("sid", req.sprint_id()));
                @SuppressWarnings("unchecked")
                List<String> current = existing.isEmpty() ? List.of()
                    : (List<String>) existing.get(0).getOrDefault("gps", List.of());
                if (!current.contains(req.git_project())) {
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "CREATE EDGE BELONGS_TO_PROJECT " +
                        "FROM (SELECT FROM KnowSprint WHERE sprint_id=:sid) " +
                        "TO   (SELECT FROM KnowGitProject WHERE slug=:gp)",
                        Map.of("sid", req.sprint_id(), "gp", req.git_project()))).await().indefinitely();
                }
            }
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true); out.put("sprint_id", req.sprint_id());
            out.put("git_project", req.git_project()); out.put("action", remove ? "removed" : "added");
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE SPRINT PROJECT] %s / %s: %s", req.sprint_id(), req.git_project(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── Write-path: link sprint ↔ component (BELONGS_TO) ─────────────────────
    // An explicit sprint→component link. When present it OVERRIDES the fuzzy
    // naming-convention match (sprint_id LIKE %component_key%) used by the
    // component_sprints / sprint-module-badges read paths.

    public record SprintComponentRequest(String sprint_id, String component_id, String action) {}

    @POST
    @Path("sprint/component")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkSprintComponent(SprintComponentRequest req,
                                        @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.sprint_id() == null || req.component_id() == null)
            return badParams("sprint_id and component_id required");
        if (!SAFE_ID.matcher(req.sprint_id()).matches() || !SAFE_ID.matcher(req.component_id()).matches())
            return badParams("ids contain illegal characters");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            // Validate both endpoints exist — CREATE EDGE FROM/TO an empty subquery is a
            // silent no-op (returns ok but writes nothing), so a typo'd component_id would
            // quietly do nothing. Fail loudly instead.
            if (ingestService.queryPublic(
                    "SELECT sprint_id FROM KnowSprint WHERE sprint_id=:s LIMIT 1",
                    Map.of("s", req.sprint_id())).isEmpty())
                return badParams("sprint not found: " + req.sprint_id());
            if (ingestService.queryPublic(
                    "SELECT component_id FROM LoreComponent WHERE component_id=:c LIMIT 1",
                    Map.of("c", req.component_id())).isEmpty())
                return badParams("component not found: " + req.component_id());
            if (remove) {
                // DELETE EDGE doesn't work in ArcadeDB — SELECT @rid + DELETE FROM
                List<Map<String, Object>> edges = ingestService.queryPublic(
                    "SELECT @rid FROM BELONGS_TO WHERE @out.sprint_id=:s AND @in.component_id=:c",
                    Map.of("s", req.sprint_id(), "c", req.component_id()));
                for (Map<String, Object> e : edges) {
                    String rid = e.get("@rid").toString();
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM BELONGS_TO WHERE @rid=" + rid, null)).await().indefinitely();
                }
            } else {
                // Idempotent: skip if already linked
                List<Map<String, Object>> existing = ingestService.queryPublic(
                    "SELECT @rid FROM BELONGS_TO WHERE @out.sprint_id=:s AND @in.component_id=:c",
                    Map.of("s", req.sprint_id(), "c", req.component_id()));
                if (existing.isEmpty()) {
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        String.format(
                            "CREATE EDGE BELONGS_TO FROM (SELECT FROM KnowSprint WHERE sprint_id='%s') " +
                            "TO (SELECT FROM LoreComponent WHERE component_id='%s')",
                            req.sprint_id(), req.component_id()),
                        null)).await().indefinitely();
                }
            }
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true);
            out.put("sprint_id", req.sprint_id());
            out.put("component_id", req.component_id());
            out.put("action", remove ? "removed" : "added");
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE SPRINT COMPONENT] %s / %s: %s", req.sprint_id(), req.component_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── Write-path: link task ↔ component (TAGGED_WITH) ─────────────────────
    // Many-to-many: a task can be tagged with 0..N components.
    // Uses TAGGED_WITH (distinct from sprint→component BELONGS_TO) so that
    // analytics queries filtering on BELONGS_TO are unaffected.

    public record TaskComponentRequest(String task_uid, String component_id, String action) {}

    @POST
    @Path("task/component")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkTaskComponent(TaskComponentRequest req,
                                      @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.task_uid() == null || req.component_id() == null)
            return badParams("task_uid and component_id required");
        if (!SAFE_ID.matcher(req.task_uid()).matches() || !SAFE_ID.matcher(req.component_id()).matches())
            return badParams("ids contain illegal characters");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            if (ingestService.queryPublic(
                    "SELECT task_uid FROM KnowTask WHERE task_uid=:t LIMIT 1",
                    Map.of("t", req.task_uid())).isEmpty())
                return badParams("task not found: " + req.task_uid());
            if (ingestService.queryPublic(
                    "SELECT component_id FROM LoreComponent WHERE component_id=:c LIMIT 1",
                    Map.of("c", req.component_id())).isEmpty())
                return badParams("component not found: " + req.component_id());
            if (remove) {
                List<Map<String, Object>> edges = ingestService.queryPublic(
                    "SELECT @rid FROM TAGGED_WITH WHERE @out.task_uid=:t AND @in.component_id=:c",
                    Map.of("t", req.task_uid(), "c", req.component_id()));
                for (Map<String, Object> e : edges) {
                    String rid = e.get("@rid").toString();
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM TAGGED_WITH WHERE @rid=" + rid, null)).await().indefinitely();
                }
            } else {
                List<Map<String, Object>> existing = ingestService.queryPublic(
                    "SELECT @rid FROM TAGGED_WITH WHERE @out.task_uid=:t AND @in.component_id=:c",
                    Map.of("t", req.task_uid(), "c", req.component_id()));
                if (existing.isEmpty()) {
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        String.format(
                            "CREATE EDGE TAGGED_WITH FROM (SELECT FROM KnowTask WHERE task_uid='%s') " +
                            "TO (SELECT FROM LoreComponent WHERE component_id='%s')",
                            req.task_uid(), req.component_id()),
                        null)).await().indefinitely();
                }
            }
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true);
            out.put("task_uid", req.task_uid());
            out.put("component_id", req.component_id());
            out.put("action", remove ? "removed" : "added");
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE TASK COMPONENT] %s / %s: %s", req.task_uid(), req.component_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── Write-path: link task ↔ ADR (JUSTIFIED_BY, ADR-LORE-022 D16) ─────────
    //
    // PL-14 оживляет мёртвый тип ребра. `JUSTIFIED_BY` был объявлен в схеме
    // (шаг V8) с комментарием «обоснование enb-задачи», и это оставалось
    // ЕДИНСТВЕННЫМ его упоминанием во всём репозитории: ни писателей, ни
    // читателей, ни слайса. То есть правило D16 «энейблер обосновывается
    // архитектурным решением» существовало только на бумаге.
    //
    // Направление ребра — задача → ADR: обоснование принадлежит задаче, а один
    // ADR обосновывает много задач.

    public record TaskAdrRequest(String task_uid, String adr_id, String action) {}

    // ── D-2026-MINILORE-OWNER-ANSWERS-06-11 п.3: задача → PR (CLOSED_BY) ───────
    //
    // Q-MINILORE-TASK-PR-EDGE, владелица «ок» 06.11.2026: связь задачи с PR —
    // ребром, а не текстом. Тогда релиз находит задачи через PR → SHIPPED_IN
    // (срез release_tasks_by_tag), а не разбором note_md.

    /** Ссылка на PR: проект (слаг KnowGitProject) и номер. Ключ KnowPR — «slug#N», как у моста Forgejo. */
    public record PrRef(String gitProject, int number) {
        String uid() { return gitProject + "#" + number; }
    }

    /**
     * «owner/repo#N» — как есть; «#N» или «N» — только вместе с проектом.
     * Голый номер без проекта неоднозначен (#38 есть и в LORE, и в Völva) —
     * null, а не догадка.
     */
    static PrRef parsePrRef(String target, String project) {
        if (target == null) return null;
        String t = target.strip();
        java.util.regex.Matcher full = java.util.regex.Pattern.compile("^([\\w.-]+/[\\w.-]+)#(\\d+)$").matcher(t);
        if (full.matches()) {
            int n = Integer.parseInt(full.group(2));
            return n > 0 ? new PrRef(full.group(1), n) : null;
        }
        java.util.regex.Matcher bare = java.util.regex.Pattern.compile("^#?(\\d+)$").matcher(t);
        if (bare.matches() && project != null && !project.isBlank()) {
            int n = Integer.parseInt(bare.group(1));
            return n > 0 ? new PrRef(project.strip(), n) : null;
        }
        return null;
    }

    public record TaskPrRequest(String task_uid, String pr, String project, String action) {}

    @POST
    @Path("task/pr")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkTaskPr(TaskPrRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.task_uid() == null || req.pr() == null)
            return badParams("task_uid and pr required");
        if (!SAFE_ID.matcher(req.task_uid()).matches())
            return badParams("task_uid contains illegal characters");
        PrRef ref = parsePrRef(req.pr(), req.project());
        if (ref == null)
            return badParams("pr must be \"owner/repo#N\", or \"#N\"/\"N\" together with project — "
                + "a bare number is ambiguous across repositories");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            // Обе стороны — ДО записи: CREATE EDGE в пустую выборку — тихий no-op.
            if (ingestService.queryPublic("SELECT task_uid FROM KnowTask WHERE task_uid=:t LIMIT 1",
                    Map.of("t", req.task_uid())).isEmpty())
                return badParams("task not found: " + req.task_uid());
            if (ingestService.queryPublic("SELECT slug FROM KnowGitProject WHERE slug=:s LIMIT 1",
                    Map.of("s", ref.gitProject())).isEmpty())
                return badParams("git project not registered: " + ref.gitProject()
                    + " (list: query_slice slice=\"git_projects\")");

            List<Map<String, Object>> existing = ingestService.queryPublic(
                "SELECT @rid FROM CLOSED_BY WHERE @out.task_uid=:t AND @in.pr_uid=:p",
                Map.of("t", req.task_uid(), "p", ref.uid()));
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true);
            out.put("task_uid", req.task_uid());
            out.put("pr_uid", ref.uid());
            if (remove) {
                for (Map<String, Object> e : existing) {
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM CLOSED_BY WHERE @rid=" + e.get("@rid"), null)).await().indefinitely();
                }
                out.put("outcome", existing.isEmpty() ? LoreOutcome.UNCHANGED : LoreOutcome.DELETED);
                return noStore(Response.ok(out));
            }
            if (!existing.isEmpty()) {
                out.put("outcome", LoreOutcome.UNCHANGED);
                return noStore(Response.ok(out));
            }
            // PR мог влиться мимо моста — заводим вершину тем же ключом, что мост Forgejo.
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE KnowPR SET pr_uid=:uid, pr_number=:n, git_project=:gp UPSERT WHERE pr_uid=:uid",
                Map.of("uid", ref.uid(), "n", ref.number(), "gp", ref.gitProject()))).await().indefinitely();
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                String.format("CREATE EDGE CLOSED_BY FROM (SELECT FROM KnowTask WHERE task_uid='%s') "
                    + "TO (SELECT FROM KnowPR WHERE pr_uid='%s') IF NOT EXISTS",
                    req.task_uid(), ref.uid().replace("'", "")), null)).await().indefinitely();
            // Исход — по факту ребра в графе, а не по факту выполнения команды.
            boolean made = !ingestService.queryPublic(
                "SELECT @rid FROM CLOSED_BY WHERE @out.task_uid=:t AND @in.pr_uid=:p",
                Map.of("t", req.task_uid(), "p", ref.uid())).isEmpty();
            out.put("outcome", made ? LoreOutcome.CREATED : LoreOutcome.NOOP);
            if (!made) { out.put("ok", false); out.put("reason", "ребро CLOSED_BY не появилось в графе"); }
            // MD-05: данные PR (title, url, state, merged_at…) — сразу; неудача связь не откатывает, а видна в ответе.
            if (!forgejo.configured()) out.put("pr_details_missing", "мост Forgejo не сконфигурирован — данные PR не подтянуты");
            else out.putAll(PrBackfill.fillOne(prStore(), forgejo.prHost(), ref.gitProject(), ref.number()));
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE TASK PR] %s → %s: %s", req.task_uid(), req.pr(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    @POST
    @Path("task/adr")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkTaskAdr(TaskAdrRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.task_uid() == null || req.adr_id() == null)
            return badParams("task_uid and adr_id required");
        if (!SAFE_ID.matcher(req.task_uid()).matches() || !SAFE_ID.matcher(req.adr_id()).matches())
            return badParams("ids contain illegal characters");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            // Обе стороны проверяем ДО записи: CREATE EDGE в пустой FROM/TO —
            // тихий no-op, и без проверки ответ был бы ok:true при отсутствии ребра.
            if (ingestService.queryPublic(
                    "SELECT task_uid FROM KnowTask WHERE task_uid=:t LIMIT 1",
                    Map.of("t", req.task_uid())).isEmpty())
                return badParams("task not found: " + req.task_uid());
            if (ingestService.queryPublic(
                    "SELECT adr_id FROM KnowADR WHERE adr_id=:a LIMIT 1",
                    Map.of("a", req.adr_id())).isEmpty())
                return badParams("ADR not found: " + req.adr_id());

            List<Map<String, Object>> existing = ingestService.queryPublic(
                "SELECT @rid FROM JUSTIFIED_BY WHERE @out.task_uid=:t AND @in.adr_id=:a",
                Map.of("t", req.task_uid(), "a", req.adr_id()));
            if (remove) {
                for (Map<String, Object> e : existing) {
                    // DELETE EDGE отсутствует в грамматике 26.7.2 — только по @rid.
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM JUSTIFIED_BY WHERE @rid=" + e.get("@rid"), null))
                        .await().indefinitely();
                }
            } else if (existing.isEmpty()) {
                // String.format, а не именованные параметры: на CREATE EDGE они в
                // этой сборке ненадёжны (правило корпуса, LORE_DB_SPEC).
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    String.format(
                        "CREATE EDGE JUSTIFIED_BY FROM (SELECT FROM KnowTask WHERE task_uid='%s') " +
                        "TO (SELECT FROM KnowADR WHERE adr_id='%s')",
                        req.task_uid(), req.adr_id()),
                    null)).await().indefinitely();
            }
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true);
            out.put("task_uid", req.task_uid());
            out.put("adr_id", req.adr_id());
            out.put("action", remove ? "removed" : "added");
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE TASK ADR] %s / %s: %s", req.task_uid(), req.adr_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── Write-path: link task ↔ file (EDITED_IN, ADR-LORE-018 T21) ───────────
    // KnowFile is a *reference* (relative path only), created lazily on first
    // link. Keyed by (project, file_path). The URL is composed at read time on
    // the client from the project's hosts[] — nothing here parses code.

    public record TaskFileRequest(String task_uid, String project, String file_path,
                                  String summary_md, String action) {}

    @POST
    @Path("task/file")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkTaskFile(TaskFileRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.task_uid() == null || req.project() == null || req.file_path() == null)
            return badParams("task_uid, project and file_path required");
        if (!SAFE_ID.matcher(req.task_uid()).matches() || !SAFE_ID.matcher(req.project()).matches())
            return badParams("task_uid/project contain illegal characters");
        // file_path allows longer, path-shaped values (deep repo paths), but no
        // quotes/newlines — it flows into String.format'd CREATE EDGE (named
        // params are unreliable there, same as every other edge write here).
        if (!req.file_path().matches("[A-Za-z0-9_./\\-]{1,300}"))
            return badParams("file_path contains illegal characters");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            if (ingestService.queryPublic(
                    "SELECT task_uid FROM KnowTask WHERE task_uid=:t LIMIT 1",
                    Map.of("t", req.task_uid())).isEmpty())
                return badParams("task not found: " + req.task_uid());
            String p = req.project(), f = req.file_path();
            if (remove) {
                List<Map<String, Object>> edges = ingestService.queryPublic(
                    "SELECT @rid FROM EDITED_IN WHERE @out.project=:p AND @out.file_path=:f AND @in.task_uid=:t",
                    Map.of("p", p, "f", f, "t", req.task_uid()));
                for (Map<String, Object> e : edges) {
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM EDITED_IN WHERE @rid=" + e.get("@rid").toString(), null)).await().indefinitely();
                }
            } else {
                // Lazy upsert of KnowFile, then idempotent edges — one sqlscript so
                // the CREATE EDGE statements see the just-upserted vertex in-tx.
                String summarySet = req.summary_md() != null
                    ? ", summary_md='" + req.summary_md().replace("'", "''") + "'" : "";
                String script = String.join(";\n",
                    String.format(
                        "UPDATE KnowFile SET project='%s', file_path='%s'%s UPSERT WHERE project='%s' AND file_path='%s'",
                        p, f, summarySet, p, f),
                    String.format(
                        "CREATE EDGE BELONGS_TO_PROJECT FROM (SELECT FROM KnowFile WHERE project='%s' AND file_path='%s') " +
                        "TO (SELECT FROM KnowGitProject WHERE slug='%s') IF NOT EXISTS", p, f, p),
                    String.format(
                        "CREATE EDGE EDITED_IN FROM (SELECT FROM KnowFile WHERE project='%s' AND file_path='%s') " +
                        "TO (SELECT FROM KnowTask WHERE task_uid='%s') IF NOT EXISTS", p, f, req.task_uid()));
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sqlscript",
                    script, null)).await().indefinitely();
            }
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true);
            out.put("task_uid", req.task_uid());
            out.put("project", p);
            out.put("file_path", f);
            out.put("action", remove ? "removed" : "added");
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE TASK FILE] %s / %s: %s", req.task_uid(), req.file_path(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── Write-path: зависимость DEPENDS_ON (MDL-13) ──────────────────────────

    public record SprintDepRequest(String from_sprint, String to_sprint, String kind, String reason, String action) {}

    /**
     * Прежний путь «спринт зависит от спринта» — теперь частный случай одной связи «зависит от»
     * ({@link #linkDependency}): те же проверки вида, цикла (409 с путём) и история в ребре. Форма ответа
     * сохраняет from_sprint / to_sprint для прежних вызывающих.
     */
    @POST
    @Path("sprint/dep")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkSprintDep(SprintDepRequest req,
                                  @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.from_sprint() == null || req.to_sprint() == null)
            return badParams("from_sprint and to_sprint required");
        Response r = linkDependency(new DepRequest("sprint", req.from_sprint(), "sprint", req.to_sprint(),
            req.kind(), req.reason(), req.action()), role);
        if (r.getStatus() == 200 && r.getEntity() instanceof Map<?, ?> body) {
            @SuppressWarnings("unchecked") Map<String, Object> out = new LinkedHashMap<>((Map<String, Object>) body);
            out.put("from_sprint", req.from_sprint());
            out.put("to_sprint", req.to_sprint());
            return noStore(Response.ok(out));
        }
        return r;
    }

    /**
     * Зависимость между задачей, фазой, спринтом и вехой в любом сочетании: {@code from} зависит от
     * {@code to}. Тип конца не назван — ищется по ключу среди четырёх типов. Вид — из справочника
     * {@code dependency_kind} (нет справочника в базе — виды спринтов), иначе 422; связь с собой — 400;
     * нет конца — 404; цикл — 409 с путём цикла. Снятие закрывает ребро (связь историчная).
     */
    public record DepRequest(String from_type, String from_id, String to_type, String to_id,
                             String kind, String reason, String action) {}

    @POST
    @Path("dep")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkDependency(DepRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.from_id() == null || req.to_id() == null)
            return badParams("from_id and to_id required");
        if (!SAFE_ID.matcher(req.from_id()).matches() || !SAFE_ID.matcher(req.to_id()).matches())
            return badParams("ids contain illegal characters");
        try {
            LoreDependency.Graph g = dependencyGraph();
            LoreDependency.Resolved from = LoreDependency.resolve(g, req.from_type(), req.from_id().trim());
            if (from.ref() == null) return noStore(Response.status(from.status()).entity(from.error()));
            LoreDependency.Resolved to = LoreDependency.resolve(g, req.to_type(), req.to_id().trim());
            if (to.ref() == null) return noStore(Response.status(to.status()).entity(to.error()));
            LoreDependency.Result r = LoreDependency.link(g, from.ref(), to.ref(), req.kind(), req.reason(), req.action(),
                activeDictCodes(LoreDependency.DICT, LoreDependency.DEFAULT_KINDS), java.time.Instant.now().toString());
            return noStore(Response.status(r.status()).entity(r.body()));
        } catch (Exception e) {
            LOG.warnf("[LORE DEP] %s → %s: %s", req.from_id(), req.to_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    private LoreDependency.Graph dependencyGraph() {
        return new LoreDependency.Graph() {
            @Override
            public List<Map<String, Object>> query(String sql, Map<String, Object> params) {
                return ingestService.queryPublic(sql, params);
            }
            @Override
            public void exec(String sql, Map<String, Object> params) {
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql", sql,
                    params == null || params.isEmpty() ? null : params)).await().indefinitely();
            }
        };
    }

    /**
     * RM-P7: единственный репозиторий спринта, либо {@code null}.
     *
     * <p>Нужен там, где из репозитория собирается адрес PR. Прежде на его месте
     * стояло молчаливое {@code "NooriUta/AIDA"}, и ссылка вела в чужой
     * репозиторий: она открывается, показывает существующий PR с тем же номером
     * и потому не выглядит ошибкой. Спринт свой репозиторий знает — спросить его
     * вернее, чем угадать.
     *
     * <p>{@code null} при НУЛЕ и при НЕСКОЛЬКИХ проектах, и это не лень: взять
     * первый значило бы решить за вызывающего молча, а «у спринта два
     * репозитория» — законное положение (на 27.08.2026 таких спринтов 17).
     * Сбой пробы тоже даёт {@code null}: не смогли выяснить — не то же самое,
     * что выяснили.
     */
    private String sprintProject(String sprintId) {
        try {
            List<Map<String, Object>> rows = ingestService.queryPublic(
                "SELECT out('BELONGS_TO_PROJECT').slug AS gps FROM KnowSprint WHERE sprint_id=:sid",
                Map.of("sid", sprintId));
            if (rows.isEmpty()) return null;
            Object gps = rows.get(0).get("gps");
            if (!(gps instanceof List<?> l) || l.size() != 1) return null;
            Object one = l.get(0);
            return one == null || String.valueOf(one).isBlank() ? null : String.valueOf(one);
        } catch (Exception e) {
            LOG.warnf("[LORE PR LINK] проект спринта %s не прочитать: %s", sprintId, e.getMessage());
            return null;
        }
    }
}
