package studio.seer.heimdall.lore;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Линтер полноты спринта и задачи — ЧИСТАЯ логика, без БД и HTTP, по образцу
 * {@link UcQuality}. Одна и та же функция питает ответ write-пути и (в
 * перспективе) панель в UI, поэтому оценки не могут разойтись по построению.
 *
 * <p><b>Зачем.</b> Четыре поля забываются раз за разом — статус, компонент,
 * оценка по времени, проект, — и до сих пор о них НАПОМИНАЛ ЧЕЛОВЕК. Слайсы
 * {@code product_hygiene} и {@code unlinked_*} ловят часть этого, но постфактум
 * и только если кто-то откроет срез; к тому моменту контекст записи утерян.
 * Здесь вердикт возвращается В ОТВЕТЕ НА ЗАПИСЬ — в момент, когда автор ещё
 * держит задачу в голове и может дописать одним вызовом.
 *
 * <p><b>Advisory, никогда не блокирует.</b> Тот же принцип, что у UC-линтера
 * (ADR-LORE-027-D14): сохранить можно всегда. Отказ в записи из-за
 * незаполненной оценки превратил бы вспомогательную дисциплину в препятствие и
 * заставил бы обходить её мусорными значениями — а мусорное «0.1 дня» хуже
 * честного пропуска, потому что неотличимо от настоящей оценки.
 *
 * <p><b>Почему часть проверок условные.</b> {@code work_class} ADR-LORE-022 (D3)
 * объявлял законно пустым, но решением владельца (2026-08-03) он ОБЯЗАТЕЛЕН —
 * см. развёрнутое обоснование у самой проверки. Условны проверки связей: ЕСЛИ
 * класс задан, дисциплина обязательна — {@code uc} без REALIZES и {@code enb}
 * без JUSTIFIED_BY — ровно те две находки, которые сегодня копятся в
 * {@code product_hygiene} сотнями.
 */
final class WorkQuality {

    private WorkQuality() {}

    /** Одна находка: прошла/не прошла, обязательна ли (обязательные идут в счёт). */
    record Finding(String code, boolean ok, boolean required, String message) {}

    /** Результат: score/max по обязательным + все находки, включая подсказки. */
    record Result(String kind, int score, int max, List<Finding> findings, Map<String, Object> extra) {
        Result(String kind, int score, int max, List<Finding> findings) {
            this(kind, score, max, findings, null);
        }
    }

    /**
     * Ответ записи: счёт одной строкой, а НЕДОСТАЮЩЕЕ — поимённо.
     *
     * <p><b>Зачем.</b> Полный список находок выдавал пройденные и непройденные
     * проверки одинаково: пять строк `ok:true` и одна `ok:false`, и разницу
     * видно, только если читать все шесть. Замечание владельца 30.08.2026 —
     * «ты на качество не реагируешь» — справедливо и объясняется именно этим:
     * пропуск тонул среди пройденного.
     *
     * <p>Это тот же дефект, что мы весь день разбираем, только в ответе
     * инструмента: сигнал есть, но он неотличим от шума, и потому не работает.
     *
     * <p>Поэтому наружу едет: {@code score} из {@code max} — «x из y», и
     * список ТОЛЬКО непройденного. Всё выполнено — ключа {@code missing} нет
     * вовсе, и короткий ответ сам по себе означает «полно».
     *
     * <p>Необязательные проверки (подсказки) вынесены отдельным ключом
     * {@code hints}: они не входят в счёт и не должны выглядеть как долг.
     */
    static Map<String, Object> compact(Result r) {
        // Судить нечего (сущности нет) — вердикта нет. Раньше здесь был NPE, и
        // release_link к несуществующему релизу отвечал 500 вместо отказа.
        if (r == null) return null;
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("kind", r.kind());
        out.put("score", r.score() + " из " + r.max());
        List<String> missing = new ArrayList<>();
        List<String> hints = new ArrayList<>();
        for (Finding f : r.findings()) {
            if (f.ok()) continue;
            // У missing ключ сам говорит «не хватает»; у hints — нет, а сообщение
            // сформулировано как условие («Оценка сходится…»). Без пометки
            // непройденная подсказка читалась как вердикт (MT-TASK-SHAPE-2).
            if (f.required()) missing.add(f.code() + " — " + f.message());
            else hints.add(f.code() + " — не выполнено: " + f.message());
        }
        if (!missing.isEmpty()) out.put("missing", missing);
        if (!hints.isEmpty()) out.put("hints", hints);
        // MT-TASK-SHAPE: форма задачи (класс сложности, рекомендации) — рядом со счётом.
        if (r.extra() != null) out.putAll(r.extra());
        return out;
    }

    private static boolean filled(String s) {
        return s != null && !s.isBlank();
    }

    /** Траверс графа отдаёт скаляр либо список — пусто значит «ребра нет». */
    private static boolean any(Object raw) {
        if (raw == null) return false;
        if (raw instanceof Collection<?> c) {
            return c.stream().anyMatch(o -> o != null && !String.valueOf(o).isBlank());
        }
        return !String.valueOf(raw).isBlank();
    }

    /**
     * Задача. Факты собирает вызывающий из графа — линтер их только судит.
     *
     * @param statusRaw  текущий статус из открытой HAS_STATE
     * @param effortDays оценка с той же строки; {@code null} = не задана
     * @param workClass  uc | jtd | enb | null (null легален, D3)
     * @param components TAGGED_WITH задачи ИЛИ унаследованные от спринта
     * @param projects   BELONGS_TO_PROJECT спринта — у задачи своего ребра нет
     * @param realizesUc REALIZES → KnowUseCase
     * @param justifiedBy JUSTIFIED_BY → KnowADR
     */
    static Result evaluateTask(String statusRaw, Double effortDays, String workClass,
                               Object components, Object projects,
                               Object realizesUc, Object justifiedBy) {
        return evaluateTask(statusRaw, effortDays, workClass, components, projects, realizesUc, justifiedBy, null);
    }

    /**
     * То же плюс форма задачи (MT-TASK-SHAPE). Форма — ПОДСКАЗКИ, не в счёт:
     * поднять их в обязательные значило бы разом уронить счёт у 88% корпуса,
     * а счёт, красный у всех, перестают читать. {@code shape == null} — текст
     * задачи вызывающему неизвестен, и судить форму не по чему.
     */
    static Result evaluateTask(String statusRaw, Double effortDays, String workClass,
                               Object components, Object projects,
                               Object realizesUc, Object justifiedBy, TaskShape.Shape shape) {
        Result base = evaluateTaskCore(statusRaw, effortDays, workClass, components, projects, realizesUc, justifiedBy);
        if (shape == null) return base;
        List<Finding> f = new ArrayList<>(base.findings());
        hint(f, "shape_why", shape.why(), "Есть «почему»: повод, факт или симптом");
        hint(f, "shape_steps", shape.steps() >= 2, "Не меньше двух шагов (проба → правка → проверка)");
        hint(f, "shape_verify", shape.verify(), "Есть наблюдаемый критерий готовности");
        if (shape.estimateFits() != null)
            hint(f, "shape_estimate", shape.estimateFits(),
                "Оценка сходится с составом (класс " + shape.complexity() + ")");
        return new Result(base.kind(), base.score(), base.max(), f, Map.of("shape", shape.toMap()));
    }

    private static Result evaluateTaskCore(String statusRaw, Double effortDays, String workClass,
                                           Object components, Object projects,
                                           Object realizesUc, Object justifiedBy) {
        List<Finding> f = new ArrayList<>();

        req(f, "status", filled(statusRaw), "Статус задан");
        // Оценка: ноль и отрицательное — не оценка. 0 не отличить от «забыл
        // поставить», а именно это забывание проверка и ловит.
        req(f, "effort_days", effortDays != null && effortDays > 0,
            "Оценка по времени задана (effort_days > 0)");
        req(f, "component", any(components), "Компонент привязан (свой или от спринта)");
        req(f, "project", any(projects), "Проект известен (через спринт)");

        // Класс работы — ОБЯЗАТЕЛЕН (решение владельца 2026-08-03).
        //
        // ADR-LORE-022 D3 объявлял пустой work_class легальным, и до сих пор он
        // был подсказкой. Практика показала цену: класс задан у 256 задач из
        // 3267, и «зачем-ось» INVEST-профиля считается на 2.3% трудоёмкости.
        // Показатель, посчитанный на такой доле, не отвечает на вопрос, ради
        // которого заведён, а выглядит рабочим.
        //
        // Проверка остаётся advisory — она не блокирует запись, а понижает счёт
        // и называет пропуск. Это нажим, а не запрет: превратить в запрет
        // значило бы поощрять простановку класса наугад, а неверный класс хуже
        // пустого, потому что неотличим от осознанного.
        req(f, "work_class", filled(workClass), "Класс работы задан (uc | jtd | enb)");
        if ("uc".equals(workClass)) {
            req(f, "realizes_uc", any(realizesUc),
                "work_class=uc обязан нести REALIZES на сценарий");
        }
        if ("enb".equals(workClass)) {
            req(f, "justified_by", any(justifiedBy),
                "work_class=enb обязан нести JUSTIFIED_BY на ADR");
        }

        return score("task", f);
    }

    /**
     * Спринт.
     *
     * @param plannedStart планируемое начало; вместе с концом это «оценка по времени» спринта
     * @param milestones   TARGETS_MILESTONE — подсказка, не штраф (ловит strategic_coverage)
     */
    static Result evaluateSprint(String statusRaw, Object projects, Object components,
                                 String plannedStart, String plannedEnd, Object milestones) {
        List<Finding> f = new ArrayList<>();

        req(f, "status", filled(statusRaw), "Статус задан");
        req(f, "project", any(projects), "Проект привязан (BELONGS_TO_PROJECT)");
        req(f, "component", any(components), "Компонент привязан (BELONGS_TO)");
        // Обе даты вместе: одна без другой не даёт ни длительности, ни места на
        // доске плана — а именно ради доски они и заполняются.
        req(f, "planned_dates", filled(plannedStart) && filled(plannedEnd),
            "Плановые даты заданы (начало и конец)");

        hint(f, "milestone", any(milestones), "Веха привязана — опционально");

        return score("sprint", f);
    }

    /**
     * Релиз. Самая дорогая из проверок этого набора: пустые связи релиза —
     * записанная боль [[PAIN-LORE-BROKEN-LINKS]], а не гипотеза. Релиз уезжает,
     * выглядит опубликованным, и только потом выясняется, что по нему нельзя
     * ответить, что в него вошло — когда контекст уже утерян.
     *
     * <p>Спринты и PR проверяются РАЗДЕЛЬНО намеренно: это два разных вызова
     * {@code release_link}, и забывается обычно первый. «Связи есть» без
     * разделения показывало бы зелёное при половине работы.
     */
    static Result evaluateRelease(String gitTag, String descriptionMd,
                                  Object sprints, Object prs, Object projects) {
        List<Finding> f = new ArrayList<>();

        req(f, "git_tag", filled(gitTag), "Тег задан");
        req(f, "description", filled(descriptionMd),
            "Описание непусто — пустой релиз выглядит опубликованным и прячет пропажу описания");
        req(f, "sprints_linked", any(sprints), "Привязан хотя бы один спринт");
        req(f, "prs_linked", any(prs), "Привязан хотя бы один PR");
        req(f, "project", any(projects), "Проект привязан");

        return score("release", f);
    }

    /**
     * ADR. Тела проверяются на НЕПУСТОТУ, а не на содержание: судить текст
     * линтер не может и не должен. Но ADR без раздела «решение» — это не
     * решение, а заметка, и отличить одно от другого структурно можно.
     *
     * @param hasDecisions есть ли дочерние KnowDecision (DECIDED_IN)
     */
    static Result evaluateAdr(String status, Object components, Object projects,
                              boolean hasDecisions,
                              String contextMd, String decisionMd, String consequencesMd) {
        return evaluateAdr(status, components, projects, hasDecisions,
            contextMd, decisionMd, consequencesMd, false);
    }

    /**
     * ADR с механическими проверками структуры (ADR-LORE-039 §5).
     *
     * @param hasSupersedesEdge пришло ли ВХОДЯЩЕЕ ребро SUPERSEDES (кто-то заменил
     *                          этот ADR) — для когерентности статуса «Заменено»
     */
    static Result evaluateAdr(String status, Object components, Object projects,
                              boolean hasDecisions,
                              String contextMd, String decisionMd, String consequencesMd,
                              boolean hasSupersedesEdge) {
        // ВЕС ПО СТАТУСУ, как casual/fully-dressed у UC (ADR-LORE-027). PROPOSED —
        // черновик: разложение, последствия и альтернативы там законно
        // отсутствуют, и штрафовать за это значит давить на самом хрупком этапе.
        // ACCEPTED — принятое правило: оно обязано быть разложено и иметь
        // последствия, иначе «принято» сказано о заметке. Один и тот же список
        // проверок даёт разный ЗНАМЕНАТЕЛЬ, а не разный набор.
        boolean accepted = "ACCEPTED".equalsIgnoreCase(status);
        List<Finding> f = new ArrayList<>();

        req(f, "status", filled(status), "Статус задан");
        req(f, "component", any(components), "Компонент привязан");
        req(f, "project", any(projects), "Проект привязан");
        req(f, "context", filled(contextMd), "Контекст заполнен");
        req(f, "decision", filled(decisionMd), "Решение заполнено");

        // Порог содержательности. Судится ОБЪЁМ, не смысл: раздел из полутора
        // строк — это отписка, и отличить её от разбора структурно можно, а
        // судить формулировки линтер не может и не должен.
        opt(f, accepted, "context_substantive", len(contextMd) >= MIN_BODY,
            "Контекст содержателен (≥ " + MIN_BODY + " симв.)");
        opt(f, accepted, "decision_substantive", len(decisionMd) >= MIN_BODY,
            "Решение содержательно (≥ " + MIN_BODY + " симв.)");

        // Разделы по конвенции заголовков. «Альтернативы» — подсказка даже у
        // ACCEPTED: бывают решения без развилки, и требовать вымышленный второй
        // вариант значит поощрять выдумку.
        hint(f, "alternatives", hasHeading(decisionMd, "льтернатив"),
            "Раздел «Рассмотренные альтернативы» — желательно");

        // Трассируемость: решение, не ссылающееся ни на один ADR/решение, стоит
        // особняком от корпуса. Подсказка у черновика, требование у принятого.
        opt(f, accepted, "traceability", refsEntity(decisionMd),
            "Решение ссылается хотя бы на один ADR-*/D-* — трассируемость");

        // Последствия и разложение: у черновика — подсказки (разложение отдельный
        // шаг, и требовать его при заведении значит блокировать черновик), у
        // принятого — обязательны (ADR-LORE-014 §4).
        opt(f, accepted, "consequences", filled(consequencesMd),
            accepted ? "Последствия заполнены" : "Последствия заполнены — желательно");
        opt(f, accepted, "decisions", hasDecisions,
            accepted ? "Разложен на атомарные решения" : "Разложен на атомарные решения — желательно");

        // Когерентность статуса: «Заменено» — утверждение о факте, и факт обязан
        // быть в графе, иначе читающий видит тупик: заменено, а чем — неизвестно.
        //
        // Ребро ВХОДЯЩЕЕ: SUPERSEDES создаётся FROM нового ADR TO старого, поэтому
        // у заменённого оно приходит извне. Раньше проверка смотрела исходящее и
        // требовала от старой записи указывать на свою замену — граф так не
        // устроен, и «починить» это можно было только ложным ребром. Поймано
        // сессией MIDGARD 2026-08-23, которая отказалась подгонять данные под гейт.
        if ("SUPERSEDED".equalsIgnoreCase(status)) {
            req(f, "superseded_by", hasSupersedesEdge,
                "Статус «Заменено» требует ребра SUPERSEDES ОТ заменяющего ADR — должно быть видно, чем именно перекрыт");
        }

        return score("adr", f);
    }

    /**
     * Решение (KnowDecision). ADR-LORE-039, таблица предлагаемых проверок.
     *
     * <p>Ключевая проверка — родитель: решение, не привязанное к ADR
     * (DECIDED_IN, ADR-LORE-019), висит вне корпуса — его не найти от ADR, оно
     * не попадает в разбор решения на правила и живёт как заметка.
     *
     * <p>Порог тела тот же, что у ADR: решение из одного заголовка — ЯРЛЫК, а
     * правило должно быть сформулировано так, чтобы по нему можно было свериться.
     */
    /**
     * Проект — ОБЯЗАТЕЛЬНЫЙ пункт с 10.09.2026 (SE-07).
     *
     * <p>Раньше его в счёте не было вовсе, хотя у ЗАДАЧИ он есть: асимметрия
     * оказалась недоделкой, а не замыслом. Пока проверки не было, инструмент
     * отвечал «готово» записи без принадлежности, и единственным контролем
     * оставался глаз владельца — срабатывал через сутки, трижды за две недели.
     *
     * <p>{ projects} приходит УЖЕ ВЫВЕДЕННЫМ: своё ребро, иначе
     * унаследованное от родительского ADR. Требовать своё значило бы заругать
     * 56 решений из 200, у которых наследование законно.
     */
    static Result evaluateDecision(String status, String bodyMd, boolean hasParentAdr,
                                   Object components, Object tags, Object projects) {
        List<Finding> f = new ArrayList<>();

        req(f, "status", filled(status), "Статус задан");
        req(f, "body", filled(bodyMd), "Тело решения непусто");
        req(f, "parent_adr", hasParentAdr, "Привязано к ADR (DECIDED_IN) — решение живёт под ADR");
        req(f, "body_substantive", len(bodyMd) >= MIN_BODY,
            "Решение сформулировано как правило (≥ " + MIN_BODY + " симв.), а не ярлык");
        req(f, "project", any(projects), "Проект известен — своим ребром либо от родительского ADR");

        hint(f, "component", any(components), "Компонент привязан — желательно");
        hint(f, "tags", any(tags), "Теги заданы — желательно");

        return score("decision", f);
    }

    /**
     * Спека (KnowSpec). Спека без содержания — заглушка: она занимает место в
     * реестре знаний и создаёт впечатление, что тема покрыта.
     *
     * <p><b>Статуса здесь нет намеренно.</b> У KnowSpec поля статуса нет в
     * модели вовсе — его не пишет ни один write-путь и не читает ни один слайс.
     * Проверка «статус задан» краснела бы всегда и на всех: не дисциплина, а
     * постоянный ложный сигнал, от которого перестают читать весь вердикт.
     */
    static Result evaluateSpec(String title, String contentMd,
                               Object components, Object projects, String version) {
        List<Finding> f = new ArrayList<>();

        req(f, "title", filled(title), "Заголовок задан");
        req(f, "content", filled(contentMd), "Содержание непусто");
        req(f, "component", any(components), "Компонент привязан");
        req(f, "project", any(projects), "Проект привязан");

        hint(f, "version", filled(version), "Версия задана — желательно");

        return score("spec", f);
    }

    /**
     * Компонент (LoreComponent). Голый {@code component_id} в списках нечитаем,
     * а без области он не ложится ни в группировку, ни в цвет на доске.
     *
     * <p><b>parent_sync — проверка не косметическая (RM-P10).</b> Родитель задан
     * ДВАЖДЫ: ребром {@code PARENT_OF} (канон, см.
     * {@code D-2026-LORE-COMPONENT-PARENT-EDGE-IS-CANON}) и денормализованным
     * полем {@code parent_id}. Копии разошлись на 12 вершинах, и цена была не в
     * аккуратности: на вопрос «сколько у нас корневых компонентов» поле отвечало
     * 26, рёбра — 14, а «сколько спринтов у AIDA» — 34 против 223. Оба числа
     * выглядели как факт, и выбор между ними зависел от способа обхода графа.
     *
     * <p>Гэп возник потому, что его никто не сверял: {@code relinkParentEdge}
     * пишет обе стороны, но вершины, заведённые до неё, остались с одной. Без
     * этой проверки он разойдётся снова — молча и тем же способом.
     */
    static Result evaluateComponent(String fullName, String area, String owner, String gameIcon,
                                    String parentId, Object parentByEdge) {
        List<Finding> f = new ArrayList<>();

        req(f, "full_name", filled(fullName), "Полное имя задано");
        req(f, "area", filled(area), "Область (area) задана");
        req(f, "parent_sync", parentInSync(parentId, parentByEdge),
            "Родитель совпадает в ребре PARENT_OF и поле parent_id");

        hint(f, "owner", filled(owner), "Владелец указан — желательно");
        hint(f, "game_icon", filled(gameIcon), "Иконка задана — желательно");

        return score("component", f);
    }

    /**
     * Ребро и поле согласованы. Корень — оба пусты — согласован: родителя у него
     * нет, и требовать заполненности значило бы требовать несуществующего.
     *
     * <p>Сравнивается ЗНАЧЕНИЕ, а не факт непустоты. Проверка вида «ребро есть и
     * поле есть» проходила бы и тогда, когда они указывают на РАЗНЫХ родителей —
     * то есть ровно в том случае, ради которого заводится.
     *
     * <p>Два ребра сразу — тоже расхождение, а не «возьмём первое». Поле хранит
     * одного родителя, значит второе ребро в поле не поместилось, и какой из
     * двух родителей настоящий, запись уже не отвечает. На проде таких вершин
     * ноль (замер 27.08.2026), и проверка нужна, чтобы ноль не стал единицей
     * незаметно.
     */
    private static boolean parentInSync(String parentId, Object parentByEdge) {
        List<String> edges = nonBlankValues(parentByEdge);
        String field = filled(parentId) ? parentId.trim() : null;
        if (edges.isEmpty()) return field == null;
        return edges.size() == 1 && edges.get(0).equals(field);
    }

    /** Непустые значения обхода; скаляр и список ведут себя одинаково. */
    private static List<String> nonBlankValues(Object raw) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        if (raw instanceof Collection<?> c) {
            for (Object o : c) {
                if (o != null && !String.valueOf(o).isBlank()) out.add(String.valueOf(o).trim());
            }
            return out;
        }
        String s = String.valueOf(raw);
        if (!s.isBlank()) out.add(s.trim());
        return out;
    }

    /**
     * Веха (KnowMilestone). Без даты веха не ложится на план — перестаёт быть
     * вехой и становится просто ярлыком.
     *
     * <p>Имена полей — как в модели: {@code label} и {@code date_display}, а не
     * «title»/«target_date». Проверка, названная по несуществующему полю,
     * краснела бы всегда (D-2026-LORE-QUALITY-NO-PHANTOM-CHECKS).
     */
    static Result evaluateMilestone(String label, String dateDisplay, Object sprints, Object products) {
        List<Finding> f = new ArrayList<>();

        req(f, "label", filled(label), "Название задано");
        req(f, "date_display", filled(dateDisplay), "Дата задана");
        // RM-S3: ТРЕБОВАНИЕ, а не подсказка. После
        // D-2026-LORE-PRODUCT-IS-OWN-ENTITY носитель дорожной карты — продукт,
        // и веха без продукта это незаполненность, а не «портфельная веха»:
        // она не попадёт ни в одну карту и не будет видна никому.
        req(f, "products", any(products), "Указан продукт — карта принадлежит продукту");

        hint(f, "sprints", any(sprints), "Привязаны спринты — иначе веха ничем не наполнена");

        return score("milestone", f);
    }

    /**
     * Открытый вопрос (KnowQuestion). Вопрос без адресата не закрывается: он
     * висит в реестре, всеми прочитан и никем не взят.
     */
    static Result evaluateQuestion(String title, String status, String owner,
                                   String dueDate, Object links) {
        List<Finding> f = new ArrayList<>();

        req(f, "title", filled(title), "Заголовок задан");
        req(f, "status", filled(status), "Статус задан");
        req(f, "owner", filled(owner), "Владелец указан — без адресата вопрос не закрывается");

        hint(f, "due_date", filled(dueDate), "Срок задан — желательно (иначе просроченность не видна)");
        hint(f, "links", any(links), "Связь с ADR/компонентом — желательно");

        return score("question", f);
    }

    /** Порог «раздел заполнен, а не отписан». Символы, не слова: слова считать дороже, а разницы нет. */
    private static final int MIN_BODY = 120;

    private static int len(String s) {
        return s == null ? 0 : s.trim().length();
    }

    /** Заголовок markdown, содержащий фрагмент (без учёта регистра и окончания). */
    private static boolean hasHeading(String md, String fragment) {
        if (md == null) return false;
        return java.util.regex.Pattern
            .compile("(?mi)^#{1,6}\\s*.*" + java.util.regex.Pattern.quote(fragment))
            .matcher(md).find();
    }

    /** Ссылка на сущность корпуса: ADR-… или D-… . */
    private static boolean refsEntity(String md) {
        return md != null && java.util.regex.Pattern.compile("\\b(ADR-[A-Z0-9-]+|D-[A-Z0-9-]{4,})")
            .matcher(md).find();
    }

    private static void opt(List<Finding> f, boolean requiredHere, String code, boolean ok, String msg) {
        f.add(new Finding(code, ok, requiredHere, msg));
    }

    /**
     * Фаза спринта.
     *
     * <p><b>Про «типизацию фаз».</b> Поля типа у {@code KnowPhase} в схеме НЕТ:
     * фаза несёт {@code phase_id}, {@code order_index}, заголовок и
     * {@code summary_md}. Завести тип фазы — это миграция схемы плюс канон-словарь,
     * то есть решение о модели, а не правка линтера. Пока проверяется полнота
     * тем, что есть: у фазы должно быть чем отличаться от соседней.
     *
     * <p>Безымянная фаза с пустым описанием — это разделитель, а не этап: она
     * ничего не говорит ни о содержании, ни о готовности, и в отчётах даёт
     * строку, по которой нельзя принять решение.
     */
    static Result evaluatePhase(String title, String summaryMd, Integer orderIndex) {
        List<Finding> f = new ArrayList<>();

        req(f, "title", filled(title), "Название задано");
        req(f, "order_index", orderIndex != null, "Порядковый номер задан");
        // Описание — подсказка: короткая фаза с говорящим названием может
        // обойтись без него, и требовать текст ради текста значит поощрять воду.
        hint(f, "summary", filled(summaryMd), "Описание заполнено — желательно");

        return score("phase", f);
    }

    private static Result score(String kind, List<Finding> f) {
        int max = 0, score = 0;
        for (Finding x : f) if (x.required()) { max++; if (x.ok()) score++; }
        return new Result(kind, score, max, f);
    }

    private static void req(List<Finding> f, String code, boolean ok, String msg) {
        f.add(new Finding(code, ok, true, msg));
    }

    private static void hint(List<Finding> f, String code, boolean ok, String msg) {
        f.add(new Finding(code, ok, false, msg));
    }
}
