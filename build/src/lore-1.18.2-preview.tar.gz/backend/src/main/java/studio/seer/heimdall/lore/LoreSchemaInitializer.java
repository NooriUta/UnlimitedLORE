package studio.seer.heimdall.lore;

import io.quarkus.runtime.Startup;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

/**
 * Idempotent DDL bootstrap for system_aida_lore.
 * Runs at startup; all statements use IF NOT EXISTS so re-runs are safe.
 * Pattern: MimirSessionInitializer.
 */
@ApplicationScoped
@Startup
public class LoreSchemaInitializer {

    private static final Logger LOG = Logger.getLogger(LoreSchemaInitializer.class);

    @ConfigProperty(name = "lore.enabled", defaultValue = "false")
    boolean enabled;

    // Standalone gate: shared system_aida_lore already has the schema, so skip
    // DDL on boot by default. Set lore.bootstrap=true for a fresh ArcadeDB.
    @ConfigProperty(name = "lore.bootstrap", defaultValue = "false")
    boolean bootstrap;

    @ConfigProperty(name = "lore.db", defaultValue = "system_aida_lore")
    String db;

    @Inject
    MartCredentials mart;

    @Inject
    @RestClient
    LoreCommandClient client;

    /**
     * Явная точка синхронизации для LoreSchemaMigrationRunner: инъекция
     * @ApplicationScoped-бина даёт ленивый прокси, и @PostConstruct НЕ выполняется
     * до первого вызова метода. Раннер зовёт этот no-op, чтобы bootstrap-DDL
     * гарантированно отработал ДО миграций (иначе порядок @Startup-бинов — лотерея,
     * и раннер вставал на БД без базовых типов).
     */
    public void ensureReady() { /* всё делает @PostConstruct при создании бина */ }

    /**
     * D-2026-LORE-AUTO-BOOTSTRAP-EMPTY-DB: ядро поднималось ТОЛЬКО флагом, а про
     * флаг знал лишь наш compose — чужая установка вставала с битым продуктовым
     * слоем. Ядровые типы, по которым база считается инициализированной.
     */
    static final List<String> CORE_TYPES = List.of("KnowTask", "KnowSprint", "KnowADR");

    /** Попыток пробы ядровых типов и пауза между ними (поля, а не конфиг: тесты ставят 0 мс). */
    int probeAttempts = 10;
    long probeDelayMs = 1000;

    /** Итог решения на этом старте. Читать ТОЛЬКО геттером: поле через CDI-прокси — null/false. */
    private volatile boolean bootstrapped;

    /** Поднималось ли ядро на этом старте (флагом или потому, что база пуста). */
    public boolean bootstrapped() { return bootstrapped; }

    /**
     * Поднимать ли ядро. {@code coreTypesPresent == null} — проба не ответила:
     * это «не смогли проверить», а не «пусто», и DDL наудачу по недоступной базе
     * не гоняется (остановит предохранитель старта, а не тишина).
     */
    static boolean shouldBootstrap(boolean flag, Boolean coreTypesPresent) {
        return flag || Boolean.FALSE.equals(coreTypesPresent);
    }

    /** Разбор ответа {@code SELECT name FROM schema:types}: есть ли хоть один ядровой тип. */
    static Boolean coreTypesPresent(Object result) {
        if (!(result instanceof List<?> rows)) return null;
        for (Object r : rows) {
            if (r instanceof java.util.Map<?, ?> m && CORE_TYPES.contains(String.valueOf(m.get("name")))) return true;
        }
        return false;
    }

    /**
     * Проба с повтором: только что созданная база (установка с нуля — база
     * создана, бэкенд стартовал следом) первые мгновения отвечает ошибкой, и
     * одна неудача означала бы «не смогли проверить» → ядро не поднято → отказ
     * старта. После {@link #probeAttempts} неудач — по-прежнему null, без DDL.
     */
    private Boolean probeCoreTypes() {
        String last = null;
        for (int i = 1; i <= probeAttempts; i++) {
            try {
                var res = client.command(db, basicAuth(),
                        new LoreCommandClient.LoreCommand("sql", "SELECT name FROM schema:types"))
                    .await().indefinitely();
                return coreTypesPresent(res == null ? null : res.result());
            } catch (Exception e) {
                last = e.getMessage();
                LOG.debugf("[LORE] проба ядровых типов %d/%d: %s", i, probeAttempts, last);
                if (i < probeAttempts && probeDelayMs > 0) {
                    try { Thread.sleep(probeDelayMs); }
                    catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; }
                }
            }
        }
        LOG.warnf("[LORE] проба ядровых типов в %s не ответила за %d попыток: %s — автоподъём ядра не выполняется",
            db, probeAttempts, last);
        return null;
    }

    @PostConstruct
    void init() {
        if (!enabled) {
            LOG.info("[LORE] schema init skipped (lore.enabled off)");
            return;
        }
        Boolean present = bootstrap ? null : probeCoreTypes();
        if (!shouldBootstrap(bootstrap, present)) {
            LOG.infof("[LORE] schema init skipped (ядро есть: %s; lore.bootstrap off)",
                present == null ? "не проверено" : "да");
            return;
        }
        if (!bootstrap) LOG.warnf("[LORE] в %s нет ядровых типов %s — ядро поднимается без флага (D-2026-LORE-AUTO-BOOTSTRAP-EMPTY-DB)", db, CORE_TYPES);
        bootstrapped = true;
        LOG.infof("[LORE] Initializing schema in %s", db);
        // Свежесозданная БД первые мгновения отвечает 500 на команды — DDL,
        // запущенный сразу после create database, молча падал на ПЕРВЫХ типах
        // (execIgnoreError глотал), и корпус жил без KnowADR/LoreComponent.
        // Пробуем реальную команду до успеха, потом катим DDL.
        // Проба обязана быть ПИШУЩЕЙ: чтение готово раньше, чем коммиты DDL, —
        // read-проба проходила, а CREATE TYPE следом всё ещё падал.
        boolean ready = false;
        for (int i = 0; i < 20 && !ready; i++) {
            try {
                client.command(db, basicAuth(),
                    new LoreCommandClient.LoreCommand("sql", "CREATE VERTEX TYPE LoreBootProbe IF NOT EXISTS"))
                    .await().indefinitely();
                ready = true;
            } catch (Exception e) {
                try { Thread.sleep(500); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; }
            }
        }
        if (!ready) LOG.errorf("[LORE] БД %s не ответила на пробу — DDL пойдёт наудачу (смотри ошибки ниже)", db);
        DDL.forEach(this::execIgnoreError);
        histValidFromText().forEach(this::execIgnoreError);
        LOG.infof("[LORE] Schema init complete for %s", db);
    }

    private void execIgnoreError(String sql) {
        try {
            client.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql", sql))
                  .await().indefinitely();
        } catch (Exception e) {
            LOG.tracef("[LORE DDL] '%s' → %s", sql, e.getMessage());
        }
    }

    private String basicAuth() {
        return mart.basicAuth();
    }

    // ── Vertex types ──────────────────────────────────────────────────────────
    static final List<String> DDL = List.of(
        // ArcadeDB's own base types — NOT auto-present on a freshly `create
        // database`'d instance (only discovered via C5's testcontainer run
        // against a genuinely empty DB; the shared system_aida_lore has had
        // these for years, which is why this was never hit in prod). Safe to
        // leave here permanently: IF NOT EXISTS makes it a no-op there.
        "CREATE VERTEX TYPE V IF NOT EXISTS",
        "CREATE EDGE TYPE E IF NOT EXISTS",
        // Справочники. Легаси-словари статусов Status* ×6, TrackType и рёбра HAS_STATUS / OF_TYPE
        // сняты V89 (SPRINT_LORE_PRODUCT_BACKLOG/SELF-PROVISION-STANDALONE): статусы — KnowDictEntry
        // + status_raw истории, тип трека — PlanTrack.area. Возврат сторожит RetiredLegacyStatusTypesTest.
        "CREATE VERTEX TYPE LoreComponent    IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE LoreTechnology   IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE LoreTag          IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE PlanTrack        IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE PlanSection      IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE PlanConfig       IF NOT EXISTS EXTENDS V",
        // Ядра
        "CREATE VERTEX TYPE KnowDecision     IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowADR          IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowTag          IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowSprint       IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowSpec         IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowFinding      IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowRelease      IF NOT EXISTS EXTENDS V",
        // KnowPR не создавался НИГДЕ — ни здесь, ни миграциями. На проде он есть
        // (543 записи) только потому, что появился в обход схемы: ArcadeDB
        // схемо-гибкий и создаёт тип на первой записи. На чистой БД его нет, и
        // это вскрылось лишь когда V12 попытался объявить KnowPR.title —
        // «Type with name 'KnowPR' was not found» на lore_ci_test.
        // Свойства — по факту прода: pr_id/pr_number/title/git_project/pr_uid.
        "CREATE VERTEX TYPE KnowPR           IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowMilestone    IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowPhase        IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowTask         IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE PlanCheckpoint   IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE PlanVersion      IF NOT EXISTS EXTENDS V",
        // Hist (SCD2)
        "CREATE VERTEX TYPE KnowDecisionHist  IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowADRHist       IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowSprintHist    IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowSpecHist      IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowFindingHist   IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowReleaseHist   IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowMilestoneHist IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowPhaseHist     IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowTaskHist      IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowDictEntryHist IF NOT EXISTS EXTENDS V", // AL-43

        // ── Edge types ────────────────────────────────────────────────────────
        "CREATE EDGE TYPE DECIDED_IN       IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE FORMALIZED_AS    IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE IMPLEMENTED_IN   IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE DEPENDS_ON       IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE SUPERSEDES       IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE YIELDED          IF NOT EXISTS EXTENDS E",
        // PRODUCED (QGJobTask→QGRecommendation) and PROMOTED_TO (QGRecommendation→
        // KnowTask) were used by LoreQgResource's CREATE EDGE ... IF NOT EXISTS calls
        // without an explicit type declaration here — ArcadeDB auto-vivifies the type
        // on first use, so this worked on the live shared DB, but a fresh bootstrap
        // (LORE_BOOTSTRAP=true) DB had no upfront declaration for either. Added for
        // parity with every other edge type (T13, 2026-07-14).
        "CREATE EDGE TYPE PRODUCED         IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE PROMOTED_TO      IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE VALIDATES        IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE BELONGS_TO       IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE DOCUMENTED_IN    IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE TAGGED_WITH      IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE RELEASED_IN      IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE INCLUDES         IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE GATES            IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE PART_OF          IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE IN_PHASE         IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE PARENT_OF        IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE USES             IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE ON_MILESTONE     IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE TARGETS_MILESTONE IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE CHANGED_IN       IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE IMPLEMENTED_IN_RELEASE IF NOT EXISTS EXTENDS E",
        "CREATE EDGE TYPE HAS_STATE        IF NOT EXISTS EXTENDS E",
        // ADR-LORE-012 level B: component → area dictionary vertex (edge-normalized
        // area; the LoreComponent.area string is kept in sync as a dual-write).
        "CREATE EDGE TYPE IN_AREA          IF NOT EXISTS EXTENDS E",
        // MG3-01: Runbook → ADR — real graph edge, replaces the text-only
        // [[ADR-ID]] wiki link some runbooks carried in content_md.
        "CREATE EDGE TYPE REFERENCES_ADR   IF NOT EXISTS EXTENDS E",

        // ── RM-P6 / D-2026-LORE-PRODUCT-IS-OWN-ENTITY: продуктовая ось ────────
        // Продукт — запись справочника (KnowDictEntry, dict_type='product'), тем
        // же приёмом, что и область (ADR-LORE-012 level B). Новый тип ВЕРШИНЫ не
        // заводится намеренно: имя `product` в коде уже занято продуктовым слоем
        // ADR-LORE-022 (Feature → UseCase → Actor), и своя вершина посадила бы на
        // одно слово два разных понятия.
        //
        // IN_PRODUCT: LoreComponent → продукт. Ребро с ролью, а не поле: компонент
        // бывает в двух продуктах ПО-РАЗНОМУ — HARPA разрабатывается в AIDA, а
        // используется маркетингом (BALDR). Одна принадлежность этого не выражает.
        "CREATE EDGE TYPE IN_PRODUCT       IF NOT EXISTS EXTENDS E",
        "CREATE PROPERTY IN_PRODUCT.role   IF NOT EXISTS STRING",
        // PARENT_PRODUCT: продукт → родительский продукт. ОТДЕЛЬНЫЙ тип, а не
        // переиспользование PARENT_OF: дерево продуктов и дерево компонентов —
        // разные деревья. Замерено 27.08.2026: HOUND лежит внутри DALI по
        // компонентам, но является суб-продуктом AIDA; MT лежит вне поддерева
        // AIDA по компонентам, но является её суб-продуктом. Смешать их в одном
        // типе ребра значит требовать type-guard в каждом обходе — и получить
        // обход, который молча пойдёт не по тому дереву.
        "CREATE EDGE TYPE PARENT_PRODUCT   IF NOT EXISTS EXTENDS E",
        // TARGETS_PRODUCT: веха → продукт (RM-S1). Носитель дорожной карты —
        // продукт, а не проект. Отдельный тип от IN_PRODUCT: компонент ВХОДИТ
        // в продукт, веха НАЦЕЛЕНА на него, и слайс products читает состав как
        // in('IN_PRODUCT').component_id — вехи на общем типе приехали бы туда
        // пачкой null'ов. Имя парное к TARGETS_MILESTONE.
        "CREATE EDGE TYPE TARGETS_PRODUCT  IF NOT EXISTS EXTENDS E",

        // ── Unique indexes on PK fields ───────────────────────────────────────
        // NB 2026-07-10: CREATE INDEX ... UNIQUE does NOT implicitly create the
        // property either (the 2026-07-01 note below only checked NOTUNIQUE) —
        // on a truly fresh DB it fails with "Cannot create the index on type
        // 'X.y' because the property does not exist". Found via C5's ArcadeDB
        // testcontainer run: the shared system_aida_lore has carried these
        // properties for years, which is why this never surfaced in prod.
        // Explicit CREATE PROPERTY first, for every PK field below.
        "CREATE PROPERTY LoreComponent.component_id   IF NOT EXISTS STRING",
        "CREATE PROPERTY LoreTechnology.tech_id       IF NOT EXISTS STRING",
        "CREATE PROPERTY LoreTag.tag_id               IF NOT EXISTS STRING",
        "CREATE PROPERTY PlanTrack.track_id           IF NOT EXISTS STRING",
        "CREATE PROPERTY PlanSection.section_id       IF NOT EXISTS STRING",
        "CREATE PROPERTY PlanConfig.config_id         IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDecision.decision_id     IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDecision.component_id    IF NOT EXISTS STRING",  // ADR-019: child-of-ADR filter axis (vertex field, no Hist)
        "CREATE PROPERTY KnowADR.adr_id               IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowTag.tag_id               IF NOT EXISTS STRING",
        // SUPERTAGS-SPIKE: свободные поля тега на ребре (раздел edge_free_fields модели) — словарь значений
        // без истории и отметки «кто/когда поставил», «кто/когда правил поля». Голое ребро их не несёт.
        "CREATE PROPERTY TAGGED_WITH.fields           IF NOT EXISTS MAP",
        "CREATE PROPERTY TAGGED_WITH.tagged_at        IF NOT EXISTS DATETIME",
        "CREATE PROPERTY TAGGED_WITH.tagged_by        IF NOT EXISTS STRING",
        "CREATE PROPERTY TAGGED_WITH.changed_at       IF NOT EXISTS DATETIME",
        "CREATE PROPERTY TAGGED_WITH.changed_by       IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowSprint.sprint_id         IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowSpec.spec_id             IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowFinding.finding_id       IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowRelease.release_id       IF NOT EXISTS STRING",
        // KnowPR: состав по факту прода (см. комментарий у CREATE VERTEX TYPE).
        "CREATE PROPERTY KnowPR.pr_id                 IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowPR.pr_uid                IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowPR.pr_number             IF NOT EXISTS INTEGER",
        "CREATE PROPERTY KnowPR.title                 IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowPR.git_project           IF NOT EXISTS STRING",
        // DBR-17: «UPDATE KnowPR … UPSERT WHERE pr_uid» (release_link, автопривязка
        // forgejo_pr_merge) на чистой базе без индекса отвечал 400 — тот же класс,
        // что QGJobTask/QGRecommendation ниже. Найдено LoreReleaseLinkOutcomeLiveDbTest.
        "CREATE INDEX IF NOT EXISTS ON KnowPR (pr_uid) UNIQUE",
        "CREATE PROPERTY KnowMilestone.milestone_id   IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowPhase.phase_uid          IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowTask.task_uid            IF NOT EXISTS STRING",
        "CREATE PROPERTY PlanCheckpoint.checkpoint_id IF NOT EXISTS STRING",
        "CREATE PROPERTY PlanVersion.version_id       IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON LoreComponent   (component_id) UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON LoreTechnology  (tech_id)      UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON LoreTag         (tag_id)       UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON PlanTrack       (track_id)     UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON PlanSection     (section_id)   UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON PlanConfig      (config_id)    UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowDecision    (decision_id)  UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowDecision    (component_id) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowADR         (adr_id)       UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowTag         (tag_id)       UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowSprint      (sprint_id)    UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowSpec        (spec_id)      UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowFinding     (finding_id)   UNIQUE",
        // REL-UID-01: номер версии повторяется между проектами (v1.4.1 у сайта и
        // у монорепо) — уникален ключ «проект#версия», а голый номер — только
        // для поиска. Прод так и живёт (16 общих номеров на 07.11.2026); здесь
        // приводим к нему свежую установку, которая отказала бы второму проекту.
        "CREATE PROPERTY KnowRelease.release_uid      IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowRelease     (release_id)   NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowRelease     (release_uid)  UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowMilestone   (milestone_id) UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowPhase       (phase_uid)    UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowTask        (task_uid)     UNIQUE",
        // NB 2026-07-01: CREATE INDEX ... NOTUNIQUE (unlike UNIQUE) does NOT
        // implicitly create the property — on a truly fresh DB it fails with
        // "property does not exist". Explicit CREATE PROPERTY first, everywhere
        // a NOTUNIQUE index follows. Confirmed by re-running backend/db-schema/
        // bootstrap.sh against a live DB missing exactly these two properties.
        "CREATE PROPERTY KnowTask.task_id IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowTask        (task_id) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON PlanCheckpoint  (checkpoint_id) UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON PlanVersion     (version_id)   UNIQUE",

        // SPRINT_PLANITEM_RETIRE: valid_from had no formal property (unlike valid_to
        // below) — different write paths stored it as different internal types
        // across the table (String vs DATETIME, different precisions), and
        // ORDER BY valid_from eventually threw "Comparison method violates its
        // general contract!" (Java TimSort on an inconsistent comparator), taking
        // down sprint_starts and /lore/analytics. Declaring the property doesn't
        // retroactively fix already-stored rows (fixed separately, one-off,
        // rewriting each value through a bind-parameter command) but prevents new
        // writes from drifting again.
        "CREATE PROPERTY KnowSprintHist.valid_from  IF NOT EXISTS DATETIME",

        // RM-P12 объявлял остальные valid_from ТЕКСТОМ (ISO-8601 UTC); RM-P13
        // (решение владельца 05.11.2026: «единый формат, рекомендованный БД»)
        // свёл ВСЕ *Hist к нативному DATETIME — на живой БД это делает шаг V56,
        // здесь свежая БД сразу приходит к той же схеме. Граница с браузером
        // (DATETIME печатается «через пробел», JS читает это как местное время)
        // закрыта в выдаче слайсов: LoreTimeFormat.isoUtcRows.
        //
        // Строки — литералами, а не генерацией: LoreHistValidFromTypedTest
        // сверяет реестр HIST_VALID_FROM_TEMPORAL с этими объявлениями по тексту
        // исходника. KnowRunbookHist и KnowDocHist — ниже, после своих типов.
        "CREATE PROPERTY KnowDecisionHist.valid_from  IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowADRHist.valid_from       IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowSpecHist.valid_from      IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowFindingHist.valid_from   IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowReleaseHist.valid_from   IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowMilestoneHist.valid_from IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowPhaseHist.valid_from     IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowTaskHist.valid_from      IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowDictEntryHist.valid_from IF NOT EXISTS DATETIME",

        // ── Hist valid_to indexes (current-row queries) ───────────────────────
        "CREATE PROPERTY KnowDecisionHist.valid_to  IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowADRHist.valid_to       IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowSprintHist.valid_to    IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowSpecHist.valid_to      IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowFindingHist.valid_to   IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowReleaseHist.valid_to   IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowMilestoneHist.valid_to IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowPhaseHist.valid_to     IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowTaskHist.valid_to      IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowDictEntryHist.valid_to IF NOT EXISTS DATETIME", // AL-43
        "CREATE INDEX IF NOT EXISTS ON KnowDecisionHist  (valid_to) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowADRHist       (valid_to) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowSprintHist    (valid_to) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowSpecHist      (valid_to) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowFindingHist   (valid_to) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowReleaseHist   (valid_to) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowMilestoneHist (valid_to) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowPhaseHist     (valid_to) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowTaskHist      (valid_to) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowDictEntryHist (valid_to) NOTUNIQUE", // AL-43

        // ── Phase 5 (v1.2): KnowRunbook + QualityGate + QGMetric ────────────────
        "CREATE VERTEX TYPE KnowRunbook     IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowRunbookHist IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE QualityGate     IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE QGMetric        IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowDoc         IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE KnowDocHist     IF NOT EXISTS EXTENDS V",

        "CREATE EDGE TYPE MEASURED_BY       IF NOT EXISTS EXTENDS E",

        "CREATE PROPERTY KnowRunbookHist.state_uid  IF NOT EXISTS STRING",
        // RM-P13: обе даты — DATETIME, как у остальных *Hist. До RM-P13 тут стояло
        // STRING, а на проде valid_to был DATETIME (снимок db-schema/schema-metadata.json):
        // свежая БД расходилась с боевой.
        "CREATE PROPERTY KnowRunbookHist.valid_from  IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowRunbookHist.valid_to    IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowRunbookHist.content_md  IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowRunbook.runbook_id      IF NOT EXISTS STRING",
        "CREATE PROPERTY QualityGate.qg_id           IF NOT EXISTS STRING",
        "CREATE PROPERTY QGMetric.metric_id          IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDoc.doc_id              IF NOT EXISTS STRING",

        "CREATE INDEX IF NOT EXISTS ON KnowRunbook    (runbook_id)  UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowRunbookHist (state_uid)  UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowRunbookHist (valid_to)   NOTUNIQUE",

        // AL-43: KnowDictEntry SCD2 history — composite key (dict_type, code)
        // denormalized onto the Hist row, same choice LoreSlices' history_dict
        // slice relies on (see LoreSchemaMigrations Step 16 for the full field set).
        "CREATE PROPERTY KnowDictEntryHist.state_uid IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDictEntryHist.dict_type IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDictEntryHist.code      IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowDictEntryHist (state_uid) UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowDictEntryHist (dict_type, code) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON QualityGate   (qg_id)        UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON QGMetric      (metric_id)    UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowDoc       (doc_id)       UNIQUE",
        // Bilingual Markdown body — content_html stays as a legacy field for the
        // pre-existing HTML-fragment docs (rendered sandboxed); new/updated docs
        // author clean Markdown per language instead (rendered in-DOM via
        // MartProse — inherits the app's font, supports mermaid fences).
        "CREATE PROPERTY KnowDoc.content_md_en IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDoc.content_md_ru IF NOT EXISTS STRING",
        // DeepWiki-style page tree: DOC_CHILD_OF (child → parent) mirrors every
        // other relationship in this schema (BELONGS_TO/DEPENDS_ON/SUPERSEDES/
        // TAGGED_WITH/TARGETS_MILESTONE) being an edge, not a plain foreign-key
        // field — a doc has at most one parent, enforced in code (doc/parent
        // replaces any existing outgoing edge before creating the new one), not
        // in the schema. sort_order is a genuine intrinsic property (position
        // among siblings), same pattern as KnowTask.order_index.
        // ArcadeDB DDL note (see Phase 6 comment below): no EXTENDS V/E via SQL.
        "CREATE EDGE TYPE DOC_CHILD_OF IF NOT EXISTS",
        "CREATE PROPERTY KnowDoc.sort_order IF NOT EXISTS INTEGER",
        "CREATE PROPERTY KnowDocHist.valid_from IF NOT EXISTS DATETIME",
        "CREATE PROPERTY KnowDocHist.valid_to IF NOT EXISTS DATETIME",
        "CREATE INDEX IF NOT EXISTS ON KnowDocHist   (valid_to) NOTUNIQUE",

        // ── Phase 6 (v1.3): ClRoutine* — routine run outputs stored in LORE ──
        // ArcadeDB DDL: CREATE VERTEX/EDGE TYPE (no EXTENDS V/E via SQL),
        // properties via CREATE PROPERTY <Type>.<prop> <TYPE>
        "CREATE VERTEX TYPE ClRoutineRun        IF NOT EXISTS",
        "CREATE PROPERTY ClRoutineRun.routine_name     IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineRun.run_date         IF NOT EXISTS DATE",
        "CREATE PROPERTY ClRoutineRun.run_ts           IF NOT EXISTS DATETIME",
        "CREATE PROPERTY ClRoutineRun.status           IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineRun.flags            IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineRun.detail_md        IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineRun.gates_failed_ids IF NOT EXISTS STRING",
        // SMART-QG run identity (qg_run_log UPSERT WHERE run_id) — durable
        "CREATE PROPERTY ClRoutineRun.run_id           IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineRun.started_at       IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineRun.finished_at      IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON ClRoutineRun (run_id) UNIQUE",

        "CREATE VERTEX TYPE ClRoutineMetric     IF NOT EXISTS",
        "CREATE PROPERTY ClRoutineMetric.routine_name  IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineMetric.run_date      IF NOT EXISTS DATE",
        "CREATE PROPERTY ClRoutineMetric.metric_key    IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineMetric.value         IF NOT EXISTS DOUBLE",
        "CREATE PROPERTY ClRoutineMetric.unit          IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineMetric.target        IF NOT EXISTS DOUBLE",
        "CREATE PROPERTY ClRoutineMetric.status        IF NOT EXISTS STRING",
        // SMART-QG metric identity + evidence (qg_run_log UPSERT WHERE metric_id) — durable
        "CREATE PROPERTY ClRoutineMetric.metric_id     IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineMetric.run_id        IF NOT EXISTS STRING",
        // source = exact reproducer command + file:line evidence, drives _qg_recommend
        "CREATE PROPERTY ClRoutineMetric.source        IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON ClRoutineMetric (metric_id) UNIQUE",

        "CREATE VERTEX TYPE ClRoutineSprintFlag IF NOT EXISTS",
        "CREATE PROPERTY ClRoutineSprintFlag.routine_name IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineSprintFlag.run_date     IF NOT EXISTS DATE",
        "CREATE PROPERTY ClRoutineSprintFlag.sprint_id    IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineSprintFlag.flag         IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineSprintFlag.lore_status  IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineSprintFlag.git_status   IF NOT EXISTS STRING",

        "CREATE VERTEX TYPE ClRoutineOutput     IF NOT EXISTS",
        "CREATE PROPERTY ClRoutineOutput.routine_name  IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineOutput.run_date      IF NOT EXISTS DATE",
        "CREATE PROPERTY ClRoutineOutput.output_type   IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineOutput.title         IF NOT EXISTS STRING",
        "CREATE PROPERTY ClRoutineOutput.content_md    IF NOT EXISTS STRING",

        "CREATE EDGE TYPE ClRoutineHasOutput    IF NOT EXISTS",

        "CREATE INDEX IF NOT EXISTS ON ClRoutineOutput(routine_name, run_date, output_type) UNIQUE",

        // ── Phase 7 (SPEC-BRAGI-ARCHIVE-001 v0.4): BRAGI content archive ────────
        // Facts+metrics dataset (спека: "Этот архив = факты и метрики"), distinct
        // from the Forseti planning graph — flat vertices, no SCD2/Hist twins.
        // MetricSnapshot itself is ARC-02 (LSM_TIMESERIES, separate storage engine —
        // no graph edges to it; consumers reference it by object_type+object_id tags).
        "CREATE VERTEX TYPE BragiPublication IF NOT EXISTS",
        "CREATE PROPERTY BragiPublication.publication_id  IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPublication.title            IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPublication.topic             IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPublication.main_text_md      IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPublication.type              IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPublication.status_general    IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPublication.source_file_path  IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON BragiPublication (publication_id) UNIQUE",

        "CREATE VERTEX TYPE BragiVariant IF NOT EXISTS",
        "CREATE PROPERTY BragiVariant.variant_id      IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiVariant.text_md         IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiVariant.status          IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiVariant.url             IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiVariant.published_at    IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON BragiVariant (variant_id) UNIQUE",

        "CREATE VERTEX TYPE BragiAsset IF NOT EXISTS",
        "CREATE PROPERTY BragiAsset.asset_id     IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiAsset.asset_type   IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiAsset.file_url     IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiAsset.alt          IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiAsset.size_bytes   IF NOT EXISTS LONG",
        "CREATE INDEX IF NOT EXISTS ON BragiAsset (asset_id) UNIQUE",

        "CREATE VERTEX TYPE BragiChannel IF NOT EXISTS",
        "CREATE PROPERTY BragiChannel.channel_id    IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiChannel.channel_type  IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiChannel.url_handle    IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiChannel.funnel_role   IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiChannel.rules_md      IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON BragiChannel (channel_id) UNIQUE",

        "CREATE VERTEX TYPE BragiKeyword IF NOT EXISTS",
        "CREATE PROPERTY BragiKeyword.keyword_id    IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiKeyword.phrase        IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiKeyword.cluster       IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiKeyword.freq_exact    IF NOT EXISTS INTEGER",
        "CREATE PROPERTY BragiKeyword.freq_broad    IF NOT EXISTS INTEGER",
        "CREATE PROPERTY BragiKeyword.source        IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiKeyword.intent        IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiKeyword.region_engine IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiKeyword.measured_at   IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON BragiKeyword (keyword_id) UNIQUE",

        "CREATE VERTEX TYPE BragiPage IF NOT EXISTS",
        "CREATE PROPERTY BragiPage.page_id       IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPage.url           IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPage.title         IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPage.description   IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPage.page_type     IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiPage.deployed_at   IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON BragiPage (page_id) UNIQUE",

        "CREATE VERTEX TYPE BragiCampaign IF NOT EXISTS",
        "CREATE PROPERTY BragiCampaign.campaign_id    IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiCampaign.utm_source     IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiCampaign.utm_medium     IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiCampaign.utm_campaign   IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiCampaign.target_url     IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiCampaign.period         IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON BragiCampaign (campaign_id) UNIQUE",

        "CREATE VERTEX TYPE BragiCompetitor IF NOT EXISTS",
        "CREATE PROPERTY BragiCompetitor.competitor_id IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiCompetitor.name          IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON BragiCompetitor (competitor_id) UNIQUE",

        "CREATE VERTEX TYPE BragiInsight IF NOT EXISTS",
        "CREATE PROPERTY BragiInsight.insight_id     IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiInsight.statement_md   IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiInsight.insight_date   IF NOT EXISTS STRING",
        // Обоснование (замеры) — MetricSnapshot живёт в отдельном TIMESERIES-движке
        // и не участвует в графовых рёбрах; ссылка на обоснование хранится текстом
        // (диапазон дат/метрика/объект), не рёбрами.
        "CREATE PROPERTY BragiInsight.evidence_ref   IF NOT EXISTS STRING",
        // V2-05: о какой строке ретро вывод — id вариации или публикации. Поле, а
        // не текст обоснования: чип строки находит инсайт точным равенством.
        "CREATE PROPERTY BragiInsight.subject_id     IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON BragiInsight (insight_id) UNIQUE",

        "CREATE VERTEX TYPE BragiIntegration IF NOT EXISTS",
        "CREATE PROPERTY BragiIntegration.integration_id  IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiIntegration.service          IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiIntegration.purpose          IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiIntegration.endpoint         IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiIntegration.scope            IF NOT EXISTS STRING",
        // Ссылка на секрет (env/vault key name) — НИКОГДА значение токена.
        "CREATE PROPERTY BragiIntegration.secret_ref       IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiIntegration.status           IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiIntegration.last_called_at   IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON BragiIntegration (integration_id) UNIQUE",

        // Рубрикатор (SPRINT_BRAGI_ARCHIVE_FOLLOWUP): фиксированный список
        // рубрик, вручную назначаемых на публикации и ключевые слова
        // (IN_RUBRIC от обоих типов) — отдельная таксономия поверх
        // произвольного BragiKeyword.cluster, не заменяет его.
        "CREATE VERTEX TYPE BragiRubric IF NOT EXISTS",
        "CREATE PROPERTY BragiRubric.rubric_id    IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiRubric.name         IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiRubric.description  IF NOT EXISTS STRING",
        "CREATE PROPERTY BragiRubric.order_index  IF NOT EXISTS INTEGER",
        "CREATE INDEX IF NOT EXISTS ON BragiRubric (rubric_id) UNIQUE",

        // Edges — 7 из заметки ARC-01 + 2 доп. для полноты ER-модели спеки v0.4
        // (Keyword→Page целевая страница, Campaign→Variant вариация) + IN_RUBRIC
        "CREATE EDGE TYPE HAS_VARIANT      IF NOT EXISTS",
        "CREATE EDGE TYPE HAS_ASSET        IF NOT EXISTS",
        "CREATE EDGE TYPE TARGETS_KEY      IF NOT EXISTS",
        "CREATE EDGE TYPE IN_CHANNEL       IF NOT EXISTS",
        "CREATE EDGE TYPE PRODUCED_BY      IF NOT EXISTS",
        "CREATE EDGE TYPE SHIPPED_IN       IF NOT EXISTS",
        "CREATE EDGE TYPE LED_TO           IF NOT EXISTS",
        "CREATE EDGE TYPE TARGETS_PAGE     IF NOT EXISTS",
        "CREATE EDGE TYPE FOR_VARIANT      IF NOT EXISTS",
        "CREATE EDGE TYPE IN_RUBRIC        IF NOT EXISTS",

        // ── ARC-02: MetricSnapshot — native ArcadeDB time-series (not a graph
        // vertex/edge; separate storage engine, hence no HAS_STATE/edges to it).
        // Real syntax confirmed against ArcadeDB docs — spec's "LSM_TIMESERIES"
        // literal does not exist, actual keyword is CREATE TIMESERIES TYPE.
        "CREATE TIMESERIES TYPE MetricSnapshot " +
            "TIMESTAMP ts " +
            "TAGS (object_type STRING, object_id STRING, metric STRING, source STRING, segment STRING) " +
            "FIELDS (value DOUBLE)",

        // ── ARC-03: secondary indexes (площадка — via IN_CHANNEL edge traversal,
        // no property index needed; статус/дата/ключ are direct properties) ────
        "CREATE INDEX IF NOT EXISTS ON BragiVariant     (status)       NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON BragiVariant     (published_at) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON BragiPublication (status_general) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON BragiKeyword     (cluster)      NOTUNIQUE",

        // ── SPRINT_PLANITEM_RETIRE: planning fields move from PlanItem onto
        // KnowSprint/KnowSprintHist directly (see ADR + memory lore_milestone_
        // sprint_via_planitem for the "why"). planned_start_date/planned_end_date/
        // track_id are SCD2-tracked (same read pattern as priority:
        // out('HAS_STATE')[field IS NOT NULL].field[0]) — hence on KnowSprintHist,
        // not the vertex. created_date is a one-time vertex stamp, deliberately
        // NOT on the hist chain (must survive every SCD2 transition unchanged, so
        // it can't live on a row that gets replaced).
        // planned_milestone_id (plain field) retired — the TARGETS_MILESTONE edge
        // is now the sole source of truth for sprint↔milestone. The field drifted
        // out of sync with the edge on 62+ sprints in production (two independent
        // write paths, no reconciliation) before being removed entirely.
        "CREATE PROPERTY KnowSprint.created_date          IF NOT EXISTS STRING",
        // Vertex-only flag (no history needed) — excluded from deploy-lag/
        // unreleased-burn metrics when true (docs-only/research/tooling sprints
        // that never ship a versioned release).
        "CREATE PROPERTY KnowSprint.no_release_required   IF NOT EXISTS BOOLEAN",
        // RM-U6: спринт вне вех осознанно — снимается из «правда забыли» на карте вех.
        "CREATE PROPERTY KnowSprint.unplanned_intentional IF NOT EXISTS BOOLEAN",
        "CREATE PROPERTY KnowSprintHist.planned_start_date IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowSprintHist.planned_end_date   IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowSprintHist.track_id           IF NOT EXISTS STRING",

        // ── ADR-LORE-012: KnowDictEntry — значения справочников как вершины графа ─
        // Одна вершина = одно значение (dict_type, code) с метаданными; цель для
        // ссылки/паспорта и (для сущностных доменов) для ребра. Reference-only
        // домены (status/priority/adr_status) читают color/icon/label отсюда,
        // храня значение строкой; сущностные (area/artifact_kind/channel/tag) —
        // позже через ребро. is_extensible гейтит affordance «+» в UI.
        "CREATE VERTEX TYPE KnowDictEntry IF NOT EXISTS",
        "CREATE PROPERTY KnowDictEntry.dict_type     IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDictEntry.code          IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDictEntry.label_ru      IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDictEntry.label_en      IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDictEntry.color         IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDictEntry.icon          IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDictEntry.sort_order    IF NOT EXISTS INTEGER",
        "CREATE PROPERTY KnowDictEntry.is_active     IF NOT EXISTS BOOLEAN",
        "CREATE PROPERTY KnowDictEntry.is_extensible IF NOT EXISTS BOOLEAN",
        // Composite unique — enables UPSERT WHERE dict_type=x AND code=y without dups.
        "CREATE INDEX IF NOT EXISTS ON KnowDictEntry (dict_type, code) UNIQUE",

        // ── ADR-LORE-015: task_type — классификация задач (первичный слой для ролей) ─
        // Значения — справочник KnowDictEntry (dict_type="task_type"), два измерения:
        // последовательные фазы (planning/design/dev/test/ops) + сквозные
        // (research/analytics/docs/content). Тип определяет дефолтных
        // author/executor/reviewer (ADR-LORE-014). Единственный объект, которому
        // недоставало типа по итогам аудита §4 ADR-LORE-015.
        "CREATE PROPERTY KnowTask.task_type IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowTask (task_type) NOTUNIQUE",

        // ── ADR-LORE-014 §4: author/executor/reviewer — SDLC ownership on a task ──
        // Deliberately on the VERTEX (KnowTask), not KnowTaskHist ("as priority" in
        // the ADR's first draft) — priority's Hist+carry-forward pattern already has
        // a live bug (readTaskHistCarryFields/restoreTaskHistFields only carry
        // note_md/effort_days; any other Hist field silently vanishes on every status
        // flip). These fields characterize WHO owns the task, not a point-in-time
        // status fact, so they belong where task_type does — immune to the whole
        // carry-forward problem class by construction.
        "CREATE PROPERTY KnowTask.author_agent   IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowTask.executor_agent IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowTask.reviewer_agent IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowTask (executor_agent) NOTUNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowTask (reviewer_agent) NOTUNIQUE",

        // ── QG-flow: QGJobTask + QGRecommendation (Tests task, 2026-07-14) ────────
        // Same gap as PRODUCED/PROMOTED_TO above, one layer deeper: LoreQgResource's
        // "UPDATE QGJobTask/QGRecommendation SET ... UPSERT WHERE ..." calls never had
        // an explicit vertex-type/index declaration either — worked on the live shared
        // DB via auto-vivification (types + ad-hoc property inference from years of
        // writes), but a fresh bootstrap DB has neither type, so the UPSERT itself
        // fails outright (surfaced by LoreScd2AndRollbackLiveDbTest's Testcontainer run
        // against a genuinely empty ArcadeDB — same class of gap C5 found for V/E).
        "CREATE VERTEX TYPE QGJobTask       IF NOT EXISTS EXTENDS V",
        "CREATE VERTEX TYPE QGRecommendation IF NOT EXISTS EXTENDS V",
        "CREATE PROPERTY QGJobTask.job_id         IF NOT EXISTS STRING",
        "CREATE PROPERTY QGRecommendation.rec_id  IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON QGJobTask       (job_id) UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON QGRecommendation (rec_id) UNIQUE",

        // ── KnowGitProject (T15: project_new) ─────────────────────────────────────
        // Previously created only via a direct ArcadeDB INSERT (see MEMORY
        // lore_git_project_registration) — never declared here either, same
        // auto-vivification-on-the-live-DB-only gap as above.
        "CREATE VERTEX TYPE KnowGitProject IF NOT EXISTS EXTENDS V",
        "CREATE PROPERTY KnowGitProject.slug IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowGitProject (slug) UNIQUE",
        // ADR-LORE-018: hosts = JSON array of hosting entries (origin + mirrors),
        // each with role/base_url/file_url_template/pr_url_template/default_branch.
        // Stored as a JSON STRING (no EMBEDDEDLIST precedent in this schema; pr_refs
        // is handled the same way); the URL is composed at read time on the client.
        "CREATE PROPERTY KnowGitProject.hosts          IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowGitProject.default_branch IF NOT EXISTS STRING",

        // BELONGS_TO_PROJECT (KnowSprint -> KnowGitProject, also read off KnowRelease/
        // KnowPR elsewhere) — same gap: only ever auto-vivified via CREATE EDGE ... IF
        // NOT EXISTS calls (sprint/project, sprint_new's new git_project param, T16/
        // ADR-LORE-017), never declared here. Added alongside the other T13/T15 finds.
        "CREATE EDGE TYPE BELONGS_TO_PROJECT IF NOT EXISTS EXTENDS E",

        // ── KnowFile (ADR-LORE-018 T21): reference to a repo file, NOT parsing. ──
        // Relative path only (no host/branch); the URL is composed at read time
        // from the project's hosts[]. Keyed by (project, file_path). Lazily created
        // on first link to a task (EDITED_IN). No file↔file / symbol graph.
        "CREATE VERTEX TYPE KnowFile IF NOT EXISTS",
        "CREATE PROPERTY KnowFile.project    IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowFile.file_path  IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowFile.summary_md IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowFile (project, file_path) UNIQUE",
        "CREATE EDGE TYPE EDITED_IN IF NOT EXISTS",   // KnowFile -> KnowTask

        // ── KnowQuestion (ADR-020/021 T25): open-questions register. Vertex-only
        // like KnowDecision — NO Hist (status/opened_date/closed_date are plain
        // fields, see ADR-021 §SCD2). GATES (question→task gate) reuses the
        // already-declared-but-empty edge; ANSWERS/RAISED_IN are new.
        "CREATE VERTEX TYPE KnowQuestion IF NOT EXISTS",
        "CREATE PROPERTY KnowQuestion.question_id  IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowQuestion.component_id IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowQuestion (question_id)  UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON KnowQuestion (component_id) NOTUNIQUE",
        "CREATE EDGE TYPE ANSWERS   IF NOT EXISTS",   // KnowDecision -> KnowQuestion
        "CREATE EDGE TYPE RAISED_IN IF NOT EXISTS",   // KnowQuestion -> KnowADR|KnowSprint|KnowTask

        // ── FULL_TEXT по телам (v1.0.50) ──────────────────────────────────────
        // Слайс `search` гонял ILIKE '%…%' по каждому телу — полный скан корпуса
        // на каждый запрос. FULL_TEXT даёт SEARCH_FIELDS(["decision_md"], "агентн*").
        // ArcadeDB schema-less: индексировать можно только ОБЪЯВЛЕННОЕ свойство,
        // поэтому перед каждым индексом идёт CREATE PROPERTY (поля уже живут в
        // документах — объявление их не трогает).
        "CREATE PROPERTY KnowADRHist.context_md      IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowADRHist.decision_md     IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowADRHist.consequences_md IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowADRHist (context_md)      FULL_TEXT",
        "CREATE INDEX IF NOT EXISTS ON KnowADRHist (decision_md)     FULL_TEXT",
        "CREATE INDEX IF NOT EXISTS ON KnowADRHist (consequences_md) FULL_TEXT",
        "CREATE PROPERTY KnowDecision.title   IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowDecision.body_md IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowDecision (title)   FULL_TEXT",
        "CREATE INDEX IF NOT EXISTS ON KnowDecision (body_md) FULL_TEXT",
        "CREATE PROPERTY KnowQuestion.title   IF NOT EXISTS STRING",
        "CREATE PROPERTY KnowQuestion.body_md IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowQuestion (title)   FULL_TEXT",
        "CREATE INDEX IF NOT EXISTS ON KnowQuestion (body_md) FULL_TEXT",
        "CREATE PROPERTY KnowSpecHist.content_md    IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowSpecHist (content_md)    FULL_TEXT",
        "CREATE PROPERTY KnowRunbookHist.content_md IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowRunbookHist (content_md) FULL_TEXT",
        "CREATE PROPERTY KnowDocHist.content_md     IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowDocHist (content_md)     FULL_TEXT",
        "CREATE PROPERTY KnowSprintHist.context_md  IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowSprintHist (context_md)  FULL_TEXT",
        "CREATE PROPERTY KnowTaskHist.note_md       IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON KnowTaskHist (note_md)       FULL_TEXT"
    );

    /**
     * RM-P12: объявления {@code valid_from} для *Hist с текстовым ISO-8601 UTC.
     *
     * <p>Собираются из {@link LoreSchemaMigrations#HIST_VALID_FROM_TEXT} —
     * того же реестра, по которому шаг V42 объявляет свойство на живой БД, а
     * {@code LoreHistValidFromTypedTest} проверяет, что ни один *Hist не
     * остался без объявления. Свежая БД и мигрированная обязаны прийти к
     * ОДНОЙ схеме; два списка руками гарантированно разъедутся — этой болезнью
     * корпус уже болеет в другом месте (RM-P8).
     *
     * <p>RM-P13: реестр пуст — текстовых valid_from больше нет, все *Hist
     * объявлены DATETIME литералами выше. Метод оставлен: если кто-то вернёт
     * тип в текстовый реестр, свежая БД получит то же объявление, что и живая,
     * а LoreHistValidFromTypedTest упадёт на «текстовых быть не должно».
     */
    static List<String> histValidFromText() {
        return LoreSchemaMigrations.HIST_VALID_FROM_TEXT.stream()
            .map(t -> "CREATE PROPERTY " + t + ".valid_from IF NOT EXISTS STRING")
            .toList();
    }
}
