package studio.seer.heimdall.lore;

import io.vertx.core.json.JsonObject;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.net.http.HttpResponse;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Pattern;

/**
 * Forgejo-мост REST (ADR-LORE-024, FJ-03): граф-контекстные git-операции —
 * PR с телом из KnowRelease, merge строго по гейту §10 (только GREEN),
 * авто-линк PR→релиз→спринт на merge (FJ-05). Операционный CI/CD (логи,
 * dispatch) сюда НЕ входит — это дом forgejo-mcp (§9); branch protection
 * читаем, никогда не пишем (решение 136).
 *
 * Pluggable: без FORGEJO_API_TOKEN все эндпоинты отвечают 503 — LORE без
 * self-hosted Forgejo работает как раньше. Токен живёт в SecretProvider и
 * не появляется ни в одном ответе или логе.
 */
@Path("/lore/forgejo")
public class LoreForgejoResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreForgejoResource.class);

    @Inject
    ForgejoBridge bridge;

    private Response notConfigured() {
        return noStore(Response.status(503).entity(new LoreError("FORGEJO_NOT_CONFIGURED",
            "forgejo bridge not configured (" + ForgejoBridge.FORGEJO_TOKEN_KEY + " unset) — fallback: tea CLI, §9")));
    }

    private Response projectNotResolvable(String slug) {
        return noStore(Response.status(Response.Status.NOT_FOUND)
            .entity(new LoreError("PROJECT_NOT_RESOLVABLE",
                ForgejoBridge.notResolvableDetail(slug, bridge.slugsForRepoPath(slug)))));
    }

    /** Живость моста — для условной регистрации MCP-инструментов (FJ-04). */
    @GET
    @Path("health")
    @Produces(MediaType.APPLICATION_JSON)
    public Response health(@HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        // FJ-10: чтение — не merge. «Живо ли» не требует admin, читает любой агент.
        return noStore(Response.ok(Map.of("configured", bridge.configured())));
    }

    // ── PR: создать с телом из KnowRelease ──────────────────────────────────

    public record PrCreateRequest(String git_project, String head, String base,
                                  String title, String release_id, String body_md) {}

    @POST
    @Path("pr")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPr(PrCreateRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (!bridge.configured()) return notConfigured();
        if (req == null || str(req.git_project()).isEmpty() || str(req.head()).isEmpty())
            return badParams("git_project and head required");
        Optional<ForgejoBridge.Repo> repo = bridge.resolve(req.git_project());
        if (repo.isEmpty()) return projectNotResolvable(req.git_project());
        try {
            String base = str(req.base()).isEmpty() ? "develop" : req.base();
            String body = str(req.body_md());
            String title = str(req.title());
            if (!str(req.release_id()).isEmpty()) {
                // Тело PR из KnowRelease (ADR-024 §9: за этим мост и нужен).
                List<Map<String, Object>> rel = ingestService.queryPublic(
                    "SELECT description_md FROM KnowRelease WHERE release_uid=:ruid",
                    Map.of("ruid", req.git_project() + "#" + req.release_id()));
                if (rel.isEmpty())
                    return badParams("release " + req.release_id() + " not found for " + req.git_project()
                        + " — создайте KnowRelease (release_new) до PR или уберите release_id");
                if (body.isEmpty()) body = str(rel.get(0).get("description_md"));
                if (title.isEmpty()) title = "release " + req.release_id();
            }
            if (title.isEmpty()) title = req.head();
            HttpResponse<String> r = bridge.api(repo.get(), "POST",
                "/repos/" + repo.get().path() + "/pulls",
                JsonObject.of("title", title, "body", body, "head", req.head(), "base", base).encode());
            if (r.statusCode() >= 300)
                return noStore(Response.status(r.statusCode())
                    .entity(new LoreError("FORGEJO_UPSTREAM", r.body())));
            JsonObject pr = new JsonObject(r.body());
            return noStore(Response.ok(Map.of("ok", true,
                "number", pr.getLong("number"),
                "url", str(pr.getString("html_url")),
                "head", req.head(), "base", base, "title", title)));
        } catch (Exception e) { return upstream(e); }
    }

    // ── PR: статус для merge-решения (§10) ──────────────────────────────────

    @GET
    @Path("pr/{n}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response prStatus(@PathParam("n") long number, @QueryParam("git_project") String gitProject,
                             @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        // FJ-10: чтение статуса PR не требует admin — только merge (см. ниже).
        if (!bridge.configured()) return notConfigured();
        if (str(gitProject).isEmpty()) return badParams("git_project required");
        Optional<ForgejoBridge.Repo> repo = bridge.resolve(gitProject);
        if (repo.isEmpty()) return projectNotResolvable(gitProject);
        try {
            PrGate gate = evaluate(repo.get(), gitProject, number);
            if (gate.error() != null)
                return noStore(Response.status(gate.httpStatus())
                    .entity(new LoreError("FORGEJO_UPSTREAM", gate.error())));
            return noStore(Response.ok(gate.toJson()));
        } catch (Exception e) { return upstream(e); }
    }

    // ── PR: merge строго по гейту (409 из любого не-GREEN) ─────────────────

    public record MergeRequest(String git_project, String release_id, String sprint_id) {}

    @POST
    @Path("pr/{n}/merge")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response merge(@PathParam("n") long number, MergeRequest req,
                          @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (!bridge.configured()) return notConfigured();
        if (req == null || str(req.git_project()).isEmpty()) return badParams("git_project required");
        Optional<ForgejoBridge.Repo> repo = bridge.resolve(req.git_project());
        if (repo.isEmpty()) return projectNotResolvable(req.git_project());
        try {
            PrGate gate = evaluate(repo.get(), req.git_project(), number);
            if (gate.error() != null)
                return noStore(Response.status(gate.httpStatus())
                    .entity(new LoreError("FORGEJO_UPSTREAM", gate.error())));
            // §10 (б): merge разрешён ТОЛЬКО из GREEN. Всё остальное — 409 с фактическим
            // статусом; UNKNOWN/STALLED — повод для forgejo-mcp диагностики, не ретраев.
            if (!ForgejoBridge.mergeAllowed(gate.status())) {
                Map<String, Object> body = gate.toJson();
                body.put("error", "MERGE_GATE");
                body.put("detail", "merge разрешён только из GREEN; сейчас " + gate.status()
                    + (ForgejoBridge.RED.equals(gate.status()) ? " — чините CI и повторяйте"
                       : " — диагностика через forgejo-mcp (§9), не повторные merge"));
                return noStore(Response.status(Response.Status.CONFLICT).entity(body));
            }
            HttpResponse<String> m = bridge.api(repo.get(), "POST",
                "/repos/" + repo.get().path() + "/pulls/" + number + "/merge",
                JsonObject.of("Do", "merge").encode());
            if (m.statusCode() >= 300)
                return noStore(Response.status(m.statusCode())
                    .entity(new LoreError("FORGEJO_UPSTREAM", m.body())));

            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true);
            out.put("merged", true);
            out.put("number", number);
            out.put("gate", gate.status());

            boolean promotion = "preprod".equals(gate.baseRef()) || "main".equals(gate.baseRef());
            out.putAll(recordMergedPr(repo.get(), req.git_project(), number, gate, !promotion));

            // CIM-03: промоушн-PR (develop→preprod, preprod→main) и релизные PR не
            // содержат сами по себе релизную работу — привязывать их к KnowRelease
            // значило бы приписать релиз промежуточному мержу веток. #321 (v1.1.1)
            // уехал в релиз ровно так: автолинк отработал по базовой ветке
            // preprod, а не по содержимому PR.
            if (!"preprod".equals(gate.baseRef()) && !"main".equals(gate.baseRef())) {
                // FJ-05: замыкание релиз-цикла — авто-линк PR→релиз (SHIPPED_IN) и
                // спринт→релиз (IMPLEMENTED_IN_RELEASE). Валидируем существование целей:
                // тихий no-op здесь уже стоил релизов с prs_linked:0 (ADR-024, контекст).
                Map<String, Object> linked = autoLink(repo.get(), req.git_project(), number, req.release_id(), req.sprint_id());
                out.putAll(linked);
            } else {
                out.put("linked", false);
                out.put("link_hint", "промоушн-PR (base=" + gate.baseRef()
                    + ") не привязывается к релизу автоматически — это не содержательный PR");
            }
            return noStore(Response.ok(out));
        } catch (Exception e) { return upstream(e); }
    }

    // ── CI-статус произвольного ref (ветки) — §10 ───────────────────────────

    @GET
    @Path("ci")
    @Produces(MediaType.APPLICATION_JSON)
    public Response ciStatus(@QueryParam("git_project") String gitProject, @QueryParam("ref") String ref,
                             @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        // FJ-10: чтение CI-статуса не требует admin — та же логика, что у pr/{n}.
        if (!bridge.configured()) return notConfigured();
        if (str(gitProject).isEmpty() || str(ref).isEmpty()) return badParams("git_project and ref required");
        Optional<ForgejoBridge.Repo> repo = bridge.resolve(gitProject);
        if (repo.isEmpty()) return projectNotResolvable(gitProject);
        try {
            // SE-13: имя ветки сначала разрешается в SHA, статусы — по SHA, как в пути PR.
            // Неразрешённая ссылка — явная ошибка, а не UNKNOWN с пустыми проверками.
            RefResolution res = resolveRef(repo.get().path(), ref, p -> fetch(repo.get(), p));
            if (res.sha() == null)
                return noStore(Response.status(res.httpStatus())
                    .entity(new LoreError("REF_NOT_RESOLVED", res.error())));
            CiProbe probe = ciProbe(repo.get(), res.sha(), 0);
            String status = ForgejoBridge.gateStatus(probe.byContext(), bridge.requiredChecks(gitProject),
                probe.ageSeconds(), bridge.graceSeconds(), probe.failed());
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ref", ref);
            out.put("sha", res.sha());
            out.put("resolved_via", res.via());
            out.put("status", status);
            out.put("checks", probe.byContext());
            // UNKNOWN остаётся словом гейта («мержить нельзя»), но рядом — почему.
            if (probe.failed()) out.put("error", probe.error());
            return noStore(Response.ok(out));
        } catch (Exception e) { return upstream(e); }
    }

    /** Что вернул Forgejo на один GET: код и тело. Отдельно от HttpResponse, чтобы
     *  разрешение ссылки проверялось на поддельных ответах, без сети. */
    record Upstream(int status, String body) {}

    /** Итог разрешения ref → SHA. sha == null → error и httpStatus объясняют, почему. */
    record RefResolution(String sha, String via, String error, int httpStatus) {}

    private static final Pattern SHA_REF = Pattern.compile("^[0-9a-fA-F]{7,40}$");

    /**
     * SE-13: ref → SHA коммита. В путь /commits/{ref}/status имя ветки подставлять
     * нельзя: {ref} у Forgejo — один сегмент пути, и слэш в имени
     * (test/ygg-gate-selftest) разрывал маршрут. Ответ-ошибка молча превращался в
     * UNKNOWN с пустыми проверками — на зелёной ветке. Эндпоинты веток и тегов
     * принимают имя со слэшем целиком, поэтому разрешаем через них.
     *
     * Порядок: похоже на SHA → как есть, без запросов; иначе ветка, затем тег.
     * Ветка, названная одними hex-символами (deadbeef), будет принята за SHA —
     * осознанно: так же трактует ref сам Forgejo.
     *
     * Сбой Forgejo (не 200 и не 404) — стоп с ошибкой: искать дальше в тегах значило
     * бы замаскировать 500 под «не найдено».
     */
    static RefResolution resolveRef(String repoPath, String ref, Function<String, Upstream> get) {
        if (SHA_REF.matcher(ref).matches()) return new RefResolution(ref, "sha", null, 200);
        for (String kind : new String[] {"branches", "tags"}) {
            Upstream u = get.apply("/repos/" + repoPath + "/" + kind + "/" + ref);
            if (u.status() == 404) continue;
            if (u.status() != 200)
                return new RefResolution(null, kind,
                    "Forgejo ответил " + u.status() + " на " + kind + "/" + ref + ": " + str(u.body()), 502);
            // У ветки коммит в commit.id, у тега — в commit.sha (id тега — SHA объекта тега, не коммита).
            JsonObject commit = new JsonObject(u.body()).getJsonObject("commit", new JsonObject());
            String sha = str(commit.getString("id", commit.getString("sha", "")));
            if (sha.isEmpty())
                return new RefResolution(null, kind,
                    "Forgejo вернул " + kind + "/" + ref + " без коммита: " + str(u.body()), 502);
            return new RefResolution(sha, kind, null, 200);
        }
        return new RefResolution(null, null, "ссылка не найдена ни среди веток, ни среди тегов: " + ref, 404);
    }

    /** GET к Forgejo в форме Upstream; исключение транспорта — код 599, тоже «не смогли». */
    private Upstream fetch(ForgejoBridge.Repo repo, String path) {
        try {
            HttpResponse<String> r = bridge.api(repo, "GET", path, null);
            return new Upstream(r.statusCode(), r.body());
        } catch (Exception e) {
            return new Upstream(599, String.valueOf(e.getMessage()));
        }
    }

    // ── Branch protection: ТОЛЬКО чтение (решение 136) ──────────────────────

    @GET
    @Path("branch-protection")
    @Produces(MediaType.APPLICATION_JSON)
    public Response branchProtection(@QueryParam("git_project") String gitProject,
                                     @QueryParam("branch") String branch,
                                     @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        // FJ-10: чтение — решение 136 уже называло branch-protection read-only.
        if (!bridge.configured()) return notConfigured();
        if (str(gitProject).isEmpty()) return badParams("git_project required");
        Optional<ForgejoBridge.Repo> repo = bridge.resolve(gitProject);
        if (repo.isEmpty()) return projectNotResolvable(gitProject);
        try {
            String path = "/repos/" + repo.get().path() + "/branch_protections"
                + (str(branch).isEmpty() ? "" : "/" + branch);
            HttpResponse<String> r = bridge.api(repo.get(), "GET", path, null);
            if (r.statusCode() >= 300)
                return noStore(Response.status(r.statusCode())
                    .entity(new LoreError("FORGEJO_UPSTREAM", r.body())));
            return noStore(Response.ok(r.body()));
        } catch (Exception e) { return upstream(e); }
    }

    // ── внутренности ─────────────────────────────────────────────────────────

    /** Снимок PR + вычисленный статус §10. error!=null → upstream-ошибка (не UNKNOWN гейта:
     *  ошибка чтения самого PR — это 502/404 вызова, а не CI-статус). */
    record PrGate(long number, String title, String state, boolean mergedAlready, String headSha,
                  String baseRef, String status, Map<String, String> checks, String error, int httpStatus) {
        Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("number", number);
            m.put("title", title);
            m.put("state", state);
            m.put("merged", mergedAlready);
            m.put("head_sha", headSha);
            m.put("status", status);
            m.put("checks", checks);
            m.put("merge_allowed", ForgejoBridge.mergeAllowed(status));
            return m;
        }
    }

    private PrGate evaluate(ForgejoBridge.Repo repo, String gitProject, long number) throws Exception {
        HttpResponse<String> r = bridge.api(repo, "GET", "/repos/" + repo.path() + "/pulls/" + number, null);
        if (r.statusCode() >= 300)
            return new PrGate(number, null, null, false, null, null, null, Map.of(), r.body(), r.statusCode());
        JsonObject pr = new JsonObject(r.body());
        String headSha = pr.getJsonObject("head", new JsonObject()).getString("sha", "");
        String baseRef = pr.getJsonObject("base", new JsonObject()).getString("ref", "");
        long age = 0;
        String updated = pr.getString("updated_at");
        if (updated != null) {
            try { age = Instant.now().getEpochSecond() - OffsetDateTime.parse(updated).toInstant().getEpochSecond(); }
            catch (Exception ignore) { }
        }
        CiProbe probe = ciProbe(repo, headSha, age);
        String status = ForgejoBridge.gateStatus(probe.byContext(), bridge.requiredChecks(gitProject),
            probe.ageSeconds(), bridge.graceSeconds(), probe.failed());
        return new PrGate(number, pr.getString("title"), pr.getString("state"),
            Boolean.TRUE.equals(pr.getBoolean("merged")), headSha, baseRef, status, probe.byContext(), null, 200);
    }

    /** Комбинированный commit-status Forgejo по SHA → контекст→state. failed=true → UNKNOWN,
     *  и error говорит почему: «не смогли проверить» не должно выглядеть как «проверок нет». */
    record CiProbe(Map<String, String> byContext, long ageSeconds, boolean failed, String error) {}

    private CiProbe ciProbe(ForgejoBridge.Repo repo, String ref, long ageSeconds) {
        try {
            HttpResponse<String> r = bridge.api(repo, "GET",
                "/repos/" + repo.path() + "/commits/" + ref + "/status", null);
            if (r.statusCode() >= 300)
                return new CiProbe(Map.of(), ageSeconds, true,
                    "Forgejo ответил " + r.statusCode() + " на статусы " + ref);
            Map<String, String> byCtx = ForgejoBridge.statusesByContext(new JsonObject(r.body()));
            return new CiProbe(byCtx, ageSeconds, false, null);
        } catch (Exception e) {
            LOG.warnf("[FORGEJO CI] %s@%s: %s", repo.path(), ref, e.getMessage());
            return new CiProbe(Map.of(), ageSeconds, true, "сбой обращения к Forgejo: " + e.getMessage());
        }
    }

    /**
     * SPRINT_LORE_MODEL_DOCS_TIDY/MD-05: после успешного мержа — данные PR в KnowPR и связь задача → PR.
     *
     * <p>Корень пустых заголовков (разбор моста 15.11): мерж держал в руках заголовок и состояние и
     * отбрасывал их — KnowPR получал только ключ. Теперь PR перечитывается у Forgejo после мержа
     * (там уже merged_at) и записывается полями {@link ForgejoBridge#prFields}: title, url, merged_at,
     * state, head_ref, base_ref. Не прочитался — пишем то, что знает гейт (заголовок, state=merged).
     *
     * <p>Связь: для каждого кода СПРИНТ/КОД из заголовка — CLOSED_BY задача → PR, как {@code /lore/task/pr}
     * (MCP {@code task_link rel=pr}). Неизвестный код мерж не роняет — он в ответе как {@code unmatched}.
     * Промоушн-PR (base preprod/main) с задачами не связываются: их заголовок перечисляет чужую работу.
     */
    private Map<String, Object> recordMergedPr(ForgejoBridge.Repo repo, String gitProject, long number,
                                               PrGate gate, boolean linkTasks) {
        Map<String, Object> out = new LinkedHashMap<>();
        String prUid = gitProject + "#" + number;
        Map<String, Object> f = new LinkedHashMap<>();
        try {
            HttpResponse<String> r = bridge.api(repo, "GET", "/repos/" + repo.path() + "/pulls/" + number, null);
            if (r.statusCode() < 300) f.putAll(ForgejoBridge.prFields(new JsonObject(r.body())));
            else out.put("pr_fields_hint", "Forgejo ответил " + r.statusCode()
                + " на чтение PR после мержа — записаны поля гейта");
        } catch (Exception e) {
            out.put("pr_fields_hint", "чтение PR после мержа не удалось (" + e.getMessage() + ") — записаны поля гейта");
        }
        if (!f.containsKey("title") && gate.title() != null && !gate.title().isBlank()) f.put("title", gate.title());
        f.putIfAbsent("state", "merged"); // мерж только что прошёл
        try {
            StringBuilder set = new StringBuilder("pr_uid=:uid, pr_number=:n, git_project=:gp");
            for (String k : f.keySet()) set.append(", ").append(k).append("=:").append(k);
            Map<String, Object> p = new LinkedHashMap<>(f);
            p.put("uid", prUid);
            p.put("n", number);
            p.put("gp", gitProject);
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE KnowPR SET " + set + " UPSERT WHERE pr_uid=:uid", p)).await().indefinitely();
            out.put("pr_recorded", true);
            out.put("pr_fields", List.copyOf(f.keySet()));
        } catch (Exception e) {
            LOG.warnf("[FORGEJO MERGE] запись KnowPR %s: %s", prUid, e.getMessage());
            out.put("pr_recorded", false);
            out.put("pr_record_hint", "KnowPR не записан (" + e.getMessage() + ") — связи с задачами не ставились");
            return out;
        }

        List<String> uids = ForgejoBridge.taskUidsInTitle(String.valueOf(f.getOrDefault("title", "")));
        List<Map<String, Object>> linked = new java.util.ArrayList<>();
        out.put("tasks_linked", linked);
        if (!linkTasks) {
            out.put("unmatched", List.of());
            if (!uids.isEmpty()) out.put("tasks_hint", "промоушн-PR (base=" + gate.baseRef()
                + ") с задачами не связывается — связи ставит содержательный PR");
            return out;
        }
        ForgejoBridge.TaskMatch m;
        try {
            m = ForgejoBridge.matchTasks(uids, uid -> !ingestService.queryPublic(
                "SELECT task_uid FROM KnowTask WHERE task_uid=:t LIMIT 1", Map.of("t", uid)).isEmpty());
        } catch (Exception e) {
            // «не смогли проверить» ≠ «таких задач нет»: в unmatched не кладём.
            LOG.warnf("[FORGEJO MERGE] сверка задач %s: %s", uids, e.getMessage());
            out.put("unmatched", List.of());
            out.put("tasks_hint", "сверка задач не удалась (" + e.getMessage() + ") — коды " + uids
                + " не проверены; task_link rel=pr руками");
            return out;
        }
        out.put("unmatched", m.unmatched());
        for (String uid : m.matched()) {
            Map<String, Object> one = new LinkedHashMap<>();
            one.put("task_uid", uid);
            try {
                boolean had = edgeExists("CLOSED_BY", "task_uid", uid, "pr_uid", prUid);
                if (!had)
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "CREATE EDGE CLOSED_BY FROM (SELECT FROM KnowTask WHERE task_uid=:t) "
                        + "TO (SELECT FROM KnowPR WHERE pr_uid=:p) IF NOT EXISTS",
                        Map.of("t", uid, "p", prUid))).await().indefinitely();
                // Исход — по ребру в графе, а не по факту выполнения команды (DBR-17).
                boolean made = had || edgeExists("CLOSED_BY", "task_uid", uid, "pr_uid", prUid);
                one.put("outcome", had ? LoreOutcome.UNCHANGED : made ? LoreOutcome.CREATED : LoreOutcome.NOOP);
            } catch (Exception e) {
                LOG.warnf("[FORGEJO MERGE] CLOSED_BY %s → %s: %s", uid, prUid, e.getMessage());
                one.put("outcome", LoreOutcome.NOOP);
                one.put("reason", e.getMessage());
            }
            linked.add(one);
        }
        return out;
    }

    /**
     * FJ-05: рёбра PR→релиз и спринт→релиз после успешного merge. release_id не
     * передан → берём текущий (is_current) релиз проекта; его нет → linked:false
     * с подсказкой, НЕ молча (урок feedback_release_link_sprint_and_pr).
     */
    private Map<String, Object> autoLink(ForgejoBridge.Repo repo, String gitProject, long prNumber,
                                         String releaseId, String sprintId) {
        Map<String, Object> out = new LinkedHashMap<>();
        try {
            String rid = str(releaseId);
            // Релиз, названный вызывающим ЯВНО, — осознанная просьба (например,
            // дозаполнение истории): её исполняем. Проверка ниже — только для
            // автовыбора, который и цеплял правки к вышедшему релизу.
            boolean autoPicked = rid.isEmpty();
            if (rid.isEmpty()) {
                List<Map<String, Object>> cur = ingestService.queryPublic(
                    "SELECT release_id FROM KnowRelease WHERE git_project=:gp AND is_current=true LIMIT 1",
                    Map.of("gp", gitProject));
                if (!cur.isEmpty()) rid = str(cur.get(0).get("release_id"));
            }
            if (rid.isEmpty()) {
                out.put("linked", false);
                out.put("link_hint", "релиз не найден (ни release_id, ни is_current у " + gitProject
                    + ") — создайте KnowRelease и вызовите release_link rel:pr + rel:sprint");
                return out;
            }
            String ruid = gitProject + "#" + rid;
            List<Map<String, Object>> rel = ingestService.queryPublic(
                "SELECT release_uid FROM KnowRelease WHERE release_uid=:ruid", Map.of("ruid", ruid));
            if (rel.isEmpty()) {
                out.put("linked", false);
                out.put("link_hint", "KnowRelease " + ruid + " не существует — release_new до merge");
                return out;
            }
            // SE-09: к ВЫПУЩЕННОМУ релизу автоматика не цепляет. 10.09 — шесть
            // слияний подряд легли в v1.10.0, у которого тег уже стоял на main;
            // правки, влитые после тега, в него физически не входят.
            if (autoPicked) {
                List<Map<String, Object>> tagRow = ingestService.queryPublic(
                    "SELECT git_tag FROM KnowRelease WHERE release_uid=:ruid", Map.of("ruid", ruid));
                String tag = tagRow.isEmpty() ? "" : str(tagRow.get(0).get("git_tag"));
                Integer tagStatus = null;
                if (!tag.isEmpty()) {
                    try {
                        tagStatus = bridge.api(repo, "GET", "/repos/" + repo.path() + "/tags/"
                            + java.net.URLEncoder.encode(tag, java.nio.charset.StandardCharsets.UTF_8), null).statusCode();
                    } catch (Exception te) {
                        LOG.warnf("[FORGEJO AUTOLINK] проверка тега %s не удалась: %s", tag, te.getMessage());
                    }
                }
                ForgejoBridge.AutoLinkDecision dec =
                    ForgejoBridge.autoLinkDecision(tag.isEmpty() ? null : tag, tagStatus);
                if (!dec.link()) {
                    out.put("linked", false);
                    out.put("link_hint", dec.reason());
                    return out;
                }
            }
            String prUid = gitProject + "#" + prNumber;
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE KnowPR SET pr_uid=:uid, pr_number=:n, git_project=:gp UPSERT WHERE pr_uid=:uid",
                Map.of("uid", prUid, "n", prNumber, "gp", gitProject))).await().indefinitely();
            // DBR-17: IF NOT EXISTS + исход из факта. Голый CREATE EDGE на
            // повторном вызове плодил дубль, а linked:true ставился по факту
            // выполнения команды, а не по ребру в графе.
            boolean prHad = edgeExists("SHIPPED_IN", "pr_uid", prUid, "release_uid", ruid);
            if (!prHad)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE SHIPPED_IN FROM (SELECT FROM KnowPR WHERE pr_uid=:uid) " +
                    "TO (SELECT FROM KnowRelease WHERE release_uid=:ruid) IF NOT EXISTS",
                    Map.of("uid", prUid, "ruid", ruid))).await().indefinitely();
            boolean prLinked = prHad || edgeExists("SHIPPED_IN", "pr_uid", prUid, "release_uid", ruid);
            out.put("linked", prLinked);
            out.put("release_id", rid);
            out.put("link_outcome", prHad ? LoreOutcome.UNCHANGED : prLinked ? LoreOutcome.CREATED : LoreOutcome.NOOP);
            if (!prLinked) out.put("link_hint", "ребро SHIPPED_IN " + prUid + " → " + ruid + " не создано — release_link rel:pr руками");
            if (!str(sprintId).isEmpty()) {
                // Оба ребра — разными вызовами, как учит feedback_release_link_sprint_and_pr.
                List<Map<String, Object>> sp = ingestService.queryPublic(
                    "SELECT sprint_id FROM KnowSprint WHERE sprint_id=:sid", Map.of("sid", sprintId));
                if (sp.isEmpty()) {
                    out.put("sprint_linked", false);
                    out.put("sprint_hint", "KnowSprint " + sprintId + " не найден");
                } else {
                    // Каждый PR спринта звал этот путь заново — без IF NOT EXISTS у
                    // спринта копилось по ребру IMPLEMENTED_IN_RELEASE на каждый мерж.
                    boolean spHad = edgeExists("IMPLEMENTED_IN_RELEASE", "sprint_id", sprintId, "release_uid", ruid);
                    if (!spHad)
                        writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                            "CREATE EDGE IMPLEMENTED_IN_RELEASE FROM (SELECT FROM KnowSprint WHERE sprint_id=:sid) " +
                            "TO (SELECT FROM KnowRelease WHERE release_uid=:ruid) IF NOT EXISTS",
                            Map.of("sid", sprintId, "ruid", ruid))).await().indefinitely();
                    boolean spLinked = spHad || edgeExists("IMPLEMENTED_IN_RELEASE", "sprint_id", sprintId, "release_uid", ruid);
                    out.put("sprint_linked", spLinked);
                    out.put("sprint_link_outcome", spHad ? LoreOutcome.UNCHANGED : spLinked ? LoreOutcome.CREATED : LoreOutcome.NOOP);
                }
            }
        } catch (Exception e) {
            LOG.warnf("[FORGEJO AUTOLINK] PR #%d: %s", prNumber, e.getMessage());
            out.put("linked", false);
            out.put("link_hint", "авто-линк упал (" + e.getMessage() + ") — release_link руками");
        }
        return out;
    }

    private Response upstream(Exception e) {
        LOG.warnf("[FORGEJO] %s", e.getMessage());
        return noStore(Response.status(Response.Status.BAD_GATEWAY)
            .entity(new LoreError("FORGEJO_UPSTREAM", e.getMessage())));
    }
}
