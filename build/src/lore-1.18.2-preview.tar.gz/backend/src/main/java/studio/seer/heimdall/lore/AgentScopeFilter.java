package studio.seer.heimdall.lore;

import io.quarkus.security.identity.SecurityIdentity;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.jboss.logging.Logger;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * AL-17 (R2) — вторая ось RBAC: ЧТО именно агенту позволено писать.
 *
 * <p>Первая ось ({@link SeerRoleFromTokenFilter}) отвечает на вопрос «пустить ли
 * вообще»: она выводит {@code X-Seer-Role} из realm-ролей токена. Но все семь
 * агентных профилей ходят с ролью {@code admin} — иначе им нечем писать, — и по
 * первой оси они неразличимы. Различие несёт claim {@code agent_scope}
 * ({@code agent-full}, {@code agent-pm}, …), который KC кладёт в токен client-ролью
 * профиля. До этого фильтра клейм существовал, но НИКТО его не проверял: маркетолог
 * с валидным токеном мог переписать ADR.
 *
 * <h2>Что проверяется</h2>
 * Только ЗАПИСЬ. Чтение (GET, слайсы) открыто всем агентам — так объявлено в
 * матрице прав админ-панели, строка «Чтение (слайсы) · все агенты».
 *
 * <h2>Кого проверяет</h2>
 * Только агентов, то есть носителей клейма {@code agent_scope}. У человека такого
 * клейма нет, и его права по-прежнему определяет {@code requireAdmin}. Поэтому
 * фильтр не может отобрать доступ у владельца — только у машины.
 *
 * <h2>Почему неперечисленное ПРОПУСКАЕТСЯ</h2>
 * Матрица покрывает не все семейства: под {@code /lore} живут ещё feature, uc,
 * pain, job, component, asset и другие. Запрет по умолчанию отрезал бы продуктовый
 * слой у architect/pm прямо посреди работы, причём отказом, неотличимым от поломки.
 * Поэтому неизвестное семейство пропускается и логируется — это строго лучше
 * нынешнего состояния, где не проверяется ВООБЩЕ ничего, и не создаёт новых
 * отказов. Закрывается расширением таблицы ниже, а не сменой поведения по умолчанию.
 *
 * <p><b>Таблица — копия матрицы из админ-панели</b> ({@code LoreAdminPanel.tsx},
 * {@code REVERSE_MATRIX}). Расхождение двух копий = права в UI показываются не те,
 * что применяются. Пиновано тестом {@code AgentScopeFilterTest}.
 */
@Provider
@Priority(Priorities.AUTHENTICATION + 200)
public class AgentScopeFilter implements ContainerRequestFilter {

    private static final Logger LOG = Logger.getLogger(AgentScopeFilter.class);

    /**
     * Семейства, закрытые для агентов совсем — их правит только человек.
     *
     * <p>{@code admin} добавлен АТ-66/АЛ-47 (регресс-гвард {@code
     * AgentScopeMatrixCoverageTest} поймал): {@code POST /lore/admin/lore/ingest}
     * перезапускает переиндексацию ВСЕГО корпуса документов (ADR, решения,
     * спринты, раннбуки, QG, доки, задачи, релизы) и был защищён только ролью
     * {@code admin} — а её несут все семь узких профилей, иначе им нечем
     * писать вообще. Маркетолог с валидным токеном мог передёрнуть весь ingest.
     */
    // AL-82/ADR-LORE-036: "user" — назначение проектной роли человеку. Тот же
    // класс, что dict/kc: правит человек, не агент (ADR-LORE-025-D13 прямо
    // запрещает MCP-инструменты для user-management) — иначе агент смог бы
    // выдать себе (своему владельцу) любую роль в любом проекте.
    // "project" (AL-84/ADR-LORE-025-D17) переехал в FAMILY_AGENTS ниже, поправка
    // 2026-08-11 (решение владельца) — см. комментарий там.
    // "news" (SPRINT_UXR_S7A_NEWS/S7A-04): единственная запись семейства — PUT
    // /lore/news/v2/read-mark, общая черта «прочитано». По §8 спеки новостей она
    // «сдвигается только действием пользователя»; агент, двигающий общую черту,
    // прятал бы владелице непрочитанное.
    // "record" (ADR-LORE-047 A2): POST /lore/record/{type}/{id}/relation — путь привязки
    // паспорта v2 в UI. Он ведёт в обработчики РАЗНЫХ семейств (sprint, task, adr, spec,
    // question), и строка матрицы для него расширила бы профиль, которому семейство цели
    // закрыто. Агенты привязывают через свои *_link (MCP) — там матрица по семейству цели.
    // model — правка модели LORE (MC-05, SPEC-LORE-MODEL-CONFIG-STORE §4): меняет поверхности всем, правит человек.
    // AP-07: users — профиль автора (имя, аватар). Свой меняет человек, чужой — админ; агенту правка лица не дана.
    // organization — решение владелицы 19.11.2026: организации заводит и связывает человек в админке (super-admin).
    private static final Set<String> HUMAN_ONLY = Set.of("dict", "kc", "admin", "user", "users", "news", "record", "model", "organization");

    /**
     * Семейство → профили, которым разрешена запись. Ключ — первый сегмент пути
     * после {@code /lore/}. Значения без префикса {@code agent-}.
     */
    // Пакетная видимость, а не private: набор читает сторож расхождения
    // AgentDefinitionsMatchMatrixTest — белые списки в .claude/agents обязаны
    // быть зеркалом этой матрицы, и расходиться они не должны молча.
    static final Map<String, Set<String>> FAMILY_AGENTS = Map.ofEntries(
        // developer заводит ADR (README профилей: adr_new) — решение владельца
        // 2026-07-18. Создание и правка неразделимы по пути: adr_new и adr_set
        // оба идут в POST /lore/adr (upsert). А вот разрушающие операции
        // разделимы, и они у developer'а изъяты — см. SUBPATH_AGENTS ниже.
        Map.entry("adr",       Set.of("full", "architect", "developer")),
        Map.entry("decision",  Set.of("full", "architect")),
        // SUPERTAGS-SPIKE (20.11.2026): тег с полями на ребре ADR/решения — POST /lore/tag/apply; те же,
        // кто ставит тег ADR (/lore/adr/tag): full, architect, developer.
        Map.entry("tag",       Set.of("full", "architect", "developer")),
        Map.entry("spec",      Set.of("full", "architect", "developer", "marketer")),
        Map.entry("runbook",   Set.of("full", "architect", "developer", "marketer")),
        Map.entry("doc",       Set.of("full", "architect", "developer", "marketer")),
        Map.entry("sprint",    Set.of("full", "pm")),
        Map.entry("milestone", Set.of("full", "pm")),
        Map.entry("phase",     Set.of("full", "pm")),
        // MDL-13: зависимость задачи, фазы, спринта и вехи (POST /lore/dep) — те же профили, что у прежнего sprint/dep.
        Map.entry("dep",       Set.of("full", "pm")),
        // architect добавлен по решению владельца 2026-07-20. Причина не в
        // удобстве: по ADR-LORE-014 §4 архитектор фигурирует АВТОРОМ и
        // РЕВЬЮЕРОМ задач — а завести задачу или перевести её в done не мог.
        // Роль, которая принимает работу, но не может отметить приёмку,
        // недееспособна.
        //
        // Заодно снято живое противоречие между осями: в профиле architect
        // стоял `status_set: allow`, то есть профиль разрешал то, что фильтр
        // запрещал. Не задело никого лишь потому, что под этим профилем ещё
        // не работали — а проявилось бы как AGENT_SCOPE_FORBIDDEN на действии,
        // которое админка показывает разрешённым.
        // product-analyst — SE-11, D-2026-LORE-AGENT-MATRIX-WIDEN-PROFILES (20.10.2026):
        // его профиль обещал task_set/status_set для своих research/analytics-задач
        // (ADR-LORE-015 §1b), а матрица отказывала.
        Map.entry("task",      Set.of("full", "pm", "developer", "tester", "marketer", "analyst", "architect", "product-analyst")),
        Map.entry("status",    Set.of("full", "pm", "developer", "tester", "marketer", "analyst", "architect", "product-analyst")),
        Map.entry("release",   Set.of("full", "developer")),
        Map.entry("qg",        Set.of("full", "tester")),
        Map.entry("question",  Set.of("full", "architect", "analyst", "pm", "product-analyst")),
        // metric/insight/rec СНЯТЫ (AL-47, регресс-гвард поймал): нет ни одного
        // write-пути с этими семействами — metric_log/insight_new пишут в
        // /lore/bragi/metric и /lore/bragi/insight (семейство "bragi"),
        // rec_new/rec_promote — в /lore/qg/recommendation (семейство "qg").
        // Мёртвые строки хуже отсутствующих: показывают права на несуществующее.
        // ── Продуктовый слой (ADR-LORE-022/030/032) ──────────────────────────
        // Владельцы по mcp-server/agent-profiles/README.md. Раньше эти семейства
        // были ВНЕ таблицы и пропускались как «неизвестные» — писать в них мог
        // любой профиль. Ключевой владелец, product-analyst, до этого коммита не
        // существовал в KC вовсе, хотя профиль был описан ещё в v1.0.53.
        Map.entry("feature",   Set.of("full", "architect", "pm", "product-analyst")),
        Map.entry("uc",        Set.of("full", "architect", "pm", "product-analyst")),
        Map.entry("pain",      Set.of("full", "architect", "pm", "product-analyst", "marketer")),
        Map.entry("gain",      Set.of("full", "architect", "pm", "product-analyst", "marketer")),
        Map.entry("job",       Set.of("full", "architect", "pm", "product-analyst", "marketer")),
        Map.entry("vp",        Set.of("full", "architect", "pm", "product-analyst")),
        Map.entry("actor",     Set.of("full", "architect", "pm")),
        // Проектный актор — то же семейство прав, что uc/feature/pain/gain, а не
        // что "actor" выше. Разница осмысленная: "actor" правит агентную ЛИЧНОСТЬ
        // (client_id, владелец, цепочка RBAC) и product-analyst туда не пускают;
        // здесь же описание того, кто действует в сценарии, — работа ровно того
        // же слоя, что сами сценарии. Держать его строже, чем UC, где этот актор
        // и упоминается, значило бы закрыть половину одной работы.
        //
        // Строка обязательна: без неё семейство «вне матрицы» и пропускается
        // ЛЮБОМУ профилю (см. allowed == null ниже) — тихо и с одной info-строкой
        // в логе. Отсутствие правила читалось бы как отсутствие доступа, а
        // означало бы обратное.
        Map.entry("project-actor", Set.of("full", "architect", "pm", "product-analyst")),
        // ── Продуктовая ОСЬ (RM-P6, D-2026-LORE-PRODUCT-IS-OWN-ENTITY) ───────
        // Не путать с продуктовым СЛОЕМ выше: там Feature → UseCase → ценность,
        // здесь «что мы делаем и продаём» — носитель дорожной карты. Совпадение
        // по слову «продукт», не по смыслу; пути тоже соседние (/lore/product/*).
        //
        // Внесено СРАЗУ, а не после аудита: до этой строки семейство `product`
        // в матрице отсутствовало, и `POST /lore/product/link` прошёл бы под
        // любым агентным профилем — фильтр неизвестные семейства ПРОПУСКАЕТ
        // (строка «семейство вне матрицы — пропускаю»). Ровно так же в v1.7.1
        // оказался открыт `/lore/quality`. Три GET-эндпоинта продуктового слоя
        // под тем же префиксом этой строкой не затрагиваются: READ_METHODS вне
        // проверки.
        Map.entry("product",   Set.of("full", "architect", "pm", "product-analyst")),
        // canvas (SPRINT_UXR_S7C_WHY_CANVAS/S7C-01) — холст «зачем»: VP-канва, BMC,
        // карта историй. Это продуктовый слой, поэтому те же профили, что у pain/gain/
        // job и фич, плюс analyst. Строкой, а не пропуском «неизвестного семейства».
        Map.entry("canvas",    Set.of("full", "architect", "pm", "product-analyst", "analyst")),
        // ── Прочее из README, чего тоже не было ──────────────────────────────
        Map.entry("component", Set.of("full", "architect")),
        // tech СНЯТ (AL-47, тем же гвардом): tech_set пишет через существующий
        // spec-upsert путь (/lore/spec, spec_id="SPEC-TECH-..."), не заводит
        // отдельного /lore/tech — семейство "spec" уже покрывает этот путь.
        // "project" (AL-84/ADR-LORE-025-D17, поправка 2026-08-11, решение
        // владельца): единственный практический путь заведения проекта был
        // мёртв — сидел в HUMAN_ONLY, ни один из семи агентных профилей не
        // писал сюда, а у человека нет ни UI-кнопки, ни отдельной проверенной
        // superadmin-учётки. Открыт РОВНО full — остальные шесть профилей
        // по-прежнему без доступа. Человеческий порог не тронут: см.
        // LoreResourceBase.requireSuperAdminOrProjectAgent (там же по-прежнему
        // нужна именно superadmin, не admin).
        // architect и pm — SE-11 (20.10.2026): их профили обещали project_new. Замок в
        // ресурсе (requireSuperAdminOrProjectAgent) читает ЭТУ строку, второго списка нет.
        Map.entry("project",   Set.of("full", "architect", "pm")),
        // "repository" — реестр репозиториев (22.11.2026). Слово владелицы: «репозиторий только админам И КТО
        // ЗАВОДИТ ПРОЕКТЫ» — отсюда тот же набор профилей, что у project, и тот же замок в ресурсе
        // (requireSuperAdminOrProjectAgent). Организация строже: она в HUMAN_ONLY и там остаётся —
        // «организацию только с административными правами full и с подтверждением».
        Map.entry("repository", Set.of("full", "architect", "pm")),
        Map.entry("bragi",     Set.of("full", "marketer")),
        // NB: «quality» и «quality-gate» ниже — РАЗНЫЕ семейства. Первое —
        // проверка полноты записи (ничего не пишет, открыта всем), второе —
        // создание гейта качества (full/tester). familyOf() режет путь по '/',
        // так что рантайм их не путает; путает человек, отсюда эта пометка.
        //
        // quality (QUAL-7) — POST по форме, но НИЧЕГО не пишет: спрашивает
        // вердикт полноты по уже существующим объектам. Метод выбран POST не
        // ради записи, а потому что список id не влезает в query-строку.
        // Открыт всем профилям: узнать, чего не хватает в СВОЕЙ записи, обязан
        // мочь любой, кто эту запись заводит, — иначе линтер учит дисциплине
        // только полный профиль, а остальные о своих пробелах не знают.
        Map.entry("quality",   Set.of("full", "architect", "developer", "pm", "marketer",
                                      "analyst", "product-analyst", "tester")),
        // find (SPRINT_SEIDRKIT_GRAPH_CANVAS/GC-05) — POST по форме, но НИЧЕГО не пишет:
        // структурный запрос «тип + поля + связь» (дерево И/ИЛИ/НЕ не влезает в строку).
        // Чтение графа открыто всем профилям, как срезы и /lore/graph.
        Map.entry("find",      Set.of("full", "architect", "developer", "pm", "marketer",
                                      "analyst", "product-analyst", "tester")),
        // me (SPRINT_UXR_S2_GRAPH_MEMORY/S2-04, D-2026-UXR-VIEWS-SERVER) — личный слой:
        // виды, избранное, недавние, настройки. «Видимость — сам пользователь и его
        // агенты»: агент пишет ОТ ИМЕНИ своего владельца (LoreMeResource берёт владельца
        // по OWNED_BY), поэтому открыто всем профилям. Строкой, а не пропуском
        // «неизвестного семейства» — чтобы решение было видно, а не подразумевалось.
        // sources (SPRINT_LORE_AGENT_OBSERVABILITY/AO-02) — след прочитанного: MCP после
        // успешного создания записи пишет рёбра SOURCED_FROM к источникам, которые агент
        // читал. Пишет тот же профиль, что создал запись, поэтому открыто всем агентным
        // профилям; запись в саму цель уже прошла матрицу по своему семейству. Строкой,
        // а не пропуском «неизвестного семейства», — чтобы решение было видно.
        Map.entry("sources",   Set.of("full", "architect", "developer", "pm", "marketer",
                                      "analyst", "product-analyst", "tester")),
        Map.entry("me",        Set.of("full", "architect", "developer", "pm", "marketer",
                                      "analyst", "product-analyst", "tester")),
        // link (SPRINT_UXR_S2_GRAPH_MEMORY/S2-06, D-2026-UXR-LINK-MENTION-EDGE) — «Связать»
        // из упоминаний: ребро между двумя любыми записями каталога LoreLinkTypes.
        // Здесь — ВХОД для всех, кто пишет хоть одну сущность каталога; настоящее
        // решение принимает LoreLinkResource по семейству ИСХОДНОЙ записи ребра
        // (ребро «принадлежит» записи, из которой выходит, как у adr_link/task_link)
        // через decide() этой же матрицы — второго списка прав нет.
        Map.entry("link",      Set.of("full", "architect", "developer", "pm", "marketer",
                                      "analyst", "product-analyst", "tester")),
        // ── Найдено сверкой таблицы с реальными путями записи (AL-62) ────────
        // Три семейства имели живой POST под /lore, но в матрице отсутствовали,
        // то есть попадали в ветку «неизвестное — пропускаю». Права выставлены
        // ПО ФАКТУ, а не на глаз: forgejo_* и asset_* не разрешены ни в одном
        // ограниченном профиле (agent-profiles/*.json — у всех "*": "deny" плюс
        // allow-лист), у tester разрешён qg_*. Поэтому ни одна строка не
        // создаёт новых отказов — требование, которое фильтр сам себе ставит.
        //
        // forgejo: POST /lore/forgejo/pr и pr/{n}/merge. Мерж PR мог сделать
        // ЛЮБОЙ профиль, хотя ADR-LORE-024 прямо говорит «merge только full».
        // Отделить merge подпутём нельзя: subPathOf берёт два сегмента, и
        // forgejo/pr/{n}/merge сворачивается в forgejo/pr вместе с созданием PR.
        Map.entry("forgejo",   Set.of("full")),
        // asset: POST /lore/asset/upload, единственный вызывающий — asset_up.
        Map.entry("asset",     Set.of("full")),
        // quality-gate: СОЗДАНИЕ гейта. В таблице был только "qg" — прогоны и
        // рекомендации, — из-за чего получилось расщепление, которого никто не
        // задумывал: записать прогон нельзя, а завести сам гейт можно кому угодно.
        Map.entry("quality-gate", Set.of("full", "tester")));

    /**
     * Исключения УЖЕ семейства: конкретный подпуть с более узким списком.
     * Проверяется раньше семейства и только точным совпадением.
     *
     * <p>Нужны там, где «завести» и «снести» — разные по последствиям операции на
     * одном семействе. developer'у положено авторствовать ADR, но не удалять и не
     * переименовывать чужие: восстановление после ошибочного сноса стоит несопоставимо
     * дороже, чем сам снос, а отличить «ошибся» от «так и хотел» постфактум нельзя.
     */
    private static final Map<String, Set<String>> SUBPATH_AGENTS = Map.of(
        "adr/delete",   Set.of("full", "architect"),
        "adr/rename",   Set.of("full", "architect"),
        "spec/delete",  Set.of("full", "architect"),
        "doc/delete",   Set.of("full", "architect"),
        // AL-83/ADR-LORE-036: назначение владельца агента — пустой набор, а не
        // отсутствие строки: НИ ОДИН агентный профиль, включая full, не пишет
        // сюда. Иначе агент мог бы переписать себе владельца на человека с
        // более широкими правами — self-эскалация через ровно тот механизм,
        // которым AL-68 будет выводить эффективные права агента.
        "actor/owner",  Set.of(),
        // S7B-MACH-1: заведение машины — заметка задачи «Права: полная роль (или admin)». Семейство
        // actor открыто ещё architect/pm — подпуть сужен до full. Владельца агент не выбирает:
        // машина получает владельца самого агента (MachineEnroll.owner), граница AL-83 цела.
        "actor/machine", Set.of("full"));

    /**
     * Точечные РАСШИРЕНИЯ внутри семейства: подпуть, открытый профилям, которым
     * семейство целиком не положено. Зеркало {@link #SUBPATH_AGENTS} (тот только
     * сужает).
     *
     * <p>SE-11, решение владельца 20.10.2026 («открыть точечно»,
     * D-2026-LORE-AGENT-MATRIX-WIDEN-PROFILES). Профили analyst/product-analyst
     * обещали insight_* и metric_log, analyst/product-analyst/marketer — rec_*;
     * эти инструменты пишут в {@code /lore/bragi/...} и {@code /lore/qg/...}.
     * Открыть семейства целиком значило бы отдать аналитику публикации BRAGI, а
     * маркетологу — гейты качества: этого профили не обещали.
     */
    private static final Map<String, Set<String>> SUBPATH_GRANTS = Map.of(
        "bragi/insight",     Set.of("analyst", "product-analyst"),
        "bragi/metric",      Set.of("analyst", "product-analyst"),
        "qg/recommendation", Set.of("analyst", "product-analyst", "marketer"),
        "qg/promote",        Set.of("analyst", "product-analyst", "marketer"));

    /** Для админки и сторожей: точечные расширения как есть. */
    static Map<String, Set<String>> subpathGrants() { return SUBPATH_GRANTS; }

    /**
     * Изъятия из {@link #HUMAN_ONLY}: подпуть, который человеческому семейству
     * принадлежит, но конкретным профилям всё же открыт.
     *
     * <p>Нужен отдельный список, а не строка в {@link #SUBPATH_AGENTS}: тот
     * только СУЖАЕТ права внутри разрешённого семейства и на запрет семейства не
     * влияет — разрешение там прошло бы проверку подпути и уткнулось бы в
     * HUMAN_ONLY строкой ниже. Такое «разрешение», которое ничего не разрешает,
     * — худший вид записи в матрице прав: выглядит как право, работает как его
     * отсутствие.
     *
     * <p><b>user/role</b> — решение владельца 30.08.2026: «раз full наследует от
     * admin, то разрешается только роли full». Обнаружено, когда full-сессия не
     * смогла завести актора для AIDA/MIDGARD: у владельца не было роли в этом
     * проекте, а выдать её агент не мог. При этом full уже пишет ADR, решения,
     * спринты, релизы и проекты — запрет именно на роли не защищал ничего, а
     * останавливал работу там, где всё прочее разрешено.
     *
     * <p>Что этим ослабляется, названо прямо в
     * {@code D-2026-LORE-FULL-WRITES-PROJECT-ROLES}: full сможет выдать роль
     * своему владельцу, то есть расширить собственное делегирование. Граница,
     * которая НЕ двигается, — {@code actor/owner} выше: назначение владельца
     * агента закрыто для всех профилей, включая full, поэтому присвоить чужую
     * цепочку прав нельзя. Плюс выдача роли журналируется
     * ({@code KnowProjectRoleEvent}), то есть остаётся видимой постфактум.
     */
    private static final Map<String, Set<String>> HUMAN_ONLY_EXEMPT = Map.of(
        "user/role", Set.of("full"));

    /**
     * Чистая функция изъятия — отдельно тестируема без контейнера.
     *
     * @return {@code null}, если подпуть не изъят (решает обычная матрица);
     *         иначе — разрешён ли он этому профилю.
     */
    static Boolean humanOnlyExemption(String subPath, String scope) {
        Set<String> allowed = HUMAN_ONLY_EXEMPT.get(subPath);
        return allowed == null ? null : allowed.contains(scope);
    }

    /** Методы, которые ничего не меняют — вне проверки. Package-private: AL-20 (аудит-лог) тоже фильтрует по ним. */
    static final Set<String> READ_METHODS = Set.of("GET", "HEAD", "OPTIONS");

    /** Чтобы «семейство вне матрицы» логировалось один раз, а не на каждый запрос. */
    private final Set<String> loggedUnlisted = ConcurrentHashMap.newKeySet();

    @Inject
    SecurityIdentity identity;

    @ConfigProperty(name = "quarkus.oidc.enabled", defaultValue = "false")
    boolean oidcEnabled;

    @Override
    public void filter(ContainerRequestContext ctx) {
        if (!oidcEnabled) return;                       // dev/local — токенов нет вовсе
        if (READ_METHODS.contains(ctx.getMethod())) return;
        if (identity == null || identity.isAnonymous()) return;  // отказ — забота первой оси

        String tokenScope = agentScope();
        if (tokenScope == null) return;                 // человек, а не агент

        String path = ctx.getUriInfo().getPath();
        // AO-07: агент full может заявить профиль на действии — запись решает его матрица.
        Effective eff = effectiveScope(tokenScope, ctx.getHeaderString(ACT_AS_HEADER));
        if (eff.refusal() != null) {
            deny(ctx, tokenScope, ACT_AS_HEADER, eff.refusal());
            return;
        }
        String scope = eff.scope();
        String approval = humanApproval(ctx.getHeaderString(HUMAN_APPROVAL_HEADER));
        Denial d = decide(scope, path, approval);
        if (d != null) {
            deny(ctx, scope, d.what(), d.why());
            return;
        }
        if (approval != null && decide(scope, path) != null) {
            // Пропущено только благодаря разрешению — каждая такая запись видна в журнале.
            LOG.warnf("[agent-scope] %s с разрешения человека: профиль %s, %s %s, разрешил: «%s»",
                familyOf(path), scope, ctx.getMethod(), path, approval.strip());
        }
        String family = familyOf(path);
        if (family != null && !HUMAN_ONLY.contains(family) && !FAMILY_AGENTS.containsKey(family)
                && loggedUnlisted.add(family)) {
            LOG.infof("[agent-scope] семейство '%s' вне матрицы прав — пропускаю. "
                + "Закрыть = добавить строку в FAMILY_AGENTS и в REVERSE_MATRIX админки", family);
        }
    }

    /** Отказ: что именно закрыто (семейство или подпуть) и почему. */
    record Denial(String what, String why) {}

    /**
     * Решение по одной записи агента — чистая функция, без контейнера.
     *
     * <p>Вынесена из {@link #filter}, чтобы сторож профилей
     * (AgentProfilesMatchMatrixTest) проверял ТУ ЖЕ логику, что отказывает на
     * проде, а не её пересказ: подпути, изъятия из HUMAN_ONLY и пропуск
     * семейства вне матрицы — всё отсюда.
     *
     * @return {@code null} — запись пропускается; иначе отказ
     */
    /**
     * Решение владелицы 09.11.2026 («перепиши правило — с разрешения человека»): семейства,
     * которые агент full может править, если в запросе назван разрешивший человек
     * ({@link #HUMAN_APPROVAL_HEADER}). Только справочник: kc/admin/user/news/record остаются
     * человеческими без исключений.
     */
    static final Set<String> HUMAN_APPROVABLE = Set.of("dict");
    /** Заголовок «кто из людей разрешил и где», URL-кодированный (кириллица в заголовке HTTP недопустима). */
    static final String HUMAN_APPROVAL_HEADER = "X-Lore-Human-Approval";
    static final int HUMAN_APPROVAL_MAX = 300;

    /**
     * Решение с учётом разрешения человека. Без разрешения — ровно {@link #decide(String, String)}.
     * С разрешением открывается только запрет человеческого семейства из {@link #HUMAN_APPROVABLE}
     * и только для профиля full; прочие проверки (подпути, матрица) не ослабляются.
     */
    static Denial decide(String scope, String path, String humanApproval) {
        Denial d = decide(scope, path);
        if (d == null || humanApproval == null) return d;
        String a = humanApproval.strip();
        if (a.isEmpty() || a.length() > HUMAN_APPROVAL_MAX) return d;
        String family = familyOf(path);
        if ("full".equals(scope) && HUMAN_APPROVABLE.contains(family) && family.equals(d.what())) return null;
        return d;
    }

    /** Значение заголовка разрешения, раскодированное; битое кодирование = разрешения нет. */
    static String humanApproval(String header) {
        if (header == null || header.isBlank()) return null;
        try {
            return java.net.URLDecoder.decode(header, java.nio.charset.StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    static Denial decide(String scope, String path) {
        String family = familyOf(path);
        if (family == null) return null;
        String sub = subPathOf(path);

        // Подпуть проверяется ПЕРВЫМ: он сужает права внутри разрешённого семейства.
        Set<String> narrowed = SUBPATH_AGENTS.get(sub);
        if (narrowed != null && !narrowed.contains(scope))
            return new Denial(sub, "разрушающая операция; доступна: " + String.join(", ", narrowed));

        // Изъятие проверяется ДО запрета семейства: иначе разрешение подпути не
        // имело бы силы — строка ниже отвергла бы его вместе со всем семейством.
        Boolean exempt = humanOnlyExemption(sub, scope);
        if (exempt != null) {
            if (!exempt)
                return new Denial(sub, "подпуть человеческого семейства открыт только: "
                    + String.join(", ", HUMAN_ONLY_EXEMPT.get(sub)));
            // Разрешено явно — HUMAN_ONLY к этому подпути не применяется.
        } else if (HUMAN_ONLY.contains(family)) {
            return new Denial(family, "это семейство правит только человек");
        }
        Set<String> granted = SUBPATH_GRANTS.get(sub);
        if (granted != null && granted.contains(scope)) return null;
        Set<String> allowed = FAMILY_AGENTS.get(family);
        if (allowed == null) return null;               // вне матрицы — пропуск (см. лог в filter)
        if (!allowed.contains(scope))
            return new Denial(family, "профилю доступны: " + String.join(", ", allowed));
        return null;
    }

    /**
     * Значение-отказ для токена с двумя РАЗНЫМИ профилями (AO-07, 10.09.2026).
     *
     * <p>Не совпадает ни с одним профилем матрицы, поэтому любая запись такого
     * вызывающего отказывает. Это НЕ null намеренно: null для фильтра значит
     * «человек, не агент», а такого пропускают вовсе без агентских ограничений —
     * неоднозначный токен получил бы больше прав, чем любой из его профилей.
     */
    static final String AMBIGUOUS_SCOPE = "__ambiguous_agent_scope__";

    /**
     * Значение {@code agent_scope} без префикса {@code agent-}, либо null для человека.
     *
     * <p>Клейм многозначный (client-роли), но профиль у токена ровно один. Два
     * РАЗНЫХ профиля означают ошибку провижининга, и на них возвращается
     * {@link #AMBIGUOUS_SCOPE} — отказ. Один профиль, повторённый маппером, —
     * не неоднозначность и определяется как этот профиль.
     *
     * <p>До 10.09.2026 этот javadoc обещал ровно такое поведение («молча выбирать
     * было бы опаснее, чем отказать»), а код брал первый элемент. Расхождение
     * было безвредным, пока у токена был один профиль; с профильными клиентами
     * неверная настройка ролей дала бы агенту права случайного из двух — без
     * единой ошибки.
     */
    private String agentScope() {
        return agentScopeOf(identity);
    }

    /**
     * Статический вариант {@link #agentScope()} — вынесен для AL-20 (аудит-лог):
     * фильтру логирования нужна ТА ЖЕ логика разбора клейма (включая снятие кавычек
     * ниже), а не вторая копия с риском разойтись после следующей правки одной из них.
     */
    static String agentScopeOf(SecurityIdentity identity) {
        if (!(identity.getPrincipal() instanceof JsonWebToken jwt)) return null;
        Object raw = jwt.getClaim("agent_scope");
        if (raw == null) return null;
        java.util.Set<String> profiles = new java.util.LinkedHashSet<>();
        if (raw instanceof Collection<?> c) {
            for (Object o : c) addProfile(profiles, unquote(String.valueOf(o)));
        } else {
            addProfile(profiles, unquote(String.valueOf(raw)));
        }
        if (profiles.isEmpty()) return null;
        if (profiles.size() > 1) return AMBIGUOUS_SCOPE;
        return profiles.iterator().next();
    }

    /** Нормализует значение клейма к имени профиля; пустые пропускает, повторы схлопывает Set. */
    private static void addProfile(java.util.Set<String> out, String value) {
        if (value == null || value.isBlank()) return;
        out.add(value.startsWith("agent-") ? value.substring("agent-".length()) : value);
    }

    /**
     * Снимает кавычки, которые приходят ВМЕСТЕ со значением из JSON-клейма.
     *
     * <p>Клейм многозначный, поэтому в токене это JSON-массив, а его элементы —
     * {@code JsonString}. У них {@code toString()} отдаёт значение <b>в кавычках</b>:
     * {@code "agent-full"}, а не {@code agent-full}. Без снятия кавычек проверка
     * {@code startsWith("agent-")} ниже не срабатывает, префикс остаётся, и скоуп
     * не совпадает ни с одной строкой матрицы — фильтр отсекает ВСЕХ агентов,
     * включая full.
     *
     * <p>Найдено первым же живым запросом после включения auth (2026-07-19):
     * <pre>AGENT_SCOPE_FORBIDDEN: профиль agent-"agent-full" не пишет в 'status'</pre>
     * Двойной префикс в сообщении и есть след необрезанных кавычек. Юнит-тесты
     * этого не ловили: они подставляли готовую строку, а не JSON-значение —
     * то есть проверяли таблицу прав, но не путь получения скоупа.
     *
     * <p>Снимаем именно так, а не приведением к {@code JsonString}: клейм может
     * прийти и обычной строкой (другой провайдер, другой маппер), и тогда
     * приведение упало бы. Обрезка кавычек верна в обоих случаях.
     */
    static String unquote(String s) {
        if (s == null) return null;
        return (s.length() >= 2 && s.charAt(0) == '"' && s.charAt(s.length() - 1) == '"')
            ? s.substring(1, s.length() - 1)
            : s;
    }

    /** Первый сегмент после {@code lore/}: "lore/task/link" → "task". */
    static String familyOf(String path) {
        if (path == null) return null;
        String p = path.startsWith("/") ? path.substring(1) : path;
        if (!p.startsWith("lore/")) return null;
        String rest = p.substring("lore/".length());
        int slash = rest.indexOf('/');
        String head = slash < 0 ? rest : rest.substring(0, slash);
        return head.isBlank() ? null : head;
    }

    /** Два первых сегмента после {@code lore/}: "lore/adr/delete" → "adr/delete". */
    static String subPathOf(String path) {
        if (path == null) return "";
        String p = path.startsWith("/") ? path.substring(1) : path;
        if (!p.startsWith("lore/")) return "";
        String[] parts = p.substring("lore/".length()).split("/");
        return parts.length >= 2 ? parts[0] + "/" + parts[1] : "";
    }

    private void deny(ContainerRequestContext ctx, String scope, String family, String why) {
        // Профиль и семейство В ОТВЕТЕ намеренно: агент читает свои ошибки сам, и
        // «403 без объяснения» превращается в слепой перебор. Секретов здесь нет.
        LOG.warnf("[agent-scope] отказ: профиль '%s' → семейство '%s' (%s)", scope, family, why);
        ctx.abortWith(Response.status(Response.Status.FORBIDDEN)
            .type(MediaType.APPLICATION_JSON)
            .entity(new LoreResourceBase.LoreError("AGENT_SCOPE_FORBIDDEN",
                "профиль agent-" + scope + " не пишет в '" + family + "': " + why))
            .build());
    }

    /** Заголовок заявки профиля на действии (AO-07, путь «full заявляет роль»). */
    static final String ACT_AS_HEADER = "X-Lore-Act-As";

    /** Действующий профиль записи либо причина отказа. */
    record Effective(String scope, String refusal) {}

    /** Все профили, известные матрице (значения FAMILY_AGENTS, подпутей и грантов). */
    static Set<String> knownProfiles() {
        Set<String> all = new java.util.TreeSet<>();
        FAMILY_AGENTS.values().forEach(all::addAll);
        SUBPATH_AGENTS.values().forEach(all::addAll);
        SUBPATH_GRANTS.values().forEach(all::addAll);
        HUMAN_ONLY_EXEMPT.values().forEach(all::addAll);
        return all;
    }

    /**
     * AO-07, решение владельца 04.11 «оба пути»: «если full, то сам агент заявляет
     * роль, либо при регистрации только роль».
     *
     * <ul>
     *   <li>Заявки нет — профиль из токена, как раньше.</li>
     *   <li>Токен {@code full} + заявка известного профиля — запись решает матрица
     *       ЗАЯВЛЕННОГО профиля. Заявка только сужает: full и так может всё.</li>
     *   <li>Профиль, закреплённый регистрацией (свой клиент), заголовком не меняется —
     *       иначе заголовок стал бы способом сменить права. Повтор своего — не смена.</li>
     *   <li>Неизвестный заявленный профиль — отказ с его именем, а не тихое
     *       игнорирование: опечатка дала бы агенту права full.</li>
     * </ul>
     */
    static Effective effectiveScope(String tokenScope, String declared) {
        if (declared == null || declared.isBlank()) return new Effective(tokenScope, null);
        String d = declared.trim();
        if (d.startsWith("agent-")) d = d.substring("agent-".length());
        if (AMBIGUOUS_SCOPE.equals(tokenScope))
            return new Effective(tokenScope, "токен с двумя профилями — заявка не принимается");
        if (d.equals(tokenScope)) return new Effective(tokenScope, null);
        if (!"full".equals(tokenScope))
            return new Effective(tokenScope, "профиль agent-" + tokenScope
                + " закреплён регистрацией клиента; заявить '" + d + "' нельзя");
        if (!knownProfiles().contains(d) || "full".equals(d))
            return new Effective(tokenScope, "неизвестный профиль '" + d + "' в " + ACT_AS_HEADER
                + "; известны: " + String.join(", ", knownProfiles()));
        return new Effective(d, null);
    }

    /** Для preflight/тестов: какие семейства реально под контролем. */
    static List<String> enforcedFamilies() {
        return FAMILY_AGENTS.keySet().stream().sorted().toList();
    }

    static Set<String> humanOnlyFamilies() {
        return HUMAN_ONLY;
    }
}
