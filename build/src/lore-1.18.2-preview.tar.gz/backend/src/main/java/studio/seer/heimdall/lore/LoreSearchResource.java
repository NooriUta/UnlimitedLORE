package studio.seer.heimdall.lore;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * SRCH-05 — сквозной поиск v2: {@code GET /lore/search} (ADR-LORE-033 D1–D5).
 *
 * <p><b>Почему отдельный эндпоинт, а не слайс.</b> compose() слайсов клеит
 * optional-фильтры без AND и не умеет заходить внутрь unionall-веток — фасеты
 * (тип/компонент/проект) обязаны отсекать НА УРОВНЕ ВЕТКИ («фильтр туда, куда
 * ходим», требование владельца), а не постфильтром по собранной выдаче.
 * Ветки выполняются по одной и сливаются в Java.
 *
 * <p><b>Почему по одной, а не одним unionall (DBU-17, замер 20.10.2026).</b>
 * Прежняя причина — «$score в unionall теряется» — НЕВЕРНА: замер 11.09
 * показал, что скор переживает объединение разнотипных веток с разными
 * индексами, а «потерянный скор» оказался null у попаданий по коду записи
 * через {@code id ILIKE OR SEARCH_INDEX} (RM-P16), с unionall не связанный.
 * Настоящая причина — изоляция отказа: каждая ветка отвечает за себя
 * ({@code warnings}, «наполовину» DBR-05, «сканом вместо индекса» DBR-09), и
 * упавшая ветка гасит один тип, а не весь поиск. Одно объединение упало бы
 * целиком. Цена раздельности измерена на боевом корпусе, 15 FT-ядер веток,
 * медианы по 25 повторам: по одной 20–31 мс, одним объединением 3–8 мс,
 * выигрыш 17–23 мс при поиске целиком 62–167 мс. Если поиск когда-нибудь
 * станет медленным, почти тот же выигрыш даёт параллельный запуск веток — без
 * потери изоляции.
 *
 * <p><b>Ранжирование (D3).</b> BM25 не откалиброван между бакетами (докам
 * ArcadeDB это известно), поэтому внутри ветки score нормируется на максимум
 * ветки и умножается на приоритет типа. Приоритеты — из утверждённого
 * прототипа search-ranking-srch05.html, переопределяются конфигом
 * {@code lore.search.type-priority} (вид {@code adr:1.25,task:0.7}) без
 * пересборки.
 *
 * <p><b>Фасет компонента/проекта с наследованием (несущее).</b> Прямые рёбра
 * BELONGS_TO есть у меньшинства (у задач 0/2847) — компонент/проект выводятся
 * от родителя: задача → спринт (PART_OF), решение → ADR (DECIDED_IN). Выведенная
 * привязка помечается {@code inherited_from}, фильтр учитывает ОБА пути.
 *
 * <p><b>href в ответе НЕТ намеренно</b> (отступление от D1): маршруты секций
 * владеет UI, серверная догадка о них протухала бы молча. UI строит ссылку из
 * {@code type + ref_id}.
 */
@Path("/lore")
public class LoreSearchResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreSearchResource.class);

    /** DBR-09: вердикт о пригодности FT-индекса — по нему ветка идёт индексом или сканом. */
    @jakarta.inject.Inject
    LoreFtIndexHealth ftHealth;

    /** Ветка поиска: всё, что нужно знать об одном типе. */
    record Branch(
        String type,            // имя типа в API (adr, task, …)
        String vertexClass,     // KnowADR…
        String idField,         // adr_id…
        String titleField,      // name | title
        String indexName,       // ftKnowADR; null → ILIKE-fallback (QualityGate)
        List<String> vertexTextFields, // индексированные поля НА вершине (для сниппета)
        String histClass,       // KnowADRHist; null → тел в hist нет
        String histIndexName,
        List<String> histTextFields,
        String compExpr,        // SQL-выражение: прямые компоненты
        String compInheritedExpr, // SQL: выведенные от родителя (null → нет пути)
        String inheritedFrom,   // подпись источника наследования (sprint | adr)
        String projExpr,        // SQL: слаги проектов (с учётом наследования)
        double priority
    ) {}

    // Пути компонентов/проектов — те же выражения, что в живых слайсах
    // (adrs/specs/tasks_of_sprint): расхождение с ними означало бы, что фасет
    // фильтрует не по тому, что показывают экраны.
    private static final String DIRECT_COMP = "out('BELONGS_TO').component_id";
    private static final String DIRECT_PROJ = "out('BELONGS_TO_PROJECT').slug";

    /** Название родителя для ветки по версиям: поле или coalesce(полей) — каждое через in('HAS_STATE'). */
    static String histTitle(String titleField) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?i)coalesce\\((.*)\\)").matcher(titleField.trim());
        if (!m.matches()) return "in('HAS_STATE')." + titleField + "[0]";
        List<String> parts = new ArrayList<>();
        for (String a : m.group(1).split(",")) parts.add("in('HAS_STATE')." + a.trim() + "[0]");
        return "coalesce(" + String.join(", ", parts) + ")";
    }

    private static final List<Branch> BRANCHES = List.of(
        new Branch("adr", "KnowADR", "adr_id", "name", "ftKnowADR",
            List.of("name"),
            "KnowADRHist", "ftKnowADRHist", List.of("context_md", "decision_md", "consequences_md"),
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.25),
        new Branch("spec", "KnowSpec", "spec_id", "title", "ftKnowSpec",
            List.of("title"),
            "KnowSpecHist", "ftKnowSpecHist", List.of("content_md"),
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.10),
        // D-2026-MIG-SPRINT-PHASE-TITLE: название спринта в новой схеме — title; context_md живёт в версии (KnowSprintHist)
        // старая схема: name заполнено, title пуст — читаем оба (полный прогон 19.11: поиск спринта по имени был пуст)
        new Branch("sprint", "KnowSprint", "sprint_id", "coalesce(title, name)", "ftKnowSprint",
            List.of("title", "name"),
            "KnowSprintHist", "ftKnowSprintHist", List.of("context_md", "outcome_md"),
            DIRECT_COMP, null, null, DIRECT_PROJ, 0.90),
        // Задачи: прямые компоненты — TAGGED_WITH (task_link rel=component);
        // выведенные — от спринта через PART_OF. Проект — только через спринт.
        new Branch("task", "KnowTask", "task_uid", "title", "ftKnowTask",
            List.of("title"),
            "KnowTaskHist", "ftKnowTaskHist", List.of("note_md"),
            "out('TAGGED_WITH').component_id",
            "out('PART_OF')." + DIRECT_COMP, "sprint",
            "out('PART_OF')." + DIRECT_PROJ, 0.70),
        // Решения: своих BELONGS_TO обычно нет — наследуют от родительского ADR.
        new Branch("decision", "KnowDecision", "decision_id", "title", "ftKnowDecision",
            List.of("title", "body_md"),
            null, null, null,
            DIRECT_COMP, "out('DECIDED_IN')." + DIRECT_COMP, "adr",
            DIRECT_PROJ, 1.20),
        new Branch("question", "KnowQuestion", "question_id", "title", "ftKnowQuestion",
            List.of("title", "body_md"),
            null, null, null,
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.00),
        new Branch("runbook", "KnowRunbook", "runbook_id", "name", "ftKnowRunbook",
            List.of("name"),
            "KnowRunbookHist", "ftKnowRunbookHist", List.of("content_md"),
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.05),
        new Branch("doc", "KnowDoc", "doc_id", "title", "ftKnowDoc",
            List.of("title", "content_md", "content_md_en", "content_md_ru"),
            "KnowDocHist", "ftKnowDocHist", List.of("content_md"),
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.10),
        // FT-индекса на QualityGate нет (реестр V11/V12) — единственная ветка
        // на ILIKE; score у неё симулируется константой ниже.
        new Branch("quality_gate", "QualityGate", "qg_id", "name", null,
            List.of("name", "content_md"),
            null, null, null,
            "component_id", null, null, DIRECT_PROJ, 0.80),
        // ── продуктовый слой ──
        // PL-28: ветка ОДНА. Фича перестала быть отдельным типом (решение №141),
        // и две ветки над одним KnowUseCase дали бы дубли в выдаче: один и тот
        // же документ пришёл бы дважды с разным приоритетом.
        //
        // Приоритет взят верхний из прежней пары (1.30, был у фичи), а не
        // средний: слияние типов не повод понижать продуктовый слой, а «фича»
        // и «сценарий» теперь одинаково релевантны запросу о продукте.
        // Тела обоих прежних веток объединены — body_md/context_md пришли от
        // корня, scenario_md/acceptance_md от сценария, и оба живут на одном типе.
        new Branch("use_case", "KnowUseCase", "uc_id", "title", "ftKnowUseCase",
            List.of("title", "body_md", "context_md", "scenario_md", "acceptance_md"),
            null, null, null,
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.30),
        new Branch("pain", "KnowPain", "pain_id", "title", "ftKnowPain",
            List.of("title", "body_md"),
            null, null, null,
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.25),
        new Branch("gain", "KnowGain", "gain_id", "title", "ftKnowGain",
            List.of("title", "body_md", "metric_md"),
            null, null, null,
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.25),
        new Branch("job", "KnowJob", "job_id", "title", "ftKnowJob",
            List.of("title", "body_md"),
            null, null, null,
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.25),
        new Branch("actor", "KnowProjectActor", "actor_id", "name", "ftKnowProjectActor",
            List.of("name", "body_md"),
            null, null, null,
            DIRECT_COMP, null, null, DIRECT_PROJ, 1.20),

        // Релизы не искались ВООБЩЕ, при том что полнотекстовых индексов у них
        // два — ftKnowRelease и ftKnowReleaseHist. Индексы строились, велись и
        // не читались никем: поиск по тегу находил только записи, где тег
        // упомянут прозой, а сам релиз оставался недостижим. Найдено живыми
        // пробами мобильного клиента 30.08.2026.
        //
        // У релиза НЕТ компонента и нет наследования — оси фасетов пусты, а
        // проект берётся ребром BELONGS_TO_PROJECT (поле git_project — вторая
        // правда, оставленная сознательно, см. слайс releases).
        //
        // Заголовок — git_tag, а не release_id: человек ищет «v1.9.1».
        new Branch("release", "KnowRelease", "release_id", "git_tag", "ftKnowRelease",
            List.of("description_md"),
            "KnowReleaseHist", "ftKnowReleaseHist", List.of("description_md"),
            null, null, null, DIRECT_PROJ, 1.15),

        // Агентные личности. Индекс ftKnowActor существовал и до сегодня, но
        // после развода акторов (ADR-LORE-041) ветка поиска уехала на
        // KnowProjectActor, и читателя у него не осталось — индекс велся впустую,
        // а личности стали ненаходимы. Это следствие МОЕЙ правки, замеченное
        // не мной, а пробами с телефона.
        //
        // Отдельный тип, а не расширение ветки actor: слить их значило бы
        // вернуть ту самую склейку личности и описательной роли, ради разведения
        // которой всё и делалось. Имя типа в API совпадает с тем, что уже принял
        // у себя шлюз miniLORE.
        new Branch("agent_actor", "KnowActor", "actor_id", "name", "ftKnowActor",
            List.of("name", "body_md"),
            null, null, null,
            null, null, null, DIRECT_PROJ, 1.10));

    /** Переопределение приоритетов без пересборки: "adr:1.4,task:0.5". */
    @ConfigProperty(name = "lore.search.type-priority")
    Optional<String> priorityOverride;

    // Сколько строк тянем с ветки ДО квоты: из этого же числа считается by_type,
    // поэтому оно же — честный потолок счётчика фасета (документировано в ответе
    // полем capped_at, чтобы «ровно 50» читалось как «не меньше 50»).
    private static final int BRANCH_CAP = 50;

    /**
     * SRCH-06 (ADR-LORE-033 D6): «похожие записи» на {@code SEARCH_INDEX_MORE}.
     *
     * <p><b>На вход идентификатор, а не строка.</b> Отдельный эндпоинт, а не
     * режим основного поиска: иначе {@code q} стал бы полиморфным — то запрос,
     * то ссылка, — и вызывающему пришлось бы догадываться, как его поймут.
     *
     * <p><b>Два ЗАМЕРЕННЫХ ограничения движка (26.7.2), оба вынесены в ответ,
     * а не спрятаны.</b>
     * <ul>
     *   <li><b>Похожесть работает ТОЛЬКО внутри своего типа.</b> Rid ADR против
     *       индекса спринтов возвращает пусто: функция ищет документ в том же
     *       индексе, где он лежит. Межтиповых «похожих» не существует, и
     *       обещать их в UI нельзя.</li>
     *   <li><b>{@code $similarity}</b> на 26.7.2 возвращал 1.0 у всех строк. GC-05 (19.11.2026): с
     *       {@code minTermFreq:1, minDocFreq:1} мера различает строки (проба на копии прода и
     *       {@code SearchSimilarEngineTest} на встроенном движке) — выдача упорядочена по ней
     *       ({@code ranked:true}), значение отдаётся полем {@code similarity}.</li>
     * </ul>
     *
     * <p>Исходная запись из выдачи исключается: «похоже на само себя» — не ответ.
     */
    /**
     * SQL «похожих» по одному rid внутри своего FT-индекса.
     *
     * <p>GC-05 (проба 19.11.2026): у {@code SEARCH_INDEX_MORE} по умолчанию {@code minTermFreq:2} — термин
     * берётся в запрос, только если встретился в исходном документе дважды. В коротком названии каждое
     * слово встречается один раз, и запрос «похожих» вырождался в пустой. Отсюда {@code minTermFreq:1,
     * minDocFreq:1}. Без {@code ORDER BY $similarity DESC} строки шли в порядке хранения.
     */
    static String similarSql(String vertexClass, String idField, String titleField,
                             String indexName, String rid, int limit) {
        return "SELECT " + idField + " AS ref_id, " + titleField + " AS title, $similarity AS similarity FROM "
            + vertexClass + " WHERE SEARCH_INDEX_MORE('" + indexName + "', [" + rid + "], "
            + "{\"minTermFreq\": 1, \"minDocFreq\": 1}) = true "
            + "ORDER BY $similarity DESC LIMIT " + limit;
    }

    @GET
    @Path("search/similar")
    @Produces(MediaType.APPLICATION_JSON)
    public Response similar(@QueryParam("ref") String ref,
                            @QueryParam("limit") Integer limitParam,
                            @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        long t0 = System.nanoTime();
        if (ref == null || ref.isBlank()) return badParams("ref required");
        if (ref.length() > 160) return badParams("ref is longer than 160 characters");

        int limit = limitParam == null || limitParam < 1 ? 10 : Math.min(limitParam, 50);

        // Ищем, какому типу принадлежит идентификатор. Ветки без FT-индекса
        // (quality_gate) пропускаем сразу: «похожих» им взять неоткуда.
        //
        // DBR-04: считаем, сколько веток реально опрошено. При лежащей БД все
        // они уходили в `continue`, и метод доходил до финального 404 «ref не
        // найден ни в одном типе» — то есть отвечал УТВЕРЖДЕНИЕМ О ДАННЫХ там,
        // где не смог посмотреть. Ни одной успешной ветки — это 502, а не 404.
        int probed = 0;
        List<String> branchErrors = new ArrayList<>();
        Throwable lastBranchFailure = null; // S1-03: классифицировать «база лежит» vs «запрос упал»
        for (Branch b : BRANCHES) {
            if (b.indexName() == null) continue;
            List<Map<String, Object>> src;
            try {
                src = ingestService.queryPublic(
                    "SELECT @rid AS rid FROM " + b.vertexClass() + " WHERE " + b.idField() + " = :ref LIMIT 1",
                    Map.of("ref", ref));
                probed++;
            } catch (Exception e) {
                lastBranchFailure = e;
                String why = LoreUpstream.detail(e);
                LOG.warnf("[LORE SIMILAR] ветка %s не опрошена: %s", b.type(), why);
                branchErrors.add(b.type() + ": " + why);
                continue;
            }
            if (src.isEmpty()) continue;

            String rid = String.valueOf(src.get(0).get("rid"));
            List<Map<String, Object>> rows;
            try {
                // rid подставляется в текст запроса, а не параметром: ArcadeDB
                // ждёт здесь литерал-коллекцию RID. Значение получено из БД
                // предыдущим запросом и снаружи не приходит — подстановка
                // безопасна по происхождению, а не по вере в неё.
                rows = ingestService.queryPublic(
                    similarSql(b.vertexClass(), b.idField(), b.titleField(), b.indexName(), rid, limit + 1),
                    Map.of());
            } catch (Exception e) {
                LOG.warnf("[LORE SIMILAR] %s: %s", ref, e.getMessage());
                return noStore(Response.status(Response.Status.BAD_GATEWAY)
                    .entity(LoreUpstream.error(e)));
            }

            List<Map<String, Object>> hits = new ArrayList<>();
            for (Map<String, Object> r : rows) {
                if (ref.equals(String.valueOf(r.get("ref_id")))) continue; // сам себе не похожий
                Map<String, Object> hit = new LinkedHashMap<>();
                hit.put("type", b.type());
                hit.put("ref_id", r.get("ref_id"));
                hit.put("title", r.get("title"));
                if (r.get("similarity") instanceof Number s) hit.put("similarity", s.doubleValue());
                hits.add(hit);
                if (hits.size() >= limit) break;
            }

            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ref", ref);
            out.put("type", b.type());
            out.put("hits", hits);
            // Явно в ответе, а не примечанием в документации: потребитель должен
            // знать, что «похожие» ограничены типом; порядок — по убыванию $similarity (GC-05).
            out.put("same_type_only", true);
            out.put("ranked", true);
            out.put("took_ms", (System.nanoTime() - t0) / 1_000_000);
            return noStore(Response.ok(out));
        }

        // DBR-04: «не найден» имеет право прозвучать только если мы ИСКАЛИ.
        // Ни одной опрошенной ветки — отказ БД, и говорить о данных нельзя.
        if (probed == 0) {
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(lastBranchFailure, "ни одна ветка не опрошена: "
                    + String.join("; ", branchErrors))));
        }
        // Часть веток упала — «не найдено» остаётся возможным ответом (в
        // опрошенных его правда нет), но умалчивать о непроверенных нельзя:
        // ref мог лежать именно там.
        if (!branchErrors.isEmpty()) {
            return noStore(Response.status(Response.Status.NOT_FOUND)
                .entity(new LoreError("NOT_FOUND", "ref «" + ref + "» не найден в опрошенных типах; "
                    + "НЕ опрошены: " + String.join("; ", branchErrors))));
        }
        return noStore(Response.status(Response.Status.NOT_FOUND)
            .entity(new LoreError("NOT_FOUND", "ref «" + ref + "» не найден ни в одном индексируемом типе")));
    }

    @GET
    @Path("search")
    @Produces(MediaType.APPLICATION_JSON)
    public Response search(@QueryParam("q") String q,
                           @QueryParam("types") String typesCsv,
                           @QueryParam("components") String componentsCsv,
                           @QueryParam("projects") String projectsCsv,
                           @QueryParam("limit") Integer limitParam,
                           @QueryParam("offset") Integer offsetParam,
                           @QueryParam("mode") String mode,
                           @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        long t0 = System.nanoTime();

        if (q == null || q.isBlank()) return badParams("q required");
        if (q.length() > 160) return badParams("q is longer than 160 characters");

        Set<String> types = csv(typesCsv);
        List<String> comps = new ArrayList<>(csv(componentsCsv));
        // SRCH-10: ось проекта стала множественной — как тип и компонент. Скаляр
        // не давал выбрать «два продукта из пяти», и UI поэтому фильтровал
        // проекты на клиенте, по одной странице выдачи.
        List<String> projs = new ArrayList<>(csv(projectsCsv));
        int limit = limitParam == null || limitParam < 1 ? 20 : Math.min(limitParam, 100);
        int offset = offsetParam == null || offsetParam < 0 ? 0 : offsetParam;
        String m = mode == null || mode.isBlank() ? "smart" : mode.toLowerCase(Locale.ROOT);
        if (!Set.of("smart", "exact", "fuzzy").contains(m))
            return badParams("mode must be one of smart|exact|fuzzy");

        String lucene = buildLuceneQuery(q, m);
        if (lucene.isBlank()) return badParams("q contains no searchable tokens");

        List<Branch> active = BRANCHES.stream()
            .filter(b -> types.isEmpty() || types.contains(b.type())).toList();
        if (active.isEmpty()) return badParams("types matched no known type");

        // Квота на тип (D5): общий limit делится между запрошенными типами,
        // но не тоньше 3 — иначе многотипный запрос вырождается в топ-1 везде.
        int perType = Math.max(3, limit / Math.max(1, active.size()));

        Map<String, Double> prio = effectivePriorities();
        List<Map<String, Object>> hits = new ArrayList<>();
        Map<String, Integer> byType = new LinkedHashMap<>();
        Map<String, Integer> byComponent = new LinkedHashMap<>();
        // SRCH-10: третья ось фасета. Раньше её не было в ответе вовсе, и UI
        // считал проекты ПО ТЕКУЩЕЙ СТРАНИЦЕ — то есть счётчики врали за
        // пределами первых 50 хитов, а серверный фильтр по проекту не
        // задействовался. Считается так же, как by_component: по всей выборке
        // ветки, а не по квоте выдачи.
        Map<String, Integer> byProject = new LinkedHashMap<>();
        // ADR-033 обещал поле warnings при падении ветки. Фактически ставилось
        // byType=-1 — и это уходило в фасет КАК СЧЁТЧИК: UI рисовал чип
        // «−1» вместо того, чтобы сказать «поиск по этому типу не отработал».
        // Минус-единица как сигнал ошибки хуже отсутствия сигнала: она
        // выглядит данными.
        List<Map<String, Object>> warnings = new ArrayList<>();
        // DBR-05: ветка может отработать НАПОЛОВИНУ — вершина опрошена, история
        // нет (или наоборот). Это не отказ ветки и не полный успех, и третье
        // состояние надо назвать: иначе половина выдачи выглядит как вся.
        Map<String, String> partialBranches = new LinkedHashMap<>();
        // DBR-09: и четвёртое состояние — «здесь искали, но сканом». Оно не
        // ошибка и не половина: выдача полная, а вот ранжирования у неё нет.
        Map<String, String> scannedBranches = new LinkedHashMap<>();

        // AL-SCOPE-HOLES A: проектный скоуп — как у срезов и обратных ссылок. Не посчитан —
        // отвечать «без скоупа» нельзя (обход); пустое множество — 403, а не пустая выдача.
        Set<String> allowed;
        try {
            allowed = sliceScope.allowedProjectsOrNull(role);
        } catch (RuntimeException e) {
            LOG.warnf("[LORE SEARCH] скоуп не посчитан: %s", e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e, "проектный скоуп не посчитан: " + LoreUpstream.detail(e))));
        }
        if (allowed != null && allowed.isEmpty())
            return noStore(Response.status(Response.Status.FORBIDDEN)
                .entity(new LoreError("SCOPE_EMPTY", "проектный скоуп: у вызывающего нет ни одного разрешённого "
                    + "проекта — поиск не отдаётся пустым")));
        int scopeHidden = 0;

        for (Branch b : active) {
            try {
                List<Map<String, Object>> rows = new ArrayList<>(
                    queryBranch(b, lucene, q, comps, projs, partialBranches, scannedBranches));
                // До счётчиков фасета и квоты: by_type/by_project не должны выдавать скрытое числом.
                scopeHidden += scopeRows(b.type(), rows, allowed);
                byType.put(b.type(), rows.size());
                // Нормировка внутри ветки: BM25 разных бакетов несравним, а
                // после деления на максимум ветки хотя бы порядок внутри типа
                // честный. Межтиповое сравнение задаёт type_priority. Это
                // ОСОЗНАННАЯ приблизительность (ADR-033 §Consequences).
                double max = rows.stream()
                    .mapToDouble(LoreSearchResource::scoreOf)
                    .max().orElse(1.0);
                double p = prio.getOrDefault(b.type(), b.priority());
                int taken = 0;
                for (Map<String, Object> r : rows) {
                    // Читаем ГОТОВЫЕ поля хита: `queryBranch` уже прогнал строки
                    // через shapeHit, и тот переименовал comp_direct/comp_inherited
                    // в `components`, а `proj` в `projects`.
                    //
                    // Здесь стоял вызов effectiveComponents(r), который ищет
                    // comp_direct — в этих строках его больше НЕТ. Агрегат выходил
                    // пустым всегда: ось «компонент» не показывала ни одного чипа,
                    // и фильтровать по компоненту было нечем, хотя у самих хитов
                    // компоненты есть и видны.
                    //
                    // Соседняя ось это маскировала: by_project добавлялся позже
                    // (SRCH-10) и сразу читал новое имя, поэтому работал. Проекты
                    // на экране были — и пустой «компонент» выглядел как «у этих
                    // записей просто нет компонента», а не как отказ.
                    for (Object c : asList(r.get("components"))) {
                        byComponent.merge(String.valueOf(c), 1, Integer::sum);
                    }
                    for (Object pr : asList(r.get("projects"))) {
                        byProject.merge(String.valueOf(pr), 1, Integer::sum);
                    }
                    if (taken++ >= perType) continue; // фасет считаем по всем, в выдачу — квоту
                    double raw = scoreOf(r);
                    double bm25 = max <= 0 ? 1.0 : raw / max;
                    // SRCH-09: ранг отдаётся РАЗЛОЖЕННЫМ. Итоговое число само по
                    // себе необъяснимо: «6.44» не отвечает, почему задача выше
                    // ADR. Слагаемые показывают, что это не мнение движка, а
                    // ДВЕ величины — совпадение текста и приоритет типа, — и
                    // вторую задаём мы. Спорить с приоритетом можно, только
                    // если он виден.
                    r.put("bm25", round3(bm25));
                    r.put("type_priority", round3(p));
                    r.put("score", round3(bm25 * p));
                    r.put("type", b.type());
                    hits.add(r);
                }
            } catch (Exception e) {
                // Ветка НЕ глотается молча: одна упавшая ветка — дырка в охвате.
                // Тип в by_type НЕ кладём вообще: счётчик означает «сколько
                // нашлось», а про упавшую ветку мы этого не знаем. Отдельное
                // поле warnings говорит «здесь не искали», и это принципиально
                // иное утверждение, чем «здесь ничего нет».
                // DBR-05: в warnings идёт РАЗВЁРНУТАЯ причина (тело ответа
                // ArcadeDB), а не родовое сообщение RESTEasy — оно одинаково
                // для локаута креда, снесённого индекса и битого SQL.
                String why = LoreUpstream.detail(e);
                LOG.warnf("[LORE SEARCH] ветка %s упала: %s", b.type(), why);
                warnings.add(Map.of("type", b.type(), "error", String.valueOf(why)));
            }
        }
        // Частично опрошенные ветки — тоже предупреждение, но с иным смыслом:
        // «здесь искали не везде», а не «здесь не искали». Отдельный признак
        // partial, чтобы читающий не принял половину за целое.
        partialBranches.forEach((type, why) ->
            warnings.add(Map.of("type", type, "partial", true, "error", why)));
        // Скан — тоже повод сказать вслух, хотя выдача полная: без ранжирования
        // порядок внутри такой ветки произволен, и молчать об этом значило бы
        // выдавать её за индексную.
        scannedBranches.forEach((type, why) ->
            warnings.add(Map.of("type", type, "scanned", true, "error", why)));

        sortHits(hits, q);
        List<Map<String, Object>> page = hits.stream().skip(offset).limit(limit).toList();

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("hits", page);
        out.put("by_type", byType);
        out.put("by_component", byComponent);
        out.put("by_project", byProject);
        // Пустой список, а не отсутствие ключа: потребителю не приходится
        // различать «поле не пришло» и «предупреждений нет».
        out.put("warnings", warnings);
        // MT-MCP-TRUTH A11: исход словом — по одним hits «упало» неотличимо от «пусто».
        // Частично опрошенные и сканированные ветки — не отказ, в счёт не идут.
        long failedBranches = warnings.stream().filter(w -> w.containsKey("error")
            && !w.containsKey("partial") && !w.containsKey("scanned")).count();
        out.put("outcome", outcomeOf(active.size(), (int) failedBranches, hits.size()));
        out.put("total_collected", hits.size());
        if (allowed != null) {
            // Скрытое называется числом: «нашлось меньше» под скоупом ≠ «в корпусе меньше».
            Map<String, Object> scope = new LinkedHashMap<>();
            scope.put("projects", allowed.size());
            scope.put("hidden", scopeHidden);
            out.put("scope", scope);
        }
        out.put("capped_at", BRANCH_CAP);
        // SRCH-09: во что превратился запрос. Пользователь ввёл слово, а в
        // индекс ушло `(слово OR слово*)` — и именно это объясняет, почему
        // нашлось не то, что ожидалось. Без показа выражения расхождение между
        // «что я искал» и «что искали за меня» проверить нечем: строку строит
        // сервер (D2), и она нигде больше не видна.
        out.put("lucene", lucene);
        out.put("mode", m);
        // Границы страницы — рядом с самой страницей: без offset потребитель
        // не может отличить «конец выдачи» от «страница пролистана мимо».
        out.put("offset", offset);
        out.put("limit", limit);
        out.put("took_ms", (System.nanoTime() - t0) / 1_000_000);
        return noStore(Response.ok(out));
    }

    /** Одна ветка: вершина + (если есть) открытая hist-строка со схлопыванием. */
    /**
     * @param partialBranches куда записать «ветка опрошена наполовину»: тип →
     *        причина. Не возвращается результатом, потому что частичный ответ
     *        остаётся ВАЛИДНЫМ ответом — вызывающий кладёт такие ветки и в
     *        by_type, и в warnings одновременно, и различать их надо ему.
     * @param scannedBranches куда записать «половина отвечена сканом»: тип →
     *        какая именно. DBR-09.
     */
    private List<Map<String, Object>> queryBranch(Branch b, String lucene, String rawQ,
                                                  List<String> comps, List<String> projs,
                                                  Map<String, String> partialBranches,
                                                  Map<String, String> scannedBranches) {
        Map<String, Object> params = new HashMap<>();
        params.put("q", lucene);
        String compFilter = componentFilter(b, comps, params, false);
        String projFilter = projectFilter(b, projs, params, false);

        // DBR-09: индекс, признанный непригодным, — это не повод отдать пустоту.
        // Пустая выдача неотличима от «в базе такого нет», а данные-то на месте:
        // пострадал только индекс. Поэтому ветка исполняется сканом по тем же
        // полям, что перечислены для неё в реестре FT_INDEXES.
        List<String> scanned = new ArrayList<>();
        boolean vertexByIndex = b.indexName() != null && ftHealth.usable(b.indexName());
        if (b.indexName() != null && !vertexByIndex) scanned.add("вершина");

        String textCols = String.join(", ", b.vertexTextFields());
        String matcher = vertexByIndex
            ? "SEARCH_INDEX('" + b.indexName() + "', :q) = true"
            : ilikeMatcher(b, params, rawQ);

        String sql = "SELECT " + b.idField() + " AS ref_id, " + b.titleField() + " AS title, "
            + (vertexByIndex ? "$score AS score, " : "1.0 AS score, ")
            + textCols + ", "
            + (b.compExpr() != null ? b.compExpr() : "null") + " AS comp_direct, "
            + (b.compInheritedExpr() != null ? b.compInheritedExpr() : "null") + " AS comp_inherited, "
            + b.projExpr() + " AS proj "
            + "FROM " + b.vertexClass() + " WHERE (" + b.idField() + " ILIKE :idlike OR " + matcher + ")"
            + compFilter + projFilter
            + " ORDER BY score DESC LIMIT " + BRANCH_CAP;
        params.put("idlike", "%" + rawQ + "%");

        // DBR-05: две половины ветки — по вершине и по hist — идут в РАЗНЫХ
        // try. Раньше они лежали в одном, и падение одного full-text индекса
        // выкашивало ветку целиком, включая работоспособную половину: живой
        // симптом — ветка `adr` стабильно отдавала 500 в warnings, хотя вершинный
        // запрос мог отработать. Половина результатов лучше, чем ноль, если про
        // недостачу сказано вслух.
        List<Map<String, Object>> rows = new ArrayList<>();
        List<String> partial = new ArrayList<>();
        // Считаем УСПЕШНЫЕ половины, а не найденные строки. Первая редакция
        // решала «ветка упала» по `rows.isEmpty()`, и это была та же ошибка,
        // против которой вся задача: половина, честно вернувшая НОЛЬ совпадений,
        // неотличима от половины, которая не отработала. Поймано сразу на живом
        // стенде — запрос, не находящий ничего, помечал ветку упавшей целиком,
        // хотя вершинная половина отработала штатно.
        int halvesOk = 0;
        try {
            for (Map<String, Object> r : ingestService.queryPublic(sql, params)) {
                rows.add(shapeHit(b, r, rawQ, b.vertexTextFields(), false));
            }
            halvesOk++;
        } catch (RuntimeException e) {
            partial.add("вершина: " + LoreUpstream.detail(e));
        }

        if (b.histClass() != null) {
            Map<String, Object> hp = new HashMap<>();
            hp.put("q", lucene);
            String histText = String.join(", ", b.histTextFields());
            // Фильтры фасета на hist-ветке идут через родителя (in('HAS_STATE')):
            // сама hist-строка рёбер компонентов не несёт.
            String hCompFilter = componentFilter(b, comps, hp, true);
            String hProjFilter = projectFilter(b, projs, hp, true);
            boolean histByIndex = ftHealth.usable(b.histIndexName());
            if (!histByIndex) scanned.add("история");
            // Скан истории идёт ТОЛЬКО по открытым строкам. Ограничение
            // `valid_to IS NULL` стоит здесь и так — оно же и делает скан
            // приемлемым: закрытые ревизии в выдаче не нужны, поиск всё равно
            // схлопывает результат к текущей версии записи, а объём обхода
            // падает вдвое.
            String hMatcher = histByIndex
                ? "SEARCH_INDEX('" + b.histIndexName() + "', :q) = true"
                : histIlikeMatcher(b, hp, rawQ);
            // [0] только у скалярных проекций (ref_id/title — родитель один);
            // компоненты/проекты — СПИСКИ, [0] оставил бы один случайный.
            String hsql = "SELECT in('HAS_STATE')." + b.idField() + "[0] AS ref_id, "
                + histTitle(b.titleField()) + " AS title, "
                + (histByIndex ? "$score AS score, " : "1.0 AS score, ")
                + histText + ", "
                // Ветка без компонента (релиз) — здесь ПРОСТО null, а не
                // «in('HAS_STATE').null»: приписав обход к отсутствующему
                // выражению, мы получали невалидный SQL и 400 на КАЖДЫЙ
                // hist-запрос ветки. Наружу это выходило не отказом, а строкой
                // «ветка опрошена частично» — то есть поиск по релизам
                // молчаливо терял половину источника. Поймано живым тестом
                // фасетов, а не чтением: у соседнего comp_inherited такая
                // проверка уже стояла, у comp_direct её не было.
                + (b.compExpr() != null ? "in('HAS_STATE')." + b.compExpr() : "null")
                + " AS comp_direct, "
                + (b.compInheritedExpr() != null
                    ? "in('HAS_STATE')." + b.compInheritedExpr() : "null") + " AS comp_inherited, "
                + "in('HAS_STATE')." + b.projExpr() + " AS proj "
                + "FROM " + b.histClass() + " WHERE valid_to IS NULL "
                + "AND (" + hMatcher + ")"
                + hCompFilter + hProjFilter
                + " ORDER BY score DESC LIMIT " + BRANCH_CAP;
            try {
                for (Map<String, Object> r : ingestService.queryPublic(hsql, hp)) {
                    rows.add(shapeHit(b, r, rawQ, b.histTextFields(), true));
                }
                halvesOk++;
            } catch (RuntimeException e) {
                partial.add("история: " + LoreUpstream.detail(e));
            }
        }

        // Отказ ветки — это НИ ОДНОЙ успешной половины, а не «ноль строк».
        // Пустая выдача при отработавшей половине — законный ответ «не нашли»,
        // и превращать его в отказ значит терять единственное, что мы точно
        // знаем: в опрошенной половине совпадений нет.
        if (halvesOk == 0) {
            throw new IllegalStateException(String.join("; ", partial));
        }
        if (!partial.isEmpty()) {
            // Половина не опрошена — сказать об этом обязательно, иначе выдача
            // выглядит полной. Ветка при этом остаётся в by_type: часть данных
            // мы всё же посмотрели.
            LOG.warnf("[LORE SEARCH] ветка %s опрошена частично: %s", b.type(), String.join("; ", partial));
            partialBranches.put(b.type(), String.join("; ", partial));
        }
        if (!scanned.isEmpty()) {
            String why = String.join(" и ", scanned)
                + ": FT-индекс непригоден, отвечено сканом — выдача полная, ранжирования нет";
            LOG.warnf("[LORE SEARCH] ветка %s: %s", b.type(), why);
            scannedBranches.put(b.type(), why);
        }

        // Дедуп по ref_id: вершина и её hist могли совпасть оба — оставляем
        // более сильный score (обе формы уже нормируются одной веткой).
        Map<Object, Map<String, Object>> dedup = new LinkedHashMap<>();
        for (Map<String, Object> r : rows) {
            dedup.merge(r.get("ref_id"), r, (a, bb) ->
                ((Number) a.get("score")).doubleValue() >= ((Number) bb.get("score")).doubleValue() ? a : bb);
        }
        List<Map<String, Object>> out = new ArrayList<>(dedup.values());
        out.sort((a, bb) -> Double.compare(
            ((Number) bb.get("score")).doubleValue(), ((Number) a.get("score")).doubleValue()));
        return out;
    }

    /**
     * Порядок выдачи: запись, чей код РАВЕН запросу (без регистра и пробелов по краям), — первой и с
     * пометкой {@code exact}; остальные — по счёту. Приёмка препрода 14.11.2026: по точному коду спринта
     * первой шла спека с похожими словами (выше BM25 × приоритет типа), Shift+Enter открыл не то.
     */
    static void sortHits(List<Map<String, Object>> hits, String q) {
        String want = q == null ? "" : q.trim();
        for (Map<String, Object> h : hits)
            if (!want.isEmpty() && want.equalsIgnoreCase(String.valueOf(h.get("ref_id")))) h.put("exact", true);
        hits.sort((a, bb) -> {
            boolean ea = Boolean.TRUE.equals(a.get("exact")), eb = Boolean.TRUE.equals(bb.get("exact"));
            if (ea != eb) return ea ? -1 : 1;
            return Double.compare(((Number) bb.get("score")).doubleValue(), ((Number) a.get("score")).doubleValue());
        });
    }

    /**
     * ILIKE-fallback для ветки без FT-индекса (QualityGate).
     * БЕЗ собственных скобок: снаружи выражение уже в скобках, а вложенную
     * группу `(x OR (a OR b))` парсер ArcadeDB 26.7.2 не принимает вовсе —
     * «no viable alternative at input». Плоское OR разбирается нормально.
     */
    private String ilikeMatcher(Branch b, Map<String, Object> params, String rawQ) {
        params.put("txtlike", "%" + rawQ + "%");
        List<String> parts = new ArrayList<>();
        for (String f : b.vertexTextFields()) parts.add(f + " ILIKE :txtlike");
        return String.join(" OR ", parts);
    }

    /**
     * То же для hist-половины (DBR-09): поля берутся из {@code histTextFields},
     * то есть ровно те, что перечислены для этого индекса в реестре.
     *
     * <p>Как и {@link #ilikeMatcher}, возвращает выражение БЕЗ собственных
     * скобок — их ставит вызывающий. Здесь это обязательно: выражение
     * подставляется после {@code AND}, и без скобок {@code AND a OR b}
     * разобралось бы как {@code (… AND a) OR b}, то есть {@code valid_to IS
     * NULL} перестало бы действовать на вторую половину OR и в выдачу поехали
     * бы закрытые ревизии.
     */
    private String histIlikeMatcher(Branch b, Map<String, Object> params, String rawQ) {
        params.put("txtlike", "%" + rawQ + "%");
        List<String> parts = new ArrayList<>();
        for (String f : b.histTextFields()) parts.add(f + " ILIKE :txtlike");
        return String.join(" OR ", parts);
    }

    /** Фасет-фильтр по компонентам: ОБА пути (прямой и выведенный), OR по значениям. */
    private String componentFilter(Branch b, List<String> comps, Map<String, Object> params, boolean viaParent) {
        if (comps.isEmpty()) return "";
        // У ветки без компонента (релиз) фильтровать НЕ ПО ЧЕМУ. Пустой фильтр
        // здесь — не пропуск проверки, а верный ответ: спрашивают «покажи то,
        // что относится к компоненту X», а у релиза компонента нет вовсе.
        // Прежде сюда подставлялось выражение из null и получался невалидный
        // SQL — то есть вместо «ничего не подходит» ветка отвечала ошибкой.
        if (b.compExpr() == null) return "";
        // БЕЗ [0] на hist-пути: обход от hist-строки через родителя возвращает
        // СПИСОК компонентов, и [0] превратил бы CONTAINS в сравнение с одним
        // случайным значением — ровно ловушка корпуса «многосвязное видно под
        // одним значением», уже поймана этим тестом.
        String direct = viaParent ? "in('HAS_STATE')." + b.compExpr() : b.compExpr();
        String inherited = b.compInheritedExpr() == null ? null
            : (viaParent ? "in('HAS_STATE')." + b.compInheritedExpr() : b.compInheritedExpr());
        List<String> parts = new ArrayList<>();
        for (int i = 0; i < comps.size(); i++) {
            String key = "c" + i;
            params.put(key, comps.get(i));
            // CONTAINS, не [0]= — правило корпуса: многосвязная сущность иначе
            // видна только под одним случайным значением.
            parts.add(direct + " CONTAINS :" + key
                + (inherited != null ? " OR " + inherited + " CONTAINS :" + key : ""));
        }
        return " AND (" + String.join(" OR ", parts) + ")";
    }

    private String projectFilter(Branch b, List<String> projs, Map<String, Object> params, boolean viaParent) {
        if (projs == null || projs.isEmpty()) return "";
        // Без [0] — тот же список-капкан, что у компонентов выше: у сущности
        // проектов может быть несколько, и сравнение с первым случайным
        // показало бы её только под одним из них.
        String expr = viaParent ? "in('HAS_STATE')." + b.projExpr() : b.projExpr();
        StringBuilder or = new StringBuilder();
        for (int i = 0; i < projs.size(); i++) {
            String key = "proj" + i;
            params.put(key, projs.get(i));
            if (i > 0) or.append(" OR ");
            or.append(expr).append(" CONTAINS :").append(key);
        }
        return " AND (" + or + ")";
    }

    /** Сниппет + matched_field + эффективные компоненты одной строки. */
    private Map<String, Object> shapeHit(Branch b, Map<String, Object> r, String rawQ,
                                         List<String> textFields, boolean fromHist) {
        Map<String, Object> hit = new LinkedHashMap<>();
        hit.put("ref_id", r.get("ref_id"));
        hit.put("title", r.get("title"));
        hit.put("score", scoreOf(r));

        // Где совпало: первое текстовое поле с токеном запроса. Совпадение может
        // быть морфологическим (поле «релиза», запрос «релиз») — тогда точного
        // вхождения нет, и честный ответ «в теле/в заголовке» по полю индекса.
        String token = rawQ.split("\\s+")[0].toLowerCase(Locale.ROOT);
        String matched = fromHist ? "body" : "title";
        String snippet = null;
        for (String f : textFields) {
            Object v = r.get(f);
            if (v == null) continue;
            String s = String.valueOf(v);
            int i = s.toLowerCase(Locale.ROOT).indexOf(token);
            if (i >= 0) {
                matched = f;
                int from = Math.max(0, i - 60);
                int to = Math.min(s.length(), i + token.length() + 60);
                snippet = (from > 0 ? "…" : "") + s.substring(from, to) + (to < s.length() ? "…" : "");
                break;
            }
        }
        hit.put("matched_field", matched);
        hit.put("snippet", snippet);

        List<Object> comps = effectiveComponents(r);
        hit.put("components", comps);
        boolean inherited = asList(r.get("comp_direct")).isEmpty() && !comps.isEmpty();
        hit.put("inherited_from", inherited ? b.inheritedFrom() : null);
        hit.put("projects", asList(r.get("proj")));
        return hit;
    }

    /** Прямые компоненты, а при их отсутствии — выведенные от родителя. */
    private List<Object> effectiveComponents(Map<String, Object> r) {
        List<Object> direct = asList(r.get("comp_direct"));
        return direct.isEmpty() ? asList(r.get("comp_inherited")) : direct;
    }

    @SuppressWarnings("unchecked")
    private static List<Object> asList(Object v) {
        if (v == null) return List.of();
        if (v instanceof List<?> l) return (List<Object>) l;
        return List.of(v);
    }

    /**
     * Сборка Lucene-выражения (D2). Пользовательский ввод НЕ трактуется как
     * Lucene-синтаксис: метасимволы вырезаются (замена пробелом), а не
     * экранируются — экранированный мусор всё равно никому не нужен, а
     * вырезание не оставляет пути к синтаксической ошибке.
     *
     * smart: (t1) AND … AND (tN OR tN*) — морфология на каждом токене,
     *        префикс на последнем (поиск-как-набираешь);
     * exact: "фраза целиком";
     * fuzzy: токены от 5 букв получают ~ (устойчивость к опечаткам).
     */
    /** Слова, которые Lucene читает как операторы ТОЛЬКО в верхнем регистре. */
    static final java.util.Set<String> LUCENE_OPERATOR_WORDS = java.util.Set.of("AND", "OR", "NOT", "TO");

    /**
     * MT-MCP-TRUTH A11: исход поиска словом, а не голыми hits. Упали все ветки —
     * «failed» (не «пусто»); упала часть — «partial_failure»: и пустая, и
     * непустая выдача тогда недостоверна по охвату. Ни одной ветки по фильтру
     * не было — это «empty», а не сбой.
     */
    static String outcomeOf(int activeBranches, int failedBranches, int hits) {
        if (activeBranches > 0 && failedBranches >= activeBranches) return "failed";
        if (failedBranches > 0) return "partial_failure";
        return hits > 0 ? "found" : "empty";
    }

    static String buildLuceneQuery(String q, String mode) {
        String cleaned = q.replaceAll("[+\\-!(){}\\[\\]^\"~*?:\\\\/&|]", " ").trim();
        if (cleaned.isBlank()) return "";
        if ("exact".equals(mode)) return "\"" + cleaned + "\"";
        String[] tokens = cleaned.split("\\s+");
        // MT-MCP-TRUTH A11 (06.11.2026): слова-операторы Lucene из ВВОДА — термы.
        // «Q-CI-LOGS-NOT-PERSISTED» после вырезания дефисов давал токен NOT, и
        // разбор падал во всех ветвях — ответ hits:[] был неотличим от пустой
        // базы. Анализатор приводит термы к нижнему регистру, поэтому «not»
        // ищет то же слово, но оператором уже не является.
        for (int k = 0; k < tokens.length; k++) {
            if (LUCENE_OPERATOR_WORDS.contains(tokens[k])) tokens[k] = tokens[k].toLowerCase(java.util.Locale.ROOT);
        }
        List<String> parts = new ArrayList<>();
        for (int i = 0; i < tokens.length; i++) {
            String t = tokens[i];
            boolean last = i == tokens.length - 1;
            if ("fuzzy".equals(mode) && t.length() >= 5) {
                parts.add("(" + t + "~)");
            } else if (last) {
                parts.add("(" + t + " OR " + t + "*)");
            } else {
                parts.add("(" + t + ")");
            }
        }
        return String.join(" AND ", parts);
    }

    private Map<String, Double> effectivePriorities() {
        Map<String, Double> out = new HashMap<>();
        for (Branch b : BRANCHES) out.put(b.type(), b.priority());
        priorityOverride.ifPresent(s -> {
            for (String pair : s.split(",")) {
                String[] kv = pair.split(":");
                if (kv.length != 2) continue;
                String type = kv[0].trim();
                // Неизвестный тип — почти наверняка опечатка: значение молча
                // осело бы в карте и ни на что не влияло, а автор конфига был
                // бы уверен, что настроил.
                if (!out.containsKey(type)) {
                    LOG.warnf("[LORE SEARCH] приоритет для неизвестного типа '%s' — пропущен", type);
                    continue;
                }
                double v;
                try { v = Double.parseDouble(kv[1].trim()); }
                catch (NumberFormatException ignored) {
                    LOG.warnf("[LORE SEARCH] неразборчивый приоритет '%s' — пропущен", pair);
                    continue;
                }
                // Диапазона раньше не было вовсе: 0 выкидывал тип из выдачи
                // целиком (score обнулялся), отрицательное отправляло его в
                // конец за всё остальное. И то и другое выглядело как «поиск
                // сломался», а не как «в конфиге опечатка».
                if (!(v > 0) || v > 10) {
                    LOG.warnf("[LORE SEARCH] приоритет %s=%s вне (0; 10] — пропущен", type, kv[1].trim());
                    continue;
                }
                out.put(type, v);
            }
        });
        return out;
    }

    // ── SPRINT_UXR_S2_GRAPH_MEMORY/S2-02: обратные связи ─────────────────────

    /**
     * Структурные рёбра — не «ссылка на запись», а её устройство: HAS_STATE
     * ведёт к строке истории SCD2,
     * BELONGS_TO_PROJECT — к проекту. Покажи их, и у любого хаба-проекта
     * «обратными связями» станет весь корпус. Список называется в ответе
     * ({@code excluded_edges}), чтобы отсутствие было объяснено, а не угадано.
     */
    static final Set<String> STRUCTURAL_EDGES = Set.of("HAS_STATE", "BELONGS_TO_PROJECT");

    /** Потолок входящих рёбер за один запрос; выше — {@code complete:false} и {@code capped_at}. */
    static final int BACKLINK_EDGE_CAP = 5000;

    /** Rid подставляется в текст запроса — только если он именно rid (получен из БД, но проверяем форму). */
    private static final java.util.regex.Pattern RID = java.util.regex.Pattern.compile("#\\d+:\\d+");

    /** Ссылка на скоуп слайсов: тот же резолвер, тот же флаг {@code lore.scope.enforce}. */
    @jakarta.inject.Inject
    AidaLoreResource sliceScope;

    /**
     * Пути до слагов проекта для проверки скоупа — те же, что у слайсов
     * ({@link LoreSlices#PROJECT_SCOPED}): решение видно и по своему ребру, и
     * по родительскому ADR; вопрос — по своему ребру, месту, где поднят, и
     * компоненту через спринты. Остальные типы — по выражению фасета ветки.
     */
    static List<String> scopePaths(Branch b) {
        return switch (b.type()) {
            case "decision" -> List.of(DIRECT_PROJ, "out('DECIDED_IN')." + DIRECT_PROJ);
            case "question" -> List.of(LoreSlices.QUESTION_SCOPE.split("\\|"));
            default -> b.projExpr() == null ? List.of() : List.of(b.projExpr());
        };
    }

    /**
     * AL-SCOPE-HOLES A: типы поиска под проектным скоупом — те, чьи срезы в PROJECT_SCOPED
     * (adr, spec_by_id, sprints, задачи через спринт, решения, вопросы, runbook, doc,
     * use_cases/uc_by_id, release_by_id).
     */
    static final Set<String> SCOPED_TYPES = Set.of(
        "adr", "spec", "sprint", "task", "decision", "question", "runbook", "doc", "use_case", "release");

    /** Типы поиска, которые скоуп не режет, — с причиной, как SHARED_SLICES / SCOPE_PENDING. */
    static final Map<String, String> UNSCOPED_TYPES = Map.of(
        "actor", "AL-106: акторы видны всем (как срезы actors/actor_load)",
        "agent_actor", "AL-106: агенты видны всем",
        "pain", "общий продуктовый профиль (как срез pains)",
        "gain", "общий продуктовый профиль (как срез gains)",
        "job", "глобальная вершина (AL-113, как срез jobs)",
        "quality_gate", "ждёт решения владелицы, как срезы qg_* (SCOPE_PENDING)");

    static List<String> branchTypes() {
        return BRANCHES.stream().map(Branch::type).toList();
    }

    /**
     * AL-SCOPE-HOLES A: вычеркнуть из строк ветки то, что вне разрешённых проектов. Правило
     * срезов: строка видна, если хотя бы один её проект разрешён; строка без проекта под
     * скоупом не видна. Неклассифицированный тип режется (безопасная сторона). Возвращает
     * число скрытых. allowed = null — скоуп выключен.
     */
    static int scopeRows(String type, List<Map<String, Object>> rows, Set<String> allowed) {
        if (allowed == null || UNSCOPED_TYPES.containsKey(type)) return 0;
        int before = rows.size();
        rows.removeIf(r -> {
            Set<String> projects = new LinkedHashSet<>();
            for (Object o : asList(r.get("projects"))) if (o != null) projects.add(String.valueOf(o));
            return !visibleUnder(projects, allowed);
        });
        return before - rows.size();
    }

    static Branch branchByType(String type) {
        for (Branch b : BRANCHES) if (b.type().equals(type)) return b;
        return null;
    }

    /** Класс вершины → ветка. Первая по порядку: у каждого класса ветка одна (PL-28). */
    static Branch branchByClass(String vertexClass) {
        for (Branch b : BRANCHES) if (b.vertexClass().equals(vertexClass)) return b;
        return null;
    }

    private static String projectColumns(Branch b) {
        StringBuilder sb = new StringBuilder();
        List<String> paths = scopePaths(b);
        for (int i = 0; i < paths.size(); i++) sb.append(", ").append(paths.get(i)).append(" AS p").append(i);
        return sb.toString();
    }

    /** Слаги проектов строки по всем путям скоупа (прямой | через родителя). */
    static Set<String> projectsOf(Map<String, Object> row, int paths) {
        Set<String> out = new LinkedHashSet<>();
        for (int i = 0; i < paths; i++) {
            Object v = row.get("p" + i);
            if (v instanceof java.util.Collection<?> c) {
                for (Object o : c) if (o != null) out.add(String.valueOf(o));
            } else if (v != null) {
                out.add(String.valueOf(v));
            }
        }
        return out;
    }

    /** Виден ли объект под скоупом: хотя бы один путь ведёт в разрешённый проект (как у слайсов). */
    static boolean visibleUnder(Set<String> projects, Set<String> allowed) {
        if (allowed == null) return true;
        for (String p : projects) if (allowed.contains(p)) return true;
        return false;
    }

    /**
     * {@code GET /lore/backlinks?type&id[&limit]} — «кто ссылается на X»: входящие
     * рёбра записи одним запросом, а не обратным полем, дописанным в отдельный
     * слайс под каждый тип (вкладка «Граф», D-2026-UXR-LOCAL-GRAPH).
     *
     * <p><b>Что считается обратной связью.</b> Входящее ребро, которое:
     * <ul>
     *   <li>не структурное ({@link #STRUCTURAL_EDGES});</li>
     *   <li>открыто в смысле SCD2 — у самого ребра нет {@code valid_to}
     *       (ROLE_HELD_BY закрывается так при смене держателя), и источник не
     *       закрытая строка истории.</li>
     * </ul>
     *
     * <p><b>Скоуп — как у слайсов.</b> Пустое множество разрешённых проектов —
     * 403 {@code SCOPE_EMPTY}, а не пустой список; цель вне скоупа — 403
     * {@code OUTSIDE_SCOPE}; источник вне скоупа скрывается и считается в
     * {@code hidden_by_scope}: «не показано» не должно выглядеть как «нет».
     * Источник неизвестного класса (не из таблицы веток) под скоупом скрыт —
     * проверить его проект нечем, и правило fail-closed то же, что у слайсов.
     *
     * <p><b>Хабы.</b> Группировка по типу ребра; {@code limit} режет items
     * группы, но не её {@code count} — у ADR с сотней задач честно видно «100,
     * показано 20». Рёбер больше {@link #BACKLINK_EDGE_CAP} — {@code complete:false}.
     */
    @GET
    @Path("backlinks")
    @Produces(MediaType.APPLICATION_JSON)
    public Response backlinks(@QueryParam("type") String type,
                              @QueryParam("id") String id,
                              @QueryParam("limit") Integer limitParam,
                              @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        long t0 = System.nanoTime();
        List<String> knownTypes = BRANCHES.stream().map(Branch::type).toList();
        if (type == null || type.isBlank()) return badParams("type required: one of " + knownTypes);
        Branch target = branchByType(type.trim());
        if (target == null) return badParams("unknown type «" + type + "»: one of " + knownTypes);
        if (id == null || id.isBlank()) return badParams("id required");
        if (id.length() > 200) return badParams("id is longer than 200 characters");
        int limit = limitParam == null || limitParam < 1 ? 20 : Math.min(limitParam, 200);

        Set<String> allowed;
        try {
            allowed = sliceScope.allowedProjectsOrNull(role);
        } catch (RuntimeException e) {
            // Скоуп не посчитан — отвечать «без скоупа» нельзя: это был бы обход.
            LOG.warnf("[LORE BACKLINKS] скоуп не посчитан: %s", e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e, "проектный скоуп не посчитан: " + LoreUpstream.detail(e))));
        }
        if (allowed != null && allowed.isEmpty()) {
            return noStore(Response.status(Response.Status.FORBIDDEN)
                .entity(new LoreError("SCOPE_EMPTY", "проектный скоуп: у вызывающего нет ни одного разрешённого "
                    + "проекта — обратные связи не отдаются пустыми")));
        }

        // ── цель ──
        Map<String, Object> tgt;
        try {
            List<Map<String, Object>> rows = ingestService.queryPublic(
                "SELECT @rid AS rid, " + target.titleField() + " AS title" + projectColumns(target)
                + " FROM " + target.vertexClass() + " WHERE " + target.idField() + " = :id LIMIT 1",
                Map.of("id", id));
            if (rows.isEmpty()) {
                return noStore(Response.status(Response.Status.NOT_FOUND)
                    .entity(new LoreError("NOT_FOUND", type + " «" + id + "» не найден")));
            }
            tgt = rows.get(0);
        } catch (Exception e) {
            LOG.warnf("[LORE BACKLINKS] %s/%s: цель не прочитана: %s", type, id, e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e, LoreUpstream.detail(e))));
        }
        if (!visibleUnder(projectsOf(tgt, scopePaths(target).size()), allowed)) {
            return noStore(Response.status(Response.Status.FORBIDDEN)
                .entity(new LoreError("OUTSIDE_SCOPE", type + " «" + id + "» существует, но вне разрешённых "
                    + "вызывающему проектов")));
        }
        String rid = String.valueOf(tgt.get("rid"));
        if (!RID.matcher(rid).matches()) {
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(new LoreError(LoreUpstream.QUERY_FAILED, "база вернула не rid: " + rid)));
        }

        // ── входящие рёбра ──
        List<Map<String, Object>> edges;
        try {
            // rid — литерал из предыдущего ответа БД (форма проверена выше).
            edges = ingestService.queryPublic(
                "SELECT @type AS edge, @out AS src, @out.@type AS src_class FROM "
                + "(SELECT expand(inE()) FROM " + rid + ") "
                + "WHERE valid_to IS NULL AND @out.valid_to IS NULL LIMIT " + (BACKLINK_EDGE_CAP + 1),
                Map.of());
        } catch (Exception e) {
            LOG.warnf("[LORE BACKLINKS] %s/%s: рёбра не прочитаны: %s", type, id, e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e, LoreUpstream.detail(e))));
        }
        boolean capped = edges.size() > BACKLINK_EDGE_CAP;
        if (capped) edges = edges.subList(0, BACKLINK_EDGE_CAP);

        // ── источники: по классу одним запросом ──
        Map<String, Set<String>> ridsByClass = new LinkedHashMap<>();
        List<Map<String, Object>> kept = new ArrayList<>();
        for (Map<String, Object> e : edges) {
            String edge = String.valueOf(e.get("edge"));
            if (STRUCTURAL_EDGES.contains(edge)) continue;
            String src = String.valueOf(e.get("src"));
            if (!RID.matcher(src).matches()) continue;
            kept.add(e);
            ridsByClass.computeIfAbsent(String.valueOf(e.get("src_class")), k -> new LinkedHashSet<>()).add(src);
        }

        Map<String, Map<String, Object>> sources = new HashMap<>(); // rid → {type, ref_id, title, projects}
        List<Map<String, Object>> warnings = new ArrayList<>();
        for (Map.Entry<String, Set<String>> en : ridsByClass.entrySet()) {
            Branch b = branchByClass(en.getKey());
            if (b == null) continue; // класс вне таблицы веток — идёт без кода (см. ниже)
            int paths = scopePaths(b).size();
            List<String> rids = new ArrayList<>(en.getValue());
            for (int from = 0; from < rids.size(); from += 500) {
                List<String> chunk = rids.subList(from, Math.min(rids.size(), from + 500));
                try {
                    for (Map<String, Object> r : ingestService.queryPublic(
                            "SELECT @rid AS rid, " + b.idField() + " AS ref_id, " + b.titleField() + " AS title"
                            + projectColumns(b) + " FROM " + b.vertexClass()
                            + " WHERE @rid IN [" + String.join(", ", chunk) + "]", Map.of())) {
                        Map<String, Object> s = new LinkedHashMap<>();
                        s.put("type", b.type());
                        s.put("ref_id", r.get("ref_id"));
                        s.put("title", r.get("title"));
                        s.put("__projects", projectsOf(r, paths));
                        sources.put(String.valueOf(r.get("rid")), s);
                    }
                } catch (Exception ex) {
                    // Источники одного класса не прочитаны — остальное отдаём, но
                    // называем дыру: молча выпавшая группа выглядела бы как «связей нет».
                    LOG.warnf("[LORE BACKLINKS] %s/%s: источники %s не прочитаны: %s",
                        type, id, b.vertexClass(), ex.getMessage());
                    warnings.add(Map.of("source_class", b.vertexClass(), "error", LoreUpstream.detail(ex)));
                }
            }
        }

        // ── группировка ──
        Map<String, List<Map<String, Object>>> byEdgeItems = new java.util.TreeMap<>();
        int hidden = 0;
        int unread = 0;
        for (Map<String, Object> e : kept) {
            String src = String.valueOf(e.get("src"));
            String srcClass = String.valueOf(e.get("src_class"));
            Map<String, Object> s = sources.get(src);
            Branch known = branchByClass(srcClass);
            if (known != null && s == null) { unread++; continue; } // класс известен, строка не прочитана
            @SuppressWarnings("unchecked")
            Set<String> projects = s == null ? Set.of() : (Set<String>) s.get("__projects");
            if (!visibleUnder(projects, allowed)) { hidden++; continue; }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("type", s == null ? null : s.get("type"));
            item.put("ref_id", s == null ? null : s.get("ref_id"));
            item.put("title", s == null ? null : s.get("title"));
            item.put("source_class", srcClass);
            byEdgeItems.computeIfAbsent(String.valueOf(e.get("edge")), k -> new ArrayList<>()).add(item);
        }

        List<Map<String, Object>> groups = new ArrayList<>();
        Map<String, Integer> byEdge = new LinkedHashMap<>();
        int total = 0;
        for (Map.Entry<String, List<Map<String, Object>>> en : byEdgeItems.entrySet()) {
            List<Map<String, Object>> items = new ArrayList<>(en.getValue());
            // Детерминированный порядок: тип источника, затем код.
            items.sort(java.util.Comparator
                .comparing((Map<String, Object> m) -> String.valueOf(m.get("type")))
                .thenComparing(m -> String.valueOf(m.get("ref_id"))));
            Map<String, Object> g = new LinkedHashMap<>();
            g.put("edge", en.getKey());
            g.put("count", items.size());
            g.put("items", items.size() > limit ? items.subList(0, limit) : items);
            g.put("truncated", items.size() > limit);
            groups.add(g);
            byEdge.put(en.getKey(), items.size());
            total += items.size();
        }
        groups.sort(java.util.Comparator
            .comparing((Map<String, Object> g) -> -((Integer) g.get("count")))
            .thenComparing(g -> String.valueOf(g.get("edge"))));

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("type", target.type());
        out.put("id", id);
        out.put("title", tgt.get("title"));
        out.put("total", total);
        out.put("groups", groups);
        out.put("by_edge", byEdge);
        out.put("hidden_by_scope", hidden);
        out.put("excluded_edges", new java.util.TreeSet<>(STRUCTURAL_EDGES));
        out.put("limit", limit);
        boolean complete = !capped && warnings.isEmpty() && unread == 0;
        out.put("complete", complete);
        if (capped) out.put("capped_at", BACKLINK_EDGE_CAP);
        if (unread > 0) out.put("unread_sources", unread);
        if (!warnings.isEmpty()) out.put("warnings", warnings);
        if (allowed != null) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("applied", true);
            m.put("projects", allowed.size());
            m.put("note", "выдача сужена проектным скоупом — источники вне разрешённых проектов не показаны");
            out.put("scope", m);
        }
        out.put("took_ms", (System.nanoTime() - t0) / 1_000_000);
        return noStore(Response.ok(out));
    }

    private static Set<String> csv(String s) {
        if (s == null || s.isBlank()) return Set.of();
        Set<String> out = new LinkedHashSet<>();
        for (String p : s.split(",")) if (!p.isBlank()) out.add(p.trim());
        return out;
    }

    /**
     * Ранг строки; {@code 1.0}, если движок его не посчитал.
     *
     * <p>Здесь стояло {@code ((Number) r.getOrDefault("score", 1.0)).doubleValue()},
     * и это была ошибка ровно на один случай: {@code getOrDefault} подставляет
     * умолчание, только когда ключа НЕТ. Ключ есть всегда — ветка выбирает
     * {@code $score} прямо в SELECT, — а вот ЗНАЧЕНИЕ приходит {@code null} у
     * каждой строки, которую нашёл не индекс, а вторая половина условия
     * {@code id ILIKE :idlike OR SEARCH_INDEX(...)}. То есть у любого попадания
     * ПО КОДУ записи, когда текст запроса в полнотекст не попал.
     *
     * <p>Цена этой мелочи была непропорциональной. NPE вылетал не в строке, а в
     * обходе ветки целиком, и внешний {@code catch} честно записывал ветку в
     * {@code warnings} — со всеми её находками. Наружу это выглядело как «такой
     * записи нет»: поиск по {@code FEAT-M} не находил только что созданный
     * FEAT-M, хотя строка лежала в базе и добывалась обычным {@code ILIKE}.
     *
     * <p>Замерено на живой БД: {@code SELECT uc_id, $score FROM KnowUseCase
     * WHERE (uc_id ILIKE '%UC-VP-MERGE%' OR SEARCH_INDEX('ftKnowUseCase', …))}
     * отдаёт {@code score: null} при непустом {@code uc_id}.
     *
     * <p>Единица — то же значение, что ветка проставляет себе сама на сканном
     * пути ({@code 1.0 AS score}): совпадение по коду ранжировать нечем, и
     * нейтральный вес честнее выдуманного.
     */
    static double scoreOf(Map<String, Object> r) {
        return r.get("score") instanceof Number n ? n.doubleValue() : 1.0;
    }

    private static double round3(double v) { return Math.round(v * 1000.0) / 1000.0; }
}
