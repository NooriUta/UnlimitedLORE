package studio.seer.heimdall.lore;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Registry of named read-only slices over system_aida_lore (ArcadeDB).
 *
 * ArcadeDB constraints (verified against Ygg :2480):
 *  - No UNION support in /api/v1/query endpoint
 *  - No "FROM T a, out('E') b" multi-source join syntax
 *  - Traversal: out("EDGE").field returns array; out("EDGE").field[0] returns scalar
 *  - expand() not available in query endpoint
 *
 * Pattern: MartSlices. Contracts: LORE_SLICES_CONTRACTS.md v1.0.
 */
public final class LoreSlices {

    private LoreSlices() {}

    public record SliceDef(String baseSql, List<String> required,
                           Map<String, String> optionalFilters, String suffix) {}

    public record Composed(String sql, Map<String, Object> params) {}

    /**
     * Conservative value whitelist — ids, dates, semver, module codes, LIKE wildcards,
     * release_uid (contains #), а также ПОИСКОВЫЕ ЗАПРОСЫ пользователя.
     *
     * UNICODE_CHARACTER_CLASS обязателен: без него java-шный `\w` — это ASCII-только
     * [a-zA-Z_0-9], поэтому любой запрос на кириллице отбивался как BAD_PARAMS (400),
     * и сквозной поиск по русскоязычной базе не работал в принципе. Флаг расширяет
     * \w до юникодных букв/цифр; набор пунктуации и лимит длины НЕ меняются — кавычек,
     * точки с запятой и скобок в whitelist по-прежнему нет, так что поверхность
     * инъекции та же (плюс значения уходят связанными параметрами, не конкатенацией).
     */
    static final Pattern VALUE_RE =
        Pattern.compile("[\\w@.,:+\\-/ %#]{1,160}", Pattern.UNICODE_CHARACTER_CLASS);

    /**
     * S7B-26: типизированные параметры среза — значение проверяется белым списком VALUE_RE, как любое,
     * а в базу уходит НЕ строкой. {@code epoch_ms} — ISO-дата (полночь UTC) или момент → epoch-мс
     * (Long): {@code MetricSnapshot.ts} — LONG, и сравнение числа со строкой не то, что ждёт читатель.
     * {@code http_code} — код ответа 100..599 (Long).
     */
    static final Map<String, Map<String, String>> TYPED_PARAMS = Map.of(
        "mcp_failures", Map.of("since", "epoch_ms", "code", "http_code"),
        "agent_action_points", Map.of("since", "epoch_ms"),
        "mcp_failure_rows", Map.of("since", "epoch_ms", "code", "http_code"));

    static Object typedValue(String name, String kind, String value) {
        String v = value.trim();
        if ("epoch_ms".equals(kind)) {
            java.time.Instant t = null;
            if (v.matches("\\d{4}-\\d{2}-\\d{2}([T ]\\d{2}:\\d{2}.*)?")) t = LoreChangedAt.instant(v);
            if (t == null) throw new IllegalArgumentException("bad value for param: " + name + " (" + value
                + ") — ISO date YYYY-MM-DD or date-time, UTC when no zone");
            return t.toEpochMilli();
        }
        if ("http_code".equals(kind)) {
            long c;
            try { c = Long.parseLong(v); }
            catch (NumberFormatException e) { throw new IllegalArgumentException("bad value for param: " + name + " (HTTP status code expected)"); }
            if (c < 100 || c > 599) throw new IllegalArgumentException("bad value for param: " + name + " (HTTP status code 100..599)");
            return c;
        }
        throw new IllegalStateException("unknown param kind: " + kind);
    }

    /** MT-03: с этой даты заведения enb-задача обязана нести JUSTIFIED_BY (раньше — вне правила). Константа времени компиляции. */
    static final String ENB_RULE_SINCE = "2026-08-01";

    private static final Map<String, SliceDef> SLICES = new LinkedHashMap<>();

    /**
     * Держатели ролей задачи — ИЗ РЕБРА, а не из полей вершины (TR-05).
     *
     * <p>Ключи ответа оставлены прежними (`author_agent` и соседи) намеренно:
     * поле исчезает, имя остаётся. Иначе пришлось бы одновременно править
     * четыре среза, экран задач и мобильного клиента — и любая рассинхронизация
     * этих правок выглядела бы как «роль пропала», а не как незавершённый
     * переезд. Переименование, если понадобится, отдельным шагом и после.
     *
     * <p>Берётся ОТКРЫТОЕ ребро: {@code valid_to IS NULL}. Закрытые — это
     * прежние держатели, и показывать их наравне с текущим значило бы вернуть
     * ту самую неоднозначность, ради устранения которой роли уехали в рёбра.
     *
     * <p>Личность приходит с другого конца ребра и лежит в разных полях у
     * человека и у агента, поэтому COALESCE: сперва {@code actor_id}, затем
     * {@code display_name}. Один ключ на обоих — они отвечают на один вопрос
     * «кто», и два ключа заставили бы каждого читателя склеивать их заново.
     */
    /**
     * Конец ребра — {@code @in}, а НЕ {@code in} (TR-05, замерено пробой).
     *
     * <p>Первая редакция писала {@code .in.actor_id} и отдавала пусто ВСЕГДА:
     * ошибки нет, значения нет — по ответу неотличимо от «роли не заведены».
     * У ребра нет обычного свойства с таким именем, поэтому чтение молча даёт
     * null; вершина на другом конце адресуется только через {@code @in}.
     *
     * <p>Замер {@code RoleEdgeHopFormLiveDbTest} на одном заведённом ребре:
     * {@code [фильтр].@in.actor_id[0]} → значение; {@code [фильтр].in.actor_id}
     * → null; и КОНТРОЛЬ — {@code .in.actor_id} БЕЗ фильтра тоже null. Значит
     * переменная одна, и фильтр к отказу отношения не имеет.
     *
     * <p>Оговорка о собственной ошибке, ради которой контроль и ставился.
     * Сначала я сравнила {@code outE(...)[фильтр].in.поле} с {@code out(...).поле}
     * и объявила виноватым фильтр — а формы отличались СРАЗУ В ДВУХ местах:
     * {@code out()} отдаёт вершину, {@code outE()} — ребро. Опыт с двумя
     * различиями не отвечает ни на один вопрос, но выглядит как ответ: я на его
     * основании успела назвать дефектом СУБД то, что было дефектом запроса.
     * Поймано владельцем. Правило: меняй по одной переменной и ставь контроль.
     */
    private static String roleHolder(String role) {
        String edge = "outE('ROLE_HELD_BY')[role='" + role + "' AND valid_to IS NULL].@in.";
        // ЧИТАЕМОЕ ИМЯ ПЕРВЫМ, идентификатор — последним запасным.
        //
        // Прежний порядок начинался с actor_id, и в списках задач всегда стоял
        // он: у агента actor_id непуст никогда, поэтому до имени очередь не
        // доходила. Человек видел «AGENT-FULL-msbt0fed», где хвост — время
        // заведения в 36-ричной записи, то есть служебный шум в лице колонки
        // «кто». Читаемое имя при этом лежало рядом и не показывалось.
        //
        // Порядок разный у двух типов на том конце: у агента (KnowActor) есть
        // name, у человека (KnowUser) его нет — только display_name. Поэтому
        // сперва name, затем display_name, и лишь потом actor_id как признак
        // того, что имя не заполнили.
        return "COALESCE(" + edge + "name[0], " + edge + "display_name[0], "
             + edge + "actor_id[0]) AS " + role + "_agent";
    }

    private static final String ROLE_HOLDERS =
        roleHolder("author") + ", " + roleHolder("executor") + ", " + roleHolder("reviewer");

    /**
     * SPRINT_UXR_S9_SCALE_OPT/S9-05, решение владелицы D14 «колонки по типу ребёнка»: строка
     * задачи-ребёнка в паспорте родителя (компонент, человек, агент) несёт исполнителя, оценку и
     * класс работы — фасад кладёт их в {@code values} связи ({@link LoreRecordFrom#CHILD_VALUES}).
     */
    static final String CHILD_TASK_COLS =
        roleHolder("executor") + ", work_class, " +
        "COALESCE(out('HAS_STATE')[valid_to IS NULL].effort_days[0], out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0]) AS effort_days";

    /**
     * S9-05 / D14: строка спринта-ребёнка (веха, компонент, релиз, проект) несёт прогресс x/y и
     * даты плана. Задачи — дети PART_OF типа KnowTask (фазы тоже PART_OF — отсеиваются);
     * «готово» считает фасад по статусам открытых строк истории тем же словарём (planToken),
     * что и факт «готово x/y» паспорта спринта, — иначе таблица и паспорт разошлись бы.
     */
    static final String CHILD_SPRINT_COLS =
        "in('PART_OF')[@type = 'KnowTask'].size() AS tasks_total, " +
        "in('PART_OF')[@type = 'KnowTask'].out('HAS_STATE')[valid_to IS NULL].status_raw AS task_statuses, " +
        "COALESCE(out('HAS_STATE')[valid_to IS NULL].planned_start_date[0], out('HAS_STATE')[planned_start_date IS NOT NULL].planned_start_date[0]) AS planned_start_date, " +
        "COALESCE(out('HAS_STATE')[valid_to IS NULL].planned_end_date[0], out('HAS_STATE')[planned_end_date IS NOT NULL].planned_end_date[0]) AS planned_end_date";

    private static void slice(String id, String baseSql) {
        slice(id, baseSql, List.of(), Map.of(), "");
    }

    /**
     * RM-P8: повторное объявление — ОТКАЗ, а не тихая перезапись.
     *
     * <p>Реестр это {@code LinkedHashMap}, и {@code put} по занятому ключу молча
     * затирал первое определение вторым. Так и жило: {@code git_projects} был
     * объявлен дважды, побеждало объявление БЕЗ поля {@code is_private} — то
     * есть форма, которую ждала форма выбора проекта в вопросах и решениях,
     * наружу не выходила вовсе. Ошибки при этом не было нигде: слайс есть,
     * отвечает, просто не тем.
     *
     * <p>Падать на старте приложения хуже, чем на сборке, но несравнимо лучше,
     * чем отвечать не тем: дубль ловится первым же прогоном тестов, потому что
     * статический блок исполняется при первом обращении к классу.
     */
    private static void slice(String id, String baseSql, List<String> required,
                              Map<String, String> optional, String suffix) {
        SliceDef prev = SLICES.put(id, new SliceDef(baseSql, required, optional, suffix));
        if (prev != null) {
            throw new IllegalStateException(
                "слайс '" + id + "' объявлен дважды — второе определение молча затирало первое. "
                + "Переименуйте один из них или удалите лишний.");
        }
    }

    /**
     * SQL-условие «состояние закрыто» — общее для всех слайсов, где закрытость
     * определяется по тексту статуса. Объявлено ДО статического блока намеренно:
     * блок его использует, а Java не допускает forward reference из инициализатора.
     *
     * <p>AL-117 сделал значок основным сигналом, и это верно: {@code status_raw} —
     * свободный текст после значка, а матчинг по словам-подстрокам систематически
     * терял формулировки, для которых не был написан. Но у отсечки строго по
     * значку своя цена: строка БЕЗ значка перестала считаться закрытой вообще.
     *
     * <p>SPRINT_QG_REBUILD/QG-06 (2026-08-26), замерено на проде: один спринт
     * ({@code SPRINT_SITE_SEO_PRERENDER}, открытая hist-строка ровно {@code "DONE"})
     * и семь задач. Спринт остался без {@code done_date}; задачи хуже — они
     * попадают в {@code open_tasks} и числятся незакрытыми. При этом
     * {@code AidaLoreResource.classifyStatus()} те же строки считает закрытыми:
     * аналитика и слайсы расходятся в том, что значит «закрыто», и расходятся молча.
     *
     * <p>Поэтому слова возвращаются вторым уровнем — но <b>якорем в начале строки</b>,
     * а не подстрокой. Ровно на подстроке {@code LIKE '%DONE%'} ошибалась версия до
     * AL-117: «📋 PLANNED — … DONE позже» ею считалось закрытым.
     */
    static final String DONE_STATUS_SQL = LoreStatusVocabulary.anySql("status_raw", "done");

    /**
     * S7B-02: семейства записи, относящиеся к админке (журнал действий админки).
     * Человеческие семейства (AgentScopeFilter.HUMAN_ONLY без контентных news/record)
     * и управление проектами и их ролями.
     */
    static final java.util.Set<String> ADMIN_FAMILIES =
        java.util.Set.of("dict", "kc", "admin", "user", "project", "project-actor");

    /**
     * S2-11: дата закрытия спринта — момент ПЕРЕХОДА в «выполнен». Правка плана
     * закрытого спринта открывает новую DONE-версию, и {@code [done].valid_from[0]}
     * мог указать на неё — дата плыла. {@code status_known_from} ставится только
     * сменой статуса и переносится правками (StatusHistoryService, правка плана),
     * поэтому у открытой DONE-версии он и есть момент закрытия. Старые версии без
     * этого поля (до S2-13) — прежнее выражение.
     */
    // Цепочка фильтров [..][..], а не AND: проекция без « AND » — сторож склейки
    // фильтров слайса (LoreSliceComposeFiltersTest) различает AND только по тексту.
    //
    // MT-MCP-TRUTH Б1/Б2 (D-2026-DONE-DATE-CLEARED-AND-STATUS-IS-TRUTH): оба плеча — только ОТКРЫТАЯ
    // версия. Запасное плечо раньше искало DONE в ЛЮБОЙ версии, и спринт, возвращённый из DONE
    // (SPRINT_ARCADEDB_26_11_ALL, 06.11), сохранял дату откатанного закрытия. Легаси-версия без
    // status_known_from — начало открытой DONE-версии, как у task_done_dates. Проба на движке —
    // DoneDateOpenVersionEngineTest.
    static final String OPEN_DONE_SQL = "out('HAS_STATE')[valid_to IS NULL][" + DONE_STATUS_SQL + "]";
    static final String DONE_DATE_SQL =
        "ifnull(" + OPEN_DONE_SQL + ".status_known_from[0], " + OPEN_DONE_SQL + ".valid_from[0])";

    /**
     * Свежесть записи в списках разделов v2 (D-2026-UXR-LISTS-DEFAULT-SORT-FRESHNESS,
     * вопрос №49 владелицы 10.11: «по последней дате изменения — это свежесть»).
     *
     * <p>{@code changed_at} — {@code valid_from} ОТКРЫТОЙ версии SCD2 (каждая смена
     * статуса и версионируемая правка открывает новую), иначе — дата заведения из
     * {@code fallbacks}. Правки «на месте» (тело спеки без checkpoint, заметка и
     * название задачи, поля релиза и решения) версию не открывают — они ставят
     * {@code updated_at} на вершине, и {@code changed_at} — МАКСИМУМ из открытой
     * версии и {@code updated_at}. Максимум считает {@link LoreChangedAt#fold}
     * (типы разные: DATETIME и строка ISO), срез отдаёт для него служебную колонку
     * {@link LoreChangedAt#TOUCHED}.
     */
    static String changedAtSql(String... fallbacks) {
        return "COALESCE(out('HAS_STATE')[valid_to IS NULL].valid_from[0], "
            + String.join(", ", fallbacks) + ") AS changed_at, updated_at AS " + LoreChangedAt.TOUCHED;
    }

    /**
     * MT-NOTE-APPEND п.3: момент ТЕКУЩЕГО СТАТУСА задачи/спринта. Правка текста открывает
     * новую версию SCD2 без смены статуса, поэтому valid_from открытой версии — уже не
     * «с какого момента в этом статусе». status_known_from ставит только смена статуса,
     * правки его переносят; у легаси-версий без поля — прежнее valid_from.
     */
    static final String STATUS_SINCE_SQL = "ifnull(out('HAS_STATE')[valid_to IS NULL].status_known_from[0], "
        + "out('HAS_STATE')[valid_to IS NULL].valid_from[0])";

    /** Дата заведения у типов без своего поля: первая версия истории (порядок рёбер — порядок вставки). */
    private static final String FIRST_STATE_FROM_SQL = "out('HAS_STATE')[valid_from IS NOT NULL].valid_from[0]";

    /** Технология (спека SPEC-TECH-*): номер, тело и «проверено» — из открытой версии. */
    private static final String TECH_OPEN_COLUMNS =
        "COALESCE(out('HAS_STATE')[valid_to IS NULL].version[0], version) AS version, " +
        "COALESCE(out('HAS_STATE')[valid_to IS NULL].content_md[0], content_md) AS content_md, " +
        "out('HAS_STATE')[valid_to IS NULL].valid_from[0] AS checked_at, ";

    /**
     * Выражение статуса в {@code open_tasks} — двойной хоп, а не поле, поэтому
     * предикат строится отдельно от {@link #DONE_STATUS_SQL}.
     */
    private static final String OPEN_TASK_STATUS_EXPR =
        "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0])";

    /**
     * Релиз ЗАДАЧИ — релиз, в который уехал её PR (CLOSED_BY → SHIPPED_IN); одна проекция у
     * open_tasks и closed_tasks. Раньше (S9-02) брались релизы спринта, и запланированная задача
     * из спринта, где другие уже уехали, показывала «v1.17.20 +2» (владелица 14.11.2026;
     * правило PU-07: у задачи — тот релиз, в котором уехал её PR). Нет PR в релизе — пусто.
     */
    /**
     * Колонки репозитория (D-2026-MIG-REPOSITORY-ORGANIZATION): ключ — адрес; роль у проекта (primary | unassigned),
     * компонент, зеркала в обе стороны и «использует» — для паспорта и списка «Репозитории».
     */
    private static final String REPO_COLUMNS =
        "SELECT url AS repo_id, url, full_path, host, owner, name, default_branch, "
        + "in('HAS_REPOSITORY').slug AS projects, inE('HAS_REPOSITORY').role AS project_roles, "
        + "in('COMPONENT_REPOSITORY').component_id AS components, "
        + "out('MIRRORED_TO').url AS mirrors, in('MIRRORED_TO').url AS mirror_of, "
        + "out('USES_REPOSITORY').url AS uses, in('USES_REPOSITORY').url AS used_by, "
        // Группировка списка по проекту (прототип): репозиторий компонента — в группе проекта компонента,
        // зеркало — в группе проекта оригинала.
        + "in('COMPONENT_REPOSITORY').out('IN_PRODUCT').out('BELONGS_TO_PROJECT').slug AS component_projects, "
        + "in('MIRRORED_TO').in('HAS_REPOSITORY').slug AS mirror_projects ";

    private static final String TASK_RELEASES_SQL =
        "out('CLOSED_BY').out('SHIPPED_IN').release_id AS release_ids";

    /**
     * Проекты задачи — проекты её спринта (PART_OF → BELONGS_TO_PROJECT), многозначное поле. Владелица 19.11.2026:
     * группировка по проекту везде, где есть проект; задача в нескольких проектах — в каждой группе.
     */
    private static final String TASK_PROJECTS_SQL = "out('PART_OF').out('BELONGS_TO_PROJECT').slug AS project_slugs";

    /**
     * RM-P17: как зовётся родитель строки истории — одна пара на цепочку SCD2.
     *
     * <p>Нужно срезу {@code history_hygiene}: находка без {@code ref_id}
     * бесполезна — по счётчику «семь строк» починить нельзя, по
     * {@code SPRINT_DALI_PARSE_MEM_PARALLEL_JUN26/P1-A} можно.
     *
     * <p><b>Какие цепочки существуют — не здесь.</b> Список берётся из реестра
     * объявления {@code valid_from} ({@link LoreSchemaMigrations#HIST_VALID_FROM_TEXT}
     * плюс {@link LoreSchemaMigrations#HIST_VALID_FROM_TEMPORAL}); эта таблица
     * отвечает только на вопрос «как зовётся родитель». Новый {@code *Hist},
     * попавший в реестр без пары здесь, валит статический блок при первом
     * обращении к классу — то есть на первом же прогоне тестов. Молча выпасть
     * из гигиены он не может, и третьей таблицы «какие бывают *Hist» в корпусе
     * не появляется (RM-P8 — расхождение двух таблиц об одном).
     *
     * <p>У записи справочника одиночного естественного id нет (ключ составной,
     * {@code dict_type} + {@code code}) — в находку едет {@code code}: он
     * адресует строку внутри своего типа, а сам тип виден в {@code hist_type}.
     */
    record HistParent(String entityType, String idField) {}

    static final Map<String, HistParent> HIST_PARENT = Map.ofEntries(
        Map.entry("KnowADRHist",       new HistParent("adr",        "adr_id")),
        Map.entry("KnowDecisionHist",  new HistParent("decision",   "decision_id")),
        Map.entry("KnowDocHist",       new HistParent("doc",        "doc_id")),
        Map.entry("KnowFindingHist",   new HistParent("finding",    "finding_id")),
        Map.entry("KnowMilestoneHist", new HistParent("milestone",  "milestone_id")),
        Map.entry("KnowPhaseHist",     new HistParent("phase",      "phase_uid")),
        Map.entry("KnowReleaseHist",   new HistParent("release",    "release_id")),
        Map.entry("KnowRunbookHist",   new HistParent("runbook",    "runbook_id")),
        Map.entry("KnowSpecHist",      new HistParent("spec",       "spec_id")),
        Map.entry("KnowTaskHist",      new HistParent("task",       "task_uid")),
        Map.entry("KnowSprintHist",    new HistParent("sprint",     "sprint_id")),
        Map.entry("KnowDictEntryHist", new HistParent("dict_entry", "code")));

    /** Все цепочки SCD2 корпуса в устойчивом порядке — иначе SQL среза плывёт между прогонами. */
    static List<String> histChains() {
        List<String> all = new java.util.ArrayList<>(LoreSchemaMigrations.HIST_VALID_FROM_TEXT);
        all.addAll(LoreSchemaMigrations.HIST_VALID_FROM_TEMPORAL);
        return List.copyOf(all);
    }

    /**
     * SQL среза {@code history_hygiene} — по одной ветке unionall на цепочку.
     *
     * <p>Собирается кодом, а не рукой: двенадцать почти одинаковых ветвей,
     * написанных вручную, расходятся при первой же правке одной из них.
     */
    private static String histHygieneSql() {
        List<String> chains = histChains();
        if (chains.size() > 26) {
            throw new IllegalStateException(
                "цепочек SCD2 больше 26 — однобуквенные имена LET-переменных кончились, "
                + "смените схему именования в histHygieneSql()");
        }
        StringBuilder vars = new StringBuilder();
        StringBuilder lets = new StringBuilder();
        for (int i = 0; i < chains.size(); i++) {
            String hist = chains.get(i);
            HistParent parent = HIST_PARENT.get(hist);
            if (parent == null) {
                throw new IllegalStateException(
                    "RM-P17: цепочка " + hist + " объявлена в реестре valid_from, но пары в "
                    + "LoreSlices.HIST_PARENT у неё нет — срез history_hygiene молча пропустил бы "
                    + "весь этот тип. Добавьте пару «класс → поле id родителя».");
            }
            String var = "$h" + (char) ('a' + i);
            if (i > 0) { vars.append(", "); lets.append(", "); }
            vars.append(var);
            lets.append(var)
                .append(" = (SELECT 'open_state_without_valid_from' AS finding, '")
                .append(parent.entityType()).append("' AS entity_type, '")
                .append(hist).append("' AS hist_type, in('HAS_STATE').")
                .append(parent.idField()).append("[0] AS ref_id, state_uid FROM ")
                .append(hist).append(" WHERE valid_to IS NULL AND valid_from IS NULL)");
            // S2-11 (прод 09.11, PRE-03): одна версия на ДВЕ сущности — история второй пуста,
            // а статус через out('HAS_STATE') виден. Ветка на каждую цепочку.
            String shared = "$g" + (char) ('a' + i);
            vars.append(", ").append(shared);
            lets.append(", ").append(shared)
                .append(" = (SELECT 'state_shared_by_entities' AS finding, '")
                .append(parent.entityType()).append("' AS entity_type, '")
                .append(hist).append("' AS hist_type, in('HAS_STATE').")
                .append(parent.idField()).append("[0] AS ref_id, state_uid FROM ")
                .append(hist).append(" WHERE in('HAS_STATE').size() > 1)");
        }
        // S2-11: ребро HAS_STATE ведёт на версию ЧУЖОГО класса — паспорт и история её не видят.
        vars.append(", $wt, $ws");
        lets.append(", $wt = (SELECT 'state_wrong_class' AS finding, 'task' AS entity_type, "
                + "'KnowTaskHist' AS hist_type, task_uid AS ref_id, null AS state_uid FROM KnowTask "
                + "WHERE out('HAS_STATE')[@type <> 'KnowTaskHist'].size() > 0)")
            .append(", $ws = (SELECT 'state_wrong_class' AS finding, 'sprint' AS entity_type, "
                + "'KnowSprintHist' AS hist_type, sprint_id AS ref_id, null AS state_uid FROM KnowSprint "
                + "WHERE out('HAS_STATE')[@type <> 'KnowSprintHist'].size() > 0)");
        // S2-11: задача или спринт без ЕДИНОЙ версии истории — запись мимо SCD2
        // (найдено 07.11: 14 задач, их O(t) не определить). Пустой срез без этой
        // ветки читался бы как «история в порядке».
        vars.append(", $nt, $ns");
        lets.append(", $nt = (SELECT 'entity_without_history' AS finding, 'task' AS entity_type, "
                + "'KnowTaskHist' AS hist_type, task_uid AS ref_id, null AS state_uid FROM KnowTask "
                + "WHERE out('HAS_STATE').size() = 0)")
            .append(", $ns = (SELECT 'entity_without_history' AS finding, 'sprint' AS entity_type, "
                + "'KnowSprintHist' AS hist_type, sprint_id AS ref_id, null AS state_uid FROM KnowSprint "
                + "WHERE out('HAS_STATE').size() = 0)");
        return "SELECT finding, entity_type, hist_type, ref_id, state_uid "
            + "FROM (SELECT expand(unionall(" + vars + ")) LET " + lets + ") "
            + "ORDER BY entity_type, ref_id";
    }

    /**
     * AL-113: типы с проектной осью — вершина без BELONGS_TO_PROJECT у них
     * дефект данных. {@code inherit} — путь к родителю, чей проект засчитывается
     * (как у read-скоупа {@link #PROJECT_SCOPED}). Глобальных вершин (KnowJob)
     * здесь нет по замыслу: у них проекта нет и быть не должно.
     */
    record ProjectOwned(String entityType, String vertexType, String idField, String titleField, String inherit) {}

    static final List<ProjectOwned> PROJECT_OWNED = List.of(
        new ProjectOwned("sprint",   "KnowSprint",   "sprint_id",   "coalesce(title, name)",       null),
        new ProjectOwned("adr",      "KnowADR",      "adr_id",      "title",      null),
        new ProjectOwned("decision", "KnowDecision", "decision_id", "title",      "out('DECIDED_IN')"),
        new ProjectOwned("question", "KnowQuestion", "question_id", "title",      "out('RAISED_IN')"),
        new ProjectOwned("release",  "KnowRelease",  "release_uid", "release_id", null),
        new ProjectOwned("spec",     "KnowSpec",     "spec_id",     "title",      null),
        new ProjectOwned("doc",      "KnowDoc",      "doc_id",      "title",      null),
        new ProjectOwned("runbook",  "KnowRunbook",  "runbook_id",  "name",       null),
        new ProjectOwned("use_case", "KnowUseCase",  "uc_id",       "title",      null)
    );

    /** SQL среза {@code entities_without_project} — по ветке unionall на тип (собирается кодом, как history_hygiene). */
    private static String entitiesWithoutProjectSql() {
        StringBuilder vars = new StringBuilder();
        StringBuilder lets = new StringBuilder();
        for (int i = 0; i < PROJECT_OWNED.size(); i++) {
            ProjectOwned t = PROJECT_OWNED.get(i);
            String var = "$e" + (char) ('a' + i);
            if (i > 0) { vars.append(", "); lets.append(", "); }
            vars.append(var);
            lets.append(var).append(" = (SELECT '").append(t.entityType()).append("' AS entity_type, ")
                .append(t.idField()).append(" AS ref_id, ").append(t.titleField()).append(" AS title FROM ")
                .append(t.vertexType()).append(" WHERE out('BELONGS_TO_PROJECT').size() = 0");
            if (t.inherit() != null)
                lets.append(" AND ").append(t.inherit()).append(".out('BELONGS_TO_PROJECT').size() = 0");
            lets.append(")");
        }
        return "SELECT entity_type, ref_id, title FROM (SELECT expand(unionall(" + vars + ")) LET "
            + lets + ") ORDER BY entity_type, ref_id";
    }

    static {
        // ── §1 Timeline — 3 separate slices, merged on frontend ──────────────
        // No UNION in ArcadeDB /api/v1/query. Frontend fetches all 3, merges by date.

        slice("timeline_adrs",
            "SELECT adr_id, date_created, " +
            "out('BELONGS_TO').component_id[0] AS component, " +
            // ADRPROJ-01: у ADR есть BELONGS_TO_PROJECT — отдаём в ленту, иначе
            // новые ADR со связкой на проект падали в «без проекта» (владелец).
            "out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowADR WHERE date_created IS NOT NULL ORDER BY date_created DESC",
            List.of(), Map.of(), " LIMIT 150");

        // ML-NEWS project derivation for decisions: the feed grouped them under
        // «без проекта» because this slice never carried a project. A decision's
        // project is either its OWN BELONGS_TO_PROJECT edge (rare, 9/300) or —
        // the model path — its parent ADR's (decision →DECIDED_IN→ ADR
        // →BELONGS_TO_PROJECT, ADRPROJ-01). news() prefers the own edge, then the
        // ADR's. Same shape as the spec row (projects[]).
        slice("timeline_decisions",
            "SELECT decision_id, title, date_created, updated_at, " +
            "out('BELONGS_TO_PROJECT').slug                  AS projects, " +
            "out('DECIDED_IN').out('BELONGS_TO_PROJECT').slug AS adr_projects " +
            "FROM KnowDecision " +
            "WHERE date_created IS NOT NULL ORDER BY date_created DESC",
            List.of(), Map.of(), "");

        // Порядок ПО ДАТЕ, а не по release_id. Было `ORDER BY release_id DESC` —
        // строковое сравнение версий, из-за которого LIMIT срезал не хвост
        // истории, а СЕРЕДИНУ окна по датам. Найдено сессией miniLORE-шлюза
        // 31.08.2026 на живых данных: у AIDA/miniLore_serverside в выдачу
        // попадали v0.3.9, v0.3.8, v0.3.7 … v0.3.42, v0.3.41, v0.3.40, v0.3.4,
        // v0.3.39 … v0.3.30, v0.3.3 — а v0.3.29…v0.3.10 не попадали вовсе, хотя
        // по датам лежат внутри тех же 22–31 августа. Счёт «за последние N дней»
        // по такому срезу занижен, и отличить это от честного числа нечем.
        //
        // Соседние timeline_* (adrs, decisions) сортируются по дате изначально —
        // расходился именно этот.
        slice("timeline_releases",
            "SELECT release_id, git_tag, release_date, is_current, git_project " +
            "FROM KnowRelease ORDER BY release_date DESC",
            List.of(), Map.of(), " LIMIT 100");

        // Окно релизов по ДАТЕ — для счётчиков «за N дней» (miniLORE CO-45).
        // Отдельным срезом, а не параметром к `releases`: тому нужны тяжёлые
        // поля (description_md, hosts, счётчики спринтов и PR), а для счёта они
        // не нужны и гоняются зря.
        //
        // LIMIT здесь тоже есть, но он честный: при сортировке по дате он режет
        // САМОЕ СТАРОЕ, то есть за пределами запрошенного окна, а не дырявит
        // середину. Тысяча — с запасом: релизов в корпусе порядка двухсот.
        slice("releases_since",
            "SELECT release_id, git_tag, release_date, is_current, git_project, " +
            "out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowRelease " +
            "WHERE release_date IS NOT NULL AND release_date >= :from",
            List.of("from"),
            new LinkedHashMap<>(Map.of(
                "project", " WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project")),
            " ORDER BY release_date DESC LIMIT 1000");

        // AL-113 (запрошено miniLORE 2026-08-16): у среза `specs` даты не было,
        // поэтому спеки не попадали в новостную ленту. Дата спеки = valid_from
        // её ПЕРВОЙ HAS_STATE (создание) — та же природа, что date_created у
        // ADR/decision. [0] = порядок вставки hist-строк = создание (вставки
        // append, как в spec_by_id). WHERE по size()>0, не по [0] IS NOT NULL:
        // индексация коллекции в WHERE ненадёжна (sprint_done_dates фильтрует
        // тем же size()). Java-часть /lore/news всё равно сортирует по дате —
        // здесь только отбор дат и потолок объёма.
        slice("timeline_specs",
            "SELECT spec_id, title, out('HAS_STATE').valid_from[0] AS date_created, " +
            "COALESCE(in('DOCUMENTED_IN').component_id[0], out('BELONGS_TO').component_id[0]) AS component, " +
            // AL-113 follow-up: у спеки есть BELONGS_TO_PROJECT (в отличие от
            // decision/adr, у которых проекта в модели нет) — отдаём, чтобы
            // spec-запись новостной ленты несла project и фильтр по проекту на
            // клиенте её не терял.
            "out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowSpec WHERE out('HAS_STATE').size() > 0",
            List.of(), Map.of(), " LIMIT 400");

        slice("timeline_sprints",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "out('HAS_STATE').valid_from[0] AS valid_from, " +
            "out('HAS_STATE').status_raw[0] AS status_raw " +
            "FROM KnowSprint ORDER BY sprint_id",
            List.of(), Map.of(), "");

        // ── §2 ADRs ──────────────────────────────────────────────────────────
        slice("adrs",
            "SELECT adr_id, name, status, date_created, " +
            changedAtSql("created_at", "date_created") + ", " +
            "out('BELONGS_TO').component_id[0] AS component, " +
            "out('BELONGS_TO').component_id    AS components, " +
            "out('TAGGED_WITH').tag_id         AS tags, " +
            "out('BELONGS_TO_PROJECT').slug    AS git_projects, " + // ADRPROJ-01
            "in('DECIDED_IN').size()           AS decision_count " +
            "FROM KnowADR",
            List.of(),
            new LinkedHashMap<>(Map.of(
                // CONTAINS, не [0]: у сущности может быть несколько BELONGS_TO, а
                // порядок рёбер — это порядок вставки, не приоритет. Сравнение с [0]
                // делало сущность видимой только под одним произвольным компонентом.
                "component", " WHERE out('BELONGS_TO').component_id CONTAINS :component")),
            " ORDER BY adr_id");

        // ADR passport — full context with traversals
        slice("adr",
            "SELECT adr_id, name, status, file_path, date_created, " +
            "out('HAS_STATE').context_md[0]      AS context_md, " +
            "out('HAS_STATE').decision_md[0]     AS decision_md, " +
            "out('HAS_STATE').consequences_md[0] AS consequences_md, " +
            "out('HAS_STATE').sprint_id[0]       AS sprint_id, " +
            "out('HAS_STATE').valid_from[0]       AS hist_valid_from, " +
            "out('BELONGS_TO').component_id       AS components, " +
            "outE('DEPENDS_ON')[valid_to IS NULL].inV().adr_id AS depends_on_ids, " +
            "out('IMPLEMENTED_IN').sprint_id      AS implemented_in_ids, " +
            "out('IMPLEMENTED_IN_RELEASE').release_id AS release_ids, " +
            "out('IMPLEMENTED_IN_RELEASE').release_uid AS release_uids, " +
            "out('SUPERSEDES').adr_id             AS supersedes_ids, " +
            "out('TAGGED_WITH').tag_id            AS tags, " +
            "out('BELONGS_TO_PROJECT').slug       AS git_projects, " + // ADRPROJ-01
            // PL-19: обратные рёбра. Паспорт ADR показывал только исходящие
            // связи, и «на что этот ADR влияет» читалось лишь с другой стороны —
            // открыв каждый сценарий и каждую задачу. Прослеживаемость обязана
            // читаться в обе стороны от точки, где стоишь.
            "in('TRACED_TO').uc_id                AS traced_by_ucs, " +    // сценарии, ссылающиеся на ADR (D9)
            "in('JUSTIFIED_BY').task_uid          AS justified_task_uids, " + // enb-задачи, обоснованные им (PL-14)
            // То же правило, не применённое к SUPERSEDES: ребро идёт FROM нового
            // ADR TO старого, поэтому у ЗАМЕНЁННОГО оно входящее и в паспорте не
            // показывалось вовсе. Статус «Заменено» стоял, а чем перекрыт —
            // нигде: цепочка решений обрывалась ровно там, где нужна.
            "in('SUPERSEDES').adr_id              AS superseded_by_ids, " +
            // S4-29 v3: «блокирует» во вкладке «Связи ADR» — входящий DEPENDS_ON не читался вовсе.
            "inE('DEPENDS_ON')[valid_to IS NULL].outV().adr_id AS blocks_ids " +
            "FROM KnowADR WHERE adr_id = :id",
            List.of("id"), Map.of(), "");

        // SCD2 history chain for one ADR. AL-30: ревизия версионирует ВСЁ — слайс
        // обязан отдавать тела, а не только хэш; иначе история из 200 ревизий тел
        // показывала прочерки. content_hash (SV-10) = дешёвый «менялось ли», тела =
        // «что именно» для пополевого диффа в UI.
        // B9: WHERE — CONTAINS, не [0] =: у общей версии (S2-11) владелец №2 иначе
        // получает пустую историю молча — фильтр сравнивался с чужим первым владельцем.
        slice("adr_history",
            "SELECT valid_from, valid_to, content_hash, source_commit, " +
            "context_md, decision_md, consequences_md " +
            "FROM KnowADRHist WHERE in('HAS_STATE').adr_id CONTAINS :id ORDER BY valid_from",
            List.of("id"), Map.of(), "");

        // AL-113 (запрошено miniLORE 2026-08-16): `adr_history` отдаёт правки
        // ОДНОГО ADR за запрос (нужен :id) — для ленты редакций по всем ADR это
        // N запросов. Батч-срез: по одной строке на каждую версию-открытие ADR
        // сразу по всем, для новостной ленты правок. valid_from — реальная
        // колонка KnowADRHist (ORDER BY по ней надёжен). Тела не тянем — лента
        // показывает факт правки, не диф.
        // B9: state_owners — число владельцев версии (> 1 — общая версия, S2-11):
        // id — первый владелец ([0] порядком хранилища не гарантирован), колонка
        // говорит потребителю, что строка относится не только к нему. Счётчик, не
        // сравнение: бинарное выражение (size() > 1) в проекции ArcadeDB не парсит.
        slice("adr_history_all",
            "SELECT in('HAS_STATE').adr_id[0] AS adr_id, valid_from, valid_to, " +
            "content_hash, source_commit, " +
            // Проект вершины — событию «изменено» в ленте (см. NewsChangedCarriesProjectTest).
            "in('HAS_STATE').out('BELONGS_TO_PROJECT').slug AS projects, " +
            "in('HAS_STATE').size() AS state_owners " +
            "FROM KnowADRHist WHERE valid_from IS NOT NULL ORDER BY valid_from DESC",
            List.of(), Map.of(), " LIMIT 300");

        // Зеркала adr_history_all для события «изменено» в ленте (ML-NEWS): правки
        // спек и решений — такая же новость, как правка ADR. Свёртку «одна строка
        // на (id, день)» делает потребитель (/news), здесь только сырые ревизии.
        // B9: state_owners — см. adr_history_all: > 1 — общая версия.
        slice("spec_history_all",
            "SELECT in('HAS_STATE').spec_id[0] AS spec_id, valid_from, valid_to, content_hash, " +
            "in('HAS_STATE').out('BELONGS_TO_PROJECT').slug AS projects, " +
            "in('HAS_STATE').size() AS state_owners " +
            "FROM KnowSpecHist WHERE valid_from IS NOT NULL ORDER BY valid_from DESC",
            List.of(), Map.of(), " LIMIT 300");

        slice("decision_history_all",
            "SELECT in('HAS_STATE').decision_id[0] AS decision_id, valid_from, valid_to, content_hash, " +
            "in('HAS_STATE').size() AS state_owners " +
            "FROM KnowDecisionHist WHERE valid_from IS NOT NULL ORDER BY valid_from DESC",
            List.of(), Map.of(), " LIMIT 300");

        // Графики 19.11.2026 (№11 «поток решений»): версии решений СО СТАТУСОМ и пометкой бэкфилла
        // (S2-13: статус в истории решений положен бэкфиллом — это не переход, его считают отдельно).
        // decision_history_all статуса не несёт и обрезан 300 строками. Без потолка: поток за квартал.
        slice("decision_status_versions",
            "SELECT in('HAS_STATE').decision_id[0] AS decision_id, status_raw, valid_from, valid_to, status_backfilled " +
            "FROM KnowDecisionHist WHERE valid_from IS NOT NULL",
            List.of(), Map.of(), "");

        // ── §2 Decisions ─────────────────────────────────────────────────────
        // ADR-019: KnowDecision as child of ADR. component_id/tags are filter axes,
        // parent_adr (out DECIDED_IN) is the "rule → why" link. ORDER BY/LIMIT live
        // in the suffix so a future optional WHERE lands before them.
        slice("decisions",
            "SELECT decision_id, title, date_created, status_raw, out('BELONGS_TO').component_id[0] AS component_id, " +
            // Свежесть (вопрос №49): правка полей ставит updated_at на вершине (версию
            // не открывает), смена статуса — версию KnowDecisionHist; changed_at — более
            // поздняя из двух (раньше updated_at брался первым и прятал смену статуса).
            changedAtSql("created_at", "date_created") + ", " +
            "out('BELONGS_TO').component_id     AS components, " +
            "out('BELONGS_TO_PROJECT').slug     AS projects, " +
            "out('TAGGED_WITH').tag_id  AS tags, " +
            "out('DECIDED_IN').adr_id[0] AS parent_adr " +
            "FROM KnowDecision",
            // Потолок был 300 при сортировке по decision_id, и корпус вырос ровно
            // до него: замер 30.08.2026 — 300 строк, самая поздняя date_created
            // 31 июля. Весь август был невидим, а признака обрезки в ответе нет,
            // поэтому «300» читалось как «все». Хуже, чем «последние 300»:
            // выпадали не старые, а те, чей код лексикографически дальше, —
            // свежие D-2026-MINILORE-… не попадали, хотя search их находил.
            //
            // Правится ДВУМЯ изменениями, и оба нужны. Порядок — от свежих:
            // если потолок когда-нибудь снова достанут, он срежет старое, а не
            // случайную по смыслу часть алфавита. Потолок поднят выше корпуса с
            // запасом на годы — он остаётся защитой от выгрузки всей базы, а не
            // рабочей отсечкой. Сообщить об обрезке в ответе слайс не может:
            // он отдаёт строки, и места под признак в контракте нет — поэтому
            // единственная честная настройка та, при которой обрезки не бывает.
            List.of(), Map.of(), " ORDER BY date_created DESC, decision_id");

        // Decisions that belong to one ADR (in('DECIDED_IN') from the ADR side).
        slice("decisions_of_adr",
            "SELECT decision_id, title, date_created, status_raw, out('BELONGS_TO').component_id[0] AS component_id, " +
            "out('BELONGS_TO').component_id AS components, " +
            "out('BELONGS_TO_PROJECT').slug AS projects, " +
            "out('TAGGED_WITH').tag_id AS tags " +
            // AL-120 (20.10.2026): ORDER BY — в suffix. В теле он стоял ПЕРЕД
            // условием скоупа («… ORDER BY decision_id AND (…)»), и под
            // включённым lore.scope.enforce срез отвечал 502 — паспорт ADR
            // ломался у всех, кроме superadmin. Найдено живым тестом под флагом.
            // SE-05 (20.10.2026): CONTAINS, а не [0] = — решение под двумя ADR
            // (совместные ADR — замысел владелицы) было видно в паспорте только
            // того родителя, что оказался первым. Тест — на ДВУХ родителях
            // (DecisionUnderTwoAdrsLiveDbTest): на одном формы неразличимы.
            "FROM KnowDecision WHERE out('DECIDED_IN').adr_id CONTAINS :id",
            List.of("id"), Map.of(), " ORDER BY decision_id");

        slice("decision",
            // AL-79: status_raw в паспорте — раньше статус был виден в списках,
            // но не в карточке одного решения.
            "SELECT decision_id, title, date_created, status_raw, " +
            "body_md, rationale_md, refs_raw, " +
            // MDL-08 ч.2 (владелица 20.11.2026: «refs … пересадить на связи»): ссылки — по связям, а не полями-строками.
            // ADR — родитель (DECIDED_IN) и упомянутые (REFERENCES); спринты, PR, релизы — REFERENCES. Выражения те же,
            // что исполняет сверка переноса (scripts/model-migration/rules/decision-refs.json; сторож DecisionRefsPassportTest).
            "unionall(out('DECIDED_IN').adr_id, out('REFERENCES')[@this INSTANCEOF 'KnowADR'].adr_id) AS adr_refs, " +
            "out('REFERENCES')[@this INSTANCEOF 'KnowSprint'].sprint_id AS sprint_refs, " +
            "out('REFERENCES')[@this INSTANCEOF 'KnowPR'].pr_uid AS pr_refs, " +
            "out('REFERENCES')[@this INSTANCEOF 'KnowRelease'].release_id AS release_refs, " +
            // Проект и компоненты в карточке. Их не было ни здесь, ни в
            // списочном срезе после его обрезки — то есть принадлежность
            // решения проекту НЕ ЧИТАЛАСЬ ничем: записать можно, проверить
            // нечем. Это та же беда, что «карточка есть, а пути до неё нет»,
            // только со стороны чтения, и замечалась она лишь задним числом на
            // доске «что изменилось». Поля те же, что в списке, — карточка и
            // список обязаны говорить об одном одинаково.
            "out('BELONGS_TO_PROJECT').slug AS projects, " +
            "out('BELONGS_TO').component_id AS components, " +
            "out('BELONGS_TO').component_id[0] AS component_id, " +
            "out('DECIDED_IN').adr_id[0] AS parent_adr, " +
            "out('TAGGED_WITH').tag_id AS tags, " +
            "out('SUPERSEDES').decision_id AS supersedes_ids, " +
            // S4-29 v3 (44а): вкладка «Вопросы» паспорта решения — на какие вопросы оно отвечает.
            "out('ANSWERS').question_id AS answers_ids, " +
            // 11.11 (полнота модели рёбер): кем заменено и сценарии, обоснованные решением.
            "in('SUPERSEDES').decision_id AS superseded_by_ids, " +
            "in('TRACED_TO').uc_id AS traced_by_ucs " +
            "FROM KnowDecision WHERE decision_id = :id",
            List.of("id"), Map.of(), "");

        // ── ADR-LORE-018 T21: files referenced (EDITED_IN) by a task ──────────
        // Returns the project's hosts[]/default_branch alongside, so the client
        // composes file URLs (+ "open in mirror") in one fetch, no second call.
        slice("files_of_task",
            "SELECT project, file_path, summary_md, " +
            "out('BELONGS_TO_PROJECT').hosts[0]          AS project_hosts, " +
            "out('BELONGS_TO_PROJECT').default_branch[0] AS project_default_branch " +
            "FROM KnowFile WHERE out('EDITED_IN').task_uid CONTAINS :id ORDER BY file_path",
            List.of("id"), Map.of(), "");

        // ── Роли на задаче ребром (ADR-LORE-042, TR-04) ──────────────────────
        // Держатель роли — ребро с открытым valid_to, как открытая строка
        // истории у самой задачи. Личность приходит из вершины на другом
        // конце, и ключ у неё ОДИН: человек и агент отвечают на один и тот же
        // вопрос «кто», и разводить их двумя ключами значило бы заставить
        // каждого читателя склеивать их заново — по-своему и с ошибками.
        //
        // Чем это отличается от полей author/executor/reviewer_agent, которые
        // пока живут рядом: поле отвечало только на «кто сейчас». Вопрос
        // «сколько раз передавали» был неотвечаем в принципе, потому что
        // прежнее значение затиралось.
        slice("task_roles",
            "SELECT role, ifnull(@in.actor_id, @in.display_name) AS identity, "
            + "profile, model, verdict, feedback_md, reviewed_at, valid_from "
            + "FROM ROLE_HELD_BY WHERE @out.task_uid = :id AND valid_to IS NULL",
            List.of("id"), Map.of(), " ORDER BY role");

        // Тот же набор, но ВСЕ рёбра, включая закрытые. Отдельным срезом, а не
        // флагом: «кто держит роль сейчас» спрашивают на каждом экране задачи,
        // а «кто держал раньше» — редко и осознанно. Слить их в один срез
        // значило бы показывать снятых держателей там, где ждут текущего.
        slice("task_roles_history",
            "SELECT role, ifnull(@in.actor_id, @in.display_name) AS identity, "
            + "profile, model, verdict, feedback_md, reviewed_at, valid_from, valid_to "
            + "FROM ROLE_HELD_BY WHERE @out.task_uid = :id",
            List.of("id"), Map.of(), " ORDER BY valid_from DESC");

        // SPRINT_LORE_AGENT_OBSERVABILITY/AO-06: покрытие ролей профилем по ВСЕМУ корпусу.
        // task_roles отдаёт profile только для одной задачи — «сколько ролей сегодня несут
        // профиль» было неотвечаемо, и улучшение нечем было измерить ни до, ни после.
        // Сырые группы (role, profile, n) — свёртку делает читатель; profile = null и есть
        // непокрытое. Только открытые роли: закрытые описывают прошлое, а не «сегодня».
        slice("role_profile_coverage",
            "SELECT role, profile, count(*) AS n FROM ROLE_HELD_BY WHERE valid_to IS NULL",
            List.of(), Map.of(), " GROUP BY role, profile ORDER BY role");

        // ── ADR-020/021 T25: open-questions register (ОВ) ─────────────────────
        // Derived overdue/blocking/age are computed on the client from the raw
        // fields (status/due_date + gating_tasks) — never stored.
        //
        // decision:D-2026-LORE-QUESTIONS-SLICE-RENAME (06.11.2026): срез звался
        // open_questions, а отдавал ВСЕ вопросы — 126 из 244 строк закрыты, и
        // потребители MCP читали закрытые как открытые. Владелица: «переназовите
        // просто вопросы и группируйте по статусу». Теперь `questions`, группы
        // open · deferred · closed · dropped (ранг — CASE, замерено на проде
        // 06.11: ArcadeDB сортирует по псевдониму), `open_questions` — синоним
        // на переход для UI, MCP и miniLORE. Неизвестный статус — в конец (4),
        // а не молча в середину.
        for (String questionsId : List.of("questions", "open_questions"))
        slice(questionsId,
            // `trigger` В ОБРАТНЫХ КАВЫЧКАХ — зарезервированное слово SQL ArcadeDB
            // (голое имя даёт CommandSQLParsingException, тот же капкан, что в
            // write-path LoreQuestionResource).
            // Поле выдаётся, потому что по ADR-LORE-021-D3 условие возврата — это
            // ВЕСЬ смысл deferred: без него отложенный вопрос неотличим от
            // забытого, и реестр гниёт в свалку отложенного.
            // MT-MCP-TRUTH A6: ответственный — по ребру ANSWERABLE_BY, без ребра — прежний текст (QuestionOwner).
            "SELECT question_id, title, body_md, status, `trigger`, out('BELONGS_TO').component_id[0] AS component_id, due_date, priority, " +
            QuestionOwner.OWNER_COLUMNS + ", " +
            "raised_by, opened_date, closed_date, " +
            // Свежесть (вопрос №49): SCD2 у вопроса нет — последнее известное изменение
            // это закрытие, иначе заведение.
            // S4-MODEL-TYPES: пути записи ставят updated_at (момент) — максимум с днём в LoreChangedAt.
            changedAtSql("closed_date", "opened_date") + ", " +
            "out('BELONGS_TO').component_id AS components, " +
            "out('BELONGS_TO_PROJECT').slug AS projects, " +
            "out('GATES').task_uid      AS gating_tasks, " +
            "out('RAISED_IN').adr_id    AS raised_adr, " +
            "out('RAISED_IN').sprint_id AS raised_sprint, " +
            "in('ANSWERS').decision_id  AS answered_by, " +
            "CASE status WHEN 'open' THEN 0 WHEN 'deferred' THEN 1 WHEN 'closed' THEN 2 " +
            "WHEN 'dropped' THEN 3 ELSE 4 END AS status_rank " +
            "FROM KnowQuestion",
            List.of(), Map.of(), " ORDER BY status_rank, question_id");


        // SPRINT_LORE_MEASURE_TRUTH/MT-MCP-TRUTH A4 · A8 · A10 (06.11.2026): гигиена
        // вопросов — сырые факты по открытым и отложенным. decision_candidates —
        // решения, чьи refs_raw упоминают id вопроса (решение есть, связи answers нет);
        // trigger отложенных на виду (A8); raised_sprint_status — вопрос в закрытом
        // спринте или ни в каком (A10).
        // БЕЗ ORDER BY — намеренно: замер прода 06.11 — с ORDER BY ArcadeDB теряет
        // корреляцию $parent.$current в LET, условие вырождается в LIKE '%%', и
        // каждому вопросу приписываются все решения (186/186). Без него — 35/204.
        // LIMIT и условие скоупа корреляцию не ломают. Сортирует потребитель.
        slice("question_hygiene",
            "SELECT question_id, title, status, " + QuestionOwner.OWNER_COLUMNS + ", priority, due_date, `trigger`, opened_date, " +
            "out('RAISED_IN').sprint_id AS raised_sprints, " +
            "out('RAISED_IN')[@type='KnowSprint'].out('HAS_STATE')[valid_to IS NULL].status_raw AS raised_sprint_status, " +
            "$d.decision_id AS decision_candidates " +
            "FROM KnowQuestion " +
            "LET $d = (SELECT decision_id FROM KnowDecision WHERE refs_raw LIKE ('%' + $parent.$current.question_id + '%')) " +
            "WHERE status IN ['open', 'deferred']",
            List.of(), Map.of(), "");

        // Адресные формы по id (SL-01, запрос сессии miniLORE через владельца).
        //
        // Шлюз miniLORE открывает записи по идентификатору. У сценариев адресной
        // формы не было ВООБЩЕ — только окрестности (`tasks_of_uc`, `uc_actors`),
        // то есть открыть сам сценарий было нечем.
        //
        // У вопросов форма как бы была — `open_questions`, — но она по построению
        // теряет закрытые и отложенные. Фильтровать её на стороне вызывающего
        // нельзя: того, чего в выдаче нет, не отфильтруешь, и «вопрос не найден»
        // означало бы «вопрос закрыт». Поэтому здесь БЕЗ фильтра по статусу.
        slice("uc_by_id",
            "SELECT uc_id, title, body_md, context_md, scenario_md, acceptance_md, " +
            "status, goal_level, rigor, priority, date_created, shipped_at, parent_uc_id, " +
            "out('BELONGS_TO').component_id[0] AS component_id, " +
            "out('BELONGS_TO').component_id    AS component_ids, " +
            "out('BELONGS_TO_PROJECT').slug    AS projects, " +
            "out('DECOMPOSES_INTO').uc_id      AS child_uc_ids, " +
            "in('DECOMPOSES_INTO').uc_id       AS parent_uc_ids, " +
            "out('HAS_ACTOR').actor_id         AS actor_ids, " +
            "out('ADDRESSES').pain_id          AS pain_ids, " +
            "out('PROMISES').gain_id           AS gain_ids, " +
            "out('HELPS_WITH').job_id          AS job_ids, " +
            "in('REALIZES').task_uid           AS task_uids, " +
            // 11.11 (полнота модели рёбер): что сценарий делает, обоснование, вехи, граф сценариев.
            "out('RELIEVES').pain_id           AS relieved_pain_ids, " +
            "out('DELIVERS').gain_id           AS delivered_gain_ids, " +
            "out('PERFORMS').job_id            AS performed_job_ids, " +
            "out('TRACED_TO')[@this INSTANCEOF 'KnowADR'].adr_id           AS traced_adrs, " +
            "out('TRACED_TO')[@this INSTANCEOF 'KnowDecision'].decision_id AS traced_decisions, " +
            "outE('TARGETS_MILESTONE')[valid_to IS NULL].inV().milestone_id AS milestone_ids, " +
            "out('BUILDS_ON').uc_id            AS builds_on_ids, " +
            "in('BUILDS_ON').uc_id             AS built_on_by_ids, " +
            "out('UC_INCLUDES').uc_id          AS includes_ids, " +
            "in('UC_INCLUDES').uc_id           AS included_by_ids, " +
            "out('UC_EXTENDS').uc_id           AS extends_ids, " +
            "in('UC_EXTENDS').uc_id            AS extended_by_ids " +
            "FROM KnowUseCase WHERE uc_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");

        slice("question_by_id",
            "SELECT question_id, title, body_md, status, `trigger`, due_date, priority, " + QuestionOwner.OWNER_COLUMNS + ", " +
            "raised_by, opened_date, closed_date, " +
            "out('BELONGS_TO').component_id[0] AS component_id, " +
            "out('BELONGS_TO').component_id    AS components, " +
            "out('BELONGS_TO_PROJECT').slug    AS projects, " +
            "out('GATES').task_uid             AS gating_tasks, " +
            "out('RAISED_IN').adr_id           AS raised_adr, " +
            "out('RAISED_IN').sprint_id        AS raised_sprint, " +
            "in('ANSWERS').decision_id         AS answered_by " +
            "FROM KnowQuestion WHERE question_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");
        slice("questions_of_adr",
            "SELECT question_id, title, status, out('BELONGS_TO').component_id[0] AS component_id, due_date, priority, " +
            "out('BELONGS_TO').component_id AS components, " +
            "out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowQuestion WHERE out('RAISED_IN').adr_id CONTAINS :id ORDER BY question_id",
            List.of("id"), Map.of(), "");

        // ── lore.record/1 (ADR-LORE-047, SPEC-LORE-UXR-RECORD-CONTRACT 0.3) ──
        // Части паспорта, которых не было срезом: вопросы задачи (RAISED_IN →
        // задача, aggregation), задачи по ADR и ADR задачи (JUSTIFIED_BY,
        // realization). Форма строк — как у соседних *_of_adr.
        slice("questions_of_task",
            "SELECT question_id, title, status, out('BELONGS_TO').component_id[0] AS component_id, due_date, priority, " +
            "out('BELONGS_TO').component_id AS components, " +
            "out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowQuestion WHERE out('RAISED_IN').task_uid CONTAINS :id",
            List.of("id"), Map.of(), " ORDER BY question_id");

        // S4-24 (SPRINT_UXR_S4_UI_SHELL_LISTS/S4-24): выпадающий список автора/исполнителя/
        // принимающего. SQL отдаёт только задачу под скоупом и её проекты; строки {code, title,
        // kind} собирает TaskRoleService.identitiesOfTask теми же методами, что проверяет запись
        // роли (TR-05), — в AidaLoreResource. Нет задачи / нет проекта — ошибка, не пустой список.
        // MC-05 (SPEC-LORE-MODEL-CONFIG-STORE §5): история версий модели — без тела (тело — GET /lore/model/config/{state_uid}).
        slice("model_config_history",
            "SELECT state_uid, valid_from, valid_to, content_hash, reason, changed_by, changed_by_kind " +
            "FROM KnowModelConfigHist WHERE in('HAS_STATE').config_id CONTAINS 'lore-model'",
            List.of(), Map.of(), " ORDER BY valid_from DESC");

        // PU-17 шаг 3: сухой прогон «перенос потерял роли» — только чтение, свёртка LoreRolesLostOnMove.fold.
        slice(LoreRolesLostOnMove.SLICE, LoreRolesLostOnMove.SQL, List.of(), Map.of(), "");

        slice(LoreTaskIdentities.SLICE,
            "SELECT task_uid, out('PART_OF').out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowTask WHERE task_uid = :id",
            List.of("id"), Map.of(), " LIMIT 1");

        slice("tasks_of_adr",
            "SELECT task_uid, task_id, title, out('PART_OF').sprint_id[0] AS sprint_id, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, task_type, work_class " +
            "FROM KnowTask WHERE out('JUSTIFIED_BY').adr_id CONTAINS :id",
            List.of("id"), Map.of(), " ORDER BY task_uid");

        slice("adrs_of_task",
            "SELECT adr_id, name, status, date_created " +
            "FROM KnowADR WHERE in('JUSTIFIED_BY').task_uid CONTAINS :id",
            List.of("id"), Map.of(), " ORDER BY adr_id");

        // D-2026-LORE-SPRINT-CLOSE-NEEDS-TASKS-CLOSED: сторож закрытия (SprintCloseGuard)
        // не трогает уже закрытые спринты — этот срез их перечисляет. Закрытый спринт —
        // открытая строка истории done/cancelled; открытая задача — ни done, ни cancelled.
        // Фазы тоже PART_OF спринта, поэтому дети фильтруются по типу.
        slice("closed_sprints_with_open_tasks",
            "SELECT sprint_id, coalesce(title, name) AS name, out('HAS_STATE')[valid_to IS NULL].status_raw[0] AS status_raw, " +
            "in('PART_OF')[@type = 'KnowTask'].task_uid AS task_uids, " +
            "in('PART_OF')[@type = 'KnowTask'].out('HAS_STATE')[valid_to IS NULL].status_raw AS task_statuses " +
            "FROM KnowSprint WHERE out('HAS_STATE')[valid_to IS NULL AND (" +
            LoreStatusVocabulary.anySql("status_raw", "done", "cancelled") + ")].size() > 0 " +
            "AND in('PART_OF')[@type = 'KnowTask'].out('HAS_STATE')[valid_to IS NULL AND " +
            LoreStatusVocabulary.noneSql("status_raw", "done", "cancelled") + "].size() > 0",
            List.of(), Map.of(), " ORDER BY sprint_id");

        slice("questions_of_sprint",
            "SELECT question_id, title, status, out('BELONGS_TO').component_id[0] AS component_id, due_date, priority, out('BELONGS_TO').component_id AS components " +
            "FROM KnowQuestion WHERE out('RAISED_IN').sprint_id CONTAINS :id ORDER BY question_id",
            List.of("id"), Map.of(), "");

        // SPRINT_QG_REBUILD/QG-16, проверка 5 (предложение координатора, переслано владелицей
        // 06.11): открытый вопрос держит (GATES) задачу, которая уже закрыта. Механизм gates
        // задуман самоочищающимся, но связь при закрытии задачи не снимается — вопрос
        // числится блокером того, что уже сделано (замер 06.11: минимум 8, среди них blocker).
        slice("questions_gating_closed_tasks",
            "SELECT question_id, title, status, priority, " + QuestionOwner.OWNER_COLUMNS + ", " +
            "out('GATES')[out('HAS_STATE')[valid_to IS NULL AND (" +
                LoreStatusVocabulary.anySql("status_raw", "done", "cancelled") +
            ")].size() > 0].task_uid AS closed_tasks, " +
            "out('GATES').task_uid AS gated_tasks " +
            "FROM KnowQuestion WHERE status <> 'closed' AND out('GATES')[out('HAS_STATE')[valid_to IS NULL AND (" +
                LoreStatusVocabulary.anySql("status_raw", "done", "cancelled") +
            ")].size() > 0].size() > 0",
            List.of(), Map.of(), " ORDER BY question_id");

        slice("gating_questions_of_task",
            "SELECT question_id, title, status, priority " +
            // QG-17: решённая связь (solved_at — задача уже закрыта) больше не блокер.
            "FROM KnowQuestion WHERE outE('GATES')[solved_at IS NULL].inV().task_uid CONTAINS :id AND status <> 'closed' ORDER BY question_id",
            List.of("id"), Map.of(), "");

        // ── §3 Sprints ───────────────────────────────────────────────────────
        // [field IS NOT NULL] filter: skip sparse hist entries where field absent
        slice("sprints",
            "SELECT sprint_id, coalesce(title, name) AS name, created_date, no_release_required, unplanned_intentional, " +
            changedAtSql("created_date") + ", " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].priority[0], out('HAS_STATE')[priority IS NOT NULL].priority[0])     AS priority, " +
            "out('HAS_STATE')[valid_from IS NOT NULL].valid_from[0] AS valid_from, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].pr_refs[0], out('HAS_STATE')[pr_refs IS NOT NULL].pr_refs[0])       AS pr_refs, " +
            "out('IMPLEMENTED_IN_RELEASE').release_id   AS release_ids, " +
            "out('IMPLEMENTED_IN_RELEASE').release_uid AS release_uids, " +
            "out('IMPLEMENTED_IN_RELEASE').release_date AS release_dates, " +
            DONE_DATE_SQL + " AS done_date, " +
            "out('BELONGS_TO_PROJECT').slug             AS git_projects, " +
            "out('BELONGS_TO')[component_id IS NOT NULL].component_id AS components, " +
            "outE('TARGETS_MILESTONE')[valid_to IS NULL].inV().milestone_id AS milestone_ids, " +
            // SPRINT_PLANITEM_RETIRE: planned_start_date/planned_end_date/track_id
            // are plain SCD2-tracked fields on KnowSprintHist (set via
            // /lore/sprint/plan) — no more PlanItem hop. planned_milestone_id
            // retired (drifted vs. milestone_ids above on 62+ sprints) — the
            // TARGETS_MILESTONE edge is the sole source of truth now.
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].planned_start_date[0], out('HAS_STATE')[planned_start_date IS NOT NULL].planned_start_date[0])     AS planned_start_date, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].planned_end_date[0], out('HAS_STATE')[planned_end_date IS NOT NULL].planned_end_date[0])         AS planned_end_date, " +
            // MDL-13 «треки б»: трек — ребро ON_TRACK (KnowTrack), без ребра — прежняя строка версии (старая схема).
            SprintTrack.COLUMNS + ", " +
            // MIG-03: в новой схеме тексты спринта живут в версии; открытая версия, иначе запись (старая схема)
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].context_md[0], context_md) AS context_md " +
            "FROM KnowSprint",
            List.of(),
            // ADR-LORE-017 (T16): optional `project` filter — Tier 1 (Sprint has a direct
            // BELONGS_TO_PROJECT edge) read-scoping.
            //
            // Прежнее ограничение СНЯТО (2026-07-21): compose() больше не
            // склеивает фрагменты встык, а нормализует связку (WHERE для
            // первого условия, AND для последующих). status и project можно
            // передавать вместе — до этого такая пара давала 500.
            new LinkedHashMap<>(Map.of(
                "status", " WHERE COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) LIKE :status",
                "project", " WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project")),
            " ORDER BY sprint_id");

        slice("sprint_tree",
            "SELECT sprint_id, coalesce(title, name) AS name, COALESCE(out('HAS_STATE')[valid_to IS NULL].context_md[0], context_md) AS context_md, COALESCE(out('HAS_STATE')[valid_to IS NULL].outcome_md[0], outcome_md) AS outcome_md, created_date, no_release_required, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].pr_refs[0], out('HAS_STATE')[pr_refs IS NOT NULL].pr_refs[0])       AS pr_refs, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].priority[0], out('HAS_STATE')[priority IS NOT NULL].priority[0])     AS priority, " +
            "out('IMPLEMENTED_IN_RELEASE').release_id              AS release_ids, " +
            "out('IMPLEMENTED_IN_RELEASE').release_uid AS release_uids, " +
            "outE('TARGETS_MILESTONE')[valid_to IS NULL].inV().milestone_id AS milestone_ids, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].planned_start_date[0], out('HAS_STATE')[planned_start_date IS NOT NULL].planned_start_date[0])     AS planned_start_date, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].planned_end_date[0], out('HAS_STATE')[planned_end_date IS NOT NULL].planned_end_date[0])         AS planned_end_date, " +
            "outE('DEPENDS_ON')[valid_to IS NULL].inV().sprint_id AS depends_on, " +
            "inE('DEPENDS_ON')[valid_to IS NULL].outV().sprint_id AS blocks, " +
            "out('BELONGS_TO').component_id AS components, " +
            "out('BELONGS_TO_PROJECT').slug AS git_projects, " +
            // reverse of ADR's IMPLEMENTED_IN (ADR → Sprint) — which ADRs this
            // sprint implements. Was missing entirely; sprint detail had no way
            // to surface the link even though adr_link(rel:"sprint") has always
            // been able to create it.
            "in('IMPLEMENTED_IN').adr_id   AS adr_ids, " +
            // 11.11 (полнота модели рёбер): документы, реализованные в спринте (doc_link rel:sprint).
            "in('IMPLEMENTED_IN').doc_id   AS doc_ids, " +
            // MDL-13: трек — по ребру ON_TRACK, без ребра — прежняя строка версии.
            SprintTrack.COLUMNS + " " +
            "FROM KnowSprint WHERE sprint_id = :id",
            List.of("id"), Map.of(), "");

        // Sprint dependency graph — all DEPENDS_ON edges with metadata
        slice("sprint_deps",
            "SELECT @out.sprint_id AS from_sprint, @in.sprint_id AS to_sprint, kind, reason " +
            "FROM DEPENDS_ON WHERE @out.sprint_id IS NOT NULL AND @in.sprint_id IS NOT NULL AND valid_to IS NULL",
            List.of(), Map.of(), "");

        // Focused dep view for a single sprint (depends_on + blocks)
        slice("sprint_deps_of",
            "SELECT outE('DEPENDS_ON')[valid_to IS NULL].inV().sprint_id AS depends_on, " +
            "inE('DEPENDS_ON')[valid_to IS NULL].outV().sprint_id AS blocks " +
            "FROM KnowSprint WHERE sprint_id = :id",
            List.of("id"), Map.of(), "");

        // SPRINT_LORE_MODEL_DOCS_TIDY/MDL-13: одна связь «зависит от» между задачей, фазой, спринтом и вехой.
        // Все текущие зависимости планирования (ADR → ADR — та же связь, но не планирование, сюда не входит);
        // закрытые рёбра — история. type — строки, где этот тип на любом конце; kind — вид.
        slice("deps",
            "SELECT " + LoreDependency.typeSql("@out") + " AS from_type, " + LoreDependency.idSql("@out") + " AS from_id, " +
            LoreDependency.titleSql("@out") + " AS from_title, " +
            LoreDependency.typeSql("@in") + " AS to_type, " + LoreDependency.idSql("@in") + " AS to_id, " +
            LoreDependency.titleSql("@in") + " AS to_title, kind, reason, valid_from " +
            "FROM DEPENDS_ON WHERE valid_to IS NULL AND " + LoreDependency.planningSql(),
            List.of(), new LinkedHashMap<>(Map.of(
                "type", " AND (" + LoreDependency.typeSql("@out") + " = :type OR " + LoreDependency.typeSql("@in") + " = :type)",
                "kind", " AND kind = :kind")),
            " ORDER BY from_type, from_id, to_type, to_id");

        // Зависимости одной записи любого из четырёх типов: dir out — «зависит от» другого конца,
        // dir in — другой конец зависит от неё. other_* — другой конец.
        slice("deps_of",
            "SELECT CASE WHEN " + depsSelf("@out") + " THEN 'out' ELSE 'in' END AS dir, " +
            "CASE WHEN " + depsSelf("@out") + " THEN " + LoreDependency.typeSql("@in") + " ELSE " + LoreDependency.typeSql("@out") + " END AS other_type, " +
            "CASE WHEN " + depsSelf("@out") + " THEN " + LoreDependency.idSql("@in") + " ELSE " + LoreDependency.idSql("@out") + " END AS other_id, " +
            "CASE WHEN " + depsSelf("@out") + " THEN " + LoreDependency.titleSql("@in") + " ELSE " + LoreDependency.titleSql("@out") + " END AS other_title, " +
            "kind, reason, valid_from " +
            "FROM DEPENDS_ON WHERE valid_to IS NULL AND " + LoreDependency.planningSql() +
            " AND (" + depsSelf("@out") + " OR " + depsSelf("@in") + ")",
            List.of("type", "id"), Map.of(), " ORDER BY dir DESC, other_type, other_id");

        // Actual completion dates: valid_from of the first hist entry whose status
        // starts with a done marker. Prefix match avoids false positives from TODO
        // statuses that mention DONE in parentheses ("⬜ TODO — (V1 ✅ DONE…)") —
        // см. DONE_STATUS_SQL про то, почему якорь, а не подстрока.
        slice("sprint_done_dates",
            "SELECT sprint_id, " +
            DONE_DATE_SQL + " AS done_date " +
            "FROM KnowSprint " +
            // MT-MCP-TRUTH Б1: закрыт тот, чья ОТКРЫТАЯ версия в DONE, а не тот, у кого DONE был когда-то
            "WHERE " + OPEN_DONE_SQL + ".size() > 0",
            List.of(), Map.of(), "");

        // Phases of a sprint (via PART_OF edges from phases). The phase title is
        // carried in KnowPhaseHist.status_raw; the latest ingest (4f032cd) left it
        // on the older hist row, so use a [field IS NOT NULL] traversal to recover it.
        slice("phases_of_sprint",
            "SELECT phase_uid, phase_id, order_index, " +
            "out('HAS_STATE')[valid_from IS NOT NULL].valid_from[0]  AS valid_from, " +
            // PU-22: название фазы — из вершины (title, у записанных phase_new — name); статус своим
            // полем. Раньше здесь стояло status_raw AS title, и любое название подменялось «📋 PLANNED».
            "coalesce(title, name) AS title, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0])  AS status_raw, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].summary_md[0], out('HAS_STATE')[summary_md IS NOT NULL].summary_md[0])  AS summary_md " +
            "FROM KnowPhase WHERE out('PART_OF').sprint_id[0] = :sprint_id " +
            "ORDER BY order_index",
            List.of("sprint_id"), Map.of(), "");

        // Tasks of a phase
        slice("tasks_of_phase",
            "SELECT task_uid, task_id, title, order_index, " +
            "out('HAS_STATE').effort_days[0] AS effort_days, " +
            "out('HAS_STATE').commit_refs[0] AS commit_refs, " +
            // sparse: a later status flip inserts a note-less open row, so recover the
            // note from whichever hist row carries it — same form as tasks_of_sprint.
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].note_md[0], out('HAS_STATE')[note_md IS NOT NULL].note_md[0]) AS note_md, " +
            "out('TAGGED_WITH').component_id AS component_ids, " +
            // author/executor/reviewer_agent (ADR-LORE-014 §4) and task_type
            // (ADR-LORE-015, T14) are plain KnowTask vertex fields — no traversal
            // needed, unlike note_md/effort_days above.
            ROLE_HOLDERS + ", task_type " +
            // SE-05 (20.10.2026): CONTAINS, а не [0] =. Модель допускает задачу
            // в нескольких фазах — task/phase add не снимает прежнюю, а remove
            // без фазы описан как «отцепить от ВСЕХ». С [0] такая задача была
            // видна только в одной фазе, какой придётся (TaskInTwoPhasesLiveDbTest).
            "FROM KnowTask WHERE outE('IN_PHASE')[valid_to IS NULL].inV().phase_uid CONTAINS :phase_uid " +
            "ORDER BY order_index",
            List.of("phase_uid"), Map.of(), "");

        // All tasks of a sprint, directly via PART_OF (covers tasks not bound to a
        // phase — every KnowTask has PART_OF→Sprint, only some have IN_PHASE→Phase).
        // phase_uid is carried so the client can group by phase when present.
        slice("tasks_of_sprint",
            "SELECT task_uid, task_id, title, order_index, " +
            "outE('IN_PHASE')[valid_to IS NULL].inV().phase_uid[0]                            AS phase_uid, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0])   AS status_raw, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].effort_days[0], out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0]) AS effort_days, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].note_md[0], out('HAS_STATE')[note_md IS NOT NULL].note_md[0])         AS note_md, " +
            "out('TAGGED_WITH').component_id                          AS component_ids, " +
            // author/executor/reviewer_agent (ADR-LORE-014 §4) and task_type
            // (ADR-LORE-015, T14) — plain vertex fields.
            ROLE_HOLDERS + ", task_type, " +
            // ADR-LORE-022: ЗАЧЕМ-ось + какой UC задача реализует (REALIZES).
            "actual_days, bookkeeping, " +
            "work_class, out('REALIZES').uc_id AS realizes_uc, " +
            // PU-07 (приёмка 0dccfe73): релиз задачи — релиз её PR, а не спринта; вложенная
            // таблица под строкой спринта брала релиз родителя (сторож TaskReleaseColumnTest).
            TASK_RELEASES_SQL + ", " +
            // PU-23 (14.11.2026): колонка «Изменено» во вложенной таблице задач спринта —
            // свежесть та же, что у open_tasks/closed_tasks (S4-04).
            changedAtSql(FIRST_STATE_FROM_SQL) + " " +
            "FROM KnowTask WHERE out('PART_OF').sprint_id[0] = :sprint_id " +
            "ORDER BY order_index",
            List.of("sprint_id"), Map.of(), "");

        // ── ADR-LORE-022: продуктовый слой ───────────────────────────────────
        // PL-28 (решение №141): тип ОДИН — KnowUseCase с само-иерархией.
        // «Фича» больше не отдельная сущность, а КОРНЕВОЙ сценарий: тот же
        // вопрос «какую пользовательскую цель закрываем», только на верхнем
        // уровне шкалы Коберна. Разделяет их goal_level: ☁ cloud / 🪁 kite —
        // корни, 🌊 sea-level / 🐟 subfunction — сценарии внутри.
        //
        // Имя слайса оставлено прежним намеренно: раздел UI называется «Фичи»,
        // и переименование слайса сломало бы потребителей ради косметики.
        // Отдаётся, однако, честный uc_id — алиас feature_id не вводим, иначе
        // слияние типов существовало бы только в схеме.
        //
        // «Фича целиком» — вычисляемый факт (D4): shipped ⇔ все дочерние shipped.
        // Слайс отдаёт счётчики, вывод статуса — на клиенте/потребителе.
        slice("features",
            "SELECT uc_id, title, body_md, context_md, status, out('BELONGS_TO').component_id[0] AS component_id, date_created, " +
            "goal_level, shipped_at, parent_uc_id, " +
            // Свежесть (S4-MODEL-TYPES): тот же источник, что у use_cases.
            changedAtSql("shipped_at", "date_created") + ", " +
            // PL-10: компоненты и проекты — рёбрами, а не плоским component_id.
            // Плоское поле не давало ни множественности, ни проектной оси.
            "out('BELONGS_TO').component_id      AS component_ids, " +
            "out('BELONGS_TO_PROJECT').slug     AS projects, " +
            "out('DECOMPOSES_INTO').uc_id AS uc_ids, " +
            "out('DECOMPOSES_INTO').size() AS uc_total, " +
            "out('DECOMPOSES_INTO')[status = 'shipped'].size() AS uc_shipped, " +
            // VP-профиль корня (ADR-032 D5): что он ЗАЯВЛЯЕТ (ADDRESSES/PROMISES/
            // HELPS_WITH). Пары рёбер сохранены при слиянии типов
            // (ADR-LORE-022-D20): «заявлено vs доставлено» — характер утверждения,
            // а не уровень узла, поэтому корень вправе нести и то, и другое.
            "out('ADDRESSES').pain_id AS pain_ids, " +
            "out('PROMISES').gain_id  AS gain_ids, " +
            "out('HELPS_WITH').job_id AS job_ids, " + // Остервальдер: третья ось профиля
            // AN-09 (D-2026-LORE-FEATURE-BUILDS-ON-EDGE): линейка — обе стороны ребра,
            // чтобы граф строился без второго запроса.
            "out('BUILDS_ON').uc_id AS builds_on_ids, " +
            "in('BUILDS_ON').uc_id AS enables_ids, " +
            "outE('TARGETS_MILESTONE')[valid_to IS NULL].inV().milestone_id[0] AS milestone_id " +
            // Корень = верхние уровни шкалы. Узлы без goal_level сюда не попадают
            // и не теряются: их видно линтером качества (goal_level обязателен).
            "FROM KnowUseCase WHERE goal_level IN ['cloud', 'kite']",
            List.of(),
            new LinkedHashMap<>(Map.of(
                // PL-19: фильтр по РЕБРУ, а не по плоскому component_id. С PL-10
                // привязка живёт на BELONGS_TO, и сравнение с полем прятало
                // записи, привязанные ребром: фильтр отдавал пусто, и это
                // читалось как «у компонента нет корней».
                // CONTAINS, а не [0]: привязок может быть несколько, а порядок
                // рёбер — это порядок вставки, не приоритет (AKI).
                "component", " AND out('BELONGS_TO').component_id CONTAINS :component")),
            " ORDER BY uc_id");

        // PL-19: «Сценарии компонента» — ВСЕ уровни, а не только корни.
        //
        // Отдельный слайс, а не параметр у `features`: тот по построению режет
        // выдачу до cloud|kite, и вкладка компонента показывала бы корни без
        // сценариев, которыми они сделаны — половину ответа на вопрос «что этот
        // компонент закрывает».
        slice("use_cases_of_component",
            "SELECT uc_id, title, status, goal_level, rigor, parent_uc_id, " +
            "out('BELONGS_TO').component_id AS component_ids, " +
            "in('REALIZES').task_uid        AS task_uids " +
            "FROM KnowUseCase WHERE out('BELONGS_TO').component_id CONTAINS :component " +
            "ORDER BY goal_level, uc_id",
            List.of("component"), Map.of(), "");

        // S4-V2-SECTIONS, «US разделом»: ВСЕ уровни шкалы, без обязательного параметра.
        // `features` режет выдачу до корней (cloud|kite), `use_cases_of_component` требует
        // компонент — раздела «все сценарии» собрать было не из чего. Тел нет: список
        // несёт заголовки, тело — в паспорте (/lore/record/feature/<uc_id>).
        slice("use_cases",
            "SELECT uc_id, title, status, goal_level, rigor, priority, parent_uc_id, date_created, shipped_at, " +
            // Свежесть (вопрос №49): SCD2 у сценария нет — последнее известное изменение
            // это поставка (shipped_at ставит система), иначе заведение.
            // S4-MODEL-TYPES: пути записи ставят updated_at (момент) — максимум с днём в LoreChangedAt.
            changedAtSql("shipped_at", "date_created") + ", " +
            "out('BELONGS_TO').component_id AS component_ids, " +
            "out('BELONGS_TO_PROJECT').slug AS projects, " +
            // Просьба kit: у детей своих рёбер нет — без наследуемого поля «компонент» и
            // «проект» у 5 из 5 детей FEAT-LORE-HONEST приходили пустыми. Те же выражения,
            // что у use_cases_of_feature: свой и унаследованный — РАЗНЫЕ поля.
            "in('DECOMPOSES_INTO').out('BELONGS_TO').component_id AS inherited_component_ids, " +
            "in('DECOMPOSES_INTO').out('BELONGS_TO_PROJECT').slug AS inherited_projects, " +
            "in('DECOMPOSES_INTO').uc_id    AS parent_uc_ids, " +
            // Прогресс «сценариев x/y». Фильтр-проекция [..].size() парсер принимает;
            // сравнение над .size() в списке полей — нет (CommandSQLParsingException).
            "out('DECOMPOSES_INTO').size()  AS uc_total, " +
            "out('DECOMPOSES_INTO')[status='shipped'].size() AS uc_shipped, " +
            "outE('TARGETS_MILESTONE')[valid_to IS NULL].inV().milestone_id[0] AS milestone_id, " +
            "in('REALIZES').size()          AS task_count " +
            "FROM KnowUseCase",
            List.of(),
            new LinkedHashMap<>(Map.of(
                "component", " WHERE out('BELONGS_TO').component_id CONTAINS :component",
                "goal_level", " WHERE goal_level = :goal_level")),
            " ORDER BY uc_id");

        // Дочерние сценарии корня. Источник истины — ребро DECOMPOSES_INTO;
        // parent_uc_id рядом с ним денормализация для индекса, а не вторая правда.
        slice("use_cases_of_feature",
            "SELECT uc_id, title, scenario_md, acceptance_md, status, parent_uc_id, date_created, " +
            // ADR-027 (D1/§2): классификация Коберна — уровень цели, вес оформления,
            // приоритет; shipped_at ставит система (ADR-029 §2).
            "goal_level, rigor, priority, shipped_at, " +
            // PL-10 (D14): компонент у сценария ПРЯМОЙ; наследование от родителя
            // отдаётся отдельным полем, чтобы «свой» и «унаследованный» не
            // склеивались в один список и тройка RBAC не врала.
            "out('BELONGS_TO').component_id                      AS component_ids, " +
            "in('DECOMPOSES_INTO').out('BELONGS_TO').component_id AS inherited_component_ids, " +
            "out('BELONGS_TO_PROJECT').slug                     AS projects, " +
            // Проект НАСЛЕДУЕТСЯ от корня — как и компонент. Сценарий живёт под
            // фичей, у фичи проект уже задан, и спрашивать его второй раз у
            // каждого сценария значит заводить второй источник правды: стоит
            // им разойтись — и непонятно, какой считать верным.
            "in('DECOMPOSES_INTO').out('BELONGS_TO_PROJECT').slug AS inherited_projects, " +
            // ADR-032 D5: что этот UC реально снимает/создаёт — правая половина VP-канвы.
            "out('RELIEVES').pain_id AS relieves_pain_ids, " +
            "out('DELIVERS').gain_id AS delivers_gain_ids, " +
            "out('PERFORMS').job_id  AS performs_job_ids, " +
            "in('REALIZES').task_uid AS task_uids, " +
            "out('TRACED_TO').adr_id AS traced_adr_ids, " +
            "out('TRACED_TO').decision_id AS traced_decision_ids, " +
            // D12/D13: акторы (multi) и поперечные связи графа UC.
            "out('HAS_ACTOR').actor_id AS actor_ids, " +
            "out('HAS_ACTOR').name     AS actor_names, " +
            "out('UC_INCLUDES').uc_id  AS includes_uc, " +
            "out('UC_EXTENDS').uc_id   AS extends_uc, " +
            "in('UC_INCLUDES').uc_id   AS included_by, " +
            "in('UC_EXTENDS').uc_id    AS extended_by " +
            "FROM KnowUseCase WHERE in('DECOMPOSES_INTO').uc_id CONTAINS :id ORDER BY uc_id",
            List.of("id"), Map.of(), "");

        // ADR-LORE-032 §2 (D5): реестры болей и выгод. Боль/выгода переиспользуются
        // НЕСКОЛЬКИМИ фичами — потому реестр проектный, а не «внутри фичи»; отсюда же
        // растёт кросс-фичевая канва по актору и «самая горячая боль» (AN-01/AN-07).
        slice("pains",
            "SELECT pain_id, title, body_md, severity, date_created, " +
            "out('FELT_BY').actor_id       AS actor_ids, " +   // чья боль
            "out('BLOCKS').job_id          AS blocks_job_ids, " + // Остервальдер: какой работе мешает
            "in('ADDRESSES').uc_id          AS claimed_by_ucs, " + // кто заявил, что адресует
            "in('ADDRESSES').size()        AS addressed_by, " +
            "in('RELIEVES').uc_id          AS relieved_by_ucs, " + // кто РЕАЛЬНО снимает
            "in('RELIEVES').size()         AS relieved_by " +
            "FROM KnowPain",
            List.of(), new LinkedHashMap<>(Map.of("severity", " WHERE severity = :severity")),
            " ORDER BY pain_id");

        slice("gains",
            "SELECT gain_id, title, body_md, metric_md, rank, date_created, " +
            "out('DESIRED_BY').actor_id    AS actor_ids, " +
            "out('SUCCESS_OF').job_id      AS success_of_job_ids, " + // успех в какой работе
            "in('PROMISES').uc_id           AS claimed_by_ucs, " +
            "in('PROMISES').size()         AS promised_by, " +
            "in('DELIVERS').uc_id          AS delivered_by_ucs, " +
            "in('DELIVERS').size()         AS delivered_by " +
            "FROM KnowGain",
            List.of(), new LinkedHashMap<>(Map.of("rank", " WHERE rank = :rank")), " ORDER BY gain_id");

        // Остервальдер VPC: РАБОТЫ — третий столп профиля клиента. Боли и выгоды
        // производны от работы («боль мешает работе», «выгода — успех в работе»),
        // поэтому реестр работ отдаёт и то, и другое: вокруг чего вообще всё крутится.
        slice("jobs",
            "SELECT job_id, title, body_md, kind, importance, date_created, " +
            "out('PERFORMED_BY').actor_id AS actor_ids, " +       // чья работа
            "in('BLOCKS').pain_id         AS blocking_pain_ids, " + // что мешает
            "in('BLOCKS').size()          AS blocked_by, " +
            "in('SUCCESS_OF').gain_id     AS gain_ids, " +        // что значит успех
            "in('HELPS_WITH').uc_id         AS claimed_by_ucs, " +     // кто ЗАЯВИЛ помощь
            "in('HELPS_WITH').size()      AS helped_by, " +
            "in('PERFORMS').uc_id         AS performed_by_ucs, " + // кто РЕАЛЬНО выполняет
            "in('PERFORMS').size()        AS performed_by " +
            "FROM KnowJob",
            List.of(), new LinkedHashMap<>(Map.of("kind", " WHERE kind = :kind")), " ORDER BY job_id");

        // D12: реестр проектируемых ролей/акторов + карта «сценарии роли».
        slice("actors",
            "SELECT actor_id, name, kind, body_md, " +
            // D18: актор проектный — иначе одноимённые роли разных продуктов
            // склеиваются в одну строку RBAC-матрицы.
            "out('BELONGS_TO_PROJECT').slug AS projects, " +
            "in('HAS_ACTOR').uc_id AS uc_ids, " +
            "in('HAS_ACTOR').size() AS uc_count " +
            "FROM KnowProjectActor",
            List.of(),
            new LinkedHashMap<>(Map.of("kind", " WHERE kind = :kind")),
            " ORDER BY actor_id");

        // ── SPRINT_LORE_MODEL_DOCS_TIDY/MD-04: паспорта роли продукта и профиля клиента ──────
        // Шапка — одна строка по деловому ключу; связи (сценарии, профиль, агенты, ссылки) фасад
        // читает по рёбрам модели (READ_BY_EDGE), поэтому здесь только свойства и проекты.
        slice("actor_by_id",
            "SELECT actor_id, name, kind, body_md, out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowProjectActor WHERE actor_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");
        slice("pain_by_id",
            "SELECT pain_id, title, body_md, severity, date_created FROM KnowPain WHERE pain_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");
        slice("gain_by_id",
            "SELECT gain_id, title, body_md, metric_md, rank, date_created FROM KnowGain WHERE gain_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");
        slice("job_by_id",
            "SELECT job_id, title, body_md, kind, importance, date_created FROM KnowJob WHERE job_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");

        // ADR-LORE-031 §3: ассеты, потерявшие вход ATTACHED_TO (сущность удалена) —
        // кормит двухшаговый GC в Админке. По построению upload сироту создать
        // не может, так что непустой срез = следы удалённых сущностей.
        slice("asset_orphans",
            "SELECT asset_key, entity_type, entity_id, mime, size_bytes, created_at " +
            "FROM KnowAsset WHERE inE('ATTACHED_TO').size() = 0",
            List.of(), new LinkedHashMap<>(), " ORDER BY created_at");

        // D16: в сценарии виден список задач СО СПРИНТОМ И ЕГО СТАТУСОМ — чтобы
        // «доехало ли» читалось прямо здесь, без перехода в спринт. Раньше слайс
        // отдавал статус ЗАДАЧИ и голый sprint_id: увидеть, что задача закрыта, а
        // спринт ещё нет (или наоборот — отменён), было нельзя.
        slice("tasks_of_uc",
            "SELECT task_uid, task_id, title, task_type, work_class, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('PART_OF').sprint_id[0] AS sprint_id, " +
            "COALESCE(out('PART_OF').out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('PART_OF').out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS sprint_status_raw, " +
            // Обоснование enb-задачи (JUSTIFIED_BY) — ребро было мёртвым до PL-14.
            "out('JUSTIFIED_BY').adr_id AS justified_by_adr_ids " +
            "FROM KnowTask WHERE out('REALIZES').uc_id CONTAINS :id ORDER BY task_uid",
            List.of("id"), Map.of(), "");

        // Зеркало дисциплины D16 для второго класса: enb-задача обязана нести
        // JUSTIFIED_BY. Advisory, как и unlinked_uc_tasks — список нарушений,
        // а не гейт записи (гейт задушил бы ввод, TOC-раздел ADR-022).
        //
        // MT-03 (05.11.2026, рекомендация 2): правило считается от даты — с
        // ENB_RULE_SINCE. Хвост июня–июля (класс проставлен задним числом, ADR не
        // подбирали) объявлен вне правила: он делал список нечитаемым (632 строки),
        // а само правило по свежим задачам работает (август — 55 %, и растёт).
        // Отсечка по САМОЙ РАННЕЙ строке истории = дате заведения: «нет ни одной
        // строки старше даты». По текущей строке нельзя — правка июльской задачи
        // вернула бы её в список. Строки истории без valid_from не мешают.
        slice("unlinked_enb_tasks",
            "SELECT task_uid, task_id, title, work_class, out('PART_OF').sprint_id[0] AS sprint_id " +
            "FROM KnowTask WHERE work_class = 'enb' AND out('JUSTIFIED_BY').size() = 0 " +
            "AND out('HAS_STATE')[valid_from < date('" + ENB_RULE_SINCE + "', 'yyyy-MM-dd')].size() = 0 " +
            "ORDER BY task_uid",
            List.of(), Map.of(), "");

        // Обзор дисциплины (D3): uc-задачи без REALIZES — advisory, не ошибка.
        slice("unlinked_uc_tasks",
            "SELECT task_uid, task_id, title, work_class, out('PART_OF').sprint_id[0] AS sprint_id " +
            "FROM KnowTask WHERE work_class = 'uc' AND out('REALIZES').size() = 0 " +
            "ORDER BY task_uid",
            List.of(), Map.of(), "");

        // AN-02 (ADR-LORE-030 §2 срез E): гигиена связок ОДНИМ срезом — четыре
        // обязательные связки D16/D5 с типом находки и ссылкой на сущность.
        // Пока здесь не ноль, остальная аналитика (fit/покрытие/динамика) ВРЁТ:
        // незамкнутая связка неотличима от несделанной работы. Advisory, не гейт
        // записи — гейт задушил бы ввод (TOC-раздел ADR-022).
        // «UC без приёмки» — только сценарные уровни (sea-level/subfunction):
        // acceptance_md — свойство сценария; у корней cloud/kite приёмка агрегатная,
        // её отсутствие — не нарушение (ADR-032 §1).
        slice("product_hygiene",
            "SELECT finding, entity_type, ref_id, title, sprint_id " +
            "FROM (SELECT expand(unionall($ut, $et, $ua, $pr, $pp)) LET " +
            "$ut = (SELECT 'uc_task_without_realizes' AS finding, 'task' AS entity_type, " +
            "       task_uid AS ref_id, title, out('PART_OF').sprint_id[0] AS sprint_id " +
            "       FROM KnowTask WHERE work_class = 'uc' AND out('REALIZES').size() = 0), " +
            "$et = (SELECT 'enb_task_without_justification' AS finding, 'task' AS entity_type, " +
            "       task_uid AS ref_id, title, out('PART_OF').sprint_id[0] AS sprint_id " +
            "       FROM KnowTask WHERE work_class = 'enb' AND out('JUSTIFIED_BY').size() = 0), " +
            // sprint_id у uc/pain-веток отсутствует НАМЕРЕННО: unionall терпит
            // разнородные документы, внешний SELECT отдаст поле как null —
            // литерал `null AS ...` в грамматике прецедента в корпусе не имеет.
            "$ua = (SELECT 'uc_without_acceptance' AS finding, 'uc' AS entity_type, " +
            "       uc_id AS ref_id, title " +
            "       FROM KnowUseCase WHERE goal_level IN ['sea-level', 'subfunction'] " +
            "       AND (acceptance_md IS NULL OR acceptance_md = '')), " +
            "$pr = (SELECT 'pain_without_relief' AS finding, 'pain' AS entity_type, " +
            "       pain_id AS ref_id, title " +
            "       FROM KnowPain WHERE in('RELIEVES').size() = 0), " +
            // WK-02: связь продукт → проект без роли — не размечено, развивает
            // продукт репозиторий или только пользуется им.
            "$pp = (SELECT 'product_project_without_role' AS finding, 'product' AS entity_type, " +
            "       @out.code AS ref_id, @in.slug AS title " +
            "       FROM BELONGS_TO_PROJECT WHERE @out.dict_type = 'product' AND role IS NULL)" +
            ") ORDER BY finding, ref_id",
            List.of(), Map.of(), "");

        // RM-P9: что ИСЧЕЗНЕТ, если включить lore.scope.enforce.
        //
        // Скоуп режет по ребру BELONGS_TO_PROJECT. Запись без этого ребра
        // отрезается не по правам, а по НЕДОСТАЮЩИМ ДАННЫМ — и пропадает у
        // всех, включая владельца. Замер 19.10.2026 по проду: у спек нет
        // проекта у 218 из 415, у доков у 239 из 292, у ранбуков у 42 из 47.
        // То есть включение «изоляции» спрятало бы 499 записей от каждого.
        //
        // Срез существует ровно для того, чтобы включение не было прыжком в
        // темноту: сначала смотрим, сколько потеряем, потом решаем. Отдаёт
        // СЫРЬЁ построчно, а не счётчики, — по счётчику нельзя пойти и
        // привязать проект, а по ref_id можно.
        slice("scope_orphans",
            "SELECT entity_type, ref_id, title FROM (SELECT expand(unionall($sp, $dc, $rb, $ad, $sr, $rl)) LET " +
            "$sp = (SELECT 'spec' AS entity_type, spec_id AS ref_id, title FROM KnowSpec " +
            "       WHERE out('BELONGS_TO_PROJECT').size() = 0), " +
            "$dc = (SELECT 'doc' AS entity_type, doc_id AS ref_id, title FROM KnowDoc " +
            "       WHERE out('BELONGS_TO_PROJECT').size() = 0), " +
            "$rb = (SELECT 'runbook' AS entity_type, runbook_id AS ref_id, name AS title FROM KnowRunbook " +
            "       WHERE out('BELONGS_TO_PROJECT').size() = 0), " +
            "$ad = (SELECT 'adr' AS entity_type, adr_id AS ref_id, name AS title FROM KnowADR " +
            "       WHERE out('BELONGS_TO_PROJECT').size() = 0), " +
            "$sr = (SELECT 'sprint' AS entity_type, sprint_id AS ref_id, coalesce(title, name) AS title FROM KnowSprint " +
            "       WHERE out('BELONGS_TO_PROJECT').size() = 0), " +
            "$rl = (SELECT 'release' AS entity_type, release_id AS ref_id, git_tag AS title FROM KnowRelease " +
            "       WHERE out('BELONGS_TO_PROJECT').size() = 0)" +
            ") ORDER BY entity_type, ref_id",
            List.of(), Map.of(), "");

        // RM-P17: открытая строка истории без valid_from — ДЕФЕКТ, и его надо видеть.
        //
        // ЗАМЕР (прод, 11.09.2026). В KnowTaskHist восемь строк с valid_from = null
        // из 9796, и семь из них ОТКРЫТЫЕ (valid_to IS NULL), то есть это текущее
        // состояние задачи: SPRINT_DALI_PARSE_MEM_PARALLEL_JUN26/P1-A…P1-G.
        //
        // ЧЕМ СТОИТ. Слайс task_starts отбирает `valid_from IS NOT NULL`,
        // task_created_dates берёт min(valid_from) по цепочке. Такие задачи
        // выпадают из аналитики МОЛЧА: их нет ни в «начале», ни в «заведении»,
        // lead/cycle time по спринту считается без них, а пустая выдача читается
        // как «таких задач не было» — тот же класс, что «пустой ответ ≠ не найдено».
        //
        // ПОЧЕМУ СРЕЗ, А НЕ ВЕРДИКТ ЗАПИСИ. Линтер полноты (WorkQuality) отвечает
        // в ответе НА ЗАПИСЬ — а запись как раз и создаёт новую открытую строку с
        // valid_from, поэтому в write-пути такая проверка всегда «ок» и не ловит
        // ничего; обязательной её сделать тоже нельзя — max вырос бы у каждой
        // задачи корпуса, сдвинув счёт там, где дефекта нет. Правило живёт срезом,
        // как product_hygiene и scope_orphans: находка с ref_id, по которому можно
        // пойти и починить, а не счётчик.
        //
        // ПОЧИНКА ДАННЫХ — НЕ ЗДЕСЬ. Восстановить дату неоткуда, кроме соседних
        // фактов, а подставленная дата станет ФАКТОМ аналитики: это решение
        // владелицы (развилка в RM-P17). Срез её не предрешает — он показывает
        // недостачу, а не заполняет её.
        slice("history_hygiene", histHygieneSql(), List.of(), Map.of(), "");

        // Проект без единой роли — тихая дыра в делегировании (найдено 30.08.2026
        // владельцем: «в full сессии Claude не даёт завести новых акторов»).
        //
        // МЕХАНИКА. У заведения актора стоит проектный гейт: клиент KC → владелец
        // → роль владельца В ЭТОМ проекте → делегирует ли роль профиль агента.
        // Нет роли — отказ ЛЮБОМУ профилю, включая full. Замер того же дня: роль
        // есть у 10 проектов из 19; у AIDA/MIDGARD её не было, отсюда и отказ.
        //
        // ПОЧЕМУ ЭТО НЕ ВИДНО БЕЗ СРЕЗА. Отсутствие роли ничем себя не проявляет,
        // пока кто-нибудь не упрётся в отказ — и упирается он не там, где причина.
        // Ровно та же болезнь, что у метрик без даты: состояние есть, величины нет.
        // Срез делает дыру счётной: её можно померить гейтом, а не обнаружить телом.
        //
        // Считаем ЛЮБУЮ роль, а не только owner: проект с ролью reader тоже
        // «настроен», просто узко, и это другой разговор, чем «о нём забыли».

        // AL-113: сущности без проекта по типам — вход для quality gate «привязка
        // к проекту». Решение и вопрос наследуют проект родителя (как в скоупе).
        slice("entities_without_project", entitiesWithoutProjectSql(), List.of(), Map.of(), "");

        slice("projects_without_role",
            "SELECT slug, name, inE('HAS_PROJECT_ROLE')[valid_to IS NULL].outV().size() AS roles " +
            "FROM KnowGitProject WHERE inE('HAS_PROJECT_ROLE')[valid_to IS NULL].outV().size() = 0 ORDER BY slug",
            List.of(), Map.of(), "");

        // AN-03 (ADR-LORE-030 §2 срез B): две стороны одного ребра TARGETS_MILESTONE.
        // KAOS-чтение (ADR-032 §1): веха = goal, фича = refinement — срез показывает
        // дыры в ОБОИХ направлениях декомпозиции: ценность вне стратегии (корень без
        // вехи) и цель без реализации (веха без корней).
        // Фильтр по классу источника обязателен: в веху целятся И спринты, И корни
        // слоя — веха со спринтами, но без единой фичи, всё равно «цель без
        // ценности». Класс вершины из траверса — ТОЛЬКО `.@type` (`.@class` в
        // грамматике 26.7.2 не парсится: «no viable alternative at input '@'»).
        slice("strategic_coverage",
            "SELECT finding, entity_type, ref_id, title " +
            "FROM (SELECT expand(unionall($f, $m)) LET " +
            "$f = (SELECT 'feature_without_milestone' AS finding, 'uc' AS entity_type, " +
            "       uc_id AS ref_id, title " +
            "       FROM KnowUseCase WHERE goal_level IN ['cloud', 'kite'] " +
            "       AND outE('TARGETS_MILESTONE')[valid_to IS NULL].inV().size() = 0), " +
            "$m = (SELECT 'milestone_without_features' AS finding, 'milestone' AS entity_type, " +
            "       milestone_id AS ref_id, label AS title " +
            "       FROM KnowMilestone " +
            "       WHERE NOT (inE('TARGETS_MILESTONE')[valid_to IS NULL].outV().@type CONTAINS 'KnowUseCase'))" +
            ") ORDER BY finding, ref_id",
            List.of(), Map.of(), "");

        // AN-04 (ADR-LORE-030 §2 срез D): инвестиционный профиль — сырые слим-факты
        // задача × work_class × effort × спринт × релизы. БЕЗ GROUP BY намеренно:
        // на этой версии ArcadeDB GROUP BY молча группирует неверно (см. MartSlices —
        // аналитика возит raw fact rows, агрегирует клиент). Клиент считает долю
        // uc/jtd/enb по effort_days с фолбэком на счёт по штукам и обязан честно
        // помечать, какая доля считана по штукам (строки с effort_days = null).
        // work_class = null — легальная строка (неклассифицированное — тоже сигнал).
        // SPRINT_LORE_PRODUCT_BACKLOG/AN-06 · ADR-LORE-030 §2 срез I «реинжиниринг-нагрузка».
        // decision:D-2026-LORE-REENG-SHIPPED-IN-REWORK: uc-задача к выпущенному сценарию
        // переводит его в in_rework, shipped_at сохраняется. Сырые факты, как у
        // invest_profile: строка на uc-задачу сценария, который хоть раз выпускался.
        // Эпизод (задача заведена ПОСЛЕ shipped_at) и его длительность считает
        // потребитель (reengLoad.ts) — min по датам состояний в SQL не берём:
        // агрегаты по датам в ArcadeDB уже роняли слайсы (ClassCastException).
        // Запрос проверен read-only на проде 06.11.
        slice("reeng_load",
            "SELECT task_uid, " +
            "out('REALIZES').uc_id[0]      AS uc_id, " +
            "out('REALIZES').title[0]      AS uc_title, " +
            "out('REALIZES').status[0]     AS uc_status, " +
            "out('REALIZES').shipped_at[0] AS shipped_at, " +
            "out('HAS_STATE').valid_from   AS state_dates, " +
            "out('HAS_STATE')[valid_to IS NULL].status_raw[0] AS status_raw, " +
            STATUS_SINCE_SQL + " AS status_since " +
            "FROM KnowTask WHERE out('REALIZES')[shipped_at IS NOT NULL].size() > 0",
            List.of(), Map.of(), " ORDER BY task_uid");

        slice("invest_profile",
            "SELECT task_uid, work_class, task_type, " +
            "out('PART_OF').sprint_id[0] AS sprint_id, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0])   AS status_raw, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].effort_days[0], out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0]) AS effort_days, " +
            "out('PART_OF').out('IMPLEMENTED_IN_RELEASE').release_id  AS release_ids, bookkeeping " +
            "FROM KnowTask ORDER BY task_uid",
            List.of(), Map.of(), "");

        // AN-01 (ADR-LORE-030 §1) — ядро VP-аналитики: строка на корень линейки
        // (cloud/kite) со ВСЕМИ множествами для fit по трём осям. Замыкание считает
        // потребитель разностью множеств (тот же принцип raw-фактов, что invest_profile):
        //  - jobs:  claimed (HELPS_WITH корня) vs performed (PERFORMS его сценариев);
        //  - pains: claimed (ADDRESSES) vs relieved (RELIEVES сценариев);
        //  - gains: claimed (PROMISES) vs delivered (DELIVERS), причём замыкает только
        //    выгода С МЕТРИКОЙ — delivered_measured_gain_ids отдельным множеством
        //    (metric_md пуст → доставка не измерима, fit не засчитывается, ADR-032 §2);
        //  - «ценность доехала» (D17): jobs, выполняемые shipped-сценариями;
        //  - actors: ФАКТИЧЕСКИЕ исполнители через HAS_ACTOR сценариев — расхождение
        //    с заявленным «для кого» видно сразу.
        // «Заявлено vs доставлено» — характер утверждения, не уровень узла (D20):
        // клеймы читаются с корня, доставка — со сценариев через DECOMPOSES_INTO.
        slice("feature_vp_analytics",
            "SELECT uc_id, title, status, shipped_at, goal_level, " +
            "outE('TARGETS_MILESTONE')[valid_to IS NULL].inV().milestone_id[0] AS milestone_id, " +
            "out('HELPS_WITH').job_id  AS claimed_job_ids, " +
            "out('ADDRESSES').pain_id  AS claimed_pain_ids, " +
            "out('PROMISES').gain_id   AS claimed_gain_ids, " +
            "out('DECOMPOSES_INTO').out('PERFORMS').job_id  AS performed_job_ids, " +
            "out('DECOMPOSES_INTO').out('RELIEVES').pain_id AS relieved_pain_ids, " +
            "out('DECOMPOSES_INTO').out('DELIVERS').gain_id AS delivered_gain_ids, " +
            "out('DECOMPOSES_INTO').out('DELIVERS')[metric_md IS NOT NULL].gain_id " +
            "    AS delivered_measured_gain_ids, " +
            "out('DECOMPOSES_INTO')[status = 'shipped'].out('PERFORMS').job_id AS shipped_job_ids, " +
            "out('DECOMPOSES_INTO').out('HAS_ACTOR').actor_id AS actor_ids " +
            "FROM KnowUseCase WHERE goal_level IN ['cloud', 'kite'] ORDER BY uc_id",
            List.of(), Map.of(), "");

        // AN-07 (ADR-LORE-030 §2 срез A): карта нагрузки ролей. Два сигнала:
        // перегруз (роль тянет несоразмерно много сценариев — кандидат на
        // расщепление) и мёртвая роль (0 UC — заявлена, но не используется).
        // Разбивка primary/supporting — по свойству role ребра HAS_ACTOR (D19).
        // Фильтр по проекту ОБЯЗАТЕЛЕН (D18: акторы проектные — одноимённые роли
        // разных продуктов не должны склеиваться в одну строку нагрузки).
        // AL-82/ADR-LORE-036: роль человека в проекте — по вердикту 148 источник
        // истины о правах граф, не KC. Два слайса — обе стороны ребра
        // HAS_PROJECT_ROLE, как явно требует задача («роли человека по проектам»
        // и обратный «кто имеет роль в проекте P»), не один слайс с фильтром:
        // AL-36 просил именно обратную матрицу для ревью доступа.
        slice("user_project_roles",
            "SELECT kc_sub, display_name, " +
            "outE('HAS_PROJECT_ROLE')[valid_to IS NULL].inV().slug AS projects, " +
            "outE('HAS_PROJECT_ROLE')[valid_to IS NULL].role AS roles " +
            "FROM KnowUser WHERE kc_sub = :kc_sub",
            List.of("kc_sub"), Map.of(), "");

        slice("project_users",
            "SELECT slug, " +
            "inE('HAS_PROJECT_ROLE')[valid_to IS NULL].outV().kc_sub AS kc_subs, " +
            "inE('HAS_PROJECT_ROLE')[valid_to IS NULL].outV().display_name AS display_names, " +
            "inE('HAS_PROJECT_ROLE')[valid_to IS NULL].role AS roles " +
            "FROM KnowGitProject WHERE slug = :project",
            List.of("project"), Map.of(), "");

        // SPRINT_UXR_S7B_ADMIN/S7B-11: вся матрица «проект × люди» одним запросом —
        // строка на человека, его проекты и роль на ребре (те же пары, что у
        // user_project_roles, но без обязательного kc_sub: N запросов на экран не нужны).
        // Правка ячейки — POST /lore/user/role и /lore/user/role/batch.
        slice("role_matrix",
            "SELECT kc_sub, display_name, " +
            "outE('HAS_PROJECT_ROLE')[valid_to IS NULL].inV().slug AS projects, " +
            "outE('HAS_PROJECT_ROLE')[valid_to IS NULL].role AS roles " +
            "FROM KnowUser",
            List.of(), Map.of(), " ORDER BY display_name");   // без потолка: SliceCapAndCardParityTest

        // AL-83/ADR-LORE-036: обратная матрица агент→владелец, тот же мотив
        // ревью доступа, что у project_users. Один агент — один живой
        // OWNED_BY (out()/outE() без индекса ok — единственная строка).
        // AL-104: agent_role отдаётся отдельной колонкой, а НЕ выводится из
        // client_id. Роль — свойство агента (миграция V21); вывод из имени
        // учётки и был тем местом, где роль с учёткой слипались.
        // Фильтр по client_id снят: агент без учётки — это заполняемое
        // состояние, и экран обязан его показать, а не спрятать.
        // AL-108: machine_id/session_id — «откуда агент писал в последний
        // раз» (самоописание через actor_new), не история и не различитель
        // двух ОДНОВРЕМЕННЫХ сессий одной роли — только последняя.

        // Описательные акторы, застрявшие в реестре ЛИЧНОСТЕЙ (AC-04).
        //
        // После развода (миграция 30) в KnowActor должны остаться только
        // личности: с client_id и владельцем. Всё остальное там — след записи,
        // ушедшей не по тому адресу.
        //
        // ЗАЧЕМ ОТДЕЛЬНЫЙ СРЕЗ. Такая вершина не видна НИГДЕ: `actors` читает
        // KnowProjectActor, `agent_owners` фильтрует kind='agent', поиск ходит
        // в индекс нового типа. Запись отвечает ok:true и исчезает. Ровно так
        // и случилось: форма акторов в UI продолжала звать /lore/actor уже
        // после того, как чтение переехало.
        //
        // Пустой ответ здесь — содержательный результат: он означает, что
        // описательных следов не осталось. Поэтому срез отдаёт их поимённо, а
        // не числом: по имени видно, откуда прилетело.
        slice("actor_identity_orphans",
            "SELECT actor_id, name, kind, client_id, "
            + "out('OWNED_BY').kc_sub AS owners, "
            + "in('HAS_ACTOR').size() AS uc_count "
            + "FROM KnowActor "
            + "WHERE (client_id IS NULL OR client_id = '') AND out('OWNED_BY').size() = 0",
            List.of(), Map.of(), " ORDER BY actor_id");
        slice("agent_owners",
            "SELECT actor_id, name, client_id, agent_role, machine_id, session_id, harness, " +
            "out('OWNED_BY').kc_sub AS owner_kc_sub, " +
            "out('OWNED_BY').display_name AS owner_display_name, " +
            // AO-MACHINE-OBJ: ВСЕ машины агента (рёбра USES_MACHINE), в отличие от
            // machine_id выше — «откуда писал последний раз».
            "out('USES_MACHINE').machine_id AS machines, " +
            // S7B-ACT-1: окно активности (часы) — у актора-машины; у прочих агентов пусто.
            // Окно агента = окно его машины (client_id minilore-link-<machine_id>) с перекрытием по harness.
            "activity_window_h, activity_window_harness, " +
            MachineActivity.DEFAULT_H + " AS activity_default_h, " +
            // S7B-ACT-1: «когда был на связи» — последняя активность его сессий (LOGGED_BY, actor/session).
            "in('LOGGED_BY').last_activity_at AS session_activity " +
            "FROM KnowActor WHERE kind = 'agent'",
            List.of(), Map.of(), " ORDER BY actor_id");

        // SPRINT_UXR_S7B_ADMIN/S7B-ACL-1 · S7B-ACL-2: допуски «человек → машина». Строка на
        // машину (актор с client_id minilore-link-*): владелец и допущенные люди параллельными
        // массивами grant_* (тот же приём, что user_project_roles; разбор — MachineAccess.grantsOf).
        // По машине (client_id) — строка есть всегда, если машина заведена: человека нет ни во
        // владельце, ни в grant_kc_subs — «закрыто», не «пусто». По человеку (kc_sub) — машины,
        // где он владелец или допущен. Этим срезом сервер miniLORE решает видимость (MachineOwners, круг 2).
        slice("machine_acl",
            "SELECT actor_id, client_id, machine_id, name, " +
            // S7B-ACT-1: окно активности машины и окна по harness (MachineActivity.effective).
            "activity_window_h, activity_window_harness, " +
            "out('OWNED_BY').kc_sub AS owner_kc_sub, " +
            "out('OWNED_BY').display_name AS owner_display_name, " +
            "in('MACHINE_ACCESS').kc_sub AS grant_kc_subs, " +
            "in('MACHINE_ACCESS').display_name AS grant_display_names, " +
            "inE('MACHINE_ACCESS').role AS grant_roles, " +
            "inE('MACHINE_ACCESS').projects AS grant_projects, " +
            "inE('MACHINE_ACCESS').harnesses AS grant_harnesses, " +
            "inE('MACHINE_ACCESS').granted_by AS grant_granted_by, " +
            "inE('MACHINE_ACCESS').granted_at AS grant_granted_at " +
            "FROM KnowActor WHERE kind = 'agent' AND client_id LIKE 'minilore-link-%'",
            List.of(),
            new LinkedHashMap<>(Map.of(
                "client_id", " AND client_id = :client_id",
                "kc_sub", " AND (in('MACHINE_ACCESS').kc_sub CONTAINS :kc_sub OR out('OWNED_BY').kc_sub CONTAINS :kc_sub)")),
            " ORDER BY client_id");

        // ADR-LORE-037 V1: журнал сессий агентов — обратная сторона LOGGED_BY
        // (agent_owners показывает АКТОРА, этот срез показывает КОНКРЕТНЫЕ
        // сессии под ним, зачем и заводился — «какая сессия сделала запись»,
        // а не только «под какой ролью»). Опциональный фильтр по актору:
        // без него — общий журнал (свежие сверху), с ним — сессии одного
        // агента (экран его карточки).
        slice("agent_sessions",
            "SELECT session_id, machine_id, project, entrypoint, dialogue_name, " +
            "started_at, last_activity_at, " +
            "out('LOGGED_BY').actor_id AS actor_ids " +
            "FROM KnowAgentSession",
            List.of(),
            new LinkedHashMap<>(Map.of("actor_id",
                " WHERE out('LOGGED_BY').actor_id CONTAINS :actor_id")),
            " ORDER BY last_activity_at DESC LIMIT 200");

        slice("actor_load",
            "SELECT actor_id, name, kind, " +
            "out('BELONGS_TO_PROJECT').slug AS projects, " +
            "in('HAS_ACTOR').uc_id AS uc_ids, " +
            "in('HAS_ACTOR').size() AS uc_count, " +
            "inE('HAS_ACTOR')[role = 'primary'].size()    AS primary_count, " +
            "inE('HAS_ACTOR')[role = 'supporting'].size() AS supporting_count " +
            "FROM KnowProjectActor WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project " +
            "ORDER BY actor_id",
            List.of("project"), Map.of(), "");

        // MT-09: роль ребра HAS_ACTOR построчно.
        //
        // До этого среза роль ребра не отдавал НИКТО: `actor_load` даёт только
        // счётчики primary/supporting по актору, `actors` — список сценариев
        // без ролей. Узнать, у какого сценария кто primary, было нельзя в
        // принципе; расхождение выявлялось лишь тем, что primary + supporting
        // не сходится с uc_count, и то если специально сложить.
        //
        // Цена непроверяемости измерена 2026-08-04: девять вызовов uc_link с
        // неверным именем параметра прошли с ok:true, роли назначились по
        // умолчанию, два сценария остались БЕЗ primary — состояние, прямо
        // запрещённое проверкой качества №7 (ADR-LORE-028 D19). Обнаружилось
        // это через сутки и не тем способом.
        //
        // Строка на РЕБРО, а не на сценарий. Первая редакция отдавала два
        // параллельных массива (акторы и роли) — и они разъезжаются: у ребра
        // без роли место в массиве ролей занимает null, соответствие с
        // массивом акторов держится только на порядке. Одна строка на ребро
        // такого вопроса не создаёт.
        //
        // Сразу вскрыло то, что счётчиками не видно: у части рёбер роли НЕТ
        // вовсе (легаси). Отсюда и расхождение «сценариев 12, а primary плюс
        // supporting равно 10» — третьего состояния в счётчиках не было.
        //
        // Без uc_id отдаёт весь слой — на нём и считается «ровно один primary».
        slice("uc_actors",
            "SELECT @out.uc_id AS uc_id, @in.actor_id AS actor_id, " +
            "@in.name AS actor_name, @in.kind AS actor_kind, role " +
            "FROM HAS_ACTOR",
            List.of(),
            new LinkedHashMap<>(Map.of("uc_id", " WHERE @out.uc_id = :uc_id")),
            " ORDER BY uc_id");

        // MT-11/D-VP-ROLE-AGENT-PAIR: пары «агент → роль» построчно, сырые
        // ингредиенты для проверки совпадения работ (сам диф — в Java,
        // LoreProductResource.checkActorPairs, тем же приёмом, что
        // uc_single_primary у uc_actors). Ребро FILLS_ROLE отдаёт ровно ОДНУ
        // строку на агента (переприсвоение сносит старое — см. миграцию), так
        // что actor_id агента здесь уникален; акторы без ребра сюда не
        // попадают вовсе — это «двойником не является», третье состояние,
        // не пустая находка.
        slice("actor_pairs",
            "SELECT @out.actor_id AS agent_id, @out.name AS agent_name, " +
            "@in.actor_id AS role_id, @in.name AS role_name, " +
            "@in.in('PERFORMED_BY').job_id AS jobs_role, " +
            "@out.in('PERFORMED_BY').job_id AS jobs_agent " +
            "FROM FILLS_ROLE WHERE valid_to IS NULL",
            List.of(), Map.of(), " ORDER BY role_id");

        // AN-05 (ADR-LORE-030 §2 срез C, зависимость PL-15): shipped-динамика.
        // Сырые строки по выехавшим сценариям; периоды/релизы группирует клиент
        // по shipped_at (GROUP BY-ловушка). Lead time = shipped_at −
        // min(active_since_dates): даты берутся из ИСТОРИИ задач (первая
        // IN PROGRESS-ревизия каждой REALIZES-задачи), НЕ из valid_from вершин —
        // sprints.valid_from = дата текущего состояния SCD2, и lead time по нему
        // выходил бы ~0 (ловушка корпуса).
        slice("shipped_dynamics",
            "SELECT uc_id, title, goal_level, shipped_at, status, " +
            "in('DECOMPOSES_INTO').uc_id[0] AS root_uc_id, " +
            "in('REALIZES').task_uid AS task_uids, " +
            "in('REALIZES').out('HAS_STATE')[status_raw LIKE '%IN PROGRESS%'].valid_from " +
            "    AS active_since_dates " +
            "FROM KnowUseCase WHERE shipped_at IS NOT NULL ORDER BY shipped_at",
            List.of(), Map.of(), "");

        // Batch variant: fetch tasks for multiple sprints in one query.
        // sprint_ids — список через запятую; слой срезов режет его в List (isListParam,
        // SE-16). До 20.10.2026 этот комментарий обещал разбор, которого не было:
        // строка "A,B" уходила в IN целиком и находила пусто.
        slice("tasks_of_sprints_batch",
            "SELECT task_uid, task_id, title, order_index, " +
            "out('PART_OF').sprint_id[0]                              AS sprint_id, " +
            "outE('IN_PHASE')[valid_to IS NULL].inV().phase_uid[0]                            AS phase_uid, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0])   AS status_raw, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].effort_days[0], out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0]) AS effort_days, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].note_md[0], out('HAS_STATE')[note_md IS NOT NULL].note_md[0])         AS note_md, " +
            "out('TAGGED_WITH').component_id                          AS component_ids, " +
            // author/executor/reviewer_agent (ADR-LORE-014 §4) and task_type
            // (ADR-LORE-015, T14) — plain vertex fields.
            ROLE_HOLDERS + ", task_type, actual_days, bookkeeping, " +
            // 08.11.2026: паритет с tasks_of_sprint (TasksBatchSliceParityTest) — ЗАЧЕМ-ось
            // и UC (ADR-LORE-022) нужны строке задачи в списке/на доске v2.
            "work_class, out('REALIZES').uc_id AS realizes_uc, " +
            // PU-07: релиз задачи — её PR (паритет с tasks_of_sprint).
            TASK_RELEASES_SQL + ", " +
            // PU-23: та же свежесть, что у tasks_of_sprint (сторож TasksBatchSliceParityTest).
            changedAtSql(FIRST_STATE_FROM_SQL) + " " +
            "FROM KnowTask WHERE out('PART_OF').sprint_id[0] IN :sprint_ids " +
            "ORDER BY out('PART_OF').sprint_id[0], order_index",
            List.of("sprint_ids"), Map.of(), "");

        // Владелица 09.11: итоги спринта (задач, оценка, факт). Лёгкая проекция БЕЗ
        // note_md — ради сумм тела не нужны (у tasks_of_sprints_batch это 3,6 МБ на
        // 20 спринтов). Строки задач AidaLoreResource сворачивает в строку на спринт
        // функцией LoreSprintTotals — той же, что кормит паспорт.
        slice("sprint_totals",
            "SELECT out('PART_OF').sprint_id[0] AS sprint_id, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].effort_days[0], out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0]) AS effort_days, " +
            "actual_days " +
            "FROM KnowTask WHERE out('PART_OF').sprint_id[0] IN :sprint_ids",
            List.of("sprint_ids"), Map.of(), "");

        // SE-01, шаг 1 (пункт 4 mig_gen, 05.11.2026): заметки задач по списку uid.
        // После open_tasks агенту нужно прочитать 10–20 заметок — раньше либо по
        // одной, либо весь спринт целиком (78–90 КБ ради трёх заметок). Поля и
        // выражения — те же, что у tasks_of_sprints_batch; список — механизмом SE-16
        // (имя на _uids уходит в СУБД списком, каждый элемент — белым списком).
        slice("tasks_by_uids",
            "SELECT task_uid, task_id, title, " +
            "out('PART_OF').sprint_id[0]                              AS sprint_id, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0])   AS status_raw, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].effort_days[0], out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0]) AS effort_days, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].note_md[0], out('HAS_STATE')[note_md IS NOT NULL].note_md[0])         AS note_md, " +
            // Паспорт: «чьего ответа ждём» и причина статуса — с текущей версии (владелица 16.11.2026:
            // «какого ответа и от кого ждёшь в карточке не написано»).
            "out('HAS_STATE')[valid_to IS NULL].waiting_for[0]          AS waiting_for, " +
            "out('HAS_STATE')[valid_to IS NULL].status_reason[0]        AS status_reason, " +
            "out('TAGGED_WITH').component_id                          AS component_ids, " +
            ROLE_HOLDERS + ", task_type, work_class, actual_days, bookkeeping, " +
            "out('CLOSED_BY').pr_uid AS closed_by_prs, " +
            // lore.record/1 (ADR-LORE-047): паспорт задачи читает фазу и UC с той же строки.
            "outE('IN_PHASE')[valid_to IS NULL].inV().phase_uid[0] AS phase_uid, " +
            "out('REALIZES').uc_id AS realizes_uc " +
            "FROM KnowTask WHERE task_uid IN :task_uids " +
            "ORDER BY task_uid",
            List.of("task_uids"), Map.of(), "");

        // Lightweight projection: one row per task carrying only its sprint_id +
        // status_raw. Feeds the sprint LIST (LoreSprintTree) task-status breakdown
        // across ALL sprints — the frontend aggregates counts per sprint in JS.
        // No GROUP BY on purpose (this ArcadeDB version groups incorrectly — same
        // reason tasks_of_sprints_batch / MartSlices avoid it), and no note_md/title
        // so the sidebar payload stays small even at 400+ sprints.
        slice("task_status_by_sprint",
            "SELECT out('PART_OF').sprint_id[0]                            AS sprint_id, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0])        AS status_raw " +
            "FROM KnowTask WHERE out('PART_OF').sprint_id[0] IS NOT NULL",
            List.of(), Map.of(), " ORDER BY out('PART_OF').sprint_id[0]");

        // ── §3 Milestones ────────────────────────────────────────────────────
        slice("milestones",
            "SELECT milestone_id, label, week, date_display, priority, " +
            // Аудит времени 10.11: цель вехи пишется ВЕРСИЕЙ KnowMilestoneHist — читается
            // открытая строка (после первой смены цели строк больше одной).
            "out('HAS_STATE')[valid_to IS NULL].goal_md[0]      AS goal_md, " +
            "out('HAS_STATE')[valid_to IS NULL].decisions_md[0] AS decisions_md, " +
            // V89: статус вехи — код milestone_status в открытой строке истории (до V89 жил только в
            // легаси-ребре HAS_STATUS → StatusMilestone и в паспорт не попадал).
            "out('HAS_STATE')[valid_to IS NULL].status_raw[0] AS status, " +
            // Свежесть: версия цели, иначе отметка правки полей вершины. Даты заведения
            // у вехи нет — без того и другого changed_at пуст, а не выдуман.
            changedAtSql("updated_at") + ", " +
            // SPRINT_PLANITEM_RETIRE (T-21) had briefly split this into a "planned"
            // bucket (KnowSprintHist.planned_milestone_id, a plain property) vs.
            // this "actual" bucket (TARGETS_MILESTONE edge). The property drifted
            // out of sync with the edge on 62+ sprints and was retired — the edge
            // is now the sole source of truth for sprint↔milestone membership.
            "inE('TARGETS_MILESTONE')[valid_to IS NULL].outV().sprint_id AS direct_sprint_ids, " +
            // RM-S2: продукты вехи. Без них UI не может ни отфильтровать карту,
            // ни показать принадлежность — а веха БЕЗ продукта после
            // D-2026-LORE-PRODUCT-IS-OWN-ENTITY это незаполненность, и её надо
            // видеть, а не выводить из пустоты.
            "out('TARGETS_PRODUCT').code       AS products " +
            "FROM KnowMilestone ORDER BY week",
            List.of(), Map.of(), "");

        // Kit 09.11: паспорт вехи (только чтение) — та же проекция, что у milestones, по id.
        slice("milestone_by_id",
            "SELECT milestone_id, label, week, date_display, priority, " +
            "out('HAS_STATE')[valid_to IS NULL].goal_md[0]      AS goal_md, " +
            "out('HAS_STATE')[valid_to IS NULL].decisions_md[0] AS decisions_md, " +
            // V89: статус вехи — код milestone_status в открытой строке истории (до V89 жил только в
            // легаси-ребре HAS_STATUS → StatusMilestone и в паспорт не попадал).
            "out('HAS_STATE')[valid_to IS NULL].status_raw[0] AS status, " +
            "inE('TARGETS_MILESTONE')[valid_to IS NULL].outV().sprint_id AS direct_sprint_ids, " +
            // 11.11 (полнота модели рёбер): фичи, целящие в веху (feature_link rel:milestone).
            "inE('TARGETS_MILESTONE')[valid_to IS NULL].outV()[@this INSTANCEOF 'KnowUseCase'].uc_id AS feature_ids, " +
            "out('TARGETS_PRODUCT').code       AS products " +
            "FROM KnowMilestone WHERE milestone_id = :id",
            List.of("id"), Map.of(), "");

        // Kit 09.11: паспорт релиза (только чтение). Ключ — release_uid («проект#тег»):
        // release_id один и тот же в разных проектах.
        slice("release_by_id",
            "SELECT release_id, release_uid, git_tag, git_tag AS version, week, type, " +
            "release_date, is_current, description_md, git_project, " +
            "out('BELONGS_TO_PROJECT').slug AS projects, " +
            "in('IMPLEMENTED_IN_RELEASE').size() AS sprint_count, " +
            "in('SHIPPED_IN').size() AS pr_count, " +
            // 11.11 (полнота модели рёбер): ADR, выпущенные релизом (adr_link rel:release).
            "in('IMPLEMENTED_IN_RELEASE')[@this INSTANCEOF 'KnowADR'].adr_id AS adr_ids " +
            "FROM KnowRelease WHERE release_uid = :id",
            List.of("id"), Map.of(), "");

        // ── RM-S2: дорожная карта продукта ───────────────────────────────────
        // Карта принадлежит ПРОДУКТУ (D-2026-LORE-PRODUCT-IS-OWN-ENTITY): «я хочу
        // создать продукты, и у них будет roadmap, а не проекты — у нас и так
        // меняется дорога». Проект остаётся границей ПРАВ и вехи не несёт.
        slice("roadmap",
            "SELECT milestone_id, label, week, date_display, priority, " +
            "out('HAS_STATE')[valid_to IS NULL].goal_md[0]       AS goal_md, " +
            "inE('TARGETS_MILESTONE')[valid_to IS NULL].outV().sprint_id AS sprint_ids, " +
            "inE('TARGETS_MILESTONE')[valid_to IS NULL].outV().size()    AS sprint_count, " +
            "out('TARGETS_PRODUCT').code       AS products " +
            "FROM KnowMilestone " +
            // CONTAINS, а не [0] = : веха может целить в несколько продуктов,
            // обход отдаёт СПИСОК, и сравнение по первому показало бы
            // многосвязную веху под одним случайным продуктом.
            "WHERE out('TARGETS_PRODUCT').code CONTAINS :code",
            List.of("code"), Map.of(), " ORDER BY week, milestone_id");

        // Спринты продукта ВНЕ вех — то самое «что забыли поставить в план»,
        // ответа на которое сегодня нет вовсе.
        //
        // Отдельным срезом, а не числом внутри roadmap, и это не оформление:
        // счётчик отвечает «сколько», а спросить надо «какие». Пустая карта при
        // ненулевом хвосте — законный и важный ответ (замерено на MINILORE: все
        // 13 его спринтов не привязаны ни к одной вехе), и число «0 вех» само по
        // себе неотличимо от «продукта не существует» — а список отличим.
        slice("roadmap_unplanned",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('BELONGS_TO').component_id AS components " +
            "FROM KnowSprint " +
            "WHERE out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code " +
            "AND outE('TARGETS_MILESTONE')[valid_to IS NULL].inV().size() = 0",
            List.of("code"), Map.of(), " ORDER BY sprint_id");

        // ── §4 Search — сквозной, по FULL_TEXT-индексам (SRCH-01, ADR-LORE-033) ─
        // Каждая ветка — ОДИН вызов SEARCH_INDEX('ftИмя', …) по именованному
        // мультиполевому индексу из реестра FT_INDEXES (V11/V12): FETCH FROM INDEX
        // вместо прежнего SCAN на ILIKE. Плюс id ILIKE — точечный поиск по
        // идентификатору («ADR-LORE-033») токенным поиском не заменяется.
        //
        // Форма запроса `q q*` (OR по умолчанию) — ОБА слагаемых нужны:
        //   q   идёт через анализатор → морфология («релиза» находит «релиз»);
        //   q*  префикс для поиска-как-набираешь, но wildcard-термы Lucene
        //       НЕ анализирует, поэтому один только `q*` теряет морфологию.
        //
        // Тела живут в *Hist-типах — отдельные ветки по ОТКРЫТОЙ строке
        // (valid_to IS NULL) со схлопыванием к родителю через in('HAS_STATE');
        // без них «Остервальдер» в note_md задачи не находился вовсе.
        // DISTINCT схлопывает дубль «нашлось и в заголовке, и в теле».
        //
        // QualityGate — единственная ветка на ILIKE: FT-индекса на него нет
        // (в FT_INDEXES из QUALITY-скоупа только прогоны/рекомендации);
        // добавление индекса = новый шаг миграции, не в этой задаче.
        // Ранжирования здесь нет по построению ($score теряется в unionall) —
        // релевантность отдаёт /lore/search (SRCH-05).
        //
        // ДЕПРЕЦИРОВАН (SRCH-08, 2026-07-21). Последний потребитель внутри
        // приложения — палитра шапки — переведён на GET /lore/search; в `src/`
        // вызовов этого слайса не осталось ни одного.
        //
        // Оставлен, а не удалён, СОЗНАТЕЛЬНО. ADR-LORE-033 обещал снять его
        // «после перевода потребителей», но потребители бывают и снаружи —
        // шлюз, скрипты, чужие сессии. Тихо отобранный эндпоинт — худший способ
        // узнать о зависимости: она проявится 404-ом у того, кто про эту правку
        // не знал. Удаление — отдельным шагом, после проверки логов обращений.
        //
        // 2026-08-04: SEARCH_INDEX(...) убран из всех веток. Причина —
        // ArcadeDB/arcadedb#4732 (см. LoreFtIndexHealth): FULL_TEXT-индекс,
        // хвост которого ушёл в бакетный подындекс, кидает NPE именно на
        // ПРЕФИКСНЫХ запросах (`term*`) — ровно ту форму, что слала эта ветка.
        // NPE всплывал наружу как 502 LORE_UPSTREAM на любой вызов, если хотя
        // бы один из ~18 задействованных индексов был в этом состоянии.
        // У этого слайса и так нет ранжирования (см. выше — оно у /lore/search),
        // поэтому лечение — не health-gating (это живёт в LoreSearchResource
        // для актуального поиска), а снятие самого источника падения: ILIKE
        // по тем же полям, что раньше индексировал SEARCH_INDEX (реестр
        // FT_INDEXES, LoreSchemaMigrations), без морфологии, зато не падает
        // НИКОГДА, независимо от состояния индексов. Первая редакция этой
        // правки по ошибке обрезала не только морфологию, а вообще все поля
        // кроме id — восстановлено по точному списку полей каждого индекса.
        slice("search",
            "SELECT DISTINCT type, ref_id, title FROM " +
            "(SELECT expand(unionall($a, $ah, $s, $sh, $p, $ph, $t, $th, $q, $r, $rh, $d, $c, $qn, $u, $pn, $gn, $jb, $ac)) LET " +
            "$a = (SELECT 'adr' AS type, adr_id AS ref_id, name AS title FROM KnowADR " +
            "      WHERE adr_id ILIKE ('%' + :pattern + '%') OR name ILIKE ('%' + :pattern + '%') LIMIT 15), " +
            "$ah = (SELECT 'adr' AS type, in('HAS_STATE').adr_id[0] AS ref_id, in('HAS_STATE').name[0] AS title " +
            "      FROM KnowADRHist WHERE valid_to IS NULL AND (" +
            "      context_md ILIKE ('%' + :pattern + '%') OR decision_md ILIKE ('%' + :pattern + '%') " +
            "      OR consequences_md ILIKE ('%' + :pattern + '%')) LIMIT 15), " +
            "$s = (SELECT 'spec' AS type, spec_id AS ref_id, title FROM KnowSpec " +
            "      WHERE spec_id ILIKE ('%' + :pattern + '%') OR title ILIKE ('%' + :pattern + '%') LIMIT 15), " +
            "$sh = (SELECT 'spec' AS type, in('HAS_STATE').spec_id[0] AS ref_id, in('HAS_STATE').title[0] AS title " +
            "      FROM KnowSpecHist WHERE valid_to IS NULL " +
            "      AND content_md ILIKE ('%' + :pattern + '%') LIMIT 15), " +
            "$p = (SELECT 'sprint' AS type, sprint_id AS ref_id, coalesce(title, name) AS title FROM KnowSprint " +
            "      WHERE sprint_id ILIKE ('%' + :pattern + '%') OR coalesce(title, name) ILIKE ('%' + :pattern + '%') " +
            "      OR context_md ILIKE ('%' + :pattern + '%') LIMIT 15), " +
            "$ph = (SELECT 'sprint' AS type, in('HAS_STATE').sprint_id[0] AS ref_id, coalesce(in('HAS_STATE').title[0], in('HAS_STATE').name[0]) AS title " +
            "      FROM KnowSprintHist WHERE valid_to IS NULL AND (" +
            "      context_md ILIKE ('%' + :pattern + '%') OR outcome_md ILIKE ('%' + :pattern + '%')) LIMIT 15), " +
            "$t = (SELECT 'task' AS type, task_uid AS ref_id, title FROM KnowTask " +
            "      WHERE task_uid ILIKE ('%' + :pattern + '%') OR title ILIKE ('%' + :pattern + '%') LIMIT 15), " +
            "$th = (SELECT 'task' AS type, in('HAS_STATE').task_uid[0] AS ref_id, in('HAS_STATE').title[0] AS title " +
            "      FROM KnowTaskHist WHERE valid_to IS NULL " +
            "      AND note_md ILIKE ('%' + :pattern + '%') LIMIT 15), " +
            "$q = (SELECT 'quality_gate' AS type, qg_id AS ref_id, name AS title FROM QualityGate " +
            "      WHERE qg_id ILIKE ('%' + :pattern + '%') OR name ILIKE ('%' + :pattern + '%') " +
            "      OR content_md ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            "$r = (SELECT 'runbook' AS type, runbook_id AS ref_id, name AS title FROM KnowRunbook " +
            "      WHERE runbook_id ILIKE ('%' + :pattern + '%') OR name ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            "$rh = (SELECT 'runbook' AS type, in('HAS_STATE').runbook_id[0] AS ref_id, in('HAS_STATE').name[0] AS title " +
            "      FROM KnowRunbookHist WHERE valid_to IS NULL " +
            "      AND content_md ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            "$d = (SELECT 'doc' AS type, doc_id AS ref_id, title FROM KnowDoc " +
            "      WHERE doc_id ILIKE ('%' + :pattern + '%') OR title ILIKE ('%' + :pattern + '%') " +
            "      OR content_md_en ILIKE ('%' + :pattern + '%') " +
            "      OR content_md_ru ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            "$c = (SELECT 'decision' AS type, decision_id AS ref_id, title FROM KnowDecision " +
            "      WHERE decision_id ILIKE ('%' + :pattern + '%') OR title ILIKE ('%' + :pattern + '%') " +
            "      OR body_md ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            // Вопросы раньше не искались ВООБЩЕ, хотя ftKnowQuestion существует —
            // реестр ОВ был невидим для единого окна.
            "$qn = (SELECT 'question' AS type, question_id AS ref_id, title FROM KnowQuestion " +
            "      WHERE question_id ILIKE ('%' + :pattern + '%') OR title ILIKE ('%' + :pattern + '%') " +
            "      OR body_md ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            // ── продуктовый слой (ADR-LORE-022/032) ──
            // PL-28: ветка одна — фича стала корневым сценарием того же типа.
            "$u = (SELECT 'use_case' AS type, uc_id AS ref_id, title FROM KnowUseCase " +
            "      WHERE uc_id ILIKE ('%' + :pattern + '%') OR title ILIKE ('%' + :pattern + '%') " +
            "      OR body_md ILIKE ('%' + :pattern + '%') OR context_md ILIKE ('%' + :pattern + '%') " +
            "      OR scenario_md ILIKE ('%' + :pattern + '%') OR acceptance_md ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            "$pn = (SELECT 'pain' AS type, pain_id AS ref_id, title FROM KnowPain " +
            "      WHERE pain_id ILIKE ('%' + :pattern + '%') OR title ILIKE ('%' + :pattern + '%') " +
            "      OR body_md ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            "$gn = (SELECT 'gain' AS type, gain_id AS ref_id, title FROM KnowGain " +
            "      WHERE gain_id ILIKE ('%' + :pattern + '%') OR title ILIKE ('%' + :pattern + '%') " +
            "      OR body_md ILIKE ('%' + :pattern + '%') OR metric_md ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            "$jb = (SELECT 'job' AS type, job_id AS ref_id, title FROM KnowJob " +
            "      WHERE job_id ILIKE ('%' + :pattern + '%') OR title ILIKE ('%' + :pattern + '%') " +
            "      OR body_md ILIKE ('%' + :pattern + '%') LIMIT 10), " +
            "$ac = (SELECT 'actor' AS type, actor_id AS ref_id, name AS title FROM KnowProjectActor " +
            "      WHERE actor_id ILIKE ('%' + :pattern + '%') OR name ILIKE ('%' + :pattern + '%') " +
            "      OR body_md ILIKE ('%' + :pattern + '%') LIMIT 10))",
            List.of("pattern"), Map.of(), "");

        // ── §5 Plan ──────────────────────────────────────────────────────────
        slice("plan_config",
            "SELECT config_id, w0_date, weeks_total FROM PlanConfig WHERE config_id = 'default'");

        slice("plan_tracks",
            // V89: тип трека — код справочника area на самой вершине (OF_TYPE → TrackType снят).
            "SELECT track_id, label, area AS type " +
            "FROM PlanTrack ORDER BY track_id",
            List.of(), Map.of(), "");

        // S4-24 (SPRINT_UXR_S4_UI_SHELL_LISTS/S4-24): выпадающий список «Трек» паспорта спринта в форме {code, title},
        // как у прочих полей с выбором. MDL-13: вершины KnowTrack модели 1.18; на старой схеме — PlanTrack
        // (ModelSchemaAdapter.legacyTypes, те же поля track_id, label, area).
        slice(LoreSprintTracks.SLICE, LoreSprintTracks.SLICE_SQL, List.of(), Map.of(), "");

        // MDL-13 (владелица 20.11.2026: «трек как веха но меньше паспорт ему тоже сделай»): паспорт трека — запись и
        // спринты на треке С ИСТОРИЕЙ: спринт, который сейчас на треке (ребро ON_TRACK, без ребра — прежняя строка
        // версии), и спринт, который ушёл (закрытое ребро). period — «название · пришёл — ушёл | сейчас» по рёбрам
        // к ЭТОМУ треку (первое ребро — приход, последнее — уход); на старой схеме рёбер нет — period пуст.
        slice("track_by_id",
            "SELECT track_id, label, area FROM KnowTrack WHERE track_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");
        // edge-history: спринты на треке — и закрытые рёбра (valid_to), это история трека.
        slice("track_sprints",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            CHILD_SPRINT_COLS + ", " +
            "CASE WHEN outE('ON_TRACK')[@in.track_id = :id].size() > 0 THEN format('%s · %s — %s', coalesce(title, name, sprint_id), " +
            "first(outE('ON_TRACK')[@in.track_id = :id].valid_from).asString().left(10), " +
            "ifnull(last(outE('ON_TRACK')[@in.track_id = :id].valid_to).asString().left(10), 'сейчас')) ELSE null END AS period " +
            "FROM KnowSprint WHERE (outE('ON_TRACK')[valid_to IS NULL OR valid_to IS NOT NULL].@in.track_id CONTAINS :id OR " +
            SprintTrack.TRACK_ID + " = :id)",
            List.of("id"), Map.of(), " ORDER BY sprint_id");

        slice("plan_sections",
            "SELECT section_id, label, start_week, end_week, color FROM PlanSection ORDER BY start_week");

        // SPRINT_PLANITEM_RETIRE/T-14: plan_items removed — PlanItem is retired
        // (LorePlanBoard.tsx now reads the `sprints` slice directly, T-12/T-13).
        // Historical PlanItem/PlanItemHist/StatusPlanItem data archived to
        // docs/archive/planitem_archive_20260704.json before the type drop.

        slice("plan_checkpoints",
            "SELECT checkpoint_id, label, desc_md, " +
            "out('ON_MILESTONE').milestone_id[0] AS milestone " +
            "FROM PlanCheckpoint ORDER BY checkpoint_id");

        slice("plan_versions",
            "SELECT version_id, version_date, changelog_md FROM PlanVersion ORDER BY version_date DESC");

        // Git projects — for the T43 multi-project picker (question/decision forms).
        slice("git_projects",
            "SELECT slug, name, short_code, short_title, short_title_en, short_title_pl, default_branch, is_private, hosts FROM KnowGitProject ORDER BY slug");

        // ── §6 Components ────────────────────────────────────────────────────
        slice("components",
            "SELECT component_id, full_name, area, parent_id, game_icon, owner, team, " +
            // Свежесть (S4-MODEL-TYPES): у компонента ни истории, ни даты — только отметка
            // updated_at путей записи; у компонентов, не правленных после неё, changed_at пуст.
            changedAtSql("updated_at") + ", " +
            "in('PARENT_OF').component_id AS children, " +
            "out('USES').tech_id AS tech, " +
            "in('BELONGS_TO')[adr_id IS NOT NULL].size()    AS adr_count, " +
            "out('DOCUMENTED_IN').size()                    AS spec_count, " +
            "in('BELONGS_TO')[qg_id IS NOT NULL].size()     AS qg_count, " +
            "in('BELONGS_TO')[sprint_id IS NOT NULL].size() AS sprint_count, " +
            // Git projects this component touches, via its sprints
            // (Component ← BELONGS_TO ← KnowSprint → BELONGS_TO_PROJECT → KnowGitProject).
            "in('BELONGS_TO')[@this INSTANCEOF 'KnowSprint'].out('BELONGS_TO_PROJECT').slug AS git_projects, " +
            // S4-PRODUCT-HILITE: продукты компонента — по ним v2 красит записи цветом продукта.
            "out('IN_PRODUCT').code AS products " +
            "FROM LoreComponent",
            List.of(),
            new LinkedHashMap<>(Map.of("root", " WHERE parent_id = :root")),
            " ORDER BY full_name");

        slice("component",
            "SELECT component_id, full_name, area, parent_id, game_icon, owner, team, " +
            "in('PARENT_OF').component_id   AS sub_components, " +
            "out('USES').tech_id            AS tech, " +
            "in('BELONGS_TO')[adr_id IS NOT NULL].adr_id  AS adrs, " +
            "out('DOCUMENTED_IN').spec_id   AS specs, " +
            // Слово владелицы 11.11 («связь с компонентами пропала»): всё, что пути записи
            // привязывают к компоненту ребром BELONGS_TO, — для вкладок паспорта v2 (как в v1:
            // QG · Знания · Сценарии). belonging_specs — спеки, у которых есть только ребро
            // спека → компонент (без DOCUMENTED_IN); паспорт сводит их со specs. Отбор — по
            // классу вершины, а не по наличию поля: qg_id носит не только QualityGate (счётчик
            // qg_count у HND — 10, а гейтов компонента — 4).
            "in('BELONGS_TO')[@this INSTANCEOF 'KnowSpec'].spec_id         AS belonging_specs, " +
            "in('BELONGS_TO')[@this INSTANCEOF 'KnowDecision'].decision_id AS decisions, " +
            "in('BELONGS_TO')[@this INSTANCEOF 'KnowQuestion'].question_id AS questions, " +
            "in('BELONGS_TO')[@this INSTANCEOF 'KnowUseCase'].uc_id        AS features, " +
            "in('BELONGS_TO')[@this INSTANCEOF 'KnowDoc'].doc_id           AS docs, " +
            "in('BELONGS_TO')[@this INSTANCEOF 'QualityGate'].qg_id        AS qgs, " +
            // 11.11 (полнота модели рёбер): продукты компонента (product_link rel:component).
            "out('IN_PRODUCT').code AS products " +
            "FROM LoreComponent WHERE component_id = :id",
            List.of("id"), Map.of(), "");

        // D-2026-MIG-REPOSITORY-ORGANIZATION (владелица 19.11.2026, прототип принят «делаем пока так»):
        // репозиторий — отдельный объект (хост + владелец + имя); проект → один основной (HAS_REPOSITORY
        // role primary), компонент → свой (COMPONENT_REPOSITORY), зеркало и «использует» — связи репозиториев.
        // Ключ записи — адрес (url): у репозитория нет своего кода, адрес уникален (индекс переноса).
        slice("repositories", REPO_COLUMNS + "FROM KnowRepository ORDER BY full_path");
        slice("repo_by_id", REPO_COLUMNS + "FROM KnowRepository WHERE url = :id LIMIT 1", List.of("id"), Map.of(), "");
        // Репозитории проекта: свой основной + репозитории компонентов его продуктов
        // (компонент → IN_PRODUCT → продукт → BELONGS_TO_PROJECT → проект; перегруппировка переносит эти рёбра на опору).
        slice("repos_of_project", REPO_COLUMNS + "FROM KnowRepository WHERE in('HAS_REPOSITORY').slug CONTAINS :project "
            + "OR in('COMPONENT_REPOSITORY').out('IN_PRODUCT').out('BELONGS_TO_PROJECT').slug CONTAINS :project "
            + "ORDER BY full_path", List.of("project"), Map.of(), "");
        slice("repos_of_component", REPO_COLUMNS + "FROM KnowRepository WHERE in('COMPONENT_REPOSITORY').component_id CONTAINS :id ORDER BY full_path",
            List.of("id"), Map.of(), "");
        slice("organizations", "SELECT org_id, name FROM KnowOrganization ORDER BY org_id");
        slice("org_by_id", "SELECT org_id, name FROM KnowOrganization WHERE org_id = :id LIMIT 1", List.of("id"), Map.of(), "");

        // Спринты компонента — по ребру BELONGS_TO (спринт → компонент), и только по нему.
        // S4-29: был LIMIT 30 и подбор по имени (sprint_id LIKE '%ключ%' у спринтов без
        // ребра) — 30 читалось как «все», а чужой спринт с похожим именем — как свой.
        // Потолка нет: страница — общими limit/offset (SE-01, page.total/has_more).
        // ORDER BY — в хвосте: скоуп вставляется перед ним.
        // SPRINT_UXR_S9_SCALE_OPT/S9-05 (часть B): «таблица детей» вехи — её спринты с названием и
        // статусом. Раньше вкладка шла сырыми id из milestone_by_id (название = id, статус пуст).
        slice("milestone_sprints",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " + CHILD_SPRINT_COLS + " " +
            "FROM KnowSprint WHERE outE('TARGETS_MILESTONE')[valid_to IS NULL].inV().milestone_id CONTAINS :mid",
            List.of("mid"), Map.of(), " ORDER BY sprint_id DESC");

        slice("component_sprints",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('BELONGS_TO').component_id AS components, " +
            "in('IMPLEMENTED_IN_RELEASE').release_id AS release_ids, in('IMPLEMENTED_IN_RELEASE').release_uid AS release_uids, " + CHILD_SPRINT_COLS + " " +
            "FROM KnowSprint WHERE out('BELONGS_TO').component_id CONTAINS :cid",
            // pattern — принимается и НИЧЕГО не фильтрует: v1 (src/, выкатывается вручную) ещё
            // шлёт его, и отказ «unknown param» уронил бы вкладку спринтов в v1.
            List.of("cid"), Map.of("pattern", ""), " ORDER BY sprint_id DESC");

        // S4-29: задачи компонента (ребро TAGGED_WITH задача → компонент) — вкладка «Задачи»
        // паспорта компонента. Та же облегчённая проекция, что open_tasks; потолка нет.
        slice("component_tasks",
            "SELECT task_uid, task_id, title, task_type, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('PART_OF').sprint_id[0] AS sprint_id, " + CHILD_TASK_COLS + " " +
            "FROM KnowTask WHERE out('TAGGED_WITH').component_id CONTAINS :cid",
            List.of("cid"), Map.of(), " ORDER BY sprint_id DESC, task_uid");

        // ── Паспорт проекта (SPRINT_UXR_S4_UI_SHELL_LISTS/S4-29, решение 53а) ──────
        // Главный срез и вкладки Спринты · Компоненты · ADR · Релизы · Люди и агенты. У вкладок
        // потолка нет: страница — общими limit/offset (SE-01, page.total/has_more), фасад отдаёт
        // первую порцию и сверх неё data_state truncated с total. ORDER BY — в хвосте: скоуп
        // вставляется перед ним. Параметр у всех один — project (slug), как у прочих срезов.
        slice("project_by_id",
            "SELECT slug, name, short_code, short_title, short_title_en, short_title_pl, title_en, title_pl, " +
            "description, description_en, description_pl, default_branch, is_private, hosts, aliases FROM KnowGitProject WHERE slug = :project",
            List.of("project"), Map.of(), "");
        slice("project_sprints",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " + CHILD_SPRINT_COLS + " " +
            "FROM KnowSprint WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY sprint_id DESC");
        // Компонент достигает проекта только через свои спринты — тем же путём, что колонка
        // git_projects у среза components (Component ← BELONGS_TO ← KnowSprint → BELONGS_TO_PROJECT).
        // Слово владелицы 11.11 («у проекта всё показывать, что связано напрямую»): + компоненты с
        // прямым ребром компонент → проект (его ставит бэкфилл scripts/backfill-component-project.js).
        slice("project_components",
            "SELECT component_id, full_name FROM LoreComponent " +
            "WHERE (in('BELONGS_TO')[sprint_id IS NOT NULL].out('BELONGS_TO_PROJECT').slug CONTAINS :project " +
            "OR out('BELONGS_TO_PROJECT').slug CONTAINS :project)",
            List.of("project"), Map.of(), " ORDER BY component_id");
        slice("project_adrs",
            "SELECT adr_id, name, status FROM KnowADR WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY adr_id");
        // Ключ паспорта релиза — release_uid «проект#тег»; свежие сверху, как у releases.
        slice("project_releases",
            "SELECT release_uid, release_id, git_tag AS version, git_tag, release_date " +
            "FROM KnowRelease WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY release_date DESC, release_uid DESC");
        // Люди — по назначению роли (HAS_PROJECT_ROLE, AL-82: источник истины о правах — граф),
        // строка на ребро: роль лежит на нём.
        // ── SPRINT_UXR_S9_SCALE_OPT/S9-05 A: паспорта человека и агента ──────────────────────
        // Шапка — одна строка; дети — задачи, где у него ОТКРЫТАЯ роль (ребро ROLE_HELD_BY без
        // valid_to: сменённый исполнитель в детях не числится). Человека задача знает по
        // display_name, но ключ паспорта — kc_sub (имя меняется, sub нет; так ведёт и проект).
        slice("user_by_id",
            "SELECT kc_sub, display_name, coalesce(login, display_name) AS login, name_source, " +
            "outE('HAS_PROJECT_ROLE')[valid_to IS NULL].inV().slug AS projects " +
            "FROM KnowUser WHERE kc_sub = :kc_sub",
            List.of("kc_sub"), Map.of(), "");
        slice("agent_by_id",
            "SELECT actor_id, name, client_id, agent_role, harness, " +
            // owner_name — рядом с owner по той же причине, что и в срезе agents: в паспорте агента владелец
            // тоже показывался опознавателем. Поля два, и оба нужны: имя человеку, kc_sub — отбору и связям.
            "out('OWNED_BY').kc_sub[0] AS owner, out('OWNED_BY').display_name[0] AS owner_name, " +
            "out('BELONGS_TO_PROJECT').slug AS projects " +
            // AP-PEOPLE-PAGE (21.11.2026): автор-агент в ленте и истории записан учёткой (client_id) — карточка агента
            // открывается и по ней, а не только по actor_id.
            "FROM KnowActor WHERE kind = 'agent' AND (actor_id = :id OR client_id = :id)",
            List.of("id"), Map.of(), "");
        // Списки разделов «Люди» и «Агенты» v2: строка — человек (агент) и его проекты.
        slice("users",
            "SELECT kc_sub, display_name, coalesce(login, display_name) AS login, name_source, " +
            "outE('HAS_PROJECT_ROLE')[valid_to IS NULL].inV().slug AS projects FROM KnowUser",
            List.of(), Map.of(), " ORDER BY display_name");
        // owner_name — имя владельца человеческими словами; owner (kc_sub) остаётся для отбора и связей.
        // Находка владелицы 22.11.2026: в колонке «Владелец» раздела «Агенты» стояли одни uuid, хотя имя в графе
        // есть и его отдаёт соседний срез agent_owners. Это была не потеря владельцев, а невыбранное поле.
        slice("agents",
            "SELECT actor_id, name, client_id, agent_role, harness, " +
            "out('OWNED_BY').kc_sub[0] AS owner, out('OWNED_BY').display_name[0] AS owner_name, " +
            "out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowActor WHERE kind = 'agent'",
            List.of(), Map.of(), " ORDER BY actor_id");
        slice("user_tasks",
            "SELECT task_uid, task_id, title, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('PART_OF').sprint_id[0] AS sprint_id, " + CHILD_TASK_COLS + " " +
            "FROM KnowTask WHERE outE('ROLE_HELD_BY')[valid_to IS NULL].inV().kc_sub CONTAINS :kc_sub",
            List.of("kc_sub"), Map.of(), " ORDER BY sprint_id DESC, task_uid");
        slice("agent_tasks",
            "SELECT task_uid, task_id, title, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('PART_OF').sprint_id[0] AS sprint_id, " + CHILD_TASK_COLS + " " +
            "FROM KnowTask WHERE outE('ROLE_HELD_BY')[valid_to IS NULL].inV().actor_id CONTAINS :id",
            List.of("id"), Map.of(), " ORDER BY sprint_id DESC, task_uid");
        slice("project_people",
            "SELECT @out.kc_sub AS kc_sub, @out.display_name AS display_name, role " +
            "FROM HAS_PROJECT_ROLE WHERE valid_to IS NULL AND @in.slug = :project",
            List.of("project"), Map.of(), " ORDER BY kc_sub");
        // Агенты — акторы kind='agent', чей владелец имеет роль в проекте (агент сам роли в
        // проекте не получает: он действует от имени владельца, AL-104).
        slice("project_agents",
            "SELECT actor_id, name, client_id, agent_role FROM KnowActor " +
            "WHERE kind = 'agent' AND out('OWNED_BY').outE('HAS_PROJECT_ROLE')[valid_to IS NULL].inV().slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY actor_id");
        // Слово владелицы 11.11: «у проекта всё показывать, что связано напрямую» — всё, что
        // привязано к проекту своим ребром BELONGS_TO_PROJECT, по вкладке на тип конца. Форма та же:
        // без потолка, порядок в хвосте, скоуп вставляется перед ним.
        slice("project_specs",
            "SELECT spec_id, title, out('HAS_STATE').status[0] AS status " +
            "FROM KnowSpec WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY spec_id");
        slice("project_decisions",
            "SELECT decision_id, title, status_raw " +
            "FROM KnowDecision WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY decision_id");
        slice("project_questions",
            "SELECT question_id, title, status " +
            "FROM KnowQuestion WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY question_id");
        slice("project_features",
            "SELECT uc_id, title, status, goal_level " +
            "FROM KnowUseCase WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY uc_id");
        slice("project_docs",
            "SELECT doc_id, title, kind " +
            "FROM KnowDoc WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY doc_id");
        slice("project_runbooks",
            "SELECT runbook_id, name, area " +
            "FROM KnowRunbook WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY runbook_id");
        // Роли продукта (KnowProjectActor) и агенты (KnowActor), привязанные к проекту своим ребром.
        slice("project_actors",
            "SELECT actor_id, name, kind " +
            "FROM KnowProjectActor WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY actor_id");
        slice("project_bound_agents",
            "SELECT actor_id, name, client_id, agent_role " +
            "FROM KnowActor WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY actor_id");
        slice("project_files",
            "SELECT project, file_path, summary_md " +
            "FROM KnowFile WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY file_path");
        slice("project_prs",
            "SELECT pr_uid, pr_number, title, merged_at, url " +
            "FROM KnowPR WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project",
            List.of("project"), Map.of(), " ORDER BY pr_number DESC, pr_uid");

        // ── §6b Specs (KnowSpec — technical articles, LAL-32) ────────────────
        // content_md/summary live on the SCD2 state row (KnowSpecHist), like ADRs.
        // The vertex `title` is backfilled from the content_md heading by
        // lore-backfill-spec-titles.mjs; until then the frontend falls back to spec_id.
        slice("specs",
            "SELECT spec_id, title, file_path, " +
            changedAtSql(FIRST_STATE_FROM_SQL) + ", " +
            "COALESCE(in('DOCUMENTED_IN').component_id[0], out('BELONGS_TO').component_id[0]) AS component_id, " +
            // DS-2: версия/аннотация/статус — с открытой ревизии, как в spec_by_id.
            // Без них сверка реестра шла N вызовами spec_by_id.
            "COALESCE(out('HAS_STATE').version[0], version) AS version, " +
            "out('HAS_STATE')[valid_to IS NULL].summary[0] AS summary, " +
            "out('HAS_STATE').status[0]  AS status, " + // DS-4
            // AL-96: ребро писалось (spec_link rel=project) с самого начала, но
            // ни один слайс его не читал — привязку можно было создать и нельзя
            // увидеть. Самый тихий вид разрыва: write-path «работает», данных нет.
            "out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowSpec",
            List.of(),
            new LinkedHashMap<>(Map.of(
                // CONTAINS, не [0]: у сущности может быть несколько BELONGS_TO, а
                // порядок рёбер — это порядок вставки, не приоритет. Сравнение с [0]
                // делало сущность видимой только под одним произвольным компонентом.
                "component", " WHERE out('BELONGS_TO').component_id CONTAINS :component",
                // DS-2: был 400 «unknown param: project».
                "project", " WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project")),
            " ORDER BY spec_id");

        slice("spec_by_id",
            "SELECT spec_id, title, file_path, " +
            "COALESCE(out('HAS_STATE').content_md[0], content_md) AS content_md, " +
            "out('HAS_STATE')[valid_to IS NULL].summary[0]        AS summary, " +
            "COALESCE(out('HAS_STATE').version[0], version)       AS version, " +
            "out('HAS_STATE').status[0]                           AS status, " + // DS-4
            "out('HAS_STATE').valid_from[0]                       AS valid_from, " +
            "COALESCE(in('DOCUMENTED_IN').component_id[0], out('BELONGS_TO').component_id[0]) AS component_id, " +
            "out('BELONGS_TO_PROJECT').slug AS projects " + // AL-96
            "FROM KnowSpec WHERE spec_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");

        // SPRINT_TECH_REGISTRY / TR-06+08: version+date+license registry per
        // component tech, stored as one KnowSpec per (component, tech) —
        // spec_id "SPEC-TECH-<COMPONENT>-<TECH>", title=tech name, version=tech
        // version, content_md=small bullet list (release_date/license/source/
        // checked_at). Piggybacks the existing /lore/spec upsert path (no new
        // backend write endpoint needed) — this slice is the read side.
        slice("tech_registry",
            "SELECT spec_id, title AS tech_name, " +
            // Аудит времени 10.11: версия, тело и «проверено» — из ОТКРЫТОЙ версии, а не из
            // первого ребра: смена номера открывает версию (LoreSpecResource), и [0] без
            // фильтра отдавал бы строку, выбранную порядком рёбер.
            TECH_OPEN_COLUMNS +
            changedAtSql(FIRST_STATE_FROM_SQL) + ", " +
            "COALESCE(in('DOCUMENTED_IN').component_id[0], out('BELONGS_TO').component_id[0]) AS component_id " +
            "FROM KnowSpec WHERE spec_id LIKE 'SPEC-TECH-%'",
            List.of(),
            new LinkedHashMap<>(Map.of(
                // CONTAINS, не [0] — см. комментарий в слайсе adrs.
                "component", " AND (out('BELONGS_TO').component_id CONTAINS :component OR component_id = :component)")),
            " ORDER BY spec_id");

        // S4-V2-SECTIONS: паспорт технологии — та же строка, что у tech_registry, по ключу.
        // Фильтр SPEC-TECH- остаётся: обычная спека — не технология, и паспорт «технологии»
        // по её id отвечает 404, а не показывает спеку под чужим видом.
        slice("tech_by_id",
            "SELECT spec_id, title AS tech_name, " +
            TECH_OPEN_COLUMNS +
            "COALESCE(in('DOCUMENTED_IN').component_id[0], out('BELONGS_TO').component_id[0]) AS component_id " +
            "FROM KnowSpec WHERE spec_id LIKE 'SPEC-TECH-%' AND spec_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");

        // ── §7 History (SCD2 chain) ───────────────────────────────────────────
        // AL-30: + все версионируемые поля ревизии (тела, план, pr_refs) — история
        // перестаёт показывать «только статус» при полных данных под ней.
        slice("history_sprint",
            "SELECT valid_from, valid_to, content_hash, source_commit, status_raw, " +
            "priority, planned_start_date, planned_end_date, track_id, pr_refs, " +
            "context_md, outcome_md, version_kind " +
            "FROM KnowSprintHist WHERE in('HAS_STATE').sprint_id CONTAINS :id ORDER BY valid_from",
            List.of("id"), Map.of(), "");

        // AL-30: тот же паттерн для задач — раньше был только status_raw через
        // task_done_dates/task_starts (агрегатные min/max, не полная цепочка).
        // effort_days и note_md версионируются (task_set пишет их в открытую
        // HAS_STATE), но ни один слайс не отдавал цепочку ревизий целиком.
        // B9: CONTAINS, не [0] = — см. adr_history.
        slice("history_task",
            "SELECT valid_from, valid_to, content_hash, source_commit, status_raw, " +
            // MT-NOTE-APPEND п.3: version_kind = 'text' — версия открыта правкой текста, статус тот же.
            "effort_days, note_md, version_kind " +
            "FROM KnowTaskHist WHERE in('HAS_STATE').task_uid CONTAINS :id ORDER BY valid_from",
            List.of("id"), Map.of(), "");

        // Bulk: every sprint state row (scalar valid_from). Frontend takes the min
        // valid_from per sprint_id = real sprint start, for lead/cycle time.
        slice("sprint_starts",
            "SELECT in('HAS_STATE').sprint_id[0] AS sprint_id, valid_from " +
            "FROM KnowSprintHist WHERE valid_from IS NOT NULL ORDER BY valid_from",
            List.of(), Map.of(), "");

        // Sprints that ever passed through a BLOCKED state — for blocked/reopen rate.
        // Frontend dedups by sprint_id and divides by total sprints.
        // SPRINT_QG_REBUILD/QG-16: строка на СПРИНТ и только по открытой строке истории.
        // Прежний срез перебирал KnowSprintHist целиком — давал по строке на каждую
        // blocked-ревизию (дубли ×2/×3) и вечно числил заблокированным спринт, который
        // когда-то им был. Колонки — объяснение блокировки: текст (status_set reason),
        // незакрытые зависимости, открытые вопросы; их читает гейт QG-LORE-BLOCKED-REASON.
        // Аналитика (LoreAnalytics «Blocked rate») читает этот срез как «спринты, КОГДА-ЛИБО
        // бывшие заблокированными» — смысл сохранён, убраны только дубли: строка на спринт,
        // а не на каждую blocked-ревизию истории (было ×2/×3, по срезу нельзя было посчитать).
        slice("blocked_sprints",
            "SELECT sprint_id FROM KnowSprint WHERE out('HAS_STATE')[status_raw LIKE '%BLOCK%'].size() > 0",
            List.of(), Map.of(), " ORDER BY sprint_id");

        // Заблокированные СЕЙЧАС (открытая строка истории) — с объяснением блокировки.
        slice("blocked_sprints_reason",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "out('HAS_STATE')[valid_to IS NULL].status_raw[0] AS status_raw, " +
            "out('HAS_STATE')[valid_to IS NULL].block_reason[0] AS block_reason, " +
            "in('PART_OF').size() AS task_count, " +
            "outE('DEPENDS_ON')[valid_to IS NULL].inV().sprint_id AS deps, " +
            "outE('DEPENDS_ON')[valid_to IS NULL].inV()[out('HAS_STATE')[valid_to IS NULL AND (" +
                LoreStatusVocabulary.anySql("status_raw", "done", "cancelled") +
            ")].size() = 0].sprint_id AS open_deps, " +
            "in('RAISED_IN')[status <> 'closed'].question_id AS open_questions " +
            "FROM KnowSprint WHERE out('HAS_STATE')[valid_to IS NULL AND status_raw LIKE '%BLOCK%'].size() > 0",
            List.of(), Map.of(), " ORDER BY sprint_id");

        // Task done-transitions for throughput. valid_from = when task became DONE.
        // states = total HAS_STATE rows of the task: states>1 means real progression
        // (vs archived "born done" dump). Frontend also cuts pre-LORE import dates.
        //
        // AL-117: was `status_raw LIKE '%DONE%'` — English-only substring, same
        // bug class miniLORE found in their own status parser (2026-08-11):
        // status_raw is free text after the marker ("✅ MERGED", "✅ ЗАКРЫТ …"),
        // and DONE-only matching drops every Russian/synonym completion. Aligned
        // to the icon-prefix pattern already used by sprint_done_dates below.
        //
        // AL-119: task_uid added alongside task_id at miniLORE's request, backed
        // by their own measurement — 295 of 2470 distinct task_id codes (12%)
        // belong to more than one task (T-01 alone: 74 different tasks), and the
        // worst offenders are exactly the short generic codes ("T-01", "P-01"..
        // "P-04") most likely to show up here. task_id alone is not a safe join
        // key; task_uid (sprint_id + "/" + task_id) is unique, same field every
        // other task-facing slice (all_tasks, tasks_of_sprint) already carries.
        slice("task_done_dates",
            // MT-NOTE-APPEND п.3: дата закрытия — момент статуса (status_known_from), а не начало
            // открытой версии: правка заметки закрытой задачи открывает версию и сдвинула бы дату.
            // states (> 1 — реальная прогрессия) считает смены статуса, правки текста — нет.
            "SELECT in('HAS_STATE').task_uid[0] AS task_uid, in('HAS_STATE').task_id[0] AS task_id, " +
            "ifnull(status_known_from, valid_from) AS valid_from, " +
            "in('HAS_STATE').out('HAS_STATE')[version_kind IS NULL].size() AS states, " +
            "in('HAS_STATE').effort_days[0] AS effort_days, " +
            "in('HAS_STATE').bookkeeping[0] AS bookkeeping, " +
            // B9: state_owners — см. adr_history_all (> 1 — общая версия). Сравнение «.size() > 1» в проекции ArcadeDB не разбирает.
            "in('HAS_STATE').size() AS state_owners " +
            "FROM KnowTaskHist WHERE valid_to IS NULL " +
            "AND (" + DONE_STATUS_SQL + ") AND valid_from IS NOT NULL",
            List.of(), Map.of(), "");

        // Every task state row (scalar valid_from). Frontend takes min per task = created date,
        // for calendar duration (proxy «потраченного» в effort accuracy).
        slice("task_starts",
            // SE-08: task_uid — пара «спринт/код»; голый task_id неоднозначен (220 кодов в
            // нескольких спринтах). task_id оставлен для прежних читателей.
            // B9: state_owners — см. adr_history_all.
            "SELECT in('HAS_STATE').task_uid[0] AS task_uid, in('HAS_STATE').task_id[0] AS task_id, valid_from, " +
            "in('HAS_STATE').size() AS state_owners " +
            "FROM KnowTaskHist WHERE valid_from IS NOT NULL",
            List.of(), Map.of(), "");

        // task_created_dates — зеркало task_done_dates для события «заведена»
        // (ML-NEWS / запрос серверной сессии miniLORE): лента отдавала задачи
        // ТОЛЬКО закрытием, и день «закрыли 9, завели 10» читался как «убыло 9».
        // Создание = МИН valid_from по цепочке KnowTaskHist задачи (первое
        // состояние). task_uid (не task_id: хвост уникален лишь внутри спринта,
        // и без uid карточку не открыть) + sprint_id (отнести к проекту).
        // GROUP BY по подзапросу: одна строка на задачу с датой её появления.
        // Сырые строки истории задач (task_uid, sprint_id, valid_from) — «заведение»
        // = МИН valid_from по задаче, считается потребителем (в Java у /news), не в
        // SQL: ArcadeDB min() кастит строку-дату и падает (ClassCastException), а
        // GROUP BY не протаскивает неагрегированные поля из подзапроса (отдаёт
        // null). Сырой слайс надёжен; одна строка на задачу собирается на нашей
        // стороне. Зеркало task_starts, но с task_uid (уникален) и sprint_id.
        slice("task_created_dates",
            "SELECT in('HAS_STATE').task_uid[0] AS task_uid, " +
            "in('HAS_STATE').out('PART_OF').sprint_id[0] AS sprint_id, valid_from, " +
            // B9: state_owners — см. adr_history_all.
            "in('HAS_STATE').size() AS state_owners " +
            "FROM KnowTaskHist WHERE valid_from IS NOT NULL",
            List.of(), Map.of(), "");

        // Графики 19.11.2026 (предложение «добавляй графики», №2 CFD и №1 время цикла; дальше №4, №5):
        // ВСЕ версии статуса задач SCD2 с обоими концами — на них стоят накопительный поток и
        // время цикла. task_starts — моменты без статуса, task_done_dates — только открытая
        // DONE-версия, history_task — одна задача за запрос: ни одного не хватает.
        // version_kind = 'text' — версия открыта правкой текста, статус тот же (MT-NOTE-APPEND п.3).
        // Фильтры — двойным хопом через ребро (как у release_tasks_by_tag), без [0] в WHERE.
        slice("task_status_versions",
            "SELECT in('HAS_STATE').task_uid[0] AS task_uid, " +
            "in('HAS_STATE').out('PART_OF').sprint_id[0] AS sprint_id, " +
            "status_raw, valid_from, valid_to, version_kind " +
            "FROM KnowTaskHist WHERE valid_from IS NOT NULL",
            List.of(), new LinkedHashMap<>(Map.of(
                "sprint", " WHERE in('HAS_STATE').out('PART_OF').sprint_id CONTAINS :sprint",
                "project", " WHERE in('HAS_STATE').out('PART_OF').out('BELONGS_TO_PROJECT').slug CONTAINS :project")),
            "");

        // SPRINT_PLANITEM_RETIRE/T-23: history_plan_item removed — PlanItem is
        // deprecated (T-14) and this slice's only consumer (LoreEvolutionView.tsx)
        // was removed in T-22. Sprint plan-field history now lives on
        // KnowSprintHist, queryable via history_sprint.

        // ── §8 KnowDoc — HTML/MD document fragments (Phase 5 LAL-30) ────────
        // Schema added in Phase 5; slices registered now so the frontend can
        // query gracefully (returns [] until KnowDoc vertices are ingested).
        slice("docs",
            // parent_doc_id/sort_order/child_ids: DeepWiki-style page tree
            // (DOC_CHILD_OF edge, child→parent) — frontend builds the tree +
            // prev/next sequence client-side from these three fields, same
            // pattern as component/milestone facets elsewhere in this app.
            "SELECT doc_id, title, kind, has_ext_deps, sort_order, " +
            // DS-3: хеш и длина каждого тела — сверка корпуса одним вызовом,
            // без N вызовов doc_by_id (сами тела список не тянет).
            LoreDocBodyDigest.selectColumns() +
            "out('DOC_CHILD_OF').doc_id[0] AS parent_doc_id, " +
            "in('DOC_CHILD_OF').doc_id     AS child_ids, " +
            "out('BELONGS_TO').component_id[0] AS component_id, " +
            "out('IMPLEMENTED_IN').sprint_id AS sprint_ids, " +
            "out('BELONGS_TO_PROJECT').slug AS projects " + // AL-92: проектная ось
            "FROM KnowDoc",
            List.of(),
            new LinkedHashMap<>(Map.of(
                // CONTAINS, не [0]: у сущности может быть несколько BELONGS_TO, а
                // порядок рёбер — это порядок вставки, не приоритет. Сравнение с [0]
                // делало сущность видимой только под одним произвольным компонентом.
                "component", " WHERE out('BELONGS_TO').component_id CONTAINS :component",
                // Панель «Правила CLAUDE»: общий корпус KnowDoc уже упирается в
                // LIMIT 200, серверный фильтр гарантирует полноту выборки по kind.
                "kind", " WHERE kind = :kind",
                // DS-3: доки одного проекта — без выгрузки всего корпуса.
                "project", " WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project")),
            " ORDER BY doc_id");

        slice("doc_by_id",
            // NB: KnowDoc has no SCD2 write path (flat vertex, see KnowDocParser
            // comment) — no HAS_STATE edge is ever created, so valid_from is
            // always null today regardless of edge name. Named HAS_STATE for
            // consistency with every other *_by_id slice (was HAS_HIST, a type
            // never declared in the schema) in case doc history is added later.
            "SELECT doc_id, title, kind, has_ext_deps, content_html, content_md_en, content_md_ru, " +
            LoreDocBodyDigest.selectColumns() + // DS-3
            "sort_order, file_path, " + // S5-DOC-PASSPORT: поле «Файл» паспорта
            "out('DOC_CHILD_OF').doc_id[0] AS parent_doc_id, " +
            "in('DOC_CHILD_OF').doc_id     AS child_ids, " +
            "out('BELONGS_TO').component_id[0] AS component_id, " +
            "out('IMPLEMENTED_IN').sprint_id AS sprint_ids, " +
            // Проекты нужны не выдаче, а РЕШЕНИЮ об обнулении тела (BODY_SCOPED):
            // без них сервер не может ответить, есть ли у читателя роль там, где
            // документ числится. Поле заодно полезно само по себе.
            "out('BELONGS_TO_PROJECT').slug AS projects, " +
            "out('HAS_STATE').valid_from[0] AS valid_from " +
            "FROM KnowDoc WHERE doc_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");

        // ── §9 KnowRunbook (Phase 5 LAL-29) ─────────────────────────────────
        slice("runbooks",
            "SELECT runbook_id, name, area, date_created, " +
            "out('REFERENCES_ADR').adr_id AS adr_ids, " +
            "out('BELONGS_TO_PROJECT').slug AS projects " + // AL-92: проектная ось
            "FROM KnowRunbook",
            List.of(),
            new LinkedHashMap<>(Map.of(
                "area", " WHERE area = :area")),
            " ORDER BY runbook_id");

        slice("runbook_by_id",
            "SELECT runbook_id, name, area, date_created, " +
            "COALESCE(out('HAS_STATE').content_md[0], content_md) AS content_md, " +
            "out('HAS_STATE').valid_from[0] AS valid_from, " +
            "out('REFERENCES_ADR').adr_id AS adr_ids, " +
            // См. doc_by_id: проекты нужны решению об обнулении тела.
            "out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM KnowRunbook WHERE runbook_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");

        // ── §10 QualityGate (Phase 5 LAL-28) ─────────────────────────────────
        slice("quality_gates",
            "SELECT qg_id, name, description, out('BELONGS_TO').component_id[0] AS component_id, status, scope, last_run_status, date_created, sprint_id, content_md, " +
            "out('BELONGS_TO').component_id AS components, out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM QualityGate",
            List.of(),
            new LinkedHashMap<>(Map.of(
                "component", " WHERE out('BELONGS_TO').component_id CONTAINS :component")),
            " ORDER BY qg_id");

        slice("quality_gate_by_id",
            // MD-04 (второй заход по QG): паспорт гейта. Владелец — проект ребром BELONGS_TO_PROJECT
            // (ADR-LORE-053 D7), компонент — связью списком; retired_at и retired_reason пишет путь
            // записи при переходе в retired. component_id (первый) оставлен прежним читателям.
            "SELECT qg_id, name, description, out('BELONGS_TO').component_id[0] AS component_id, status, last_run_status, date_created, content_md, sprint_id, " +
            "retired_at, retired_reason, scope, " +
            "out('BELONGS_TO').component_id AS components, out('BELONGS_TO_PROJECT').slug AS projects " +
            "FROM QualityGate WHERE qg_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");

        slice("qg_metrics",
            // Все поля спеки LORE_SCHEMA_V12_NEW_TYPES: порог, единица, направление, последнее измерение, итог.
            "SELECT metric_id, name, threshold, unit, direction, current_value, status " +
            "FROM QGMetric WHERE in('MEASURED_BY').qg_id[0] = :qg_id",
            List.of("qg_id"), Map.of(), " LIMIT 100");

        slice("qg_job_tasks",
            "SELECT job_id, inv_id, severity, status, run_date, note_md " +
            "FROM QGJobTask WHERE qg_id = :qg_id ORDER BY run_date DESC",
            List.of("qg_id"), Map.of(), " LIMIT 200");

        slice("qg_recommendations",
            "SELECT rec_id, title, body_md, status, " +
            "in('PRODUCED').inv_id[0] AS inv_id, in('PRODUCED').severity[0] AS severity, " +
            "in('PRODUCED').qg_id[0] AS qg_id, " +
            "out('PROMOTED_TO').task_uid[0]                     AS promoted_task_uid, " +
            "out('PROMOTED_TO').out('PART_OF').sprint_id[0]     AS promoted_sprint_id " +
            "FROM QGRecommendation WHERE in('PRODUCED').qg_id CONTAINS :qg_id " +
            "ORDER BY status",
            List.of("qg_id"), Map.of(), "");

        // ── §10b QG dashboard slices (no required params) ─────────────────────
        slice("qg_violations",
            "SELECT job_id, inv_id, severity, status, run_date, note_md, qg_id, " +
            "out('BELONGS_TO').component_id[0] AS component_id " +
            "FROM QGJobTask WHERE status = 'open' ORDER BY run_date DESC",
            List.of(), Map.of(), " LIMIT 300");

        slice("qg_pending_recs",
            "SELECT rec_id, title, body_md, status, priority, severity, effort_days, " +
            "tags, out('BELONGS_TO').component_id[0] AS component_id, qg_id, inv_id, fix_cmd, how_to_verify " +
            "FROM QGRecommendation WHERE status = 'pending' ORDER BY priority ASC",
            List.of(), Map.of(), "");

        // All QG routine runs (latest first). Includes run_id for metric join.
        slice("qg_routine_runs",
            "SELECT run_id, routine_name, run_date, status, flags, started_at, finished_at " +
            "FROM ClRoutineRun WHERE routine_name LIKE 'qg-%' ORDER BY run_date DESC",
            List.of(), Map.of(), " LIMIT 200");

        // Latest metric snapshot per routine — one row per metric_key.
        slice("qg_metrics_latest",
            "SELECT routine_name, run_date, metric_key, value, unit, target, status " +
            "FROM ClRoutineMetric WHERE routine_name LIKE 'qg-%' ORDER BY routine_name, metric_key",
            List.of(), Map.of(), "");

        // All metrics for a specific run (detail panel).
        slice("qg_run_metrics",
            "SELECT metric_id, metric_key, value, unit, target, status, source " +
            "FROM ClRoutineMetric WHERE run_id = :run_id ORDER BY metric_key",
            List.of("run_id"), Map.of(), "");

        // ── §11 KnowTask standalone (Phase 5 LAL-31) ─────────────────────────
        // RM-P8: здесь было ВТОРОЕ объявление git_projects. Оно молча затирало
        // первое (§ выше, для формы выбора проекта) и отличалось отсутствием
        // поля is_private — то есть наружу уходила форма без признака закрытости
        // репозитория, а ошибки не было нигде. Снято; повторное объявление
        // теперь валит старт (см. slice()).

        // AL-102: журнал выдачи/снятия проектных ролей (append-only, KnowProjectRoleEvent).
        // «кто (роль) · кому (kc_sub) · что (project+role) · действие · когда (at)».
        // Опциональные фильтры по человеку/проекту — узкий разрез для карточки.
        slice("project_role_events",
            "SELECT event_uid, kc_sub, project, role, action, by_role, at "
            + "FROM KnowProjectRoleEvent",
            List.of(),
            new LinkedHashMap<>(Map.of(
                "kc_sub",  " WHERE kc_sub = :kc_sub",
                "project", " WHERE project = :project")),
            " ORDER BY at DESC LIMIT 500");

        // Fixed 2026-07-02: PART_OF is Task --PART_OF--> Sprint (out from the task), so
        // in('PART_OF') on KnowTask always returns empty — the old query classified EVERY
        // task as backlog regardless of sprint membership.
        slice("backlog_tasks",
            "SELECT task_uid, task_id, title, status_raw, priority, out('BELONGS_TO').component_id[0] AS component_id, task_type " +
            "FROM KnowTask WHERE out('PART_OF').size() = 0",
            List.of(), Map.of(), " ORDER BY task_uid");

        slice("all_tasks",
            // author/executor/reviewer_agent (ADR-LORE-014 §4) выбираются наравне
            // с остальными слайсами задач (tasks_of_sprint, tasks_of_phase). Без
            // них таблица показывала роли пустыми ДАЖЕ когда они заданы — то есть
            // «нет роли» в UI не означало отсутствие роли, а означало, что слайс её
            // не отдал. Ровно тот класс, что ловили весь спринт: данные есть, путь
            // их не доносит.
            // MT-12: статус читается из ОТКРЫТОЙ СТРОКИ ИСТОРИИ, а не с вершины.
            //
            // Прежняя редакция брала status_raw прямо с KnowTask — и 1421 задача
            // из 3279 (43%) выглядела «без статуса», потому что на вершине поле
            // пустое. Тот же срез при этом УЖЕ читал note_md и effort_days через
            // HAS_STATE: их починил SPRINT_LORE_TASK_NOTE_MD_FIX, а status_raw в
            // той правке пропустили.
            //
            // Цена: 04.08 по этому срезу я вывела, что «25 задач открыты в
            // спринтах, помеченных DONE», и записала это в план как находку
            // гигиены. Проверка через tasks_of_sprint показала, что все они
            // закрыты. Дефект не роняет запрос — он меняет ответ на
            // противоположный, и по нему строятся планы.
            //
            // Правило: у поля SCD2 ровно один законный источник — открытая
            // строка истории. Чтение с вершины даёт правдоподобную неправду.
            "SELECT task_uid, task_id, title, priority, out('BELONGS_TO').component_id[0] AS component_id, task_type, " +
            ROLE_HOLDERS + ", " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('PART_OF').sprint_id[0]    AS sprint_id, " +
            "out('PART_OF').title[0]        AS sprint_title, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].note_md[0], out('HAS_STATE')[note_md IS NOT NULL].note_md[0]) AS note_md, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].effort_days[0], out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0]) AS effort_days " +
            "FROM KnowTask",
            // No frontend consumer as of this writing (grep-confirmed) — LIMIT is a
            // defensive cap, not a UX pagination boundary. Raised 500→5000 so a full
            // task-effort export (e.g. the fractional-hours migration) doesn't
            // silently truncate; still bounded to avoid an unbounded query.
            List.of(), Map.of("q", ""), " ORDER BY sprint_id, task_uid");

        // SE-01: пожелание сессии проекта UDWE/mig_gen (передано владельцем
        // 2026-08-11/12) — `all_tasks` несёт `note_md`, из-за чего выдача по
        // всему корпусу раздувается в сотни раз (4 млн символов / 57 730 строк
        // на живом замере той же ночи), а получить «открытые задачи одного
        // проекта» без note_md было нельзя вовсе. `open_tasks` — облегчённая
        // проекция БЕЗ note_md, с фильтром «не done и не cancelled» встроенным
        // в само название (не нужно перечислять статусы), плюс узкие фильтры
        // по проекту/спринту/компоненту/классу работы (тоже из пожелания).
        //
        // "Открыто" читается по значку статуса (тот же icon-first паттерн,
        // что в AidaLoreResource.classifyStatus/AL-117), а не по слову — иначе
        // тот же класс дефекта, что уже ловили на этой же задаче раньше.
        slice("open_tasks",
            "SELECT task_uid, task_id, title, work_class, " +
            changedAtSql(FIRST_STATE_FROM_SQL) + ", " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('PART_OF').sprint_id[0] AS sprint_id, " +
            "out('TAGGED_WITH').component_id AS component_ids, " +
            // S9-02: релиз задачи — релиз её спринта (как у tasks_of_sprint); спринт
            // бывает в нескольких релизах — поле многозначное. Без него у раздела
            // «Задачи» не было оси «Релиз» вовсе.
            TASK_RELEASES_SQL + ", " +
            TASK_PROJECTS_SQL + ", " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].effort_days[0], out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0]) AS effort_days " +
            "FROM KnowTask " +
            // «Открытая» = не закрытая и не отменённая. Оба словаря берутся из
            // LoreStatusVocabulary, отрицание раскрыто по де Моргану в цепочку
            // NOT LIKE — см. noneSql() про то, почему не NOT ( ... OR ... ).
            "WHERE " + LoreStatusVocabulary.noneSql(OPEN_TASK_STATUS_EXPR, "done", "cancelled"),
            List.of(),
            new LinkedHashMap<>(Map.of(
                // Двойной хоп — тот же паттерн, что уже проверен в этом файле
                // (напр. tasks_of_uc: out('PART_OF').out('HAS_STATE')...).
                "project", " WHERE out('PART_OF').out('BELONGS_TO_PROJECT').slug CONTAINS :project",
                "sprint",  " WHERE out('PART_OF').sprint_id CONTAINS :sprint",
                "component", " WHERE out('TAGGED_WITH').component_id CONTAINS :component",
                "work_class", " WHERE work_class = :work_class")),
            " ORDER BY sprint_id, task_uid");

        // Аудит UX 09.11, D-30 (SPRINT_UXR_S9_SCALE_OPT/S9-01): закрытые задачи для
        // порционной подгрузки в разделе «Задачи» v2 — та же облегчённая проекция и
        // фильтры, что у open_tasks. Порции — общие limit/offset (SlicePage, page.has_more),
        // потолка нет. «done ИЛИ cancelled» — через OR, поэтому В СКОБКАХ: фильтры
        // дописываются через AND и без скобок легли бы только на последнюю ветку.
        slice("closed_tasks",
            "SELECT task_uid, task_id, title, work_class, " +
            changedAtSql(FIRST_STATE_FROM_SQL) + ", " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('PART_OF').sprint_id[0] AS sprint_id, " +
            "out('TAGGED_WITH').component_id AS component_ids, " +
            TASK_RELEASES_SQL + ", " +
            TASK_PROJECTS_SQL + ", " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].effort_days[0], out('HAS_STATE')[effort_days IS NOT NULL].effort_days[0]) AS effort_days " +
            "FROM KnowTask " +
            "WHERE (" + LoreStatusVocabulary.anySql(OPEN_TASK_STATUS_EXPR, "done", "cancelled") + ")",
            List.of(),
            new LinkedHashMap<>(Map.of(
                "project", " WHERE out('PART_OF').out('BELONGS_TO_PROJECT').slug CONTAINS :project",
                "sprint",  " WHERE out('PART_OF').sprint_id CONTAINS :sprint",
                "component", " WHERE out('TAGGED_WITH').component_id CONTAINS :component",
                "work_class", " WHERE work_class = :work_class")),
            " ORDER BY sprint_id, task_uid");

        // SPRINT_LORE_MEASURE_TRUTH/MT-CAL-START (решение D6 14.11: «пока никаких правил, давай
        // соберём статистику прыжков»): путь закрытия задачи одним вызовом. Строка на задачу,
        // чья ОТКРЫТАЯ версия — done. work_versions = 0 — прыжок planned/todo → done без
        // рабочего статуса; status_versions = 1 — задача заведена сразу закрытой. done_at и
        // changed_at — момент статуса (правка текста его не двигает), поэтому
        // changed_from/changed_to режут по ДНЮ ЗАКРЫТИЯ. Пакет (много закрытий за секунды
        // одним актором) отделяет потребитель — по done_at и closed_by.
        slice("task_close_path",
            "SELECT task_uid, out('PART_OF').sprint_id[0] AS sprint_id, " +
            STATUS_SINCE_SQL + " AS done_at, " +
            STATUS_SINCE_SQL + " AS changed_at, " +
            "out('HAS_STATE')[valid_to IS NULL].changed_by[0] AS closed_by, " +
            "out('HAS_STATE')[valid_to IS NULL].changed_by_kind[0] AS closed_by_kind, " +
            "out('HAS_STATE')[version_kind IS NULL].size() AS status_versions, " +
            // review — отдельно: с v1.17.21 (WK-05) done возможен только из review, и «прыжок»
            // planned → review → done иначе стал бы неотличим от работы по построению.
            "out('HAS_STATE')[" + LoreStatusVocabulary.anySql("status_raw",
                "in_progress", "partial", "uat", "ready_for_deploy") + "].size() AS work_versions, " +
            "out('HAS_STATE')[" + LoreStatusVocabulary.anySql("status_raw", "review") + "].size() AS review_versions, " +
            "bookkeeping " +
            "FROM KnowTask WHERE out('HAS_STATE')[valid_to IS NULL][" + DONE_STATUS_SQL + "].size() > 0",
            List.of(),
            new LinkedHashMap<>(Map.of(
                "project", " WHERE out('PART_OF').out('BELONGS_TO_PROJECT').slug CONTAINS :project",
                "sprint",  " WHERE out('PART_OF').sprint_id CONTAINS :sprint")),
            " ORDER BY task_uid");

        // ── §12 KnowFinding (Phase 5 LAL-31) ─────────────────────────────────
        slice("findings",
            "SELECT finding_id, type, verified, source_sprint " +
            "FROM KnowFinding",
            List.of(),
            new LinkedHashMap<>(Map.of(
                "type", " WHERE type = :type")),
            " ORDER BY finding_id");

        // MDL-05: evidence_md снят — поля нет ни в схеме, ни в модели, писателя нет, в проде пусто (0 из 31).
        slice("finding_by_id",
            "SELECT finding_id, type, verified, source_sprint, summary_md " +
            "FROM KnowFinding WHERE finding_id = :id LIMIT 1",
            List.of("id"), Map.of(), "");

        // ── Releases ─────────────────────────────────────────────────────────
        slice("releases",
            // MDL-08 ч.2: KnowRelease.version снят — дубль git_tag (снимок 18.11: 92 из 92 совпали); ключ ответа прежний
            "SELECT release_id, release_uid, git_tag, git_tag AS version, week, type, " +
            changedAtSql("released_at", "release_date") + ", " +
            "release_date, is_current, description_md, git_project, " +
            // AL-96: плоское git_project и ребро BELONGS_TO_PROJECT — две правды
            // об одном (аудит проектной оси). Поле оставлено: на нём живут табы
            // фронта и release_uid. Ребро выведено рядом — по нему работает
            // read-скоуп (AL-94), и расхождение теперь ВИДНО, а не скрыто.
            "out('BELONGS_TO_PROJECT').slug AS projects, " +
            // AL-112: hosts[] проекта релиза — remote'ы (primary|mirror) как
            // места, где тег физически лежит. Клиент (Forseti/miniLORE) строит
            // ссылку релиза per-host, а не хардкодом github.com, и показывает
            // репозитории как remote'ы ОДНОГО проекта, а не отдельные проекты.
            "out('BELONGS_TO_PROJECT').hosts[0] AS project_hosts, " +
            "in('IMPLEMENTED_IN_RELEASE').size() AS sprint_count, " +
            "in('SHIPPED_IN').size() AS pr_count " +
            // Порядок по ДАТЕ, а не по release_id: строковое сравнение версий
            // ставило v0.3.9 выше v0.3.42, и LIMIT 200 отрезал середину окна, а
            // не хвост истории (тот же дефект, что у timeline_releases выше).
            // Для UI безопасно: доска релизов сортирует сама, semverCompare
            // (LoreReleasesBoard.tsx:132), порядок среза она не наследует.
            //
            // AL-120 (20.10.2026): ORDER BY — в suffix, а не в теле. compose()
            // вставляет условие скоупа перед suffix'ом, и при сортировке в теле
            // получалось «… ORDER BY release_date DESC WHERE (…) LIMIT 200» —
            // ошибка разбора, 502 на списке релизов у каждого, кроме superadmin,
            // в момент включения lore.scope.enforce. Без скоупа итоговый SQL тот же
            // символ в символ: тело + suffix склеиваются как раньше.
            "FROM KnowRelease",
            List.of(),
            // DS-9: релизы одного проекта (был 400 «unknown param: project») —
            // по ребру, тем же путём, что read-скоуп. Свой LIMIT 200 снят: он прятал
            // старые релизы целиком, и is_current у v1.8.0 нечем было прочесть.
            // Потолки списочных срезов сняты решением владельца 30.08.2026,
            // серверное усечение помечается явно (DBU-13).
            new LinkedHashMap<>(Map.of(
                "project", " WHERE out('BELONGS_TO_PROJECT').slug CONTAINS :project")),
            // 05.11.2026 (Völva): limit=1 отдавал произвольный релиз одной даты, а не
            // текущий. Текущий — первым (true раньше false/null — проверяет
            // ReleasesCurrentFirstLiveDbTest на настоящей базе), при равной дате —
            // детерминированно по release_uid.
            " ORDER BY is_current DESC, release_date DESC, release_uid DESC");

        slice("release_decisions",
            "SELECT decision_id, title, status_raw FROM KnowDecision " +
            // MDL-08 ч.2: решения релиза — по связи REFERENCES решение → релиз (тег — release_id релиза)
            "WHERE out('REFERENCES')[@this INSTANCEOF 'KnowRelease'].release_id CONTAINS :tag ORDER BY decision_id",
            List.of("tag"), Map.of(), "");

        // Sprints linked to a given release via IMPLEMENTED_IN_RELEASE edge.
        // Prefer ruid (release_uid, e.g. "NooriUta/AIDA#v1.0.0") for multi-project safety.
        // Falls back to tag (release_id) when ruid is absent (legacy callers).
        // S4-29: был LIMIT 50 без ORDER BY — произвольные 50 без признака обрезки.
        // Потолка нет, порядок детерминирован; страница — общими limit/offset (SE-01).
        slice("release_sprints",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " + CHILD_SPRINT_COLS + " " +
            "FROM KnowSprint WHERE out('IMPLEMENTED_IN_RELEASE').release_uid CONTAINS :ruid",
            List.of("ruid"), Map.of(), " ORDER BY sprint_id");

        slice("release_sprints_by_tag",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw " +
            "FROM KnowSprint WHERE out('IMPLEMENTED_IN_RELEASE').release_id CONTAINS :tag",
            // REL-UID-01: номер версии общий у разных проектов — project сужает до своего.
            List.of("tag"), Map.of("project", " WHERE out('IMPLEMENTED_IN_RELEASE').out('BELONGS_TO_PROJECT').slug CONTAINS :project"), " ORDER BY sprint_id");

        // PRs shipped in a given release via the SHIPPED_IN edge (KnowPR → KnowRelease).
        // Prefer ruid for multi-project safety.
        slice("release_prs",
            "SELECT pr_number, pr_uid, git_project, title, merged_at, url " +
            "FROM KnowPR WHERE out('SHIPPED_IN').release_uid CONTAINS :ruid ORDER BY pr_number",
            List.of("ruid"), Map.of(), "");

        // 1.18 (владелица 21.11.2026: «в меню под релизы вход в PR сделай»): список всех PR — раздел «PR».
        // Проект — поле git_project и ребро BELONGS_TO_PROJECT (скоуп PROJECT_SCOPED — по любому из двух);
        // релизы — по ключу release_uid «проект#тег»; свежие сверху по моменту мержа (changed_at = merged_at).
        slice("prs",
            "SELECT pr_uid, pr_number, git_project, title, url, state, merged_at, merged_at AS changed_at, head_ref, base_ref, " +
            "out('SHIPPED_IN').release_uid AS release_uids, " +
            "unionall(git_project, out('BELONGS_TO_PROJECT').slug) AS git_projects, " +
            // #1708: подпись проекта — краткое название (по связи с проектом; без связи — ключ из поля)
            "out('BELONGS_TO_PROJECT').slug AS project_slugs, out('BELONGS_TO_PROJECT').short_title AS project_titles " +
            "FROM KnowPR",
            List.of(), Map.of(), " ORDER BY merged_at DESC, pr_uid");

        // SPRINT_LORE_MODEL_DOCS_TIDY/MD-05: паспорт PR — одна строка KnowPR по pr_uid «проект#номер».
        // Задачи — по ребру CLOSED_BY (задача → PR), релизы — по SHIPPED_IN (PR → релиз): те же рёбра,
        // что пишут мерж (forgejo_pr_merge), task_link rel=pr и release_link rel=pr.
        slice("pr_by_id",
            "SELECT pr_uid, pr_number, git_project, title, url, state, merged_at, head_ref, base_ref, " +
            "in('CLOSED_BY').task_uid AS task_uids, out('SHIPPED_IN').release_uid AS release_uids, " +
            "unionall(git_project, out('BELONGS_TO_PROJECT').slug) AS git_projects " +
            "FROM KnowPR WHERE pr_uid = :id LIMIT 1",
            List.of("id"), Map.of(), "");

        // D-2026-MINILORE-OWNER-ANSWERS-06-11 п.3: задачи релиза — через PR, который
        // их закрыл (CLOSED_BY), и релиз этого PR (SHIPPED_IN). Не разбор note_md.
        slice("release_tasks_by_tag",
            "SELECT task_uid, title, out('PART_OF').sprint_id[0] AS sprint_id, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('CLOSED_BY').pr_uid AS closed_by_prs " +
            "FROM KnowTask WHERE out('CLOSED_BY').out('SHIPPED_IN').release_id CONTAINS :tag",
            List.of("tag"), Map.of("project", " WHERE out('CLOSED_BY').out('SHIPPED_IN').out('BELONGS_TO_PROJECT').slug CONTAINS :project"), " ORDER BY task_uid");

        slice("release_prs_by_tag",
            "SELECT pr_number, pr_uid, git_project, title, merged_at, url " +
            "FROM KnowPR WHERE out('SHIPPED_IN').release_id CONTAINS :tag",
            List.of("tag"), Map.of("project", " WHERE out('SHIPPED_IN').out('BELONGS_TO_PROJECT').slug CONTAINS :project"), " ORDER BY pr_number");

        // Графики 19.11.2026 (№9 «от мержа до прода»): выпущенный PR — момент мержа и дата его релиза.
        // project_prs не несёт релиза, release_prs_by_tag требует тег. Релиз — первый по ребру SHIPPED_IN.
        slice("pr_ship_lag",
            "SELECT pr_uid, pr_number, git_project, merged_at, " +
            "out('SHIPPED_IN').release_id[0] AS release_id, " +
            "out('SHIPPED_IN').release_date[0] AS release_date, " +
            "out('SHIPPED_IN').released_at[0] AS released_at " +
            "FROM KnowPR WHERE out('SHIPPED_IN').size() > 0",
            List.of(), Map.of("project", " WHERE out('SHIPPED_IN').out('BELONGS_TO_PROJECT').slug CONTAINS :project"), "");

        // ── §13 ClRoutine* slices (Phase 6 v1.3) ─────────────────────────────
        slice("routine_latest",
            "SELECT metric_key, value, unit, status, run_date " +
            "FROM ClRoutineMetric WHERE routine_name = :routine_name " +
            "AND run_date = (SELECT max(run_date) FROM ClRoutineMetric " +
            "WHERE routine_name = :routine_name) ORDER BY metric_key",
            List.of("routine_name"), Map.of(), "");

        slice("routine_last_run",
            "SELECT routine_name, run_date, status, flags, detail_md, gates_failed_ids " +
            "FROM ClRoutineRun WHERE routine_name = :routine_name " +
            "ORDER BY run_date DESC LIMIT 1",
            List.of("routine_name"), Map.of(), "");

        slice("routine_outputs",
            "SELECT output_type, title, run_date " +
            "FROM ClRoutineOutput WHERE routine_name = :routine_name " +
            "ORDER BY run_date DESC LIMIT 50",
            List.of("routine_name"), Map.of(), "");

        slice("routine_output_by_type",
            "SELECT output_type, title, run_date, content_md " +
            "FROM ClRoutineOutput WHERE routine_name = :routine_name " +
            "AND output_type = :output_type ORDER BY run_date DESC LIMIT 1",
            List.of("routine_name", "output_type"), Map.of(), "");

        slice("qg_run_history",
            "SELECT run_id, routine_name, run_date, status, flags, started_at, finished_at " +
            "FROM ClRoutineRun WHERE routine_name = :routine_name " +
            "ORDER BY started_at DESC, run_date DESC",
            List.of("routine_name"), Map.of(), " LIMIT 20");

        // Графики 19.11.2026 (№16 «гейты: доля пройденных по неделям»): прогоны гейтов с даты since без
        // потолка — qg_routine_runs отдаёт 200 последних, а супервизор пишет прогон раз в час (неделя, не квартал).
        // run_date — строка ГГГГ-ММ-ДД: сравнение со строкой since верное.
        slice("qg_run_outcomes",
            "SELECT routine_name, run_date, started_at, status " +
            "FROM ClRoutineRun WHERE routine_name LIKE 'qg-%'",
            List.of(), Map.of("since", " WHERE run_date >= :since"), "");

        // ── MCP-05: BRAGI content archive read slices (SPEC-BRAGI-ARCHIVE-001) ──
        slice("bragi_overview",
            "SELECT status_general, count(*) AS n FROM BragiPublication GROUP BY status_general",
            List.of(), Map.of(), "");

        slice("bragi_publications",
            "SELECT publication_id, title, topic, main_text_md, type, status_general, source_file_path, " +
            // V2-02: annotation_md (permanent editorial meta) / todo_md (transient
            // "- [ ]" checklist) — editor-only fields, deliberately never fed into
            // BragiSkinPreview. Publication + per-variant (parallel arrays, same
            // index convention as variant_texts/variant_channels below).
            "annotation_md, todo_md, " +
            "out('HAS_ASSET').file_url AS cover_asset_urls, " +
            "out('HAS_VARIANT').variant_id AS variant_ids, " +
            "out('HAS_VARIANT').status AS variant_statuses, " +
            "out('HAS_VARIANT').url AS variant_urls, " +
            "out('HAS_VARIANT').text_md AS variant_texts, " +
            "out('HAS_VARIANT').annotation_md AS variant_annotation_texts, " +
            "out('HAS_VARIANT').todo_md AS variant_todo_texts, " +
            "out('HAS_VARIANT').out('IN_CHANNEL').channel_id AS variant_channels, " +
            "out('HAS_VARIANT').out('HAS_ASSET').file_url AS variant_asset_urls, " +
            "out('TARGETS_KEY').keyword_id AS keyword_ids, " +
            "out('IN_RUBRIC').rubric_id AS rubric_ids, " +
            "out('IN_RUBRIC').name AS rubric_names, " +
            "out('PRODUCED_BY').task_uid AS produced_by_task_ids, " +
            "out('PRODUCED_BY').sprint_id AS produced_by_sprint_ids, " +
            "out('SHIPPED_IN').release_id AS shipped_in_release_ids " +
            "FROM BragiPublication",
            List.of(), Map.of(), " ORDER BY publication_id");

        // Calendar: variants that have a published_at date. No distinct "planned
        // date" field exists yet (v0.4 spec only has published_at on Variant) —
        // planned-but-undated variants are visible via bragi_publications instead.
        slice("bragi_calendar",
            "SELECT variant_id, status, published_at, url, " +
            "in('HAS_VARIANT').publication_id AS publication_id, " +
            "in('HAS_VARIANT').title AS title, " +
            "out('IN_CHANNEL').channel_id AS channel_id, " +
            // V2-06: группировка ретро по рубрике — рубрика живёт на публикации.
            "in('HAS_VARIANT').out('IN_RUBRIC').name AS rubric_names " +
            "FROM BragiVariant WHERE published_at IS NOT NULL",
            List.of(), Map.of(), " ORDER BY published_at");

        slice("bragi_keys",
            "SELECT keyword_id, phrase, cluster, freq_exact, freq_broad, intent, source, measured_at, " +
            "out('TARGETS_PAGE').page_id AS page_id, " +
            "out('TARGETS_PAGE').url AS page_url, " +
            "out('IN_RUBRIC').rubric_id AS rubric_ids, " +
            "out('IN_RUBRIC').name AS rubric_names " +
            "FROM BragiKeyword",
            List.of(), Map.of(), " ORDER BY freq_exact DESC");

        slice("bragi_rubrics",
            "SELECT rubric_id, name, description, order_index FROM BragiRubric",
            List.of(), Map.of(), " ORDER BY order_index, name");

        // Recent metric feed — for filtered/aggregated queries use metric_get
        // (POST /lore/bragi/metric/query) instead; this slice is a flat recent-points
        // feed for dashboard cards. object_type='probe' is a schema-verification
        // artifact (ARC-02/ARC-03), always excluded. The remaining exclusions
        // (V2-01, SPRINT_BRAGI_ARCHIVE_V2) mirror queryBragiMetric's filter —
        // MetricSnapshot is TIMESERIES/sealed, so pre-policy seed/test points can't
        // be physically deleted and are filtered at every read path instead.
        slice("bragi_analytics",
            "SELECT object_type, object_id, metric, value, ts, source, segment " +
            "FROM MetricSnapshot WHERE object_type != 'probe' " +
            "AND object_id != 'PUB-QA-E2E' AND source NOT IN ['qa-e2e', 'test-mcp03'] " +
            "AND NOT (ts = '2026-06-27 12:00:00' AND object_id IN ['PUB-04', 'PUB-04-VC', 'PUB-04-TG', 'PUB-05', 'PUB-05-HABR']) " +
            "AND NOT (ts = '2026-07-02 09:00:00' AND (object_type = 'competitor' OR object_id = 'KW-08'))",
            List.of(), Map.of(), " ORDER BY ts DESC LIMIT 100");

        // ── STAT-1: кто что и по сколько запрашивает ─────────────────────────
        //
        // Сырьё пишет LoreRequestStats (агрегат за окно, не точка на запрос).
        // Свёртка здесь именно SUM по (кто × ось × что): без неё окна за сутки
        // читались бы вручную, а вопрос владельца — «по сколько», то есть итог.
        //
        // Порога по времени НЕТ намеренно: ts в MetricSnapshot — LONG (epoch
        // millis), а параметры слайсов приходят строками, и сравнение строки с
        // LONG молча не отберёт ничего. Отдавать «за период» здесь значило бы
        // отдавать пустоту, выглядящую как «событий не было». Для интервалов
        // есть metric_get (POST /lore/bragi/metric/query) — он умеет фильтры
        // типизированно. Здесь верхний срез: агрегат и последние точки.
        slice("requests_by_caller",
            "SELECT object_id AS caller, segment AS axis, source AS what, sum(value) AS calls " +
            "FROM MetricSnapshot WHERE metric = 'lore.requests' " +
            "GROUP BY object_id, segment, source",
            List.of(), Map.of(), " ORDER BY calls DESC LIMIT 200");

        // AO-01: журнал мутирующих действий — «кто создал/изменил эту сущность».
        // Код ответа в value: упавшие вызовы видны наравне с успешными.
        // D-2026-LORE-AGENT-MACHINE-EVERYWHERE п.4: ряд — AgentActionLog, с клиентом и машиной.
        slice("agent_actions",
            "SELECT " + AgentActionLog.ROW_COLUMNS + " FROM AgentActionLog",
            List.of(), new LinkedHashMap<>(Map.of(
                "entity_id", " WHERE object_id = :entity_id",
                "caller", " WHERE source = :caller",
                "client", " WHERE client = :client",
                "machine", " WHERE machine = :machine")),
            " ORDER BY ts DESC LIMIT 500");

        // SPRINT_UXR_S7B_ADMIN/S7B-02: журнал действий АДМИНКИ — тот же ряд AO-01,
        // только админские семейства (ADMIN_FAMILIES). «Кто» — caller, «человек или
        // агент» — axis, «что» — family + entity_id, «когда» — ts, исход — status (код
        // ответа): отказы видны наравне с успехом.
        slice("admin_actions",
            "SELECT " + AgentActionLog.ROW_COLUMNS + " FROM AgentActionLog " +
            "WHERE object_type IN [" + String.join(", ", ADMIN_FAMILIES.stream().sorted().map(f -> "'" + f + "'").toList()) + "]",
            List.of(), new LinkedHashMap<>(Map.of(
                "family", " WHERE object_type = :family",
                "caller", " WHERE source = :caller",
                "machine", " WHERE machine = :machine")),
            " ORDER BY ts DESC LIMIT 500");

        // Тот же ряд, свёрнутый до вызывающего: «кто вообще сколько зовёт»,
        // без разбивки по эндпоинтам — верхний уровень ответа.
        slice("requests_total",
            "SELECT object_id AS caller, segment AS axis, sum(value) AS calls " +
            "FROM MetricSnapshot WHERE metric = 'lore.requests' " +
            "GROUP BY object_id, segment",
            List.of(), Map.of(), " ORDER BY calls DESC LIMIT 100");

        // SPRINT_UXR_S7B_ADMIN/S7B-07: подключения MCP и их честное «здоровье».
        // MCP-сервер работает у агента на машине; LORE видит только его вызовы,
        // поэтому здоровье — наблюдённое: профиль агента (caller), сколько звал,
        // когда в последний раз (last_seen, epoch millis). Агента, который не звал
        // ни разу, здесь нет — это «не видели», а не «здоров».
        // GROUP BY — в хвосте: фильтры дописываются после базы, а не после группировки.
        slice("mcp_connections",
            "SELECT object_id AS caller, sum(value) AS calls, max(ts) AS last_seen " +
            "FROM MetricSnapshot WHERE metric = 'lore.requests' AND segment = 'agent'",
            List.of(), Map.of("caller", " WHERE object_id = :caller"),
            " GROUP BY object_id ORDER BY last_seen DESC LIMIT 100");

        // Сбои агентских записей: ответ с кодом ≥ 400 (AO-01 пишет код в value).
        // S7B-26: since (ISO-дата/момент, UTC → epoch-мс числом: ts — LONG) и code (точный код) —
        // Главной админки нужно «403 за сутки», а не «≥ 400 за всё время» (TYPED_PARAMS).
        slice("mcp_failures",
            "SELECT source AS caller, count(*) AS failures, max(ts) AS last_failure " +
            "FROM AgentActionLog WHERE segment = 'agent' AND value >= 400",
            List.of(), new LinkedHashMap<>(Map.of(
                "caller", " WHERE source = :caller",
                "since", " WHERE ts >= :since",
                "code", " WHERE value = :code")),
            " GROUP BY source ORDER BY last_failure DESC LIMIT 100");

        // S7B-30: те же отказы ПОСТРОЧНО — детализация карточки Главной «N отказов ≥ 400».
        // Условие и фильтры — ровно как у mcp_failures (счётчик и список обязаны сходиться 1:1);
        // admin_actions не годится (режет агентские записи по админским семействам), agent_actions —
        // тоже (500 последних действий всех исходов, отказы среди них — малая часть).
        slice("mcp_failure_rows",
            "SELECT ts, object_type AS family, object_id AS entity_id, source AS caller, client, machine, value AS status " +
            "FROM AgentActionLog WHERE segment = 'agent' AND value >= 400",
            List.of(), new LinkedHashMap<>(Map.of(
                "caller", " WHERE source = :caller",
                "since", " WHERE ts >= :since",
                "code", " WHERE value = :code")),
            " ORDER BY ts DESC LIMIT 500");

        // Графики 19.11.2026 (№13 действия агентов по дням, №14 отказы MCP по кодам): действия агентов
        // ТОЧКАМИ за период. agent_actions — 500 последних строк всех исходов (за месяц — пара дней),
        // mcp_failure_rows — только отказы; здесь все исходы агента с since (epoch-мс числом, TYPED_PARAMS).
        // Свёртка по дням — у потребителя: GROUP BY по моменту TIMESERIES здесь не проверен.
        slice("agent_action_points",
            "SELECT ts, source AS caller, client, value AS status " +
            "FROM AgentActionLog WHERE segment = 'agent'",
            List.of(), new LinkedHashMap<>(Map.of(
                "since", " WHERE ts >= :since",
                "caller", " WHERE source = :caller")),
            " ORDER BY ts DESC");

        // НАСТОЯЩИЕ логины — события LOGIN из Keycloak (LoreKcLoginPoller).
        // Отличать от sessions_recent намеренно: здесь наблюдённый факт входа,
        // там — догадка LORE по первому запросу после паузы. source = clientId,
        // то есть видно, куда именно человек вошёл.
        slice("logins_recent",
            "SELECT object_id AS user, source AS client_id, ts " +
            "FROM MetricSnapshot WHERE metric = 'lore.login'",
            List.of(), Map.of(), " ORDER BY ts DESC LIMIT 200");

        slice("logins_by_user",
            "SELECT object_id AS user, sum(value) AS logins " +
            "FROM MetricSnapshot WHERE metric = 'lore.login' " +
            "GROUP BY object_id",
            List.of(), Map.of(), " ORDER BY logins DESC LIMIT 100");

        // Начала сессий — догадка, а не факт: вход в Keycloak происходит вне
        // периметра LORE. Полезно для АГЕНТОВ, у которых логина в KC нет вовсе
        // (client_credentials): для них это единственный признак «пришёл».
        slice("sessions_recent",
            "SELECT object_id AS caller, segment AS axis, ts " +
            "FROM MetricSnapshot WHERE metric = 'lore.session_start'",
            List.of(), Map.of(), " ORDER BY ts DESC LIMIT 200");

        slice("bragi_competitors",
            "SELECT competitor_id, name FROM BragiCompetitor",
            List.of(), Map.of(), " ORDER BY competitor_id");

        // FE-05: was missed in the original MCP-05 pass — Insights need a read
        // slice too. out('LED_TO') fans out to both KnowTask and KnowADR; ArcadeDB
        // returns whatever field exists on the target (adr_id null on a task row
        // and vice versa), so both arrays below are safe to project together.
        slice("bragi_insights",
            "SELECT insight_id, statement_md, insight_date, evidence_ref, subject_id, " +
            "out('LED_TO').task_uid AS led_tasks, " +
            "out('LED_TO').adr_id AS led_adrs " +
            "FROM BragiInsight",
            List.of(), Map.of(), " ORDER BY insight_date DESC");

        slice("bragi_integrations",
            "SELECT integration_id, service, purpose, endpoint, scope, secret_ref, status, last_called_at " +
            "FROM BragiIntegration",
            List.of(), Map.of(), " ORDER BY integration_id");

        // FE-06: another gap found while building the create-forms — channel/page
        // pickers need lookup slices too, not just the content-display ones.
        slice("bragi_channels",
            "SELECT channel_id, channel_type, url_handle, funnel_role, rules_md FROM BragiChannel",
            List.of(), Map.of(), " ORDER BY channel_id");

        slice("bragi_pages",
            "SELECT page_id, url, title FROM BragiPage",
            List.of(), Map.of(), " ORDER BY page_id");

        // ── ADR-LORE-012: dictionary (KnowDictEntry) ─────────────────────────
        // Without dict_type — весь справочник; с dict_type — один домен.
        // Читается фронтом (useDictionary), бэкендом и MCP как единый канон.
        // Admin LORE (ADR-LORE-025): tag usage counts for the read-only «Теги» tab.
        // Без потолка (PU-29, 14.11.2026): LIMIT 500 давал «показано 500 из 500»
        // при большем корпусе, а поиск вкладки искал только в этих 500. Справочник
        // — не лента; серверный потолок HTTP-API назван флагом truncated.
        slice("tags_usage",
            "SELECT tag_id, in('TAGGED_WITH').size() AS uses FROM KnowTag",
            List.of(), Map.of(), " ORDER BY uses DESC, tag_id");
        // SUPERTAGS-SPIKE: сущности по тегу с полями — рёбра TAGGED_WITH тега, словарь полей на ребре
        // (fields) и отметки. Колонки и фасеты считает GET /lore/tag/entities (LoreEdgeFreeFields.table);
        // здесь — строки для MCP query_slice. vertex — класс записи (KnowADR, KnowDecision).
        slice("tag_entities",
            LoreEdgeFreeFields.entitiesSql("TAGGED_WITH"),
            List.of("tag"), Map.of(), " ORDER BY tagged_at DESC");
        // lore_tags_usage удалён вместе с типом LoreTag (AL-29, миграция V17) —
        // KnowTag/LoreTag были дублирующими справочниками, схлопнуты в один.

        slice("dictionary",
            // ifnull() masks the brief NULL-flag window on a freshly-upserted row
            // (defaults are set in a second, IS NULL-gated statement) — readers
            // always see the effective defaults, never NULL.
            "SELECT dict_type, code, label_ru, label_en, color, icon, sort_order, " +
            "ifnull(is_active, true) AS is_active, ifnull(is_extensible, false) AS is_extensible, kind FROM KnowDictEntry",
            List.of(),
            new LinkedHashMap<>(Map.of(
                "dict_type", " WHERE dict_type = :dict_type")),
            " ORDER BY dict_type, sort_order");

        // ── RM-P6: продуктовая ось (D-2026-LORE-PRODUCT-IS-OWN-ENTITY) ───────
        // Продукт — запись справочника dict_type='product'. Состав читается
        // ТОЛЬКО рёбрами, денормализованных копий у него нет намеренно: ровно
        // на копии разъехалось дерево компонентов (RM-P10 — у 12 вершин ребро
        // было, а поле parent_id пустовало, и «сколько у нас корней» отвечалось
        // 26 или 14 в зависимости от способа счёта).
        //   компоненты      — in('IN_PRODUCT')      (компонент → продукт)
        //   родительский    — out('PARENT_PRODUCT') (продукт → родитель)
        //   суб-продукты    — in('PARENT_PRODUCT')
        //   репозитории     — out('BELONGS_TO_PROJECT')
        slice("products",
            "SELECT code, label_ru, label_en, color, icon, sort_order, " +
            "ifnull(is_active, true) AS is_active, " +
            "is_extensible, " +
            // WK-01 (D-2026-LORE-PRODUCT-KINDS-TECH-SERVICE): вид продукта tech | service; пусто — не размечен.
            "kind, " +
            "in('IN_PRODUCT').component_id  AS components, " +
            "out('PARENT_PRODUCT').code     AS parent_code, " +
            "in('PARENT_PRODUCT').code      AS sub_products, " +
            "out('BELONGS_TO_PROJECT').slug AS git_projects, " +
            // WK-02: роль связи продукт → проект параллельным списком; out() и
            // outE() обходят одни и те же рёбра в одном порядке.
            "outE('BELONGS_TO_PROJECT').role AS git_project_roles, " +
            // WK-03: кому продукт служит и как — параллельные списки, как роли выше.
            "out('SERVES').code AS serves_codes, " +
            "outE('SERVES').kind AS serves_kinds " +
            "FROM KnowDictEntry WHERE dict_type = 'product'",
            List.of(), Map.of(), " ORDER BY sort_order, code");

        // Спринты продукта — через компоненты продукта. Отдельным срезом, потому
        // что состав продукта это два перехода (продукт ← компонент ← спринт), а
        // не поле: спринт к продукту напрямую не привязан и привязан не будет —
        // иначе появится третья копия той же связи.
        slice("product_sprints",
            "SELECT sprint_id, coalesce(title, name) AS name, " +
            "COALESCE(out('HAS_STATE')[valid_to IS NULL].status_raw[0], out('HAS_STATE')[status_raw IS NOT NULL].status_raw[0]) AS status_raw, " +
            "out('BELONGS_TO').component_id AS components " +
            "FROM KnowSprint " +
            // CONTAINS, а не [0] = : у спринта несколько компонентов и у
            // компонента несколько продуктов, поэтому обход отдаёт СПИСОК.
            // Сравнение через [0] показало бы многосвязное под одним случайным
            // значением — записанная ловушка ArcadeDB, уже ловившая нас.
            "WHERE out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code",
            List.of("code"), Map.of(), " ORDER BY sprint_id");

        // ── S4-PRODUCTS-NODE: паспорт продукта (v2, только чтение) ────────────
        // Продукт — статья словаря (dict_type='product'), ключ — код. Та же проекция,
        // что у среза products, по одному коду. Цвет — колонка color статьи: в v2 он
        // показывается как есть, нет его — null (цвет не выдумывается).
        slice("product_by_id",
            "SELECT code, label_ru, label_en, color, icon, sort_order, " +
            "ifnull(is_active, true) AS is_active, " +
            "is_extensible, " +
            // WK-01 (D-2026-LORE-PRODUCT-KINDS-TECH-SERVICE): вид продукта tech | service; пусто — не размечен.
            "kind, " +
            "in('IN_PRODUCT').component_id  AS components, " +
            "out('PARENT_PRODUCT').code     AS parent_code, " +
            "in('PARENT_PRODUCT').code      AS sub_products, " +
            "out('SERVES').code             AS serves, " +
            "in('SERVES').code              AS served_by, " +
            "in('TARGETS_PRODUCT').milestone_id AS milestone_ids, " +
            "out('BELONGS_TO_PROJECT').slug AS git_projects " +
            "FROM KnowDictEntry WHERE dict_type = 'product' AND code = :code",
            List.of("code"), Map.of(), "");

        // Вкладки паспорта продукта. Своих рёбер к сценариям, болям, выгодам, работам и
        // ролям у продукта нет — путь тот же, что у product_sprints: продукт ← компонент
        // (IN_PRODUCT) ← сценарий (BELONGS_TO) → боль/выгода/работа/роль. Сценарии — ВСЕ
        // уровни (фичи и US — один тип KnowUseCase, один паспорт), только со своим
        // ребром к компоненту: унаследованного у детей сценария срез не видит — это
        // сказано в подписи вкладки клиента, а не замолчано.
        slice("product_features",
            "SELECT uc_id, title, status, goal_level " +
            "FROM KnowUseCase " +
            "WHERE out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code",
            List.of("code"), Map.of(), " ORDER BY goal_level, uc_id");

        // Боль — продукту, если её ЗАЯВЛЯЕТ (ADDRESSES) или СНИМАЕТ (RELIEVES) сценарий
        // продукта: обе стороны «заявлено vs доставлено» (ADR-LORE-032 D5).
        slice("product_pains",
            "SELECT pain_id, title, severity " +
            "FROM KnowPain " +
            "WHERE in('ADDRESSES').out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code " +
            "OR in('RELIEVES').out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code",
            List.of("code"), Map.of(), " ORDER BY pain_id");

        slice("product_gains",
            "SELECT gain_id, title, rank " +
            "FROM KnowGain " +
            "WHERE in('PROMISES').out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code " +
            "OR in('DELIVERS').out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code",
            List.of("code"), Map.of(), " ORDER BY gain_id");

        slice("product_jobs",
            "SELECT job_id, title, kind " +
            "FROM KnowJob " +
            "WHERE in('HELPS_WITH').out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code " +
            "OR in('PERFORMS').out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code",
            List.of("code"), Map.of(), " ORDER BY job_id");

        // Пользовательские роли (клиентские сегменты) — акторы сценариев продукта (HAS_ACTOR).
        slice("product_actors",
            "SELECT actor_id, name, kind " +
            "FROM KnowProjectActor " +
            "WHERE in('HAS_ACTOR').out('BELONGS_TO').out('IN_PRODUCT').code CONTAINS :code",
            List.of("code"), Map.of(), " ORDER BY actor_id");

        // AL-43: SCD2 history for one dict entry — same close/open pattern as
        // history_sprint/history_task/adr_history, keyed by the composite
        // (dict_type, code) denormalized onto KnowDictEntryHist rather than a
        // graph traversal (KnowDictEntry's key isn't a single field).
        slice("history_dict",
            "SELECT valid_from, valid_to, label_ru, label_en, color, icon, sort_order, " +
            "is_active, is_extensible FROM KnowDictEntryHist " +
            "WHERE dict_type = :dict_type AND code = :code ORDER BY valid_from",
            List.of("dict_type", "code"), Map.of(), "");

        // ADR-LORE-012 level B: components linked to an area via the IN_AREA edge
        // (graph traversal, not the string field) — «all components in area X».
        slice("components_in_area",
            "SELECT component_id, full_name, area, game_icon FROM LoreComponent " +
            "WHERE out('IN_AREA').code CONTAINS :code",
            List.of("code"), Map.of(), " ORDER BY component_id");
    }

    public static Set<String> ids() { return SLICES.keySet(); }

    public static SliceDef get(String id) { return SLICES.get(id); }

    private static final java.util.regex.Pattern PLAN_BOARD_TYPE =
        java.util.regex.Pattern.compile("\\bFROM\\s+Plan(Config|Track|Section|Checkpoint|Version)\\b");

    /** Имя типа после FROM (не schema:…, не INDEX:…, не подзапрос). */
    private static final java.util.regex.Pattern FROM_TYPE =
        java.util.regex.Pattern.compile("\\bFROM\\s+([A-Z][A-Za-z0-9_]*)\\b(?!\\s*:)");

    /** Типы (вершины, связи, ряды), которые читает срез; пусто — среза нет. Для сторожа «тип вне модели». */
    static Set<String> typesOf(String id) {
        SliceDef d = SLICES.get(id);
        if (d == null) return Set.of();
        Set<String> out = new java.util.LinkedHashSet<>();
        java.util.regex.Matcher m = FROM_TYPE.matcher(d.baseSql());
        while (m.find()) out.add(m.group(1));
        return out;
    }

    /** Срез читает типы старой доски плана (D-2026-MIG-PLAN-BOARD-INSTALLER-OPTION). */
    static boolean usesPlanBoard(String id) {
        SliceDef d = SLICES.get(id);
        return d != null && PLAN_BOARD_TYPE.matcher(d.baseSql()).find();
    }

    /**
     * AL-94: слайсы, у которых сущность несёт ребро BELONGS_TO_PROJECT напрямую,
     * и потому read-скоуп применим (значение — выражение траверса до slug'ов).
     *
     * <p>Список намеренно КОРОТКИЙ и явный, а не «все слайсы с project-фильтром»:
     * скоуп меняет видимость данных, и молча накрыть им слайс, чью проектную ось
     * никто не проверял, — способ получить пустой экран без объяснения. Типы с
     * derived-привязкой (components — через спринты) сюда не входят: у них
     * «проект» вычислим, но не является фактом самой вершины (решение AL-92).</p>
     */
    // Несколько выражений на слайс (разделитель "|") = проверка И ПРЯМОЙ связи,
    // И КОСВЕННОЙ — через родительский объект. Решение владельца: «проверять надо
    // как прямую связь, так и косвенную через родительские объекты».
    //
    // Зачем: у решений собственного ребра проекта почти нет (300 из 300 — проект
    // выводится через родительский ADR), у вопросов — у 24 из 37 непривязанных.
    // Со строгой проверкой ТОЛЬКО прямой связи включённый скоуп отрезал бы автору
    // его же вопрос, поднятый в его же ADR («не проходит редактирование с обрезкой
    // прав по проектам»). Проверка «хотя бы один путь ведёт в разрешённый проект»
    // сохраняет смысл скоупа и не наказывает за неполноту рёбер.
    /** Скоуп вопросов: своё ребро | RAISED_IN | компонент → спринты → проект (D-2026-LORE-QUESTION-VISIBILITY-INHERIT-OR-LANE). */
    static final String QUESTION_SCOPE =
        "out('BELONGS_TO_PROJECT').slug|out('RAISED_IN').out('BELONGS_TO_PROJECT').slug"
        + "|out('BELONGS_TO').in('BELONGS_TO')[@type='KnowSprint'].out('BELONGS_TO_PROJECT').slug";

    /**
     * S1-08: проект некорневого сценария НАСЛЕДУЕТСЯ по DECOMPOSES_INTO (своего ребра у
     * детей нет). Шкала Коберна — 4 уровня, до корня максимум 3 шага. Без этого скоуп
     * отсекал детей: use_cases_of_feature отдавал 0 при uc_total = 5.
     */
    static final String UC_INHERITED_SCOPE =
        "out('BELONGS_TO_PROJECT').slug"
        + "|in('DECOMPOSES_INTO').out('BELONGS_TO_PROJECT').slug"
        + "|in('DECOMPOSES_INTO').in('DECOMPOSES_INTO').out('BELONGS_TO_PROJECT').slug"
        + "|in('DECOMPOSES_INTO').in('DECOMPOSES_INTO').in('DECOMPOSES_INTO').out('BELONGS_TO_PROJECT').slug";

    /**
     * Скоуп гейта качества (QG-01): своё ребро проекта ИЛИ признак общего гейта. «?» — условие-литерал,
     * не зависящее от проекта вызывающего (см. {@link #scopeClause}).
     */
    static final String QG_SCOPE = "out('BELONGS_TO_PROJECT').slug|?scope = 'global'";

    static final Map<String, String> PROJECT_SCOPED = Map.ofEntries(
        Map.entry("sprints",   "out('BELONGS_TO_PROJECT').slug"),
        // Решение владелицы 11.11.2026: зависимость видна, только если видны ОБА спринта
        // («&» — обязательные концы ребра DEPENDS_ON). Скрытые рёбра — числом (scope.hidden).
        Map.entry("sprint_deps", "@out.out('BELONGS_TO_PROJECT').slug&@in.out('BELONGS_TO_PROJECT').slug"),
        // MDL-13: зависимость задачи, фазы, спринта и вехи — то же правило «видны оба конца»; задача и фаза —
        // через проект своего спринта, веха проекта не имеет (общая).
        Map.entry("deps", LoreDependency.scopeOf("@out") + "&" + LoreDependency.scopeOf("@in")),
        Map.entry("deps_of", LoreDependency.scopeOf("@out") + "&" + LoreDependency.scopeOf("@in")),
        Map.entry("adrs",      "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("releases",  "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("release_by_id", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("docs",      "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("runbooks",  "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("specs",     "out('BELONGS_TO_PROJECT').slug"),
        // Решение: своё ребро ИЛИ проект родительского ADR (DECIDED_IN).
        Map.entry("decisions",
            "out('BELONGS_TO_PROJECT').slug|out('DECIDED_IN').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("decisions_of_adr",
            "out('BELONGS_TO_PROJECT').slug|out('DECIDED_IN').out('BELONGS_TO_PROJECT').slug"),
        // Вопрос: своё ребро ИЛИ место, где поднят (RAISED_IN → ADR/спринт), ИЛИ —
        // decision:D-2026-LORE-QUESTION-VISIBILITY-INHERIT-OR-LANE (06.11.2026) —
        // компонент вопроса, который через СПРИНТЫ принадлежит проекту (компонент
        // достигает проекта только через спринты). Не нашёлся ни одним путём —
        // «полоса вне проектов»: её видят admin и superadmin (bypassesScope),
        // остальным она не показывается. Замер прода 06.11: без проекта 120 открытых,
        // наследование через компонент открывает 80, в полосе остаётся 40.
        Map.entry("open_questions", QUESTION_SCOPE),
        // D-2026-LORE-QUESTIONS-SLICE-RENAME: новое имя того же среза — тот же скоуп.
        Map.entry("questions", QUESTION_SCOPE),
        // MT-MCP-TRUTH A4/A8/A10: гигиена вопросов видна тем же, кому видны сами вопросы.
        Map.entry("question_hygiene", QUESTION_SCOPE),
        // SPRINT_QG_REBUILD/QG-01 (решение владелицы 19.11.2026 «2а»): гейт виден, если он общий
        // (scope = 'global', проекта у него нет по построению) ИЛИ разрешён его проект.
        Map.entry("quality_gates", QG_SCOPE),
        Map.entry("quality_gate_by_id", QG_SCOPE),
        // AL-SCOPE-HOLES (06.11.2026): выпадающий список проектов — по самому slug («=» — скалярное поле).
        Map.entry("git_projects", "=slug"),
        // S4-29 (53а): паспорт проекта — тем же правилом, что выпадающий список проектов.
        Map.entry("project_by_id", "=slug"),
        Map.entry("project_sprints", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("project_adrs", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("project_releases", "out('BELONGS_TO_PROJECT').slug"),
        // 11.11: прямые связи проекта — запись видна тому, кому виден её проект (своё ребро).
        Map.entry("project_specs", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("project_decisions", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("project_questions", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("project_features", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("project_docs", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("project_runbooks", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("project_files", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("project_prs", "out('BELONGS_TO_PROJECT').slug"),
        // 1.18: раздел «PR» — проект по ребру или по полю git_project (ребро у старых PR не стоит).
        Map.entry("prs", "out('BELONGS_TO_PROJECT').slug|=git_project"),
        // Задачи — проект через спринт.
        Map.entry("tasks_of_sprint", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("tasks_of_phase", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry(LoreTaskIdentities.SLICE, "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry(LoreRolesLostOnMove.SLICE, "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("tasks_of_uc", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        // S9-05 A: задачи человека и агента — проект через спринт, как у прочих задач.
        Map.entry("user_tasks", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("agent_tasks", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("tasks_by_uids", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("tasks_of_sprints_batch", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("sprint_totals", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("open_tasks", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("closed_tasks", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("task_close_path", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("component_tasks", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        // D-2026-MINILORE-OWNER-ANSWERS-06-11 п.3: задача релиза — проект через её спринт.
        Map.entry("release_tasks_by_tag", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        // AN-06: срез I — строка на uc-задачу, проект через её спринт.
        Map.entry("reeng_load", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("backlog_tasks", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("all_tasks", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("task_status_by_sprint", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("unlinked_enb_tasks", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("unlinked_uc_tasks", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("invest_profile", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("history_task", "in('HAS_STATE').out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("task_done_dates", "in('HAS_STATE').out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("task_created_dates", "in('HAS_STATE').out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("task_starts", "in('HAS_STATE').out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("task_status_versions", "in('HAS_STATE').out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("phases_of_sprint", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        // Спринты мимо sprints.
        Map.entry("timeline_sprints", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("sprint_tree", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("sprint_deps_of", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("sprint_done_dates", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("component_sprints", "out('BELONGS_TO_PROJECT').slug"),
        // S9-05 B: спринты вехи — строки-спринты, скоуп по проекту спринта, как у компонента.
        Map.entry("milestone_sprints", "out('BELONGS_TO_PROJECT').slug"),
        // MDL-13: спринты на треке (с историей) — спринты своих проектов.
        Map.entry("track_sprints", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("product_sprints", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("release_sprints", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("release_sprints_by_tag", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("blocked_sprints", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("blocked_sprints_reason", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("roadmap_unplanned", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("history_sprint", "in('HAS_STATE').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("sprint_starts", "in('HAS_STATE').out('BELONGS_TO_PROJECT').slug"),
        // ADR, решения, спеки, релизы мимо скоупных списков.
        Map.entry("adr", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("timeline_adrs", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("timeline_specs", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("timeline_releases", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("releases_since", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("adr_history", "in('HAS_STATE').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("adr_history_all", "in('HAS_STATE').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("spec_history_all", "in('HAS_STATE').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("decision", "out('BELONGS_TO_PROJECT').slug|out('DECIDED_IN').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("timeline_decisions", "out('BELONGS_TO_PROJECT').slug|out('DECIDED_IN').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("release_decisions", "out('BELONGS_TO_PROJECT').slug|out('DECIDED_IN').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("decision_status_versions", "in('HAS_STATE').out('BELONGS_TO_PROJECT').slug|in('HAS_STATE').out('DECIDED_IN').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("decision_history_all", "in('HAS_STATE').out('BELONGS_TO_PROJECT').slug|in('HAS_STATE').out('DECIDED_IN').out('BELONGS_TO_PROJECT').slug"),
        // Вопросы — своё ребро или место, где подняты.
        Map.entry("question_by_id", "out('BELONGS_TO_PROJECT').slug|out('RAISED_IN').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("questions_of_adr", "out('BELONGS_TO_PROJECT').slug|out('RAISED_IN').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("questions_of_task", "out('BELONGS_TO_PROJECT').slug|out('RAISED_IN').out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("tasks_of_adr", "out('PART_OF').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("adrs_of_task", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("closed_sprints_with_open_tasks", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("questions_of_sprint", "out('BELONGS_TO_PROJECT').slug|out('RAISED_IN').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("gating_questions_of_task", "out('BELONGS_TO_PROJECT').slug|out('RAISED_IN').out('BELONGS_TO_PROJECT').slug"),
        Map.entry("questions_gating_closed_tasks", "out('BELONGS_TO_PROJECT').slug|out('RAISED_IN').out('BELONGS_TO_PROJECT').slug"),
        // Продуктовый слой: сценарии и акторы несут BELONGS_TO_PROJECT.
        Map.entry("features", "out('BELONGS_TO_PROJECT').slug"),
        Map.entry("uc_by_id", UC_INHERITED_SCOPE),
        Map.entry("use_cases_of_component", UC_INHERITED_SCOPE),
        // S4-PRODUCTS-NODE: сценарии продукта — тот же скоуп, что у сценариев компонента.
        Map.entry("product_features", UC_INHERITED_SCOPE),
        Map.entry("use_cases", UC_INHERITED_SCOPE),
        Map.entry("use_cases_of_feature", UC_INHERITED_SCOPE),
        Map.entry("shipped_dynamics", UC_INHERITED_SCOPE),
        Map.entry("feature_vp_analytics", "out('BELONGS_TO_PROJECT').slug")
        // actors / actor_load — НЕ здесь: AL-106, агенты видны всем (см. SHARED_SLICES).
    );

    /**
     * AL-SCOPE-HOLES: срезы, которые ЗАКОННО не режутся проектным скоупом — с причиной.
     * Сторож ScopeCoverageGuardTest требует, чтобы каждый срез был скоупным, общим или
     * «ждёт решения»: иначе новый срез тихо уезжает мимо скоупа (так было с 132 из 141).
     */
    static final Map<String, String> SHARED_SLICES = Map.ofEntries(
        Map.entry("user_project_roles", "по нему miniLORE делит выдачу по людям (D-2026-LORE-MINILORE-READER-READS-ALL)"),
        Map.entry("project_users", "то же: участники проекта для разделения по людям"),
        Map.entry("project_people", "паспорт проекта (S4-29): участники — та же выборка, что project_users"),
        Map.entry("user_by_id", "паспорт человека (S9-05): имя и проекты — те же сведения, что project_people"),
        Map.entry("users", "раздел «Люди» (S9-05): имена и проекты — те же сведения, что project_people"),
        Map.entry("agents", "раздел «Агенты» (S9-05): агенты видны всем (AL-106), как actors"),
        Map.entry("agent_by_id", "паспорт агента (S9-05): агенты видны всем (AL-106), как project_agents"),
        Map.entry("project_agents", "паспорт проекта (S4-29): агенты видны всем (AL-106), как actors"),
        Map.entry("project_actors", "паспорт проекта (11.11): роли продукта видны всем, как actors (AL-106)"),
        Map.entry("project_bound_agents", "паспорт проекта (11.11): агенты видны всем (AL-106), как project_agents"),
        Map.entry("project_components", "паспорт проекта (S4-29): компоненты — общий справочник, как components"),
        Map.entry("components", "справочник компонентов — общий"),
        Map.entry("component", "паспорт компонента — общий справочник"),
        Map.entry("components_in_area", "справочник компонентов — общий"),
        Map.entry("dictionary", "справочники — общие"),
        Map.entry("history_dict", "история справочника — общая"),
        Map.entry("products", "продукты — общий справочник"),
        Map.entry("product_by_id", "паспорт продукта (S4-PRODUCTS-NODE) — общий справочник, как products"),
        Map.entry("product_pains", "боли продукта — общий продуктовый профиль, как pains"),
        Map.entry("product_gains", "выгоды продукта — общий продуктовый профиль, как gains"),
        Map.entry("product_jobs", "работы продукта — глобальные вершины, как jobs (AL-113)"),
        Map.entry("product_actors", "роли продукта — AL-106: акторы видны всем, как actors"),
        Map.entry("tags_usage", "теги — общие"),
        Map.entry("jobs", "работа (JTBD) — глобальная вершина по построению (AL-113)"),
        Map.entry("pains", "боли сегмента — общий продуктовый профиль"),
        Map.entry("gains", "выгоды сегмента — общий продуктовый профиль"),
        Map.entry("agent_owners", "реестр агентов и владельцев — служебный"),
        Map.entry("machine_acl", "допуски к машинам (S7B-ACL-1) — служебный: по нему miniLORE решает видимость диалогов машины"),
        Map.entry("agent_sessions", "журнал сессий агентов — служебный"),
        Map.entry("actor_identity_orphans", "сторож учёток — служебный"),
        Map.entry("projects_without_role", "сторож ролей — служебный"),
        Map.entry("project_role_events", "журнал смены ролей — служебный"),
        Map.entry("entities_without_project", "сторож сирот — по определению сущности БЕЗ проекта"),
        Map.entry("scope_orphans", "сторож сирот скоупа — по определению без проекта"),
        Map.entry("history_hygiene", "сторож истории — служебный"),
        Map.entry("asset_orphans", "сторож ассетов — служебный"),
        Map.entry("tech_registry", "реестр технологий — общий"),
        Map.entry("tech_by_id", "паспорт технологии — тот же общий реестр"),
        Map.entry("actors", "AL-106: агенты видны всем при включённом скоупе (решение владельца 04.11.2026)"),
        Map.entry("actor_load", "AL-106: та же выборка акторов с нагрузкой — видна всем"),
        // MD-04: паспорта — тот же скоуп, что у их списков (actors, pains, gains, jobs).
        Map.entry("actor_by_id", "паспорт роли продукта (MD-04): AL-106, роли видны всем, как actors"),
        Map.entry("pain_by_id", "паспорт боли (MD-04): общий продуктовый профиль, как pains"),
        Map.entry("gain_by_id", "паспорт выгоды (MD-04): общий продуктовый профиль, как gains"),
        Map.entry("job_by_id", "паспорт работы (MD-04): глобальная вершина (AL-113), как jobs"),
        Map.entry("role_profile_coverage", "AO-06: агрегат покрытия ролей профилем — числа по корпусу, без записей проектов"),
        Map.entry("model_config_history", "MC-05: модель LORE одна на всю студию — история её версий общая"),
        // D-2026-MIG-REPOSITORY-ORGANIZATION: организация — самостоятельный объект студии, с проектами не связана.
        Map.entry("organizations", "организации — самостоятельные объекты студии, связей с проектами нет (D-2026-MIG-REPOSITORY-ORGANIZATION)"),
        Map.entry("org_by_id", "паспорт организации — та же выборка, что organizations")
    );

    /**
     * AP-08 (SPRINT_LORE_ADMIN_POLISH/AP-08, автотест RBAC на препроде 15.11.2026, кейс AD-01):
     * админские журналы — только admin/superadmin. До гейта их отдавали любому вошедшему: viewer
     * открывал админку и видел «0 отказов» вместо «нет прав». Агентские профили несут роль admin
     * (KcBridge), поэтому MCP-чтение журналов не ломается; служебный читатель miniLORE их не читает
     * (requests_by_caller, 15.11). Сторож AdminOnlySlicesGateTest: новый срез из SCOPE_PENDING с
     * пометкой «админский/журнал/телеметрия» без места здесь не проходит.
     */
    public static final Set<String> ADMIN_ONLY = Set.of(
        "mcp_failures", "mcp_failure_rows", "mcp_connections", "agent_actions", "admin_actions", "agent_action_points",
        "logins_recent", "logins_by_user", "sessions_recent", "requests_by_caller", "requests_total", "role_matrix");

    /** Срез админский, а роль вызывающего — не admin/superadmin: отказ 403, а не пустая выдача. */
    public static boolean adminOnlyDenied(String id, String role) {
        return ADMIN_ONLY.contains(id) && !"admin".equals(role) && !"superadmin".equals(role);
    }

    /**
     * AL-SCOPE-HOLES: проектные по смыслу, но пока НЕ под скоупом — нужно решение владелицы
     * (общая это поверхность или проектная) либо путь до проекта нетривиален. Явный
     * список, а не умолчание: каждая запись — открытая дыра, видимая в коде.
     */
    static final Map<String, String> SCOPE_PENDING = Map.ofEntries(
        Map.entry("search", "сложный SQL (подзапрос); эндпоинт /lore/search под скоупом с AL-SCOPE-HOLES A, легаси-срез палитры — ещё нет"),
        Map.entry("product_hygiene", "агрегат по подзапросу — скоуп внутрь подзапроса"),
        Map.entry("strategic_coverage", "агрегат по подзапросу — скоуп внутрь подзапроса"),
        Map.entry("milestones", "вехи M0…M7 не связаны с проектами (MT-GOALS) — решение о модели вех"),
        Map.entry("milestone_by_id", "то же: паспорт вехи, веха без проекта"),
        // MDL-13: трек — справочник студии без проекта, как веха; спринты на нём режутся скоупом (PROJECT_SCOPED).
        Map.entry("track_by_id", "паспорт трека: трек — справочник студии без проекта, как веха"),
        Map.entry("roadmap", "то же: веха без проекта"),
        Map.entry("uc_actors", "ребро HAS_ACTOR — путь через сценарий"),
        Map.entry("actor_pairs", "ребро FILLS_ROLE — служебное, решение"),
        Map.entry("files_of_task", "KnowFile — путь через задачу"),
        Map.entry("task_roles", "ребро ROLE_HELD_BY — путь через задачу"),
        Map.entry("tag_entities", "ребро TAGGED_WITH — путь через запись (ADR, решение); скоуп по проекту записи — SUPERTAGS шаг 3"),
        Map.entry("task_roles_history", "ребро ROLE_HELD_BY — путь через задачу"),
        Map.entry("release_prs", "KnowPR — путь через релиз"),
        Map.entry("release_prs_by_tag", "KnowPR — путь через релиз"),
        Map.entry("pr_by_id", "паспорт PR (MD-05): KnowPR — путь через релиз или задачу, как release_prs"),
        Map.entry("pr_ship_lag", "KnowPR — путь через релиз (графики 19.11, №9)"),
        Map.entry("findings", "находки — решение владелицы"),
        Map.entry("finding_by_id", "находки — решение владелицы"),
        // D-2026-MIG-REPOSITORY-ORGANIZATION: репозиторий связан с проектом, но путь двойной (свой основной и через компонент).
        Map.entry("repositories", "репозитории — общий реестр (как components) или по проекту (HAS_REPOSITORY / компонент → продукт → проект): решение владелицы"),
        Map.entry("repo_by_id", "репозитории — общий реестр (как components) или по проекту (HAS_REPOSITORY / компонент → продукт → проект): решение владелицы"),
        Map.entry("repos_of_project", "репозитории — общий реестр (как components) или по проекту (HAS_REPOSITORY / компонент → продукт → проект): решение владелицы"),
        Map.entry("repos_of_component", "репозитории — общий реестр (как components) или по проекту (HAS_REPOSITORY / компонент → продукт → проект): решение владелицы"),
        Map.entry("qg_metrics", "QG — QG-04"),
        Map.entry("qg_job_tasks", "QG — QG-04"),
        Map.entry("qg_recommendations", "QG — QG-04"),
        Map.entry("qg_violations", "QG — QG-04"),
        Map.entry("qg_pending_recs", "QG — QG-04"),
        Map.entry("qg_routine_runs", "QG — QG-04"),
        Map.entry("qg_metrics_latest", "QG — QG-04"),
        Map.entry("qg_run_metrics", "QG — QG-04"),
        Map.entry("qg_run_history", "QG — QG-04"),
        Map.entry("qg_run_outcomes", "QG — QG-04 (графики 19.11, №16)"),
        Map.entry("routine_latest", "рутины QG — QG-04"),
        Map.entry("routine_last_run", "рутины QG — QG-04"),
        Map.entry("routine_outputs", "рутины QG — QG-04"),
        Map.entry("routine_output_by_type", "рутины QG — QG-04"),
        Map.entry("plan_config", "план студии — общий или проектный, решение"),
        Map.entry("plan_tracks", "план — решение"),
        Map.entry(LoreSprintTracks.SLICE, "план — решение (те же треки, что plan_tracks)"),
        Map.entry("plan_sections", "план — решение"),
        Map.entry("plan_checkpoints", "план — решение"),
        Map.entry("plan_versions", "план — решение"),
        Map.entry("bragi_overview", "BRAGI — маркетинг студии, общий или проектный — решение"),
        Map.entry("bragi_publications", "BRAGI — решение"),
        Map.entry("bragi_calendar", "BRAGI — решение"),
        Map.entry("bragi_keys", "BRAGI — решение"),
        Map.entry("bragi_rubrics", "BRAGI — решение"),
        Map.entry("bragi_analytics", "BRAGI — решение"),
        Map.entry("bragi_competitors", "BRAGI — решение"),
        Map.entry("bragi_insights", "BRAGI — решение"),
        Map.entry("bragi_integrations", "BRAGI — решение"),
        Map.entry("bragi_channels", "BRAGI — решение"),
        Map.entry("bragi_pages", "BRAGI — решение"),
        Map.entry("requests_by_caller", "телеметрия обращений — админская, решение"),
        Map.entry("requests_total", "телеметрия — решение"),
        Map.entry("agent_actions", "журнал действий (AO-01) — админский, как телеметрия; решение"),
        Map.entry("admin_actions", "журнал действий админки (S7B-02) — тот же ряд AO-01, админский; решение"),
        Map.entry("role_matrix", "матрица ролей проект × люди (S7B-11) — админская, как project_users для всех; решение"),
        Map.entry("mcp_connections", "подключения MCP (S7B-07) — телеметрия агентов, админская; решение"),
        Map.entry("mcp_failures", "сбои записей агентов (S7B-07) — ряд AO-01, админский; решение"),
        Map.entry("mcp_failure_rows", "отказы записей агентов построчно (S7B-30) — ряд AO-01, админский; решение"),
        Map.entry("agent_action_points", "действия агентов точками для графиков (19.11) — ряд AO-01, админский; решение"),
        Map.entry("logins_recent", "журнал входов — админский, решение"),
        Map.entry("logins_by_user", "журнал входов — решение"),
        Map.entry("sessions_recent", "журнал сессий — решение")
    );

    /**
     * Слайсы, у которых при отсутствии роли обнуляется ТЕЛО, а не прячется
     * строка. Значение — поля тела; поле проектов у всех трёх `projects`.
     *
     * <p>Решение владелицы 19.10.2026: «достаточно обнулять текст самого
     * документа при выдаче по MCP или же в web». Это принципиально иная мера,
     * чем {@link #PROJECT_SCOPED}: там строка исчезает из выдачи, здесь —
     * остаётся с опознавательными полями (идентификатор, заголовок, вид,
     * проекты), а скрывается только содержимое.
     *
     * <p><b>Почему это лучше для документов.</b> Скоуп по строкам режет по
     * ребру {@code BELONGS_TO_PROJECT}, и запись БЕЗ ребра он отрезает не по
     * правам, а по недостающим данным — у всех, включая владельца. Замер
     * 19.10.2026: проекта нет у 218 спек из 415, у 239 доков из 292, у 42
     * ранбуков из 47. Построчное скрытие спрятало бы 499 записей от каждого;
     * обнуление тела не прячет ни одной.
     *
     * <p><b>Обнулённое тело обязано отличаться от пустого документа.</b> Рядом
     * ставится признак {@code body_redacted} и причина: иначе «нет доступа»
     * стало бы неотличимо от «не написано» — тот самый класс, против которого
     * написана половина проверок корпуса.
     *
     * <p><b>Запись без проекта НЕ обнуляется.</b> У неё нет проекта, на котором
     * можно иметь роль, и обнулять её значило бы снова наказывать за недостачу
     * данных. Такие записи перечисляет срез {@code scope_orphans} — это видимая
     * работа, а не тихая дыра.
     */
    static final Map<String, List<String>> BODY_SCOPED = Map.of(
        "doc_by_id",     List.of("content_html", "content_md_en", "content_md_ru"),
        "spec_by_id",    List.of("content_md", "summary"),
        "runbook_by_id", List.of("content_md"),
        // K2-FEED-BODY-MORE: голова тела спеки в строке списка — то же тело, что
        // content_md паспорта; обнуляется до свёртки, и головы у записи нет вовсе.
        "specs",         List.of(LoreBodyHead.SRC + "1")
    );

    /** Значение-заглушка для пустого скоупа: slug, которого не бывает. */
    static final String SCOPE_NONE = "__no_project__";

    /**
     * Скоуп-вариант compose: {@code allowed == null} — без ограничения
     * (superadmin, выключенная аутентификация, слайс вне PROJECT_SCOPED),
     * непустое множество — «виден, если разрешён ХОТЯ БЫ ОДИН его проект»
     * (решение владельца про сущности на пересечении), пустое множество —
     * не видно ничего (заведомо ложное условие через SCOPE_NONE, а не пустой
     * IN: поведение пустого списка в грамматике ArcadeDB не проверено).
     *
     * <p>Сущность БЕЗ единого ребра проекта скоупом отсекается — это осознанно:
     * иначе «ничьё» было бы видно всем, и скоуп ничего не гарантировал бы. Хвост
     * непривязанных вершин после V20 (AL-92) — причина держать enforcement за
     * флагом до наполнения графа.</p>
     */
    public static Composed compose(String id, Map<String, String> given, java.util.Set<String> allowed) {
        Composed base = compose(id, given);
        String traversal = allowed == null ? null : PROJECT_SCOPED.get(id);
        if (traversal == null) return base;

        Map<String, Object> params = new LinkedHashMap<>(base.params());
        // Выражений может быть несколько (прямая связь | через родителя) — сущность
        // видна, если ХОТЯ БЫ ОДИН путь ведёт в разрешённый проект.
        //
        // Решение владелицы 11.11.2026 (sprint_deps под скоуп): у ребра ДВА конца,
        // и показывать его можно, только если видны ОБА — иначе оно ведёт в
        // невидимое. Группы через «&» — обязательные концы: каждая обязана привести
        // в разрешённый проект (внутри группы «|», как и прежде, — «хотя бы один»).
        List<String> keys = new java.util.ArrayList<>();
        if (allowed.isEmpty()) {
            params.put("__scope0", SCOPE_NONE);
            keys.add("__scope0");
        } else {
            int i = 0;
            for (String slug : allowed) {
                String key = "__scope" + i++;
                params.put(key, slug);
                keys.add(key);
            }
        }
        String[] groups = traversal.split("&");
        StringBuilder all = new StringBuilder();
        for (String group : groups) {
            String[] traversals = group.split("\\|");
            StringBuilder or = new StringBuilder();
            for (String key : keys) {
                for (String tr : traversals) {
                    if (or.length() > 0) or.append(" OR ");
                    or.append(scopeClause(tr, key));
                }
            }
            if (all.length() > 0) all.append(" AND ");
            all.append("(").append(or).append(")");
        }
        String condition = groups.length == 1 ? all.toString() : "(" + all + ")";
        // Скоуп дописывается ПОСЛЕ suffix'а базового SQL нельзя — ORDER BY/LIMIT
        // уже там. Поэтому пересобираем: условие идёт перед хвостом слайса.
        String sql = base.sql();
        SliceDef def = SLICES.get(id);
        String suffix = def.suffix();
        String head = suffix.isEmpty() || !sql.endsWith(suffix) ? sql : sql.substring(0, sql.length() - suffix.length());
        // AL-SCOPE-HOLES: у части срезов ORDER BY/LIMIT записан в самом запросе, а не
        // в хвосте — условие, дописанное после него, ломало бы SQL.
        int cut = trailingClauseStart(head);
        String tail = cut < 0 ? "" : head.substring(cut);
        if (cut >= 0) head = head.substring(0, cut);
        String connector = containsWhere(head) ? " AND " : " WHERE ";
        return new Composed(head + connector + condition + tail + suffix, params);
    }

    /**
     * SE-16: списочный параметр — имя на {@code _ids} или {@code _uids}. Уходит в
     * СУБД СПИСКОМ: ArcadeDB в {@code IN :ids} находит элементы массива, а строку
     * «A,B» сравнивает целиком и отдаёт пусто (замер на проде 20.10.2026) — так
     * пакетный срез работал только с одним элементом.
     */
    static final int LIST_PARAM_MAX = 200;

    static boolean isListParam(String name) {
        return name.endsWith("_ids") || name.endsWith("_uids");
    }

    /** Каждый элемент — тем же белым списком, что одиночное значение; пустые выброшены. */
    static List<String> listValue(String name, String raw) {
        List<String> out = new java.util.ArrayList<>();
        if (raw != null) for (String part : raw.split(",")) {
            String v = part.trim();
            if (v.isEmpty()) continue;
            if (!VALUE_RE.matcher(v).matches() || v.contains(","))
                throw new IllegalArgumentException("bad value for param: " + name);
            out.add(v);
        }
        if (out.isEmpty()) throw new IllegalArgumentException("empty list for param: " + name);
        if (out.size() > LIST_PARAM_MAX)
            throw new IllegalArgumentException("too many values for param: " + name + " (max " + LIST_PARAM_MAX + ")");
        return out;
    }

    public static Composed compose(String id, Map<String, String> given) {
        SliceDef def = SLICES.get(id);
        if (def == null) throw new IllegalArgumentException("unknown slice: " + id);

        for (String key : given.keySet()) {
            if (!def.required().contains(key) && !def.optionalFilters().containsKey(key))
                throw new IllegalArgumentException("unknown param: " + key);
        }
        for (String key : def.required()) {
            if (given.get(key) == null || given.get(key).isBlank())
                throw new IllegalArgumentException("missing required param: " + key);
        }
        Map<String, Object> params = new LinkedHashMap<>();
        for (Map.Entry<String, String> e : given.entrySet()) {
            String value = e.getValue();
            if (isListParam(e.getKey())) {
                params.put(e.getKey(), listValue(e.getKey(), value));
                continue;
            }
            if (value == null || !VALUE_RE.matcher(value).matches())
                throw new IllegalArgumentException("bad value for param: " + e.getKey());
            String kind = TYPED_PARAMS.getOrDefault(id, Map.of()).get(e.getKey());
            params.put(e.getKey(), kind == null ? value : typedValue(e.getKey(), kind, value));
        }

        // MDL-13: тип 1.18, у которого на старой схеме другое имя (KnowTrack ← PlanTrack), — по схеме базы.
        StringBuilder sql = new StringBuilder(ModelSchemaAdapter.legacyTypes(def.baseSql()));
        // Склейка нескольких одновременных фильтров.
        //
        // Раньше фрагменты просто дописывались подряд, а каждый нёс СВОЁ
        // « WHERE » — два фильтра сразу давали «… WHERE a WHERE b», то есть
        // невалидный SQL и 500 у вызывающего. Ограничение было известно и
        // задокументировано у слайса `sprints`, но обходилось соглашением
        // «по одному активному фильтру на слайс» — до первого, кто передаст
        // status и project вместе (поймано 2026-07-21 на шлюзе).
        //
        // Здесь связка нормализуется в одном месте: у фрагмента отрезается
        // ведущее WHERE/AND, а соединитель выбирается по факту — WHERE, если
        // условий ещё не было, иначе AND. Так десять существующих регистраций
        // остаются нетронутыми в обеих формах написания.
        boolean hasWhere = containsWhere(def.baseSql());
        for (Map.Entry<String, String> opt : def.optionalFilters().entrySet()) {
            if (!given.containsKey(opt.getKey())) continue;
            String frag = stripLeadingConnector(opt.getValue());
            if (frag.isEmpty()) continue;
            sql.append(hasWhere ? " AND " : " WHERE ").append(frag);
            hasWhere = true;
        }
        sql.append(def.suffix());
        return new Composed(sql.toString(), params);
    }

    /**
     * Есть ли в базовом запросе собственное условие. Скобки и строковые
     * литералы не разбираем: слайсы — наш код, а не пользовательский ввод, и
     * ни один из них не содержит слова WHERE внутри литерала. Если такой
     * появится, честнее будет завести ему явный флаг, чем городить парсер.
     */
    /**
     * «=field» — скалярное поле (равенство); «?условие» — литерал, видимый под любым скоупом (общий гейт
     * QG-01); иначе — обход рёбер (CONTAINS).
     */
    /** MDL-13: конец ребра DEPENDS_ON — сама запись среза deps_of (тип и ключ из параметров). */
    static String depsSelf(String end) {
        return "(" + LoreDependency.typeSql(end) + " = :type AND " + LoreDependency.idSql(end) + " = :id)";
    }

    static String scopeClause(String traversal, String key) {
        if (traversal.startsWith("?")) return traversal.substring(1);
        return traversal.startsWith("=")
            ? traversal.substring(1) + " = :" + key
            : traversal + " CONTAINS :" + key;
    }

    /** Начало завершающего ORDER BY или LIMIT верхнего уровня (вне скобок); -1 — нет. */
    static int trailingClauseStart(String sql) {
        String u = sql.toUpperCase(java.util.Locale.ROOT);
        int depth = 0, found = -1;
        for (int i = 0; i < u.length(); i++) {
            char c = u.charAt(i);
            if (c == '(') depth++;
            else if (c == ')') depth--;
            else if (depth == 0 && found < 0 && (u.startsWith(" ORDER BY ", i) || u.startsWith(" LIMIT ", i))) found = i;
        }
        return found;
    }

    private static boolean containsWhere(String sql) {
        return sql.toUpperCase(java.util.Locale.ROOT).contains(" WHERE ");
    }

    /** Отрезает ведущее WHERE/AND у фрагмента фильтра, оставляя само условие. */
    private static String stripLeadingConnector(String fragment) {
        String s = fragment == null ? "" : fragment.trim();
        String upper = s.toUpperCase(java.util.Locale.ROOT);
        if (upper.startsWith("WHERE ")) return s.substring(6).trim();
        if (upper.startsWith("AND "))   return s.substring(4).trim();
        return s;
    }
}
