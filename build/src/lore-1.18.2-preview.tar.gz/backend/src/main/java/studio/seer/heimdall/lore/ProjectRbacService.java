package studio.seer.heimdall.lore;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * AL-68/ADR-LORE-036: резолвер «клиент KC → агент → владелец → роль владельца
 * в проекте → разрешён ли профиль агента здесь» (матрица D4) + сама матрица.
 *
 * <p>Собран как самостоятельный, полностью протестированный сервис — WIRING в
 * реальный запрос (чтение {@code client_id} вызывающего агента из JWT) сюда
 * НЕ входит и сделан отдельным шагом. Причина: клейм с client_id клиента
 * (обычно {@code azp}, но не проверено на живом токене lore-mcp-*) нигде в
 * кодовой базе ещё не читается, и ошибка в имени клейма тихо превратит
 * проверку в always-deny — тот самый обрыв работающих агентов, от которого
 * предостерегает note AL-66. Резолвер сам по себе безопасен: не встроен —
 * не может ничего сломать, а протестирован полностью на графовых фикстурах.
 *
 * <p><b>Инвариант «профиль вне набора роли = запрет, не сужение»</b> (ADR-036):
 * неизвестная роль, отсутствие роли (проект не виден) и профиль вне набора
 * роли — все три ветки возвращают {@code false}, ни одна не пропускает по
 * умолчанию.
 */
@ApplicationScoped
public class ProjectRbacService {

    @Inject
    LoreIngestService ingestService;

    /**
     * Матрица «роль человека в проекте × профиль агента» (ADR-LORE-036-D4).
     * Спорные клетки (`✅?`) решены в пользу «да» — see [[ADR-LORE-036-D4]]
     * / [[OQ-RBAC-MATRIX-CELLS]], закрыт решением, привязанным к D4.
     * Коды ролей — те, что предложены владельцу для словаря project_role
     * в задаче AL-81 (owner/architect/pm/developer/business-analyst/
     * marketer/tester/reader); коды профилей — те же, что в
     * {@code AgentScopeFilter.FAMILY_AGENTS}.
     */
    static final Map<String, Set<String>> ROLE_AGENT_MATRIX = Map.of(
        "owner",             Set.of("full", "architect", "pm", "developer",
                                     "product-analyst", "analyst", "marketer", "tester"),
        "architect",         Set.of("architect", "developer", "tester"),
        "pm",                Set.of("pm", "product-analyst", "analyst", "tester"),
        "developer",         Set.of("developer", "tester"),
        "business-analyst",  Set.of("product-analyst", "analyst"),
        "marketer",          Set.of("marketer"),
        "tester",            Set.of("tester")
        // "reader" сознательно отсутствует строкой: пустой набор и есть
        // допустимое значение по умолчанию для роли без явной записи ниже.
    );

    /** Чистая функция, без похода в граф — отдельно юнит-тестируема. */
    static boolean delegationAllowed(String projectRole, String agentScope) {
        if (projectRole == null || agentScope == null) return false;
        Set<String> allowed = ROLE_AGENT_MATRIX.get(projectRole);
        return allowed != null && allowed.contains(agentScope);
    }

    /**
     * SPRINT_LORE_ADMIN_POLISH/AP-03 — ответ «что будет делать агент с профилем agentScope у
     * этого владельца» ДО выдачи учётки: по каждому проекту владельца (строки HAS_PROJECT_ROLE
     * {slug, role}) — роль, делегирует ли она agentScope ({@link #delegationAllowed}, та же
     * матрица, что на записи) и какие профили она делегирует вообще (для счётчиков мастера).
     * Чистая функция; проекты по алфавиту; строка без проекта пропускается.
     */
    static List<Map<String, Object>> delegationPlan(List<Map<String, Object>> roleRows, String agentScope) {
        var out = new java.util.ArrayList<Map<String, Object>>();
        for (var r : roleRows) {
            Object slug = r.get("slug");
            if (slug == null || String.valueOf(slug).isBlank()) continue;
            String role = r.get("role") == null ? null : String.valueOf(r.get("role"));
            var row = new java.util.LinkedHashMap<String, Object>();
            row.put("project", String.valueOf(slug));
            row.put("role", role);
            row.put("delegates", delegationAllowed(role, agentScope));
            row.put("profiles", role == null ? List.of()
                : ROLE_AGENT_MATRIX.getOrDefault(role, Set.of()).stream().sorted().toList());
            out.add(row);
        }
        out.sort(java.util.Comparator.comparing(m -> String.valueOf(m.get("project"))));
        return out;
    }

    /** {@link #delegationPlan} по ролям человека из графа. */
    public List<Map<String, Object>> delegationForOwner(String kcSub, String agentScope) {
        if (kcSub == null) return List.of();
        return delegationPlan(ingestService.queryPublic(
            "SELECT @in.slug AS slug, role FROM HAS_PROJECT_ROLE WHERE valid_to IS NULL AND @out.kc_sub = :sub",
            Map.of("sub", kcSub)), agentScope);
    }

    /**
     * client_id клиента KC → kc_sub владельца, либо {@code null}, если клиент
     * не связан ни с одним актором-агентом в графе ([[AL-83]]: агент без
     * владельца — отказ, не пропуск, а не «нет входа в цепочку»).
     */
    String ownerKcSub(String clientId) {
        if (clientId == null || clientId.isBlank()) return null;
        var rows = ingestService.queryPublic(
            "SELECT out('OWNED_BY').kc_sub AS owners FROM KnowActor "
            + "WHERE kind = 'agent' AND client_id = :cid", Map.of("cid", clientId));
        if (rows.isEmpty()) return null;
        Object owners = rows.get(0).get("owners");
        if (!(owners instanceof java.util.List<?> l) || l.isEmpty()) return null;
        return String.valueOf(l.get(0));
    }

    /**
     * Роль владельца (kc_sub) в проекте (slug), либо {@code null} — нет роли,
     * значит по матрице D4 «проект не виден вовсе» ([[AL-82]]).
     */
    String ownerRoleInProject(String kcSub, String project) {
        if (kcSub == null || project == null) return null;
        var rows = ingestService.queryPublic(
            "SELECT role FROM HAS_PROJECT_ROLE WHERE valid_to IS NULL AND @out.kc_sub = :sub AND @in.slug = :proj",
            Map.of("sub", kcSub, "proj", project));
        if (rows.isEmpty()) return null;
        return String.valueOf(rows.get(0).get("role"));
    }

    /**
     * Композит трёх шагов диаграммы D4: client_id → владелец → роль в
     * проекте → сверка с матрицей. {@code false} на любом обрыве цепочки
     * (осиротевший клиент, владелец без роли в этом проекте, профиль вне
     * набора роли) — сознательно один и тот же вердикт, разные причины
     * различимы через отдельные методы выше при отладке/логировании.
     */
    public boolean agentAllowedInProject(String clientId, String project, String agentScope) {
        String owner = ownerKcSub(clientId);
        if (owner == null) return false;
        String role = ownerRoleInProject(owner, project);
        return delegationAllowed(role, agentScope);
    }

    // ── AL-93 (фаза PROJECT_SCOPE): список разрешённых проектов вызывающего ──
    //
    // Резолвер ЧИСТЫЙ: superadmin-bypass и «auth off = superadmin» решаются на
    // уровне вызывающего (скоуп-фильтры AL-94), не здесь — иначе каждая ветка
    // обхода должна была бы знать про роли реалма, и bypass расползся бы по
    // графовым запросам. Пустое множество = «не видит ни одного проекта» —
    // честный ответ для вызывающего без ролей, не ошибка.

    /**
     * Проекты, где у человека (kc_sub) есть ЛЮБАЯ роль — сама роль для read-скоупа
     * не важна: даже reader видит проект, просто ничего в нём не пишет.
     */
    public Set<String> allowedProjectsForUser(String kcSub) {
        if (kcSub == null || kcSub.isBlank()) return Set.of();
        var rows = ingestService.queryPublic(
            "SELECT outE('HAS_PROJECT_ROLE')[valid_to IS NULL].inV().slug AS slugs FROM KnowUser WHERE kc_sub = :sub",
            Map.of("sub", kcSub));
        if (rows.isEmpty()) return Set.of();
        return distinct(rows.get(0).get("slugs"));
    }

    /**
     * Есть ли у вызывающего вход в граф ролей ВООБЩЕ: актор-агент с таким
     * {@code client_id} либо {@code KnowUser} с таким {@code sub}.
     *
     * <p><b>Зачем отдельный вопрос рядом с «какие проекты разрешены».</b>
     * Резолверы выше отдают пустое множество в ДВУХ разных случаях, и по
     * значению они неотличимы: «вызывающего завели, роль не дали» — ответ по
     * правам; «вызывающего в графе нет» — недостача данных. Решение, принятое
     * на стороне записи (запись без проекта не обнуляем, потому что на ней
     * нельзя иметь роль), симметрично требует того же со стороны вызывающего:
     * иначе неопознанный клиент получает «нет доступа» там, где правда — «мы
     * не смогли определить, кто вы».
     *
     * <p><b>Замер, из-за которого это понадобилось</b> (прод, 19.10.2026):
     * главный потребитель API — служебная учётка приложения miniLORE, 25 478
     * вызовов, и её нет ни в {@code agent_owners} (7 профилей
     * {@code lore-mcp-*}), ни в {@code actors}. То есть пустое множество на
     * главном читающем пути означает именно второй случай.
     *
     * <p><b>Границы.</b> Это НЕ разрешение: «не опознан» не даёт прав и не
     * должно давать. Ответ годится ровно на то, чтобы выбрать между «скрыть»
     * и «сказать, что проверить не смогли» — построчный скоуп на нём
     * послаблений не делает, иначе незаведённый клиент читал бы весь корпус.
     */
    public boolean knownToRoleGraph(String clientId, String kcSub) {
        if (clientId != null && !clientId.isBlank()) return ownerKcSub(clientId) != null;
        if (kcSub == null || kcSub.isBlank()) return false;
        return !ingestService.queryPublic(
            "SELECT kc_sub FROM KnowUser WHERE kc_sub = :sub", Map.of("sub", kcSub)).isEmpty();
    }

    /**
     * Проекты, ВИДИМЫЕ агенту на чтении: все проекты его владельца, БЕЗ сужения
     * матрицей D4.
     *
     * <p>Решение владельца (2026-08-01): <b>читать — всё в пределах своих
     * проектов, изменять — в пределах роли</b>. Участник проекта, включая его
     * агента, должен знать артефакты своего проекта; иначе получается странное —
     * человек в проекте состоит, а истории решений по нему не видит.
     *
     * <p>Поэтому D4 здесь НЕ применяется: матрица делегирования отвечает на
     * вопрос «что агенту позволено ДЕЛАТЬ», а не «что ему позволено ЗНАТЬ».
     * Агент всё равно не видит больше владельца — множество берётся из его
     * рёбер, — но и не уже проекта, в котором владелец участвует.
     *
     * <p>Для записи по-прежнему {@link #allowedProjectsForAgent}: там сужение
     * ролью обязательно.
     */
    public Set<String> visibleProjectsForAgent(String clientId) {
        String owner = ownerKcSub(clientId);
        return owner == null ? Set.of() : allowedProjectsForUser(owner);
    }

    /**
     * Проекты, где роль ВЛАДЕЛЬЦА агента делегирует профиль этого агента
     * (матрица D4 поверх всех ролей владельца одним запросом по рёбрам,
     * а не обходом всех KnowGitProject). Осиротевший клиент → пустое множество.
     *
     * <p><b>Только для ЗАПИСИ.</b> На чтении сужать по роли нельзя — см.
     * {@link #visibleProjectsForAgent}.
     */
    public Set<String> allowedProjectsForAgent(String clientId, String agentScope) {
        String owner = ownerKcSub(clientId);
        if (owner == null || agentScope == null) return Set.of();
        var rows = ingestService.queryPublic(
            "SELECT @in.slug AS slug, role FROM HAS_PROJECT_ROLE WHERE valid_to IS NULL AND @out.kc_sub = :sub",
            Map.of("sub", owner));
        var out = new java.util.LinkedHashSet<String>();
        for (var r : rows) {
            Object slug = r.get("slug");
            if (slug != null && delegationAllowed(String.valueOf(r.get("role")), agentScope)) {
                out.add(String.valueOf(slug));
            }
        }
        return out;
    }

    /** Результат графового траверса (скаляр или список) → distinct non-null строки. */
    private static Set<String> distinct(Object raw) {
        var out = new java.util.LinkedHashSet<String>();
        if (raw instanceof java.util.Collection<?> c) {
            for (Object o : c) if (o != null && !String.valueOf(o).isBlank()) out.add(String.valueOf(o));
        } else if (raw != null && !String.valueOf(raw).isBlank()) {
            out.add(String.valueOf(raw));
        }
        return out;
    }
}
