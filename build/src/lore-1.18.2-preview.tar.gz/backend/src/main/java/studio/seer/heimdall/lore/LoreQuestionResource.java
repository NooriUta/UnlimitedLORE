package studio.seer.heimdall.lore;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * KnowQuestion write path — the open-questions register (ADR-LORE-020/021).
 *
 * Vertex-only, like KnowDecision (ADR-021 §SCD2): status / opened_date /
 * closed_date are plain vertex fields, NO KnowQuestionHist. `closed` is set
 * ONLY when a decision ANSWERS the question (the /question/answers link) — never
 * directly — so "closed without a closing decision" cannot happen. `deferred`
 * requires a non-empty trigger (otherwise the register rots into a dump).
 */
@Path("/lore")
public class LoreQuestionResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreQuestionResource.class);

    static final java.util.Set<String> STATUSES = java.util.Set.of("open", "deferred", "closed", "dropped");

    /**
     * MT-MCP-TRUTH A1–A2 (06.11.2026): отказ на closed руками обязан объяснять
     * механику. Прежний текст её не называл, и агент ставил dropped как
     * ближайшее по смыслу — четыре доказательства ушли в заметки вместо решения.
     */
    static final String CLOSE_GUIDANCE =
        "status='closed' не ставится руками: вопрос закрывается САМ, когда решение отвечает на него. "
        + "Сделай: decision_new с доказательством (коммит, PR, замер, слово владелицы), затем "
        + "question_link rel=answers (POST /lore/question/answers) — статус станет closed. "
        + "Одно решение может закрыть несколько вопросов — по связи answers на каждый. "
        + "Не путай с dropped: dropped = «решили НЕ отвечать»; «устарел, и вот доказательство» = closed через решение.";

    /**
     * MT-MCP-TRUTH A6 (решение владелицы 19.11.2026, «1а»): ответственный — ребро ANSWERABLE_BY к человеку или
     * агенту реестра, а не текст. Прежде здесь пять написаний владелицы сводились к строке omiloreadmin и
     * писались в поле owner; теперь значение сопоставляется с реестром ({@link QuestionOwner#resolve}), незнакомое —
     * 422 с причиной, текст поля больше не пишется (остаётся только для чтения старых записей).
     */
    private QuestionOwner.Graph ownerGraph() {
        return new QuestionOwner.Graph() {
            @Override
            public List<Map<String, Object>> query(String sql, Map<String, Object> params) {
                return ingestService.queryPublic(sql, params);
            }
            @Override
            public void exec(String sql, Map<String, Object> params) {
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql", sql, params)).await().indefinitely();
            }
        };
    }

    private static Response ownerRefused(String why) {
        return noStore(Response.status(422).entity(new LoreError("OWNER_UNKNOWN", why)));
    }

    public record QuestionCreateRequest(
        String question_id, String title, String body_md, String status,
        String trigger, String component_id, String due_date, String priority,
        String owner, String raised_by, String opened_date, String closed_date) {}

    @POST
    @Path("question")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createQuestion(QuestionCreateRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.question_id() == null || req.question_id().isBlank())
            return badParams("question_id required");
        if (!SAFE_ID.matcher(req.question_id()).matches())
            return badParams("question_id contains illegal characters");
        if (req.status() != null && !STATUSES.contains(req.status()))
            return badParams("status must be one of open|deferred|closed|dropped");
        // closed is a consequence of an ANSWERS link, never set by hand.
        if ("closed".equals(req.status()))
            return badParams(CLOSE_GUIDANCE);
        // deferred without a trigger is exactly the rot ADR-021 warns against.
        if ("deferred".equals(req.status()) && (req.trigger() == null || req.trigger().isBlank()))
            return badParams("status='deferred' requires a non-empty trigger");
        // MT-MCP-TRUTH A6: ответственный сопоставляется с реестром ДО записи — незнакомый не оставляет
        // полузаписанного вопроса и не пишется текстом.
        QuestionOwner.Target ownerTarget = null;
        if (req.owner() != null) {
            QuestionOwner.Resolved r;
            try {
                r = QuestionOwner.resolve(ownerGraph(), req.owner());
            } catch (Exception e) {
                LOG.warnf("[LORE QUESTION OWNER] %s: %s", req.question_id(), e.getMessage());
                return upstream(e);
            }
            if (r.refusal() != null) return ownerRefused(r.refusal());
            ownerTarget = r.target();
        }
        try {
            StringBuilder sql = new StringBuilder("UPDATE KnowQuestion SET question_id=:qid");
            Map<String, Object> p = new java.util.HashMap<>();
            p.put("qid", req.question_id());
            // Правило владелицы 19.11.2026: вопрос без статуса (новый или со статусом null) получает начальный
            // статус типа по модели (question.status.initial), подстановка — в ответе (defaulted).
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> had = (List<Map<String, Object>>) writeClient.command(db, basicAuth(),
                new LoreCommandClient.LoreCommand("sql", "SELECT status FROM KnowQuestion WHERE question_id=:qid",
                    Map.of("qid", req.question_id()))).await().indefinitely().result();
            boolean noStatusYet = had == null || had.isEmpty() || had.get(0).get("status") == null;
            final CreateDefaultStatus.Pick statusPick = noStatusYet ? CreateDefaultStatus.pick("question", req.status()) : null;
            putIf(sql, p, "title",        ":title", req.title());
            putIf(sql, p, "body_md",      ":body",  req.body_md());
            putIf(sql, p, "status",       ":status", statusPick != null ? statusPick.value() : req.status());
            // `trigger` В ОБРАТНЫХ КАВЫЧКАХ — зарезервированное слово SQL ArcadeDB.
            // Без них запрос не парсится вовсе:
            //   CommandSQLParsingException: mismatched input ',' … trigger=:trig
            // Из-за этого статус deferred был НЕДОСТИЖИМ: D3 требует непустой
            // trigger, валидация выше не пускает deferred без него, а запись
            // самого trigger падала на разборе. Замкнутый круг, который не
            // проявлялся, пока никто не пробовал отложить вопрос по-настоящему
            // (первый случай — 2026-07-19, вопросов с trigger было ноль).
            putIf(sql, p, "`trigger`",    ":trig",  req.trigger());
            putIf(sql, p, "component_id", ":comp",  req.component_id());
            putIf(sql, p, "due_date",     ":due",   req.due_date());
            putIf(sql, p, "priority",     ":prio",  req.priority());
            // owner текстом не пишется (A6): ответственный — ребро ANSWERABLE_BY, ниже.
            putIf(sql, p, "raised_by",    ":rb",    req.raised_by());
            putIf(sql, p, "opened_date",  ":od",    req.opened_date());
            putIf(sql, p, "closed_date",  ":cd",    req.closed_date());
            // S4-MODEL-TYPES (свежесть): у вопроса истории нет — момент заведения/правки на вершине.
            sql.append(", updated_at=:upd");
            p.put("upd", java.time.Instant.now().toString());
            sql.append(" UPSERT WHERE question_id=:qid");
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                sql.toString(), p)).await().indefinitely();
            // Default on fresh insert: opened_date=today (only where null). Статус — выше, из модели.
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE KnowQuestion SET opened_date=:d WHERE question_id=:qid AND opened_date IS NULL",
                Map.of("d", java.time.LocalDate.now(java.time.ZoneOffset.UTC).toString(), "qid", req.question_id()))).await().indefinitely();
            Map<String, Object> out = new java.util.LinkedHashMap<>();
            out.put("ok", true);
            out.put("question_id", req.question_id());
            // NM-03 (ADR-LORE-041): вопрос писал component_id полем; 86 вопросов
            // на проде связаны с компонентом только так, и ни один слайс их не
            // показывает. Отдельная ирония: реестр открытых вопросов ровно за
            // тем и нужен, чтобы ничего не терялось.
            linkComponentEdge("KnowQuestion", "question_id", req.question_id(), req.component_id(), out);
            if (ownerTarget != null)
                out.put("owner", QuestionOwner.assign(ownerGraph(), req.question_id(), ownerTarget,
                    "question:" + callerLabel(), java.time.Instant.now().toString()));
            // Вердикт полноты (ADR-LORE-039): вопрос без владельца не закрывается —
            // он висит прочитанный и никем не взятый.
            WorkQuality.Result quality = questionQuality(req.question_id());
            if (quality != null) out.put("quality", WorkQuality.compact(quality));
            CreateDefaultStatus.report(out, statusPick); // правило владелицы 19.11.2026: подстановка видна
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE QUESTION CREATE] %s: %s", req.question_id(), e.getMessage());
            return upstream(e);
        }
    }

    /**
     * Вердикт полноты открытого вопроса (ADR-LORE-039). Читается ПОСЛЕ записи —
     * в том числе после проставления умолчаний (status=open, opened_date),
     * иначе вердикт судил бы состояние, которого уже нет. Сбой сборки не роняет
     * ответ: запись состоялась.
     */
    // Факты собирает LoreQualityFacts — один источник на путь записи и
    // батч-API. Своя копия проекции здесь была причиной трёх разошедшихся
    // прочтений за один день (status vs status_raw, поле не из модели,
    // release_id вместо release_uid).
    @jakarta.inject.Inject
    LoreQualityFacts qualityFacts;

    private WorkQuality.Result questionQuality(String questionId) {
        return qualityFacts.forOne(LoreQualityFacts.Kind.QUESTION, questionId);
    }

    // ── Links ────────────────────────────────────────────────────────────────

    public record QAnswersRequest(String decision_id, String question_id, String action) {}

    @POST
    @Path("question/answers")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkAnswers(QAnswersRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.decision_id() == null || req.question_id() == null)
            return badParams("decision_id and question_id required");
        if (!SAFE_ID.matcher(req.decision_id()).matches() || !SAFE_ID.matcher(req.question_id()).matches())
            return badParams("ids contain illegal characters");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            // DBR-17 (ADR-LORE-043): проба ДО записи — исход из факта, а не из ok:true.
            boolean had = edgeExists("ANSWERS", "decision_id", req.decision_id(), "question_id", req.question_id());
            boolean linked = false;
            if (remove) {
                deleteEdges("ANSWERS", "@out.decision_id=:d AND @in.question_id=:q",
                    Map.of("d", req.decision_id(), "q", req.question_id()));
                // AL-26: инвариант «closed ⇔ на вопрос есть ANSWERS» должен работать
                // в ОБЕ стороны. Раньше remove снимал ребро и оставлял status=closed —
                // вопрос повисал закрытым без единого ответа, и состояние врало.
                //
                // Возвращаем в open ТОЛЬКО когда снят ПОСЛЕДНИЙ ответ: если у вопроса
                // остаются другие ANSWERS, он закрыт по праву. Условие `in('ANSWERS').size()=0`
                // проверяет это на самой вершине, а не доверяет тому, что снятое ребро
                // было единственным.
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "UPDATE KnowQuestion SET status='open', closed_date=null " +
                    "WHERE question_id=:q AND status='closed' AND in('ANSWERS').size()=0",
                    Map.of("q", req.question_id()))).await().indefinitely();
            } else {
                linked = created(writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE ANSWERS FROM (SELECT FROM KnowDecision WHERE decision_id=:d) " +
                    "TO (SELECT FROM KnowQuestion WHERE question_id=:q) IF NOT EXISTS",
                    Map.of("d", req.decision_id(), "q", req.question_id()))).await().indefinitely().result());
                // The invariant: a question is closed exactly when a decision answers it.
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "UPDATE KnowQuestion SET status='closed', closed_date=:cd " +
                    "WHERE question_id=:q AND status <> 'closed'",
                    Map.of("cd", java.time.LocalDate.now(java.time.ZoneOffset.UTC).toString(), "q", req.question_id()))).await().indefinitely();
            }
            if (remove ? had : (linked && !had)) touchUpdatedAt("KnowQuestion", "question_id", req.question_id());
            Map<String, Object> base = new LinkedHashMap<>(Map.of("ok", true, "question_id", req.question_id(),
                "decision_id", req.decision_id(), "action", remove ? "removed" : "added"));
            // MT-MCP-TRUTH A6 (владелица 19.11.2026): вопрос закрыт решением — ответственным становится автор
            // решения. Только на НОВОЙ связи: повтор старой не должен перетягивать ответственного назад.
            // Автор неизвестен — ребро не трогается, причина в ответе (не молча).
            if (!remove && linked && !had) {
                // Повтор связи придёт с had=true и автора уже не переведёт — поэтому сбой перевода не роняет
                // ответ (связь записана), а называется в нём.
                try {
                    QuestionOwner.Graph g = ownerGraph();
                    QuestionOwner.Resolved author = QuestionOwner.decisionAuthor(g, req.decision_id());
                    if (author.target() != null)
                        base.put("owner", QuestionOwner.assign(g, req.question_id(), author.target(),
                            "answers:" + req.decision_id(), java.time.Instant.now().toString()));
                    else
                        base.put("owner_unchanged", author.refusal() + " — ответственный вопроса не менялся");
                } catch (Exception e) {
                    LOG.warnf("[LORE QUESTION ANSWERS OWNER] %s: %s", req.question_id(), e.getMessage());
                    base.put("owner_unchanged", "ответственного не удалось перевести на автора решения: " + e.getMessage()
                        + " — связь answers записана, ответственный вопроса не менялся (question_set owner=…)");
                }
            }
            return remove ? unlinkOutcome(base, had)
                : linkOutcome(had, base, linked, "ANSWERS", "decision_id", req.decision_id(),
                    "question_id", req.question_id(), "решение " + req.decision_id() + " или вопрос " + req.question_id());
        } catch (Exception e) {
            LOG.warnf("[LORE QUESTION ANSWERS] %s: %s", req.question_id(), e.getMessage());
            return upstream(e);
        }
    }

    public record QRaisedInRequest(String question_id, String target_type, String target_id, String action) {}

    @POST
    @Path("question/raised_in")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkRaisedIn(QRaisedInRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.question_id() == null || req.target_type() == null || req.target_id() == null)
            return badParams("question_id, target_type and target_id required");
        if (!SAFE_ID.matcher(req.question_id()).matches() || !SAFE_ID.matcher(req.target_id()).matches())
            return badParams("ids contain illegal characters");
        // target_type → (vertex type, id field)
        String type, field;
        switch (req.target_type()) {
            case "adr":    type = "KnowADR";    field = "adr_id";    break;
            case "sprint": type = "KnowSprint"; field = "sprint_id"; break;
            case "task":   type = "KnowTask";   field = "task_uid";  break;
            default: return badParams("target_type must be adr|sprint|task");
        }
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            boolean had = edgeExists("RAISED_IN", "question_id", req.question_id(), field, req.target_id()); // DBR-17
            boolean linked = false;
            if (remove) {
                deleteEdges("RAISED_IN", "@out.question_id=:q AND @in." + field + "=:t",
                    Map.of("q", req.question_id(), "t", req.target_id()));
            } else {
                linked = created(writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE RAISED_IN FROM (SELECT FROM KnowQuestion WHERE question_id=:q) " +
                    "TO (SELECT FROM " + type + " WHERE " + field + "=:t) IF NOT EXISTS",
                    Map.of("q", req.question_id(), "t", req.target_id()))).await().indefinitely().result());
            }
            if (remove ? had : (linked && !had)) touchUpdatedAt("KnowQuestion", "question_id", req.question_id());
            Map<String, Object> base = Map.of("ok", true, "question_id", req.question_id(),
                "target_id", req.target_id(), "action", remove ? "removed" : "added");
            return remove ? unlinkOutcome(base, had)
                : linkOutcome(had, base, linked, "RAISED_IN", "question_id", req.question_id(), field, req.target_id(),
                    "вопрос " + req.question_id() + " или " + req.target_type() + " " + req.target_id());
        } catch (Exception e) {
            LOG.warnf("[LORE QUESTION RAISED_IN] %s: %s", req.question_id(), e.getMessage());
            return upstream(e);
        }
    }

    public record QGatesRequest(String question_id, String task_uid, String action) {}

    @POST
    @Path("question/gates")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkGates(QGatesRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.question_id() == null || req.task_uid() == null)
            return badParams("question_id and task_uid required");
        if (!SAFE_ID.matcher(req.question_id()).matches() || !SAFE_ID.matcher(req.task_uid()).matches())
            return badParams("ids contain illegal characters");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            boolean had = edgeExists("GATES", "question_id", req.question_id(), "task_uid", req.task_uid()); // DBR-17
            boolean linked = false;
            if (remove) {
                deleteEdges("GATES", "@out.question_id=:q AND @in.task_uid=:t",
                    Map.of("q", req.question_id(), "t", req.task_uid()));
            } else {
                linked = created(writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE GATES FROM (SELECT FROM KnowQuestion WHERE question_id=:q) " +
                    "TO (SELECT FROM KnowTask WHERE task_uid=:t) IF NOT EXISTS",
                    Map.of("q", req.question_id(), "t", req.task_uid()))).await().indefinitely().result());
            }
            if (remove ? had : (linked && !had)) touchUpdatedAt("KnowQuestion", "question_id", req.question_id());
            Map<String, Object> base = Map.of("ok", true, "question_id", req.question_id(),
                "task_uid", req.task_uid(), "action", remove ? "removed" : "added");
            return remove ? unlinkOutcome(base, had)
                : linkOutcome(had, base, linked, "GATES", "question_id", req.question_id(), "task_uid", req.task_uid(),
                    "вопрос " + req.question_id() + " или задача " + req.task_uid());
        } catch (Exception e) {
            LOG.warnf("[LORE QUESTION GATES] %s: %s", req.question_id(), e.getMessage());
            return upstream(e);
        }
    }

    public record QComponentRequest(String question_id, String component_id, String action) {}

    @POST
    @Path("question/component")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkComponent(QComponentRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.question_id() == null || req.component_id() == null)
            return badParams("question_id and component_id required");
        if (!SAFE_ID.matcher(req.question_id()).matches() || !SAFE_ID.matcher(req.component_id()).matches())
            return badParams("ids contain illegal characters");
        // T43: components are now MULTI, via BELONGS_TO edges (like tasks) — add/remove.
        // The legacy component_id vertex field is kept in sync as the "primary" (first) one.
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            boolean had = edgeExists("BELONGS_TO", "question_id", req.question_id(), "component_id", req.component_id()); // DBR-17
            boolean linked = false;
            if (remove) {
                deleteEdges("BELONGS_TO", "@out.question_id=:q AND @in.component_id=:c",
                    Map.of("q", req.question_id(), "c", req.component_id()));
            } else {
                linked = created(writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE BELONGS_TO FROM (SELECT FROM KnowQuestion WHERE question_id=:q) " +
                    "TO (SELECT FROM LoreComponent WHERE component_id=:c) IF NOT EXISTS",
                    Map.of("q", req.question_id(), "c", req.component_id()))).await().indefinitely().result());
                // keep the legacy single field pointing at the primary component if unset
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "UPDATE KnowQuestion SET component_id=:c WHERE question_id=:q AND component_id IS NULL",
                    Map.of("c", req.component_id(), "q", req.question_id()))).await().indefinitely();
            }
            if (remove ? had : (linked && !had)) touchUpdatedAt("KnowQuestion", "question_id", req.question_id());
            Map<String, Object> base = Map.of("ok", true, "question_id", req.question_id(),
                "component_id", req.component_id(), "action", remove ? "removed" : "added");
            return remove ? unlinkOutcome(base, had)
                : linkOutcome(had, base, linked, "BELONGS_TO", "question_id", req.question_id(),
                    "component_id", req.component_id(), "вопрос " + req.question_id() + " или компонент " + req.component_id());
        } catch (Exception e) {
            LOG.warnf("[LORE QUESTION COMPONENT] %s: %s", req.question_id(), e.getMessage());
            return upstream(e);
        }
    }

    public record QProjectRequest(String question_id, String project, String action) {}

    @POST
    @Path("question/project")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkProject(QProjectRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.question_id() == null || req.project() == null)
            return badParams("question_id and project required");
        if (!SAFE_ID.matcher(req.question_id()).matches())
            return badParams("question_id contains illegal characters");
        // T43: questions belong to one or more git projects (multi) via BELONGS_TO_PROJECT.
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            boolean had = edgeExists("BELONGS_TO_PROJECT", "question_id", req.question_id(), "slug", req.project()); // DBR-17
            boolean linked = false;
            if (remove) {
                deleteEdges("BELONGS_TO_PROJECT", "@out.question_id=:q AND @in.slug=:p",
                    Map.of("q", req.question_id(), "p", req.project()));
            } else {
                linked = created(writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE BELONGS_TO_PROJECT FROM (SELECT FROM KnowQuestion WHERE question_id=:q) " +
                    "TO (SELECT FROM KnowGitProject WHERE slug=:p) IF NOT EXISTS",
                    Map.of("q", req.question_id(), "p", req.project()))).await().indefinitely().result());
            }
            if (remove ? had : (linked && !had)) touchUpdatedAt("KnowQuestion", "question_id", req.question_id());
            Map<String, Object> base = Map.of("ok", true, "question_id", req.question_id(),
                "project", req.project(), "action", remove ? "removed" : "added");
            // linked=false на незарегистрированном проекте — noop с причиной, а не ok:true.
            return remove ? unlinkOutcome(base, had)
                : linkOutcome(had, base, linked, "BELONGS_TO_PROJECT", "question_id", req.question_id(),
                    "slug", req.project(), "вопрос " + req.question_id() + " или проект " + req.project()
                        + " (проект заводится через project_new)");
        } catch (Exception e) {
            LOG.warnf("[LORE QUESTION PROJECT] %s: %s", req.question_id(), e.getMessage());
            return upstream(e);
        }
    }

    // ── helpers ────────────────────────────────────────────────────────────

    /** Вернул ли CREATE EDGE строку. Признак, не факт: решает linkOutcome с пробой. */
    private static boolean created(Object result) {
        return result instanceof java.util.List<?> l && !l.isEmpty();
    }

    private static void putIf(StringBuilder sql, Map<String, Object> p, String col, String bind, Object val) {
        if (val != null) { sql.append(", ").append(col).append('=').append(bind); p.put(bind.substring(1), val); }
    }

    private Response upstream(Exception e) {
        return noStore(Response.status(Response.Status.BAD_GATEWAY)
            .entity(LoreUpstream.error(e)));
    }
}
