package studio.seer.heimdall.lore;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ADR-LORE-023: реестр миграций схемы system_aida_lore. Принципы взяты из
 * ADR-HND-022 (V{n}__имя, ledger применённых, checksum-verify, деструктив за
 * флагом), раннер — свой, под специфику LORE (ответ OQ-023-RUNNER, 2026-07-17).
 *
 * Правила:
 * - Шаг применяется РОВНО один раз; факт — строка LoreSchemaVersion (версия,
 *   имя, checksum, applied_at). Текущая версия БД = max(version).
 * - Каждый SQL-стейтмент идемпотентен (IF NOT EXISTS) — повторный прогон
 *   безопасен; но ledger предотвращает его в норме.
 * - Изменять УЖЕ ВЫПУЩЕННЫЙ шаг нельзя — checksum-verify откажет старту
 *   (дрейф кода против применённой истории). Нужна правка → новый шаг.
 * - Аддитивные шаги (всё ниже) данных не трогают (ADR-023 п.5).
 * - version=4 — Java-шаг (backfill), см. LoreSchemaMigrationRunner#javaStep.
 */
final class LoreSchemaMigrations {

    /**
     * version — сквозной ordinal: порядок применения и ключ ledger, неизменяем.
     * compatMajor — ось СОВМЕСТИМОСТИ (major версии схемы). Аддитивные шаги делят
     * major с предыдущими (10.1/10.2/10.3 — старый бинарь major=10 их спокойно
     * переживёт, форвард-совместимость), несовместимый шаг ПОДНИМАЕТ major (11) —
     * и только тогда дрейф-гард отказывает старту старого кода.
     * Историческим шагам (3-арг конструктор) compatMajor=version — каждый сам себе
     * major; НОВЫЙ аддитивный шаг передаёт МЕНЬШИЙ compatMajor явно (4-арг), напр.
     * new Step(11, 10, "…", …) = ordinal 11, но major 10 → человеку это «10.1».
     */
    record Step(int version, int compatMajor, String name, List<String> sql) {
        Step(int version, String name, List<String> sql) { this(version, version, name, sql); }

        String checksum() {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                for (String s : sql) md.update(s.getBytes(StandardCharsets.UTF_8));
                byte[] d = md.digest();
                StringBuilder sb = new StringBuilder(16);
                for (int i = 0; i < 8; i++) sb.append(String.format("%02x", d[i]));
                return sb.toString();
            } catch (Exception e) { throw new IllegalStateException(e); }
        }

        /** Человекочитаемая версия major.minor (minor = порядковый среди шагов того же major). */
        String human() {
            long minor = STEPS.stream()
                .filter(s -> s.compatMajor() == compatMajor && s.version() <= version).count() - 1;
            return compatMajor + "." + minor;
        }
    }

    private LoreSchemaMigrations() {}

    /** Код-ожидаемая версия схемы = максимум реестра (ordinal). */
    static int codeVersion() { return STEPS.get(STEPS.size() - 1).version(); }

    /** Ось совместимости: максимальный major в реестре. Отстал от него бинарь → отказ старта. */
    static int codeCompatMajor() { return STEPS.stream().mapToInt(Step::compatMajor).max().orElse(0); }

    /** major.minor последнего шага — для логов и сообщений. */
    static String codeHuman() { return STEPS.get(STEPS.size() - 1).human(); }

    /**
     * Типы, которые ОБЯЗАНЫ физически существовать в схеме на любой БД, чей
     * ledger заявляет актуальную версию (dbVersion == codeVersion). Продуктовый
     * слой канвы Остервальдера: сценарии, боли, выгоды, работы, акторы, ассеты.
     *
     * <p>ЗАЧЕМ. Ledger-строка пишется отдельным INSERT ПОСЛЕ DDL/Java-шага
     * (LoreSchemaMigrationRunner.run), не атомарно с ним. Шаг, чья часть сделала
     * no-op или прервалась, оставляет «версия записана, а типов нет». Сверка
     * ТОЛЬКО номера версии этого не ловит — приложение стартует и отдаёт 500 по
     * продуктовым слайсам (features/pains/gains/jobs/actors/asset_orphans). Ровно
     * этот отказ и наблюдался на внешней установке 2026-08-17. Материальная сверка
     * превращает тихие 500 в громкий отказ старта с указанием, что накатить.
     *
     * <p>СПИСОК ВЫВОДИТСЯ ИЗ САМИХ ШАГОВ, а не ведётся рукой. Рукой ведомый
     * список отставал молча: в нём было шесть имён из сорока трёх, которые
     * шаги создают, — то есть пропажа тридцати семи типов не роняла старт и
     * обнаруживалась только запросом в рантайме. Ошибка не в том, что кто-то
     * забыл дописать строку: список, который надо помнить, забывают по
     * определению, и признака этого нет.
     *
     * <p>Ниже — ровно та же мысль, что во всём корпусе: две правды об одном
     * факте расходятся, поэтому правда должна быть одна. Здесь источник правды
     * — {@link #STEPS}, а сверка её читает.
     *
     * <p>Исключения именные и с причиной у каждого, потому что исключение
     * обязано быть решением, а не тихой строкой.
     */
    // МЕТОД, А НЕ ПОЛЕ, и это не стилистика. Статические поля инициализируются
    // в порядке объявления: поле, посчитанное здесь, читало бы STEPS до того,
    // как список создан, и класс падал бы при загрузке. Ленивое вычисление
    // снимает зависимость от порядка строк в файле.
    private static volatile List<String> requiredLiveTypes;

    static List<String> requiredLiveTypes() {
        List<String> v = requiredLiveTypes;
        if (v == null) {
            v = typesCreatedBySteps();
            requiredLiveTypes = v;
        }
        return v;
    }


    /**
     * Типы, которых на здоровой АКТУАЛЬНОЙ базе быть не должно, хотя шаг их
     * когда-то создавал: позже другой шаг их растворил и удалил. Требовать их
     * наличия значило бы ложно ронять старт.
     */
    private static final Set<String> DROPPED_BY_LATER_STEPS = Set.of(
        // V6 создаёт, V13 растворяет в KnowUseCase и ДРОПАЕТ
        // (mergeFeaturesIntoUseCases). На актуальной БД его нет и быть не должно.
        "KnowFeature");

    /** {@code CREATE VERTEX|EDGE|DOCUMENT TYPE X} — с {@code IF NOT EXISTS} и без. */
    private static final Pattern CREATE_TYPE = Pattern.compile(
        "(?i)CREATE\\s+(?:VERTEX|EDGE|DOCUMENT)\\s+TYPE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?`?(\\w+)`?");

    private static List<String> typesCreatedBySteps() {
        Set<String> types = new LinkedHashSet<>();
        for (Step s : STEPS) {
            for (String sql : s.sql()) {
                Matcher m = CREATE_TYPE.matcher(sql);
                while (m.find()) types.add(m.group(1));
            }
        }
        types.removeAll(DROPPED_BY_LATER_STEPS);
        return List.copyOf(types);
    }

    /** Решение раннера о старте по версиям — чистое, тестируется без БД (ADR-023). */
    enum StartupDecision {
        UP_TO_DATE,      // db == code
        RUN_PENDING,     // db < code — доиграть недостающие шаги
        FORWARD_COMPAT,  // db впереди по аддитивным шагам того же major — работаем, варнинг
        INCOMPATIBLE     // у БД major новее кода — ломающий шаг, которого нет в коде → отказ
    }

    static StartupDecision decide(int dbVersion, int dbCompatMajor, int codeVersion, int codeCompatMajor) {
        if (dbCompatMajor > codeCompatMajor) return StartupDecision.INCOMPATIBLE;
        if (dbVersion > codeVersion)         return StartupDecision.FORWARD_COMPAT;
        if (dbVersion < codeVersion)         return StartupDecision.RUN_PENDING;
        return StartupDecision.UP_TO_DATE;
    }

    /**
     * RM-P12: типы *Hist, у которых {@code valid_from} — ТЕКСТ в ISO-8601 UTC.
     *
     * <p>Один список на три потребителя: SQL шага V42 объявляет по нему
     * свойство, {@code LoreSchemaMigrationRunner.normalizeHistValidFrom}
     * приводит по нему строки, {@code LoreHistValidFromTypedTest} по нему же
     * проверяет полноту. Ровно тот класс расхождения, который в этом же спринте
     * разбирается отдельной задачей (RM-P8: PROJECT_SCOPED ведётся вручную в
     * двух местах и они уже разошлись) — не заводим третью такую таблицу.
     *
     * <p><b>Почему STRING, а не DATETIME</b>, хотя два соседа объявлены DATETIME
     * ({@link #HIST_VALID_FROM_TEMPORAL}). Замер по проду 04.09.2026, все 9400
     * строк KnowTaskHist — четыре разных вида хранения в одной таблице:
     * <pre>
     *   ISO-8601 UTC  "2026-08-31T12:34:56.789Z"   8523   90.7 %
     *   через пробел  "2026-06-11 22:26:41"         838
     *   только дата   "2026-06-14"                   29
     *   эпоха, число  1781569369738                  10
     * </pre>
     * Разнобой ИСТОРИЧЕСКИЙ и уже прекратился: всё, что записано после
     * 30.06.2026, — ISO-8601 UTC, и все нынешние пишущие пути дают именно его
     * ({@code Instant.now().toString()}). То есть ISO-Z — не выбор вкуса, а
     * фактическое представление системы; DATETIME у двух соседей появился
     * позже, как лечение того же бага.
     *
     * <p>Решающий довод, однако, не в дешевизне (877 строк против 9400), а на
     * границе с потребителем. Объявление DATETIME заставило бы ArcadeDB
     * приводить записи, и наружу пошёл бы вид «через пробел» — проверено на
     * KnowSprintHist, который объявлен DATETIME: слайс {@code sprint_starts}
     * отдаёт 1711 из 1711 строк как {@code "2026-04-13 00:00:00"}. В JS
     * {@code new Date("2026-04-13 00:00:00")} разбирается как МЕСТНОЕ время, а
     * {@code new Date("2026-04-13T00:00:00Z")} — как UTC. Потребители здесь
     * браузерные (фронтенд и шлюз miniLORE), так что вид без обозначения зоны
     * молча сдвигает дату на смещение читателя. ISO-Z однозначен.
     *
     * <p>Оговорка, которую не прячем: у 838 строк «через пробел» зона в самих
     * данных не записана. Считаем их UTC — потому что все пишущие пути
     * происходят от {@code Instant} (UTC по определению), а наносекундная
     * дробь в этих значениях ({@code 2026-06-30 06:24:46.590910794}) выдаёт
     * именно java-сериализацию Instant, а не рендер DATETIME (у того точность
     * миллисекундная). Цифры часов при этом НЕ трогаются: приведение меняет
     * форму, а не момент, и любой существующий порядок сохраняется.
     *
     * <p><b>RM-P13 (05.11.2026): реестр ЗАМОРОЖЕН.</b> Это список, по которому
     * когда-то шли V41 и V42, и только он: SQL шага V42 собирается из него, а
     * checksum выпущенного шага неизменяем (дрейф = отказ старта). Действующее
     * правило — {@link #HIST_VALID_FROM_TEXT} (пуст) и
     * {@link #HIST_VALID_FROM_TEMPORAL} (все *Hist), переход делает V56.
     */
    static final List<String> V42_HIST_VALID_FROM_TEXT = List.of(
        "KnowADRHist",
        "KnowDecisionHist",
        "KnowDocHist",
        "KnowFindingHist",
        "KnowMilestoneHist",
        "KnowPhaseHist",
        "KnowReleaseHist",
        "KnowRunbookHist",
        "KnowSpecHist",
        "KnowTaskHist");

    /**
     * RM-P13: типы *Hist, у которых {@code valid_from} хранится ТЕКСТОМ. Пуст —
     * и должен оставаться пустым.
     *
     * <p>Решение владельца 05.11.2026: «единый формат, рекомендованный БД,
     * перестаём сочинять». Время в корпусе — нативный DATETIME ArcadeDB
     * (миллисекунды, UTC wall clock). Довод RM-P12 против DATETIME был о
     * ГРАНИЦЕ с браузером («2026-04-13 00:00:00» JS читает как местное время),
     * а не о хранении — и граница теперь закрыта в одном месте:
     * {@link LoreTimeFormat#isoUtcRows} переводит выдачу слайсов в ISO-8601 с
     * {@code Z}. Формат выдачи самой базы ({@code dateTimeFormat}) не трогаем:
     * на 26.10.2 формат, не кончающийся на {@code S}, искажается.
     *
     * <p>Список оставлен, а не удалён: {@code LoreHistValidFromTypedTest}
     * держит инвариант «каждый *Hist ровно в одном реестре», и новый тип,
     * заведённый сюда, валит его проверку «текстовых нет».
     */
    static final List<String> HIST_VALID_FROM_TEXT = List.of();

    /**
     * RM-P13: типы *Hist, у которых {@code valid_from} и {@code valid_to}
     * объявлены DATETIME — все двенадцать. До V56 сюда входили только
     * KnowSprintHist и KnowDictEntryHist; порядок — прежний (сначала бывшие
     * текстовые, потом два исходных), чтобы SQL среза history_hygiene,
     * собираемый по этому списку, не переставлял ветки без нужды.
     */
    static final List<String> HIST_VALID_FROM_TEMPORAL = List.of(
        "KnowADRHist",
        "KnowDecisionHist",
        "KnowDocHist",
        "KnowFindingHist",
        "KnowMilestoneHist",
        "KnowPhaseHist",
        "KnowReleaseHist",
        "KnowRunbookHist",
        "KnowSpecHist",
        "KnowTaskHist",
        "KnowSprintHist",
        "KnowDictEntryHist");

    /** S2-13: Hist-типы, чей статус ведёт StatusHistoryService (V67). Объявлен ДО STEPS: статика инициализируется по порядку. */
    static final List<String> STATUS_HIST_TYPES = List.of(
        "KnowTaskHist", "KnowSprintHist", "KnowPhaseHist", "KnowADRHist", "KnowSpecHist", "KnowDecisionHist");

    /** RM-P13 (V56): свойства времени SCD2-строки, которые приводятся к DATETIME. */
    static final List<String> HIST_TIME_FIELDS = List.of("valid_from", "valid_to");

    // SV-06: DDL сессий 2026-07 задним числом. На живой БД эти стейтменты уже
    // исполнялись out-of-band — идемпотентный replay безвреден и ставит ledger.
    static final List<Step> STEPS = List.of(
        new Step(1, "2026-07_questions_files_hosts_decision_component", List.of(
            "CREATE PROPERTY KnowDecision.component_id IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowDecision (component_id) NOTUNIQUE",
            "CREATE PROPERTY KnowGitProject.hosts IF NOT EXISTS STRING",
            "CREATE VERTEX TYPE KnowFile IF NOT EXISTS",
            "CREATE PROPERTY KnowFile.project    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowFile.file_path  IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowFile.summary_md IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowFile (project, file_path) UNIQUE",
            "CREATE EDGE TYPE EDITED_IN IF NOT EXISTS",
            "CREATE VERTEX TYPE KnowQuestion IF NOT EXISTS",
            "CREATE PROPERTY KnowQuestion.question_id  IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowQuestion.component_id IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowQuestion (question_id)  UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowQuestion (component_id) NOTUNIQUE",
            "CREATE EDGE TYPE ANSWERS   IF NOT EXISTS",
            "CREATE EDGE TYPE RAISED_IN IF NOT EXISTS"
        )),
        new Step(2, "fulltext_primary_bodies", List.of(
            "CREATE PROPERTY KnowADRHist.context_md      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowADRHist.decision_md     IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowADRHist.consequences_md IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowADRHist (context_md)      FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowADRHist (decision_md)     FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowADRHist (consequences_md) FULL_TEXT",
            "CREATE PROPERTY KnowDecision.title   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDecision.body_md IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowDecision (title)   FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowDecision (body_md) FULL_TEXT",
            "CREATE PROPERTY KnowQuestion.title   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowQuestion.body_md IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowQuestion (title)   FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowQuestion (body_md) FULL_TEXT",
            "CREATE PROPERTY KnowSpecHist.content_md    IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowSpecHist (content_md)    FULL_TEXT",
            "CREATE PROPERTY KnowRunbookHist.content_md IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowRunbookHist (content_md) FULL_TEXT",
            "CREATE PROPERTY KnowDocHist.content_md     IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowDocHist (content_md)     FULL_TEXT",
            "CREATE PROPERTY KnowSprintHist.context_md  IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowSprintHist (context_md)  FULL_TEXT",
            "CREATE PROPERTY KnowTaskHist.note_md       IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowTaskHist (note_md)       FULL_TEXT"
        )),
        // SV-09: сплошная ревизия — ВСЕ оставшиеся *_md объявлены и проиндексированы.
        // Самый заметный долг: KnowSprintHist.outcome_md — именно там живут эссе
        // спринтов, а поиска по ним не было.
        new Step(3, "fulltext_md_sweep_rest", List.of(
            "CREATE PROPERTY KnowSprintHist.outcome_md   IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowSprintHist (outcome_md)   FULL_TEXT",
            "CREATE PROPERTY KnowRelease.description_md  IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowRelease (description_md)  FULL_TEXT",
            "CREATE PROPERTY KnowMilestoneHist.goal_md   IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowMilestoneHist (goal_md)   FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowFile (summary_md)         FULL_TEXT",
            "CREATE PROPERTY KnowDoc.content_md          IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowDoc (content_md)          FULL_TEXT",
            "CREATE PROPERTY BragiChannel.rules_md       IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON BragiChannel (rules_md)       FULL_TEXT",
            "CREATE PROPERTY BragiInsight.statement_md   IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON BragiInsight (statement_md)   FULL_TEXT",
            "CREATE PROPERTY BragiPublication.main_text_md IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON BragiPublication (main_text_md) FULL_TEXT",
            "CREATE PROPERTY BragiVariant.text_md        IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON BragiVariant (text_md)        FULL_TEXT",
            // SV-10: content_hash объявляется на всех Hist-типах (писаться будет
            // кодом на записи; объявление нужно на будущее индексирование/выборку).
            "CREATE PROPERTY KnowADRHist.content_hash     IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSprintHist.content_hash  IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTaskHist.content_hash    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSpecHist.content_hash    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowRunbookHist.content_hash IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDocHist.content_hash     IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowMilestoneHist.content_hash IF NOT EXISTS STRING"
        )),
        // Java-шаг: backfill content_hash по существующим Hist-строкам (SQL не умеет
        // SHA-256) — см. LoreSchemaMigrationRunner#javaStep.
        new Step(4, "java__backfill_content_hash", List.of()),
        // V4 первой редакции брал LIMIT 5000 БЕЗ цикла — на живой БД KnowTaskHist
        // упёрся в лимит, хвост остался без хэша. Выпущенный шаг неизменяем
        // (checksum-гард) — добор оформлен новым шагом, backfill теперь циклом.
        new Step(5, "java__backfill_content_hash_tail", List.of()),
        // ADR-LORE-022 (ACCEPTED 2026-07-17): продуктовый слой Feature → UC +
        // ось work_class. Feature/UC — vertex-only (без Hist, как KnowDecision/
        // KnowQuestion); work_class — на ВЕРШИНЕ KnowTask (carry-forward ловушка
        // Hist, ADR-021). Словарь work_class — канон (правят люди, D10) — сидится
        // идемпотентными UPSERT'ами здесь же.
        new Step(6, "product_layer_feature_uc_workclass", List.of(
            "CREATE VERTEX TYPE KnowFeature IF NOT EXISTS",
            "CREATE PROPERTY KnowFeature.feature_id   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowFeature.title        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowFeature.body_md      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowFeature.status       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowFeature.component_id IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowFeature.context_md   IF NOT EXISTS STRING", // D13: большое контекстное поле, как у спринта
            "CREATE PROPERTY KnowFeature.date_created IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowFeature (feature_id) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowFeature (title)   FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowFeature (body_md)    FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowFeature (context_md) FULL_TEXT",
            "CREATE VERTEX TYPE KnowUseCase IF NOT EXISTS",
            "CREATE PROPERTY KnowUseCase.uc_id         IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUseCase.title         IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUseCase.scenario_md   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUseCase.acceptance_md IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUseCase.status        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUseCase.feature_id    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUseCase.date_created  IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowUseCase (uc_id) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowUseCase (feature_id) NOTUNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowUseCase (title)         FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowUseCase (scenario_md)   FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowUseCase (acceptance_md) FULL_TEXT",
            "CREATE EDGE TYPE DECOMPOSES_INTO IF NOT EXISTS", // KnowFeature -> KnowUseCase
            "CREATE EDGE TYPE REALIZES        IF NOT EXISTS", // KnowTask    -> KnowUseCase
            "CREATE EDGE TYPE TRACED_TO       IF NOT EXISTS", // KnowUseCase -> KnowADR | KnowDecision (опц., D9)
            // D12: актор — первоклассная вершина («проектируемая роль приложения»),
            // у UC акторов может быть НЕСКОЛЬКО (multi-ребро HAS_ACTOR).
            "CREATE VERTEX TYPE KnowActor IF NOT EXISTS",
            "CREATE PROPERTY KnowActor.actor_id IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowActor.name     IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowActor.kind     IF NOT EXISTS STRING", // human-role | system | agent
            "CREATE PROPERTY KnowActor.body_md  IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowActor (actor_id) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowActor (body_md) FULL_TEXT",
            "CREATE EDGE TYPE HAS_ACTOR   IF NOT EXISTS", // KnowUseCase -> KnowActor (multi)
            // D13: граф UC не только иерархия — классические include/extend.
            "CREATE EDGE TYPE UC_INCLUDES IF NOT EXISTS", // UC -> UC (обязательный под-сценарий)
            "CREATE EDGE TYPE UC_EXTENDS  IF NOT EXISTS", // UC -> UC (вариант-расширение)
            "CREATE PROPERTY KnowTask.work_class IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowTask (work_class) NOTUNIQUE",
            // Сид канон-словаря work_class (идемпотентно; канон — правят люди, D10).
            "UPDATE KnowDictEntry SET dict_type='work_class', code='uc',  label_ru='Use Case — реализует сценарий', color='#5AB4E8', sort_order=10, is_active=true, is_extensible=false UPSERT WHERE dict_type='work_class' AND code='uc'",
            "UPDATE KnowDictEntry SET dict_type='work_class', code='jtd', label_ru='Job to be Done — задача-хелпер', color='#C0A36E', sort_order=20, is_active=true, is_extensible=false UPSERT WHERE dict_type='work_class' AND code='jtd'",
            "UPDATE KnowDictEntry SET dict_type='work_class', code='enb', label_ru='Enabler — расчищает дорогу', color='#9A8CDB', sort_order=30, is_active=true, is_extensible=false UPSERT WHERE dict_type='work_class' AND code='enb'"
        )),

        // ADR-LORE-031: generic-ассеты для всех MD-полей. Ключ = контент-адрес
        // {entity_type}/{entity_id}/{sha256-16}.{ext} — бакет самодокументируемый,
        // дедуп по содержимому; вершина+ребро создаются В ТОМ ЖЕ запросе, что и
        // файл (сирота невозможен на записи). Настройки — словарь app_setting
        // (реестр Админки AL-38); value живёт в label_ru.
        new Step(7, "generic_assets_knowasset", List.of(
            "CREATE VERTEX TYPE KnowAsset IF NOT EXISTS",
            "CREATE PROPERTY KnowAsset.asset_key    IF NOT EXISTS STRING", // {type}/{id}/{hash}.{ext}
            "CREATE PROPERTY KnowAsset.entity_type  IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowAsset.entity_id    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowAsset.mime         IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowAsset.size_bytes   IF NOT EXISTS LONG",
            "CREATE PROPERTY KnowAsset.alt          IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowAsset.created_at   IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowAsset (asset_key) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowAsset (entity_id) NOTUNIQUE",
            "CREATE EDGE TYPE ATTACHED_TO IF NOT EXISTS", // сущность -> KnowAsset
            "UPDATE KnowDictEntry SET dict_type='app_setting', code='md_images_enabled', label_ru='true', sort_order=10, is_active=true, is_extensible=true UPSERT WHERE dict_type='app_setting' AND code='md_images_enabled'",
            "UPDATE KnowDictEntry SET dict_type='app_setting', code='md_image_max_mb', label_ru='5', sort_order=20, is_active=true, is_extensible=true UPSERT WHERE dict_type='app_setting' AND code='md_image_max_mb'"
        )),

        // ADR-LORE-032 (§2, решение D5) + ADR-LORE-027 (D1) + ADR-LORE-029 (§2):
        // ценность фичи становится ВЫЧИСЛИМОЙ — боли и выгоды выносятся из прозы
        // в вершины, а fit VP-канвы считается по рёбрам, не парсингом MD.
        // Единая шкала целей Коберна на весь слой (☁ cloud/🪁 kite — фичи,
        // 🌊 sea-level/🐟 subfunction — UC) + два веса оформления (casual|fully-dressed).
        new Step(8, "product_layer_vp_pain_gain_cockburn_scale", List.of(
            // Боль клиента: чья (FELT_BY), какая фича адресует (ADDRESSES), какой UC снимает (RELIEVES).
            "CREATE VERTEX TYPE KnowPain IF NOT EXISTS",
            "CREATE PROPERTY KnowPain.pain_id      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPain.title        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPain.body_md      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPain.severity     IF NOT EXISTS STRING", // high|normal|low (словарь priority)
            "CREATE PROPERTY KnowPain.date_created IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowPain (pain_id) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowPain (title)   FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowPain (body_md) FULL_TEXT",
            // Выгода: metric_md — ОБЯЗАТЕЛЬНОЕ поле для fit (выгода без метрики не замкнута).
            "CREATE VERTEX TYPE KnowGain IF NOT EXISTS",
            "CREATE PROPERTY KnowGain.gain_id      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowGain.title        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowGain.body_md      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowGain.metric_md    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowGain.date_created IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowGain (gain_id) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowGain (title)     FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowGain (body_md)   FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowGain (metric_md) FULL_TEXT",
            // Шесть рёбер VP-канвы: левая половина (профиль) и правая (value map).
            "CREATE EDGE TYPE FELT_BY    IF NOT EXISTS", // KnowPain    -> KnowActor
            "CREATE EDGE TYPE DESIRED_BY IF NOT EXISTS", // KnowGain    -> KnowActor
            "CREATE EDGE TYPE ADDRESSES  IF NOT EXISTS", // KnowFeature -> KnowPain
            "CREATE EDGE TYPE PROMISES   IF NOT EXISTS", // KnowFeature -> KnowGain
            "CREATE EDGE TYPE RELIEVES   IF NOT EXISTS", // KnowUseCase -> KnowPain (pain reliever)
            "CREATE EDGE TYPE DELIVERS   IF NOT EXISTS", // KnowUseCase -> KnowGain (gain creator)
            // Стратегическая цель фичи (ADR-032 §1, KAOS: веха = goal, фича = refinement).
            // Тип ребра уже существует у спринтов — объявление идемпотентно.
            "CREATE EDGE TYPE TARGETS_MILESTONE IF NOT EXISTS",
            // Обоснование enb-задачи (D16): KnowTask -> KnowADR.
            "CREATE EDGE TYPE JUSTIFIED_BY IF NOT EXISTS",
            // Классификация Коберна: уровень цели и вес оформления (ADR-027 §2).
            "CREATE PROPERTY KnowUseCase.goal_level IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUseCase.rigor      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUseCase.priority   IF NOT EXISTS STRING",
            // shipped_at ставит СИСТЕМА при первом переходе вычислителя в shipped
            // (ADR-029 §2) — факт первого выхода переживает реинжиниринг.
            "CREATE PROPERTY KnowUseCase.shipped_at IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowUseCase (goal_level) NOTUNIQUE",
            // Фича живёт на той же шкале — ☁ cloud/🪁 kite (ADR-032 §1).
            "CREATE PROPERTY KnowFeature.goal_level IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowFeature.shipped_at IF NOT EXISTS STRING",
            // Канон-словари (правят люди, механизм ADR-012). Уровни целей — по Коберну.
            "UPDATE KnowDictEntry SET dict_type='uc_goal_level', code='cloud',      label_ru='☁ Облако — стратегическая цель (фича)', color='#88B8A8', sort_order=10, is_active=true, is_extensible=false UPSERT WHERE dict_type='uc_goal_level' AND code='cloud'",
            "UPDATE KnowDictEntry SET dict_type='uc_goal_level', code='kite',       label_ru='🪁 Змей — обзорная цель', color='#A8B860', sort_order=20, is_active=true, is_extensible=false UPSERT WHERE dict_type='uc_goal_level' AND code='kite'",
            "UPDATE KnowDictEntry SET dict_type='uc_goal_level', code='sea-level',  label_ru='🌊 Уровень моря — пользовательская цель', color='#5AB4E8', sort_order=30, is_active=true, is_extensible=false UPSERT WHERE dict_type='uc_goal_level' AND code='sea-level'",
            "UPDATE KnowDictEntry SET dict_type='uc_goal_level', code='subfunction', label_ru='🐟 Рыба — подфункция', color='#665C48', sort_order=40, is_active=true, is_extensible=false UPSERT WHERE dict_type='uc_goal_level' AND code='subfunction'",
            "UPDATE KnowDictEntry SET dict_type='uc_rigor', code='casual',        label_ru='⚡ Лёгкий (casual)', color='#D4922A', sort_order=10, is_active=true, is_extensible=false UPSERT WHERE dict_type='uc_rigor' AND code='casual'",
            "UPDATE KnowDictEntry SET dict_type='uc_rigor', code='fully-dressed', label_ru='📋 Полный (fully dressed)', color='#88B8A8', sort_order=20, is_active=true, is_extensible=false UPSERT WHERE dict_type='uc_rigor' AND code='fully-dressed'"
        )),

        // ADR-LORE-028 (D19): primary|supporting — свойство role на ребре HAS_ACTOR.
        // У сценария ровно один primary-актор (правило линтера ADR-027 №7); первый
        // привязанный становится primary по умолчанию (D19). Свойство на РЕБРЕ, не
        // на вершине: одна роль может быть primary в одном UC и supporting в другом.
        new Step(9, "has_actor_role_property", List.of(
            "CREATE PROPERTY HAS_ACTOR.role IF NOT EXISTS STRING"
        )),

        // ADR-LORE-032 §2.1: добор канвы Остервальдера до полной. Боли и выгоды
        // (V8) — только ДВА столпа профиля клиента; третий, из которого растут оба,
        // — РАБОТЫ (customer jobs): «боль мешает работе», «выгода — успех в работе».
        // Без Job'а как вершины job-строки в тексте фичи не проверить рёбрами (fit
        // считался по 2 осям из 3) и не переиспользовать между фичами, как pain/gain.
        new Step(10, "vpc_osterwalder_jobs_and_ranks", List.of(
            "CREATE VERTEX TYPE KnowJob IF NOT EXISTS",
            "CREATE PROPERTY KnowJob.job_id       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowJob.title        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowJob.body_md      IF NOT EXISTS STRING",
            // Остервальдер: тип работы — функциональная | социальная | эмоциональная
            // | supporting (вспомогательная). Словарь job_kind ниже.
            "CREATE PROPERTY KnowJob.kind         IF NOT EXISTS STRING",
            // importance: насколько работа важна клиенту (Остервальдер ранжирует
            // jobs по important|insignificant — у нас словарь priority-шкалы).
            "CREATE PROPERTY KnowJob.importance   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowJob.date_created IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowJob (job_id) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowJob (title)   FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowJob (body_md) FULL_TEXT",
            // Профиль клиента: чья работа (как FELT_BY/DESIRED_BY у pain/gain).
            "CREATE EDGE TYPE PERFORMED_BY IF NOT EXISTS", // KnowJob     -> KnowActor
            // Фича ЗАЯВЛЯЕТ, что помогает с работой (симметрия ADDRESSES/PROMISES).
            "CREATE EDGE TYPE HELPS_WITH   IF NOT EXISTS", // KnowFeature -> KnowJob
            // UC РЕАЛЬНО выполняет работу — это ребро и замыкает третью ось fit
            // (симметрия RELIEVES/DELIVERS).
            "CREATE EDGE TYPE PERFORMS     IF NOT EXISTS", // KnowUseCase -> KnowJob
            // Остервальдер связывает боли и выгоды С РАБОТАМИ: боль мешает работе,
            // выгода — желаемый успех в работе. Без этих рёбер профиль клиента —
            // три несвязанных списка, а не канва.
            "CREATE EDGE TYPE BLOCKS   IF NOT EXISTS",     // KnowPain -> KnowJob
            "CREATE EDGE TYPE SUCCESS_OF IF NOT EXISTS",   // KnowGain -> KnowJob
            // Ранги Остервальдера: боль severe|moderate (у нас severity уже есть,
            // V8), выгода — essential|expected|desired|unexpected.
            "CREATE PROPERTY KnowGain.rank IF NOT EXISTS STRING",
            // Словарь типов работ (канон, правят люди — механизм ADR-012).
            "UPDATE KnowDictEntry SET dict_type='job_kind', code='functional', label_ru='⚙ Функциональная — выполнить задачу', color='#5AB4E8', sort_order=10, is_active=true, is_extensible=false UPSERT WHERE dict_type='job_kind' AND code='functional'",
            "UPDATE KnowDictEntry SET dict_type='job_kind', code='social', label_ru='👥 Социальная — как выглядеть в глазах других', color='#C0A36E', sort_order=20, is_active=true, is_extensible=false UPSERT WHERE dict_type='job_kind' AND code='social'",
            "UPDATE KnowDictEntry SET dict_type='job_kind', code='emotional', label_ru='💭 Эмоциональная — как себя чувствовать', color='#9A8CDB', sort_order=30, is_active=true, is_extensible=false UPSERT WHERE dict_type='job_kind' AND code='emotional'",
            "UPDATE KnowDictEntry SET dict_type='job_kind', code='supporting', label_ru='🔧 Вспомогательная — обслуживает основную работу', color='#665C48', sort_order=40, is_active=true, is_extensible=false UPSERT WHERE dict_type='job_kind' AND code='supporting'",
            // Словарь рангов выгоды (Остервальдер, VPC).
            "UPDATE KnowDictEntry SET dict_type='gain_rank', code='essential', label_ru='🔴 Обязательная — без неё решение не работает', color='#C85848', sort_order=10, is_active=true, is_extensible=false UPSERT WHERE dict_type='gain_rank' AND code='essential'",
            "UPDATE KnowDictEntry SET dict_type='gain_rank', code='expected', label_ru='🟠 Ожидаемая — клиент считает её само собой', color='#D4922A', sort_order=20, is_active=true, is_extensible=false UPSERT WHERE dict_type='gain_rank' AND code='expected'",
            "UPDATE KnowDictEntry SET dict_type='gain_rank', code='desired', label_ru='🟢 Желаемая — обрадуется, но не ждёт', color='#7DBF78', sort_order=30, is_active=true, is_extensible=false UPSERT WHERE dict_type='gain_rank' AND code='desired'",
            "UPDATE KnowDictEntry SET dict_type='gain_rank', code='unexpected', label_ru='✨ Неожиданная — превосходит ожидания', color='#88B8A8', sort_order=40, is_active=true, is_extensible=false UPSERT WHERE dict_type='gain_rank' AND code='unexpected'"
        )),

        // ── V11 (10.1) SRCH-03: полнотекст под сквозной поиск ────────────────
        // Аддитивный шаг: объявляем недостающие текстовые свойства, индексы
        // создаёт Java-шаг (см. ниже, почему не SQL).
        //
        // Замерено на ArcadeDB 26.7.2: заголовки ADR/спек/задач/ранбуков/спринтов
        // ЛЕЖАТ В ДАННЫХ, но в схеме не объявлены — а необъявленное поле
        // проиндексировать нельзя. Отсюда поиск по названию ADR шёл сканом.
        // Проверено там же: поздно объявленное свойство индексируется вместе с
        // уже лежащими значениями, ручной backfill не нужен.
        new Step(11, 10, "fulltext_named_multifield_indexes", List.of(
            "CREATE PROPERTY KnowADR.name              IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSpec.title            IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTask.title            IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowRunbook.name          IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSprint.name           IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDoc.title             IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowReleaseHist.description_md IF NOT EXISTS STRING"
        )),

        // ── V12 (10.2) SRCH-06: полный охват + область поиска ────────────────
        // Аудит схемы показал текст, который в поиск не попадал вовсе: тела
        // релизной истории, сводки по файлам, цели вех, двуязычные тела доков,
        // а также два соседних продукта в той же БД — Bragi и QG-рутины.
        // Индексируем ВСЁ, но каждая ветка несёт область (FtScope), и поиск
        // отсекает лишнее ДО запроса, а не фильтрует выдачу после.
        new Step(12, 10, "fulltext_full_coverage_and_scope", List.of(
            "CREATE PROPERTY KnowPhase.title       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPR.title          IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowRelease.release_name IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowFinding.summary   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSpecHist.summary  IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDoc.content_md_en IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDoc.content_md_ru IF NOT EXISTS STRING"
        )),

        // ── V13 (13.0) PL-28: ОДИН тип с само-иерархией ──────────────────────
        // Решение владельца №141: KnowFeature и KnowUseCase сливаются в ОДИН
        // тип. Фича — это корневой сценарий, а не отдельная сущность: она
        // отвечает на тот же вопрос «какую пользовательскую цель закрываем»,
        // только на верхнем уровне шкалы Коберна. Дискриминатором уровня
        // становится уже существующий и заполненный goal_level:
        // ☁ cloud / 🪁 kite — бывшие фичи, 🌊 sea-level / 🐟 subfunction — бывшие UC.
        //
        // Почему это ЛОМАЮЩИЙ шаг (compatMajor=13, а не аддитивный 10.x):
        // тип KnowFeature исчезает. Старый бинарь читает его в слайсах, REST и
        // поиске — против новой схемы он отдавал бы пустоту, молча и с ok:true.
        // Скачок major заставляет такой бинарь ОТКАЗАТЬСЯ стартовать
        // (StartupDecision.INCOMPATIBLE), а не работать неправильно.
        //
        // Здесь только АДДИТИВНАЯ часть — поля, которые были у фичи и которых
        // нет у сценария. Перенос данных, перевод рёбер и снос типа делает
        // javaStep(13): рёбра нельзя перецепить SQL-запросом, у них
        // неизменяемые концы, а @rid-адресация нужна поимённо (см.
        // LoreSchemaMigrationRunner#mergeFeaturesIntoUseCases).
        new Step(13, "product_layer_merge_feature_into_usecase", List.of(
            // Ценность/критерий фичи. У сценария были только scenario_md и
            // acceptance_md — короткому «зачем это вообще» места не было.
            "CREATE PROPERTY KnowUseCase.body_md    IF NOT EXISTS STRING",
            // Большой контекст (D13) — как у спринта; у UC его не было.
            "CREATE PROPERTY KnowUseCase.context_md IF NOT EXISTS STRING",
            // Родитель в само-иерархии. Заменяет денормализованный feature_id:
            // тот указывал в другой тип, этот — в свой же.
            "CREATE PROPERTY KnowUseCase.parent_uc_id IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowUseCase (parent_uc_id) NOTUNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowUseCase (body_md)    FULL_TEXT",
            "CREATE INDEX IF NOT EXISTS ON KnowUseCase (context_md) FULL_TEXT"
        )),

        // AL-79 (указание владельца 2026-07-23): статус решения — ЗНАЧЕНИЕ СЛОВАРЯ,
        // а не свободный текст. До этого статусы жили только у решений, залитых
        // прямой записью при сидировании (fixed 79 / accepted 58 / done 20), а
        // инструмента простановки не существовало вовсе — decision_new статуса не
        // имел, status_set решения не принимал. Сид повторяет фактический зоопарк
        // прода: fixed/done — легаси-значения, оставлены активными (79+20 живых
        // решений не должны стать «вне канона» задним числом); их судьба — ревизия
        // при вердикте владельца, выключаются флагом is_active в админке, не кодом.
        // Поле вершины — status_raw (так лежат статусы сида и так читают слайсы
        // decisions/decisions_of_adr), НЕ status: второе имя стало бы второй правдой.
        // АДДИТИВНЫЙ шаг (ordinal 14, major 13 → «13.1»): свойство IF NOT EXISTS +
        // строки словаря. Старый бинарь против этой схемы работает — плоский
        // конструктор объявил бы шаг ломающим и зря отказал в старте всем без V14.
        new Step(14, 13, "decision_status_dictionary", List.of(
            "CREATE PROPERTY KnowDecision.status_raw IF NOT EXISTS STRING",
            "UPDATE KnowDictEntry SET dict_type='decision_status', code='proposed',   label_ru='📋 Предложено — правило сформулировано, вердикта нет', color='#5AB4E8', sort_order=10, is_active=true, is_extensible=false UPSERT WHERE dict_type='decision_status' AND code='proposed'",
            "UPDATE KnowDictEntry SET dict_type='decision_status', code='accepted',   label_ru='✅ Принято — действующее правило', color='#A8B860', sort_order=20, is_active=true, is_extensible=false UPSERT WHERE dict_type='decision_status' AND code='accepted'",
            "UPDATE KnowDictEntry SET dict_type='decision_status', code='deferred',   label_ru='⏸ Отложено — намеренно не сейчас', color='#B8A860', sort_order=30, is_active=true, is_extensible=false UPSERT WHERE dict_type='decision_status' AND code='deferred'",
            "UPDATE KnowDictEntry SET dict_type='decision_status', code='superseded', label_ru='♻ Вытеснено — заменено более поздним решением', color='#665C48', sort_order=40, is_active=true, is_extensible=false UPSERT WHERE dict_type='decision_status' AND code='superseded'",
            "UPDATE KnowDictEntry SET dict_type='decision_status', code='fixed',      label_ru='📌 Fixed (легаси сида) — к ревизии', color='#88B8A8', sort_order=50, is_active=true, is_extensible=false UPSERT WHERE dict_type='decision_status' AND code='fixed'",
            "UPDATE KnowDictEntry SET dict_type='decision_status', code='done',       label_ru='☑ Done (легаси сида) — к ревизии', color='#7A8890', sort_order=60, is_active=true, is_extensible=false UPSERT WHERE dict_type='decision_status' AND code='done'"
        )),

        // AL-86 (найдено вопросом владельца 2026-07-30 «один статус — несколько
        // иконок?»): V14 завела decision_status с двумя расхождениями от канона
        // task_status/adr_status — эмодзи вписан ПРЯМО В ТЕКСТ label_ru вместо
        // структурного icon-слага (game-icons), и цвет — сырой hex вместо
        // семантического CSS-токена (var(--suc) и т.п.), который один адаптируется
        // под тему и палитру (lore-status.ts). Плюс словарь не читался фронтом
        // вовсе — STATUS_DICTS не включал decision_status, так что dictColor/
        // dictIcon для него всегда возвращали пусто, каким бы ни был контент строки.
        //
        // Иконография — та же, что у adr_status для общих кодов (proposed/
        // accepted/superseded): статус решения и статус ADR — близкие понятия,
        // разная иконография для одного смысла путала бы глаз сильнее, чем
        // помогала различать. legacy fixed/done намеренно НЕ зелёные: это не
        // «всё хорошо», а «требует ревизии» (OQ-DECSTATUS-LEGACY) — amber,
        // battery-50, тот же маркер, что у partial.
        // major=13, не 14: чисто содержательная правка словаря (цвет/иконка),
        // старый бинарь рендерит decision-чипы устаревшими, но работает — не
        // повод поднимать ось несовместимости выше того, что уже задал V13.
        new Step(15, 13, "decision_status_icons_and_semantic_colors", List.of(
            "UPDATE KnowDictEntry SET label_ru='Предложено — правило сформулировано, вердикта нет', icon='calendar',      color='var(--inf)' UPSERT WHERE dict_type='decision_status' AND code='proposed'",
            "UPDATE KnowDictEntry SET label_ru='Принято — действующее правило',                      icon='laurel-crown', color='var(--suc)' UPSERT WHERE dict_type='decision_status' AND code='accepted'",
            "UPDATE KnowDictEntry SET label_ru='Отложено — намеренно не сейчас',                      icon='pause-button', color='var(--t3)'  UPSERT WHERE dict_type='decision_status' AND code='deferred'",
            "UPDATE KnowDictEntry SET label_ru='Вытеснено — заменено более поздним решением',         icon='pause-button', color='var(--t3)'  UPSERT WHERE dict_type='decision_status' AND code='superseded'",
            "UPDATE KnowDictEntry SET label_ru='Fixed (легаси сида) — к ревизии',                     icon='battery-50',   color='var(--wrn)' UPSERT WHERE dict_type='decision_status' AND code='fixed'",
            "UPDATE KnowDictEntry SET label_ru='Done (легаси сида) — к ревизии',                      icon='battery-50',   color='var(--wrn)' UPSERT WHERE dict_type='decision_status' AND code='done'"
        )),

        // AL-43 (указание владельца: вариант (а) — тот же HAS_STATE+Hist, что у
        // задач/спринтов/ADR/спек, а не отдельный механизм): «продукт про SCD2,
        // а кто и когда менял справочник — нигде». Ключ у KnowDictEntry составной
        // (dict_type, code), не одно поле — Hist-строка несёт ОБА, денормализовано,
        // как KnowSpecHist несёт spec_id (запрос по составному ключу без обхода
        // графа, тот же выбор, что у спек). WHO закрывает AL-20 (аудит-лог,
        // dict — семейство HUMAN_ONLY, значит axis всегда human): Hist отвечает на
        // «когда и что», лог — на «кто». compatMajor=13: старый бинарь читает/пишет
        // KnowDictEntry как раньше и просто не видит историю — не ломающий шаг.
        new Step(16, 13, "dict_entry_scd2_history", List.of(
            "CREATE VERTEX TYPE KnowDictEntryHist IF NOT EXISTS",
            "CREATE PROPERTY KnowDictEntryHist.state_uid      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDictEntryHist.dict_type      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDictEntryHist.code           IF NOT EXISTS STRING",
            // DATETIME, не STRING: SPRINT_PLANITEM_RETIRE уже ловил "Comparison
            // method violates its general contract!" на смешанных типах
            // valid_from в ORDER BY (LoreSchemaInitializer, комментарий рядом).
            "CREATE PROPERTY KnowDictEntryHist.valid_from     IF NOT EXISTS DATETIME",
            "CREATE PROPERTY KnowDictEntryHist.valid_to       IF NOT EXISTS DATETIME",
            "CREATE PROPERTY KnowDictEntryHist.label_ru       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDictEntryHist.label_en       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDictEntryHist.color          IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDictEntryHist.icon           IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDictEntryHist.sort_order     IF NOT EXISTS INTEGER",
            "CREATE PROPERTY KnowDictEntryHist.is_active      IF NOT EXISTS BOOLEAN",
            "CREATE PROPERTY KnowDictEntryHist.is_extensible  IF NOT EXISTS BOOLEAN",
            "CREATE INDEX IF NOT EXISTS ON KnowDictEntryHist (state_uid) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowDictEntryHist (dict_type, code) NOTUNIQUE"
        )),

        // AL-29 (OQ-ADMIN-TAG-SPLIT): KnowTag и LoreTag несли одни и те же теги
        // (security/frontend/lineage/schema/scd2…) под двумя разными вершинами
        // в зависимости от того, откуда пришёл тег — вопросам (LoreTag) или
        // ADR/decision/task (KnowTag). Схлопывается в KnowTag (шире по охвату
        // сущностей) — javaStep(17): mergeLoreTagIntoKnowTag. 3-арг конструктор,
        // не 4-арг с compatMajor=13 — шаг ТРОГАЕТ ДАННЫЕ (переносит рёбра, сносит
        // тип), как V13 mergeFeaturesIntoUseCases, а не просто добавляет схему.
        // tag_id уже STRING на обоих типах — новых свойств шагу не нужно.
        new Step(17, "loretag_merged_into_knowtag", List.of()),

        // AL-82/ADR-LORE-036: предусловие всей проектной RBAC-модели — человек
        // как вершина графа (по вердикту 148 источник истины о правах — граф,
        // а человека в нём нет вовсе). KnowUser ключуется по kc_sub (клейм
        // Keycloak), НЕ по имени — имя меняется, sub нет. HAS_PROJECT_ROLE —
        // то же устройство, что HAS_ACTOR со свойством role (ADR-028 D19):
        // одно ребро на пару человек×проект, роль — свойством, множественность
        // по построению (человек в нескольких проектах с разными ролями).
        // compatMajor=17 (не 13): 13 был последним breaking ДО V17
        // (loretag-merge подняло планку) — новая база для аддитивных шагов.
        // Чисто новые типы, старый бинарь их просто не видит — не ломающий шаг.
        new Step(18, 17, "user_project_role", List.of(
            "CREATE VERTEX TYPE KnowUser IF NOT EXISTS",
            "CREATE PROPERTY KnowUser.kc_sub       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUser.display_name IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowUser (kc_sub) UNIQUE",
            "CREATE EDGE TYPE HAS_PROJECT_ROLE IF NOT EXISTS",
            "CREATE PROPERTY HAS_PROJECT_ROLE.role IF NOT EXISTS STRING"
        )),

        // AL-83/ADR-LORE-036: связка KnowActor(kind=agent) ↔ владелец-человек.
        // client_id — то же значение, что несёт клейм client_id/azp токена
        // агента (KC clientId, напр. "lore-mcp-full"), НЕ внутренний UUID
        // клиента KC. OWNED_BY без свойств: один агент — один живой владелец
        // (переприсвоение — снести старое ребро и создать новое, как у
        // HAS_PROJECT_ROLE, не накапливать историю рёбер). Без UNIQUE-индекса
        // на client_id: у большинства акторов (kind≠agent) поле пустое, а
        // поведение ArcadeDB UNIQUE на множественных NULL не проверено —
        // дубль client_id у двух акторов сегодня ловится детектором
        // осиротевших (agent-orphans), не индексом.
        new Step(19, 17, "actor_agent_owner", List.of(
            "CREATE PROPERTY KnowActor.client_id IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowActor (client_id) NOTUNIQUE",
            "CREATE EDGE TYPE OWNED_BY IF NOT EXISTS"
        )),

        // AL-92/ADR-LORE-036 (фаза PROJECT_SCOPE): бэкфилл рёбер BELONGS_TO_PROJECT
        // у сущностей, где write-path давно есть, а исторические вершины остались
        // без привязки. SQL-часть пустая — тип ребра существует с ранних шагов;
        // вся работа в javaStep(20) (три категории, идемпотентно — только вершины
        // БЕЗ единого out('BELONGS_TO_PROJECT')):
        //   KnowADR      ← проекты его спринтов (IMPLEMENTED_IN), мультипривязка;
        //   KnowRelease  ← плоское поле git_project (ребро выравнивается по полю —
        //                  двойная правда, найденная аудитом AL-96);
        //   KnowSpec     ← проекты спринтов его компонентов, ТОЛЬКО при ровно
        //                  одном distinct-проекте (неоднозначные — вручную).
        new Step(20, 17, "project_edges_backfill", List.of()),

        // AL-104/D-AGENT-IDENTITY: роль агента — СВОЙСТВО агента, а не следствие
        // имени его учётки. До этого шага роль нигде не хранилась: её выводили
        // из client_id (`lore-mcp-architect` → architect), из-за чего роль и
        // учётка были неразличимы, а двух агентов одной роли завести было
        // некуда. Значения — коды справочника `agent_role`.
        new Step(21, 17, "actor_agent_role", List.of(
            "CREATE PROPERTY KnowActor.agent_role IF NOT EXISTS STRING")),

        // DBR-06: тип IN_AREA объявлялся В РАНТАЙМЕ — эндпоинт бэкфилла
        // (`/lore/dict/backfill-area`) начинался с `CREATE EDGE TYPE ... IF NOT
        // EXISTS`. Это была компенсация отключённого в проде bootstrap-DDL, и с
        // токеном без updateSchema она даст 403: обычная операция бэкфилла
        // упёрлась бы в право менять схему, которого у рантайма больше нет.
        // Объявление переезжает сюда, эндпоинт остаётся чистым бэкфиллом рёбер.
        new Step(22, 17, "in_area_edge_type", List.of(
            "CREATE EDGE TYPE IN_AREA IF NOT EXISTS")),

        // MT-11/D-VP-ROLE-AGENT-PAIR (редакция 3): агент, исполняющий работу
        // роли, связан с ней явным ребром KnowActor(agent) -> KnowActor(role)
        // — различие не сворачивается в свойство. У ребра есть проверяемый
        // инвариант (множества PERFORMED_BY у пары обязаны совпадать, см.
        // LoreProductResource.checkActorPairs / срез actor_pairs), а не он
        // сам несёт данные — без свойств, как OWNED_BY: переприсвоение — снести
        // старое ребро и создать новое, не накапливать историю.
        new Step(23, 17, "actor_fills_role", List.of(
            "CREATE EDGE TYPE FILLS_ROLE IF NOT EXISTS")),

        // AL-108: несколько Claude-сессий пишут через ОДНОГО агента (общая
        // учётка KC, agent-full) — доска и git не различали, какая сессия
        // сделала запись (MG-SETTINGS-PARSE закрылась чужой сессией из того
        // же индекса до того, как отчитывающаяся до неё дошла). machine_id/
        // session_id — та же природа, что client_id/agent_role: свойство
        // агента, обновляемое при каждой самозаписи (актор пишет их себе сам
        // через actor_new — это не назначение владельца, эскалации тут нет),
        // не накапливаемая история. Различить ДВЕ ОДНОВРЕМЕННЫЕ сессии одной
        // роли это не позволяет (поле одно, последняя запись выигрывает) —
        // для этого нужен tag в самой записи (commit/note_md), не в акторе;
        // здесь — только «откуда агент писал в последний раз».
        new Step(24, 17, "actor_machine_session", List.of(
            "CREATE PROPERTY KnowActor.machine_id IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowActor.session_id IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowActor (machine_id) NOTUNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowActor (session_id) NOTUNIQUE")),

        // ADR-LORE-037 V1: журнал сессий агентов — ОТДЕЛЬНАЯ вершина, не
        // расширение KnowActor (шаг 24 несёт mutable «сейчас», этот шаг несёт
        // append-факт «что было»). Одна вершина на сессию (upsert по
        // session_id — сессия живёт, activity обновляется; сессия закрылась —
        // строка остаётся, новая сессия создаёт новую строку: это и есть
        // журнал). LOGGED_BY БЕЗ UNIQUE на своей стороне — агент копит много
        // сессий за жизнь, в отличие от OWNED_BY/FILLS_ROLE, где
        // переприсвоение сносит старое ребро.
        // V1 намеренно не несёт содержимого диалога (текст реплик, tool-calls)
        // — транскрипт уже живёт на диске и в гейтвее miniLORE, дублировать
        // его в графе создало бы третий источник правды без выигрыша (см.
        // ADR-LORE-037 D2). Timeseries-часть (D5) — открытый вопрос, эта
        // миграция её не решает и не блокирует ею V1.
        new Step(25, 17, "agent_session_log", List.of(
            "CREATE VERTEX TYPE KnowAgentSession IF NOT EXISTS",
            "CREATE PROPERTY KnowAgentSession.session_id       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowAgentSession.machine_id       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowAgentSession.project          IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowAgentSession.entrypoint       IF NOT EXISTS STRING", // cli | claude-desktop
            "CREATE PROPERTY KnowAgentSession.dialogue_name    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowAgentSession.started_at       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowAgentSession.last_activity_at IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowAgentSession (session_id) UNIQUE",
            "CREATE EDGE TYPE LOGGED_BY IF NOT EXISTS")), // KnowAgentSession -> KnowActor(agent), multi

        // PS-20: у релизов ребро BELONGS_TO_PROJECT не создавалось write-path'ом
        // (ни createRelease, ни release_mv/update) — а срез release.projects читает
        // ИМЕННО ребро, поэтому оно всегда было пустым при заполненном поле
        // git_project. V20 бэкфиллил релизы разово; всё, что создано/перенесено
        // ПОСЛЕ V20, снова осталось без ребра (напр. v1.0.23/v1.0.34 после
        // release_mv в этой сессии). Write-path теперь выравнивает ребро по полю
        // (relinkReleaseProjectEdge); этот шаг добирает исторический хвост — та же
        // идемпотентная логика size()=0, что у V20 (см. backfillReleaseProjectEdges).
        new Step(26, 17, "release_project_edges_backfill", List.of()),

        // AL-102: журнал выдачи/снятия проектных ролей (append-only). Ребро
        // HAS_PROJECT_ROLE хранит ТЕКУЩЕЕ состояние (одно на пару человек↔проект,
        // роль свойством); кто/когда роль выдал или снял оно не помнит. Отдельная
        // вершина-событие KnowProjectRoleEvent — та же природа, что KnowAgentSession
        // (ADR-037): лог «что происходило», а не изменяемое состояние. Пишется на
        // каждый grant/update/remove в setUserRole. Поля: кому (kc_sub), проект,
        // роль (null при снятии), действие, чьей ролью выдано (by_role — точная
        // идентичность человека требует sub в токене, см. AL-105), когда (at).
        new Step(27, 17, "project_role_event_log", List.of(
            "CREATE VERTEX TYPE KnowProjectRoleEvent IF NOT EXISTS",
            "CREATE PROPERTY KnowProjectRoleEvent.event_uid IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowProjectRoleEvent.kc_sub    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowProjectRoleEvent.project   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowProjectRoleEvent.role      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowProjectRoleEvent.action    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowProjectRoleEvent.by_role   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowProjectRoleEvent.at        IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowProjectRoleEvent (event_uid) UNIQUE")),

        // DBU-09/DBR-12 (#5321): апгрейд ArcadeDB на 26.8.1 оставляет FULL_TEXT-
        // индексы с НЕ-ASCII (кириллическими) ключами физически отсортированными
        // в старом порядке — на 26.8.1 lookup по такому индексу возвращает МЕНЬШЕ
        // записей, чем скан (движок предупреждает «should be rebuilt» при открытии
        // system_aida_lore). Health-гейт LoreSearchResource это ловит и отвечает
        // сканом (полная выдача, без ранжирования) — честно, но поиск теряет
        // релевантность. Лечится ТОЛЬКО пересозданием (DROP+CREATE), НЕ REBUILD:
        // на 26.8.1 REBUILD INDEX теряет имя индекса (DBR-12) — после него
        // SEARCH_INDEX('ftИмя') находит «Index not found». Шаг сносит все FT из
        // реестра по имени и пересоздаёт свежими через createFullTextIndexes
        // (тот же vetted-путь, что V11/12/13; он же чистит клэши по полям).
        new Step(28, 17, "ft_indexes_recreate_5321", List.of()),

        // SPRINT_QG_REBUILD/QG-12 + QG-03 + QG-15: контракт записи прогона гейта.
        // Эндпоинт записи (POST /lore/qg/run) существует давно, но НИ ОДНОГО поля
        // контракта в схеме не было — проверено по коду 2026-08-26. Следствия,
        // все измеренные, а не предполагаемые:
        //
        // - CI работает и гейтит каждый merge, но не оставляет в корпусе ни одной
        //   записи: ClRoutineRun от Actions нет. Покрытие считается по рутинам,
        //   которых почти не осталось, и показывает 4.5%, игнорируя пайплайн;
        // - 56 строк метрик из 191 (29%) не имеют даты вовсе, и 35 из них — те
        //   самые SKIP «не измерено». Метрика без даты не встаёт в ряд, не
        //   стареет и не поднимает детектор молчания: сказать «держится N дней»
        //   не от чего;
        // - причина «не измерено» жила свободным текстом или не жила вовсе.
        //
        // ПОЧЕМУ НЕ В flags. У ClRoutineRun есть свободная строка flags, куда всё
        // это влезло бы за один вечер. Нельзя: причина обязана быть счётной,
        // иначе по ней не сгруппировать и не посчитать длительность. lore_addr_drift
        // прожил пять дней незамеченным именно потому, что не был величиной.
        // Уложить контракт в flags — воспроизвести исходный дефект с видом
        // выполненной работы.
        //
        // ПОЛЯ НЕОБЯЗАТЕЛЬНЫЕ НАМЕРЕННО. NOT NULL на run_date сломал бы 56
        // существующих строк, то есть скрыл бы масштаб проблемы вместо того,
        // чтобы его показать. Обязательность вводится на пути записи, где её
        // можно объяснить отказом; старые строки остаются видимым долгом.
        new Step(29, 17, "qg_run_contract_fields", List.of(
            // канал: без него «прогона не было, потому что не было коммитов»
            // неотличимо от «гейт умер» — а это разные вердикты (спека §4.8)
            "CREATE PROPERTY ClRoutineRun.channel      IF NOT EXISTS STRING",
            // ссылка на источник: дойти от красной метрики до лога за одно
            // нажатие, а не искать прогон по времени
            "CREATE PROPERTY ClRoutineRun.source_url   IF NOT EXISTS STRING",
            // коммит и PR: делают вердикт атрибутируемым ИЗМЕНЕНИЮ. Без них
            // Actions-гейт теряет единственное преимущество перед расписанием
            "CREATE PROPERTY ClRoutineRun.commit_sha   IF NOT EXISTS STRING",
            "CREATE PROPERTY ClRoutineRun.pr_number    IF NOT EXISTS INTEGER",
            // какая модель вынесла суждение. Владелец выбрала держать вызов LLM
            // на своей стороне ради СРАВНЕНИЯ моделей (QG-11); сравнивать нечего,
            // если по прогону не видно, чей это вердикт. Для канала actions поле
            // пустое осмысленно: там суждения нет, только факт сборки
            "CREATE PROPERTY ClRoutineRun.model        IF NOT EXISTS STRING",
            // типизированная причина «не измерено» (спека §5): source_unreachable,
            // source_missing, stand_absent, tool_disabled, script_absent,
            // not_implemented, budget_exhausted, no_changes, no_evidence
            "CREATE PROPERTY ClRoutineMetric.not_measured_reason IF NOT EXISTS STRING",
            // отметка времени на самой метрике: run_date есть, но пустует у 56
            // строк. Отдельное поле не заводим — чинится путь записи, а не схема
            "CREATE PROPERTY ClRoutineMetric.model     IF NOT EXISTS STRING")),

        // Развод акторов: проектируемая роль отдельно от агентной ЛИЧНОСТИ.
        //
        // ЧТО БЫЛО. KnowActor отвечал на два разных вопроса сразу. Как вершина
        // продуктового слоя он описывал, кто пользуется системой (HAS_ACTOR из
        // сценариев, FELT_BY у болей, DESIRED_BY у выгод, PERFORMED_BY у работ).
        // И он же был НЕСУЩИМ для прав: ProjectRbacService резолвит владельца
        // запросом `SELECT out('OWNED_BY').kc_sub FROM KnowActor WHERE
        // kind='agent' AND client_id=:cid`, то есть цепочка прав начиналась в
        // реестре описаний.
        //
        // ЧЕМ ЭТО АУКНУЛОСЬ. У заведения актора появился проектный RBAC-гейт,
        // которого нет ни у фич, ни у сценариев: создание актора могло создать
        // личность. Владелец 30.08.2026 упёрлась в отказ на описательной работе
        // («в full-сессии не даёт завести акторов для UC и фич») — механизм для
        // прав резал проектирование.
        //
        // РЕШЕНИЕ ВЛАДЕЛЬЦА (30.08.2026): «MCP, RBAC остаётся на старой ноде,
        // весь бизнес-анализ переезжает на новую». KnowActor остаётся личностью
        // и RBAC не трогается вовсе; описательная сторона уезжает в новый тип.
        //
        // РАЗРЕЗ ЧИСТЫЙ — измерено перед миграцией, а не предположено: 10 вершин
        // без client_id держат ВСЕ 85 проектных рёбер, 7 вершин с client_id
        // держат только OWNED_BY (7) и LOGGED_BY (55). Ни одна вершина не нужна
        // обеим сторонам, поэтому двойники не заводятся.
        new Step(30, 17, "project_actor_split", List.of(
            "CREATE VERTEX TYPE KnowProjectActor IF NOT EXISTS",
            "CREATE PROPERTY KnowProjectActor.actor_id IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowProjectActor.name     IF NOT EXISTS STRING",
            // kind — ОПИСАТЕЛЬНЫЙ признак: human-role | system | automation.
            //
            // `agent` переименован в `automation` при переносе (решение владельца
            // 30.08.2026). Иначе слово `agent` осталось бы в ДВУХ реестрах: в
            // KnowActor как учётная запись с client_id и владельцем, здесь — как
            // роль агента в сценарии. Тип вершины их различает, человек нет —
            // та же ловушка, что `architect` как роль проекта против `architect`
            // как профиля агента. Переименование едет попутно: миграция и так
            // переписывает эти строки, отдельно потом стоило бы своего деплоя.
            "CREATE PROPERTY KnowProjectActor.kind     IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowProjectActor.body_md  IF NOT EXISTS STRING",
            // UNIQUE: идентификатор роли — ключ, по которому её ищут ссылки и
            // повторный прогон миграции. Дубль означал бы две правды об одной роли.
            "CREATE INDEX IF NOT EXISTS ON KnowProjectActor (actor_id) UNIQUE")),

        // Слияние двух представлений принадлежности компоненту (ADR-LORE-041,
        // SPRINT_LORE_ONE_TRUTH/NM-02).
        //
        // ЧТО БЫЛО. Принадлежность компоненту писалась ПОЛЕМ component_id и
        // читалась РЕБРОМ BELONGS_TO. Инструмент отвечал ok:true, поле стояло,
        // паспорт компонента оставался пуст. Наблюдалось дважды за один день,
        // независимо, и каждый раз выглядело как «связи нет», а не как «связь
        // записана не туда, куда смотрят».
        //
        // ЧТО ПОКАЗАЛ ЗАМЕР (прод, 30.08.2026). Ожидалось «поле устарело».
        // Оказалось, что представления почти не пересекаются и расходятся в ОБЕ
        // стороны: у спек поле без ребра — 184, ребро без поля — 165, оба лишь
        // у 35 из 349 связанных. У ADR наоборот: 161 связь держится только
        // ребром. Решения — только полем: 358.
        //
        // ПОЧЕМУ ЭТОТ ШАГ ТОЛЬКО ДОБАВЛЯЕТ. Напрашивалось перевести читателей на
        // ребро и на этом закончить. Такой «порядок» молча стёр бы 184 связи
        // спек, 358 решений, 112 доков и 86 вопросов — они существуют ТОЛЬКО
        // полем. Поэтому шаг ничего не удаляет и не переписывает: он доводит
        // рёбра до полей, после чего обе правды совпадают. Снятие поля — свой
        // шаг, и он последний (NM-05), потому что он единственный необратимый.
        //
        // Схемных изменений нет намеренно: тип ребра давно существует, вся
        // работа шага — в java-части, где её видно и можно пересчитать.
        new Step(31, 17, "component_edge_backfill", List.of(
            "CREATE EDGE TYPE BELONGS_TO IF NOT EXISTS")),

        // Повторный развод акторов: вычистить то, что натекло ПОСЛЕ шага 30.
        //
        // Шаг 30 закончился проверкой «описательных вершин в KnowActor не
        // осталось» и она прошла. Но форма акторов в UI ещё несколько часов
        // писала в /lore/actor — то есть в реестр личностей, — уже после того,
        // как чтение переехало на новый тип. Каждая такая запись отвечала
        // ok:true и пропадала из списка: её не показывает ни один срез.
        //
        // Отсюда шаг: тот же splitProjectActors, он идемпотентен и заканчивается
        // той же проверкой. Ничего не найдёт — отработает вхолостую и скажет об
        // этом; найдёт — перенесёт и снова оставит ноль.
        //
        // Чинить данные миграцией, а не руками, потому что то же самое могло
        // произойти на любой другой установке, где успели нажать «сохранить».
        new Step(32, 17, "actor_split_recheck", List.of(
            "CREATE VERTEX TYPE KnowProjectActor IF NOT EXISTS")),

        // NM-07: тот же добор, но по РАСШИРЕННОЙ таблице типов.
        //
        // Отдельным шагом, а не правкой 31-го, по двум причинам, и обе жёсткие.
        // Первая: шаг 31 уже применён на стенде, а выпущенные шаги неизменяемы —
        // правка тела уронила бы старт проверкой checksum. Вторая, важнее:
        // java-часть шага 31 больше НЕ выполнится, потому что версия стоит в
        // ledger. Дописав туда типы, я получила бы код, который выглядит
        // работающим и на существующей базе не делает ничего.
        //
        // Добор идемпотентен, поэтому повторный проход по уже обработанным
        // семи типам безвреден — он их просто пересчитает.
        new Step(33, 17, "component_edge_backfill_qg", List.of(
            "CREATE EDGE TYPE BELONGS_TO IF NOT EXISTS")),

        // Снятие поля component_id — ЕДИНСТВЕННЫЙ необратимый шаг спринта
        // (ADR-LORE-041, SPRINT_LORE_ONE_TRUTH/NM-05).
        //
        // Всё, что до него, можно было отменить возвратом к полю. После него —
        // нельзя: восстанавливать связи будет неоткуда. Поэтому он стоит
        // последним и едет своим релизом, а не в общей пачке.
        //
        // ПРЕДУСЛОВИЯ, ВЫПОЛНЕННЫЕ НА ЖИВЫХ ДАННЫХ (проверено срезом
        // component_field_edge_drift, 30.08.2026, не по коду возврата):
        //   • «поле без ребра» = 0 по всем ДЕВЯТИ типам-носителям;
        //   • встречный счётчик не изменился — добор добавлял, не переписывал;
        //   • ни один срез больше не читает поле (тест SliceReadsEdgeNotFieldTest);
        //   • экраны сверены: список гейтов, фильтр по компоненту, доска решений,
        //     реестр вопросов, бэклог, спеки, доки.
        //
        // Java-часть снимает поле у каждого типа отдельно и ПЕРЕСЧИТЫВАЕТ связи
        // до и после. Просто выполнить DROP и отчитаться успехом здесь мало:
        // если бы ребро где-то не доехало, потеря обнаружилась бы много позже и
        // выглядела бы как «у записи никогда не было компонента».
        new Step(34, 17, "drop_component_field", List.of(
            // Схема правится java-частью: имена типов и наличие свойства
            // проверяются по факту, а не перечисляются вслепую — DROP PROPERTY
            // у отсутствующего свойства уронил бы старт на ровном месте.
            "CREATE EDGE TYPE BELONGS_TO IF NOT EXISTS")),

        // Роли задач — рёбрами на заявленные личности (ADR-LORE-042,
        // SPRINT_LORE_TASK_ROLE_EDGES/TR-02).
        //
        // ЧТО БЫЛО. author_agent/executor_agent/reviewer_agent — свободный
        // текст на вершине. Замер 30.08.2026: 4114 заполненных значений, 73
        // различных написания при десяти заявленных в админке личностях.
        // Владелец записана шестью написаниями.
        //
        // Причина не в небрежности: в одну строку клали ЧЕТЫРЕ разных факта —
        // кто, под каким профилем, на какой модели и (за неимением места) где,
        // то есть в какой сессии. Два значения содержат ДВОИХ сразу
        // («claude-full + соседняя сессия»), чего поле выразить не могло.
        //
        // Половину написаний поставлял сам интерфейс: AgentRolePicker предлагал
        // значения справочника agent_role, то есть ПРОФИЛИ, в поле, отвечающее
        // на вопрос «кто».
        new Step(35, 17, "task_role_edges", List.of(
            "CREATE EDGE TYPE ROLE_HELD_BY IF NOT EXISTS",

            // role — какая это роль. Четыре значения, и reviewer с handoff
            // разведены НАМЕРЕННО (ADR-LORE-042 §2): «подхватил работу» не то
            // же, что «проверил работу», и склейка их закрывала бы гейт
            // приёмки фактом, к проверке отношения не имеющим.
            "CREATE PROPERTY ROLE_HELD_BY.role IF NOT EXISTS STRING",

            // Атрибуты ДЕЙСТВИЯ, а не личности (§3). Агент мультиролевой:
            // одна вершина сегодня архитектор, завтра тестировщик — значит
            // профиль принадлежит конкретному действию. На вершине они дали бы
            // «последнее значение выигрывает» и потерю истории.
            "CREATE PROPERTY ROLE_HELD_BY.profile IF NOT EXISTS STRING",
            "CREATE PROPERTY ROLE_HELD_BY.model   IF NOT EXISTS STRING",

            // Обратная связь ревьюера (TR-06). Сегодня её негде записать:
            // гейт проверяет, что ревьюер непуст и отличается от исполнителя,
            // и не проверяет НИЧЕГО о содержании. Поэтому «проверено» сейчас
            // неотличимо от проставленной строки, а агент не узнаёт, что было
            // не так, и повторит ошибку.
            "CREATE PROPERTY ROLE_HELD_BY.verdict     IF NOT EXISTS STRING",
            "CREATE PROPERTY ROLE_HELD_BY.feedback_md IF NOT EXISTS STRING",
            "CREATE PROPERTY ROLE_HELD_BY.reviewed_at IF NOT EXISTS STRING",

            // Смена — мягким удалением (§4). Поле отвечало только на «кто
            // сейчас» и стирало «кто был»; вопрос «сколько раз передавали»
            // был неотвечаем в принципе. Текущий держатель роли — ребро с
            // valid_to IS NULL, как открытая строка истории у задач.
            "CREATE PROPERTY ROLE_HELD_BY.valid_from IF NOT EXISTS STRING",
            "CREATE PROPERTY ROLE_HELD_BY.valid_to   IF NOT EXISTS STRING",

            // Индекс по роли: и добор, и чтение всегда спрашивают «роль такая-то
            // у этой задачи», а не перебирают все рёбра.
            "CREATE INDEX IF NOT EXISTS ON ROLE_HELD_BY (role) NOTUNIQUE")),

        // Добор рёбер ролей из полей (TR-03). Шаг только ДОБАВЛЯЕТ: поля
        // author/executor/reviewer_agent остаются нетронутыми, пока обе правды
        // не сойдутся. Снятие — отдельным шагом и последним.
        //
        // Схемных изменений нет: тип ребра заведён шагом 35, вся работа в
        // java-части, где её видно и можно пересчитать.
        new Step(36, 17, "task_role_backfill", List.of(
            "CREATE EDGE TYPE ROLE_HELD_BY IF NOT EXISTS")),

        // Добор ПОСЛЕ расширения правил сопоставления (TR-05, согласовано
        // владельцем 31.08.2026): любое `claude-<что-то>` — тот же единственный
        // агент, суффикс отвечает на «где», а не на «кто».
        //
        // Отдельным шагом, а не правкой шага 36. Выпущенные шаги неизменяемы —
        // сторож контрольных сумм отвергнет старт, если тронуть применённый. И
        // это правильно: на базах, где 36 уже отработал, история должна
        // показывать, что добор был ДВАЖДЫ и по разным правилам.
        //
        // Схемных изменений нет, работа целиком в java-части. Шаг идемпотентен:
        // добор пропускает роль, у которой уже есть открытое ребро, поэтому
        // повторный прогон не создаёт вторых рёбер.
        new Step(37, 17, "task_role_backfill_claude_prefix", List.of(
            "CREATE EDGE TYPE ROLE_HELD_BY IF NOT EXISTS")),

        // Сохранить в примечание задачи то, что НЕ стало ребром, — перед
        // снятием полей. Согласовано владельцем: «сохранить исходное значение в
        // примечание». Работа целиком в java-части.
        new Step(38, 17, "preserve_role_fields_into_note", List.of(
            "CREATE EDGE TYPE ROLE_HELD_BY IF NOT EXISTS")),

        // СНЯТИЕ ПОЛЕЙ. Последний шаг перехода: роль живёт ребром, читают её
        // ребром, пишут ребром, а непредставленное сохранено шагом 38.
        //
        // Почему отдельным шагом, а не вместе с сохранением: если бы сохранение
        // и снятие шли одной транзакцией, отказ на середине оставил бы часть
        // задач без поля И без примечания. Разные шаги — разные записи в
        // реестре версий, и после падения видно, докуда дошли.
        //
        // DROP PROPERTY не трогает уже записанные значения в существующих
        // документах — они становятся недоступны схеме, но физически остаются до
        // перезаписи. Это не аргумент «можно вернуть»: читать их будет нечем.
        // Именно поэтому шаг 38 обязателен и стоит раньше.
        // Сам DROP идёт java-частью: у него нет идемпотентной SQL-формы, а часть
        // значений живёт schemaless и переживает DROP PROPERTY — их надо снимать
        // отдельно. Тот же приём, что в V34.
        new Step(39, 17, "drop_task_role_fields", List.of(
            "CREATE EDGE TYPE ROLE_HELD_BY IF NOT EXISTS")),

        // RM-P6 / D-2026-LORE-PRODUCT-IS-OWN-ENTITY: тринадцать продуктов сидом.
        //
        // Почему сидом, а не через MCP. Продукт — запись справочника
        // (dict_type='product'); семейство 'dict' в матрице прав человеко-только,
        // и dict_set агенту отвечает 403. Это правило верное: словари задают
        // словарь всей системы, и имена продуктов даёт владелец, а не агент.
        // Но и человеку эта дверь была закрыта: вкладка «Справочники» собирает
        // список типов из УЖЕ существующих строк (LoreAdminPanel.tsx), поэтому
        // пустой dict_type='product' в интерфейсе не появлялся вовсе — завести
        // первую запись было нечем ни с одной стороны. Сид снимает ровно это:
        // после него тип виден, is_extensible=true, и четырнадцатый продукт
        // владелец заводит руками в админке штатной кнопкой «+ значение».
        //
        // Состав — замер по проду 27.08.2026 (RM-P2), не догадка. Три вещи,
        // которые он показал и которые здесь закреплены:
        //   - HOUND лежит ВНУТРИ поддерева DALI, но это суб-продукт AIDA;
        //   - MT лежит ВНЕ поддерева AIDA, но это тоже суб-продукт AIDA;
        //   - дерево продуктов и дерево компонентов — РАЗНЫЕ деревья,
        //     поэтому связь ведётся рёбрами IN_PRODUCT/PARENT_PRODUCT, а
        //     не выводится обходом PARENT_OF.
        // Сами рёбра сюда НЕ входят намеренно: они пишутся product_link'ом,
        // это семейство агенту открыто, и складывать 90 связей в миграцию
        // значило бы зашить замер одного дня в код.
        //
        // Не продукты и потому здесь отсутствуют: HARPA (сайт: делает AIDA,
        // использует BALDR), BALDR (маркетинг), FREYJA (не разработка),
        // FE и SVC (сняты). Отношение BALDR↔BRAGI владельцем не решено.
        new Step(40, 17, "product_dictionary_seed", List.of(
            // AIDA и её четыре суб-продукта: sort_order 10 и 11..14 —
            // соседние числа держат их вместе в любом списке по порядку.
            dictProduct("AIDA",     "AIDA",          "brain",        "var(--acc)",                                    10),
            dictProduct("HOUND",    "HOUND",         "wolf-head",    "color-mix(in srgb,var(--acc) 60%,var(--dng))",  11),
            dictProduct("SEIDR",    "SEIDR STUDIO",  "crystal-ball", "color-mix(in srgb,var(--acc) 60%,var(--inf))",  12),
            dictProduct("HEIMDALL", "HEIMDALL",      "guards",       "color-mix(in srgb,var(--suc) 70%,var(--bg0))",  13),
            dictProduct("MT",       "Mimir (MT)",    "open-book",    "var(--inf)",                                    14),
            // Два продукта на одной БАЗЕ ДАННЫХ, но в разных репозиториях:
            // OMILORE — ведение наших проектов, MINILORE — управление с телефона.
            dictProduct("OMILORE",  "OMILORE",       "spell-book",   "var(--suc)",                                    20),
            dictProduct("MINILORE", "miniLORE",      "smartphone",   "color-mix(in srgb,var(--suc) 60%,var(--inf))",  30),
            dictProduct("BRAGI",    "BRAGI",         "scroll-quill", "color-mix(in srgb,var(--acc) 55%,var(--wrn))",  40),
            dictProduct("MIDGARD",  "Мидгард", "Midgard", "house",   "color-mix(in srgb,var(--wrn) 60%,var(--suc))",  50),
            dictProduct("ODIN",     "ODIN",          "horned-helm",  "color-mix(in srgb,var(--inf) 70%,var(--bg0))",  60),
            dictProduct("VOLVA",    "Völva",         "third-eye",    "color-mix(in srgb,var(--inf) 60%,var(--acc))",  70),
            dictProduct("MIGGEN",   "mig_gen (UDWE)","gears",        "var(--t2)",                                     80),
            dictProduct("TYR",      "TYR",           "scales",       "color-mix(in srgb,var(--t2) 70%,var(--wrn))",   90))),

        // RM-P12: valid_from у *Hist приводится к ОДНОМУ виду — ISO-8601 UTC.
        //
        // Порядок из двух шагов существенный и он не косметика: SQL шага
        // выполняется ДО его javaStep, поэтому объявить свойство и переписать
        // строки одним шагом нельзя — объявление легло бы на ещё не приведённые
        // значения. Сначала V41 приводит данные, потом V42 закрывает тип.
        new Step(41, 17, "java__hist_valid_from_normalize_iso_utc", List.of()),

        // Объявление — та же мера, что уже приняли дважды по тому же поводу:
        // KnowSprintHist.valid_from (SPRINT_PLANITEM_RETIRE, «Comparison method
        // violates its general contract!» на ORDER BY) и KnowDictEntryHist
        // (V16). Разница в выбранном типе, и она обоснована замером — см.
        // комментарий к V42_HIST_VALID_FROM_TEXT (замороженный список шага;
        // с RM-P13 тип сменён на DATETIME шагом V56, сам V42 неизменяем).
        new Step(42, 17, "hist_valid_from_declared_string",
            V42_HIST_VALID_FROM_TEXT.stream()
                .map(t -> "CREATE PROPERTY " + t + ".valid_from IF NOT EXISTS STRING")
                .toList()),

        // ДОБОР ЗА PR #598: продуктовая ось объявила свои рёбра ТОЛЬКО в
        // LoreSchemaInitializer — и на прод они бы не доехали.
        //
        // Инициализатор гейтится флагом lore.bootstrap (default false, в
        // compose тоже `${LORE_BOOTSTRAP:-false}`): на общей боевой БД он
        // молча пропускается целиком — «schema init skipped». Дверь на прод
        // одна, и это миграции (lore.migrate=true).
        //
        // В PR #598 рассуждение было «рёбра объявлены EXTENDS E без привязки
        // к типам вершин, новый шаг миграции не нужен». Довод верен про
        // СВОЙСТВА на существующем типе и неверен про СОЗДАНИЕ типа: в
        // ArcadeDB CREATE EDGE по необъявленному типу не заводит его сам, а
        // падает. Прецедент рядом и ровно об этом — шаг V22, который целиком
        // состоит из одной строки «CREATE EDGE TYPE IN_AREA».
        //
        // Без этого шага после промоушна product_link отвечал бы ошибкой на
        // каждую запись, а выглядело бы это как «продуктовая ось не работает
        // после выката» — то есть причину искали бы в деплое, а не здесь.
        // Сторож против повторения — ProductEdgeTypesReachProdTest.
        // БЕЗ «EXTENDS E» — и это не стиль, это отказ выката 04.09.2026:
        //
        //   V43: CREATE EDGE TYPE IN_PRODUCT IF NOT EXISTS EXTENDS E
        //        → "Supertype 'E' not found"
        //
        // На боевой БД базового типа E НЕТ. Объявляет его только
        // LoreSchemaInitializer, а он там выключен (lore.bootstrap=false) — то
        // есть ровно та дыра, которую этот же шаг и закрывает. Все рёбра,
        // заведённые миграциями, живут без супертипа: V22 это буквально
        // «CREATE EDGE TYPE IN_AREA IF NOT EXISTS», V39 — то же для
        // ROLE_HELD_BY. Форму «EXTENDS E» я скопировала из инициализатора
        // вместо прецедента миграций, и она валила старт приложения в цикле:
        // шаг не проходит → раннер отказывается поднять сервис → docker
        // перезапускает контейнер → снова бэкап и снова отказ.
        new Step(43, 17, "product_edge_types_on_prod", List.of(
            "CREATE EDGE TYPE IN_PRODUCT     IF NOT EXISTS",
            "CREATE PROPERTY IN_PRODUCT.role IF NOT EXISTS STRING",
            "CREATE EDGE TYPE PARENT_PRODUCT IF NOT EXISTS")),

        // RM-S1: веха → продукт. Отдельный тип, а не общий IN_PRODUCT:
        // семантика другая (компонент ВХОДИТ в продукт, веха НАЦЕЛЕНА на него),
        // и слайс products читает состав как in('IN_PRODUCT').component_id —
        // вехи на том же типе приехали бы туда пачкой null'ов. Имя парное к
        // TARGETS_MILESTONE: цепь карты читается подряд спринт → веха → продукт.
        // Тоже без «EXTENDS E» — по той же причине, см. комментарий к V43.
        new Step(44, 17, "milestone_targets_product", List.of(
            "CREATE EDGE TYPE TARGETS_PRODUCT IF NOT EXISTS")),

        // V45: отметка времени последней правки решения.
        //
        // Решение живёт БЕЗ истории (плоская модель, ADR-019), поэтому события
        // «изменено» для него взять было неоткуда: лента читала тип
        // KnowDecisionHist, который схема создаёт, срез читает, а не пишет
        // НИКТО — строки в нём остались от прежней модели, самая свежая от
        // 14 июня. Отказ тихий: лента не пустела, пропадало только то, чего
        // читатель не ждёт увидеть поимённо.
        //
        // Поле, а не история: восстанавливать SCD2 ради одного события дороже
        // и противоречит принятой плоской модели. Одна отметка отвечает на
        // «когда правили в последний раз» — ровно на тот вопрос, который
        // задаёт лента.
        new Step(45, 17, "decision_updated_at", List.of(
            "CREATE PROPERTY KnowDecision.updated_at IF NOT EXISTS STRING")),

        // AO-05 (решение владельца 31.08.2026): 123 значения роли, которые V36/V37
        // не сопоставили ни с одной личностью, лежат в примечаниях задач блоком V38.
        // Все они — один и тот же агент AGENT-FULL; различались они тем, ГДЕ
        // работала сессия (rollout, minilore-app, gateway-session…). Этому факту
        // в модели ребра места не было — отсюда и остаток. origin — то самое место:
        // необязательный атрибут ДЕЙСТВИЯ, пишется дословно, без приведения к
        // общему виду (группировать — отдельным решением, когда будет основание).
        // Java-часть шага (backfillDroppedRoleNotes) ставит рёбра — см. runner.
        new Step(46, 17, "role_edge_origin", List.of(
            "CREATE PROPERTY ROLE_HELD_BY.origin IF NOT EXISTS STRING")),

        // RM-P9: спеки, доки и ранбуки без проекта получают его через ПРОДУКТ
        // своего компонента. SQL пуст — вся работа в javaStep(47).
        //
        // Зачем отдельный шаг, если V20 это уже делал: V20 выводил проект через
        // спринты компонента и брал результат только при одном distinct-проекте.
        // Замер 19.10.2026 — это закрывает 15 записей из 499, потому что путь
        // отвечает «в каких репозиториях трогали компонент», а не «чей документ».
        // Путь через продукт однозначен: смешанных наборов продуктов у 457 спек
        // и доков НЕ НАЙДЕНО НИ ОДНОГО.
        //
        // Карта «продукт → проект» выведена из уже привязанных записей и зашита
        // в PRODUCT_TO_PROJECT — читаемо на ревью и одинаково на любом прогоне.
        new Step(47, 17, "java__doc_project_edges_by_product", List.of()),

        // SE-06, D-2026-LORE-AGENT-ROLE-DICT-IS-PROFILE (20.10.2026): справочник
        // agent_role хранит ПРОФИЛИ агентов (набор разрешённых инструментов), а
        // имя «роль» путало его с ролью доступа человека (project_role) и ролью в
        // продукте. Коды не меняются. SQL пуст: перенос — два UPDATE данных,
        // текстовое правило идемпотентности SQL-шагов их не пропустило бы, —
        // вся работа в javaStep(48).
        //
        // Ось совместимости не поднимается: Java-код бэкенда словарь по имени не
        // читает, читают фронт и описание MCP — они правятся в том же PR.
        // Свойство KnowActor.agent_role и поле API actor/owner.agent_role — это
        // другой контракт (клиенты вне репозитория) и этим шагом НЕ трогаются.
        new Step(48, 17, "java__dict_agent_role_to_agent_profile", List.of()),

        // DS-3 (SPRINT_LORE_MCP_DOCSYNC_GAPS): хеш и длина каждого тела KnowDoc
        // для сверки корпуса по списку docs. Новые записи получают их при upsert
        // (LoreDocResource, LoreIngestService); этот шаг добирает уже записанные.
        // SQL пуст — вся работа в javaStep(49). Аддитивен: только новые поля.
        new Step(49, 17, "java__doc_body_digest", List.of()),

        // DS-4: у спеки не было поля статуса — «предложение» жило только в тексте
        // (SPEC-DWL-RUNE-DREAMS, сверка DWL 24.10.2026). Статус пишется на
        // открытую KnowSpecHist (SCD2, как у ADR), значения — из этого словаря.
        // Коды и иконография — те же, что у adr_status/decision_status: один
        // смысл, один вид. is_extensible=true — владелец дополняет в админке.
        new Step(50, 17, "spec_status_dictionary", List.of(
            "CREATE PROPERTY KnowSpecHist.status IF NOT EXISTS STRING",
            "UPDATE KnowDictEntry SET dict_type='spec_status', code='proposed',   label_ru='Предложение', label_en='Proposed', icon='calendar',     color='var(--inf)', sort_order=10, is_active=true, is_extensible=true UPSERT WHERE dict_type='spec_status' AND code='proposed'",
            "UPDATE KnowDictEntry SET dict_type='spec_status', code='accepted',   label_ru='Принята',     label_en='Accepted', icon='laurel-crown', color='var(--suc)', sort_order=20, is_active=true, is_extensible=true UPSERT WHERE dict_type='spec_status' AND code='accepted'",
            "UPDATE KnowDictEntry SET dict_type='spec_status', code='deprecated', label_ru='Устарела',    label_en='Deprecated', icon='pause-button', color='var(--t3)', sort_order=30, is_active=true, is_extensible=true UPSERT WHERE dict_type='spec_status' AND code='deprecated'",
            "UPDATE KnowDictEntry SET dict_type='spec_status', code='superseded', label_ru='Вытеснена',   label_en='Superseded', icon='pause-button', color='var(--t3)', sort_order=40, is_active=true, is_extensible=true UPSERT WHERE dict_type='spec_status' AND code='superseded'"
        )),

        // LH-44, пункт 3 (решение владельца 27.10.2026: «удалить после выгрузки»):
        // легаси-рёбра HAS_STATUS KnowADRHist → StatusAdr от Python-ingest. Их не
        // читает ни один слайс, UI, MCP или скрипт (сверено grep-ом по всему
        // репозиторию); статус ADR живёт в KnowADR.status. Рассинхрон с полем —
        // ложь, которую можно прочесть прямым запросом. SQL пуст: javaStep(51)
        // сначала ВЫГРУЖАЕТ каждое ребро в лог (rid, состояние ADR, статус), потом
        // удаляет — по @rid, DELETE EDGE в грамматике нет. Типы StatusAdr и
        // HAS_STATUS не снимаются: схема аддитивна, снос типа — отдельное решение.
        new Step(51, 17, "java__drop_legacy_adr_has_status", List.of()),

        // RM-P17 (D-2026-LORE-OWNER-ANSWERS-20261104, ответ №8 «а»): открытые
        // строки KnowTaskHist без valid_from получают дату СОЗДАНИЯ задачи из
        // честного источника — самой ранней даты её же истории, либо отметки
        // создания на вершине. Источника нет — строка остаётся NULL и пишется в
        // лог: выдуманная дата стала бы фактом аналитики
        // (D-2026-LORE-HISTORY-GAP-VISIBLE-NOT-GUESSED). Плюс снимается остаток
        // тестового прогона (state_uid «test-state-*») — по @rid, после выгрузки
        // строки в лог. SQL пуст — вся работа в javaStep(52).
        new Step(52, 17, "java__task_hist_valid_from_backfill_and_test_rows", List.of()),

        // RM-X1 (ответ №9 «а»): id вехи «M2 ✓ core» с пробелом и глифом
        // неадресуем. Переименование в M2 — тот же вид, что у соседей M0…M7;
        // label не трогается. Рёбра идут по @rid и не меняются; переписываются
        // строковые ссылки в полях. Идемпотентен: старого id нет → no-op.
        new Step(53, 17, "java__milestone_m2_core_rename", List.of()),

        // T-14 (ответ №15 «да»): DROP TYPE PlanItem, PlanItemHist, ON_TRACK,
        // CONTRIBUTES_TO — ТОЛЬКО при нулевом использовании. Счётчик > 0 у
        // любого из них → не удаляется ничего, WARN с числами, старт не
        // валится. Бэкап перед шагом снимает раннер (upgrade-путь). Ни один шаг
        // и ни инициализатор эти типы не создают — requiredLiveTypes их не ждёт.
        new Step(54, 17, "java__drop_planitem_types_if_unused", List.of()),

        // RM-P17, хвост V52 (решение владельца 05.11.2026: «1 ок» — вариант «б»):
        // у семи задач SPRINT_DALI_PARSE_MEM_PARALLEL_JUN26/P1-A…G даты создания в
        // корпусе нет нигде, V52 честно оставил их NULL. Владелец разрешил взять
        // ближайший факт — момент мержа PR #204, которым эти задачи сделаны.
        // Только перечисленные задачи и только открытые строки с valid_from IS NULL;
        // источник — в valid_from_source. SQL пуст — работа в javaStep(55).
        new Step(55, 17, "java__dali_p1_valid_from_from_pr204", List.of()),

        // RM-P13 (решение владельца 05.11.2026: «единый формат, рекомендованный
        // БД, перестаём сочинять»): valid_from и valid_to у ВСЕХ *Hist —
        // нативный DATETIME. Смена типа уже объявленного свойства в ArcadeDB
        // делается только DROP PROPERTY + CREATE PROPERTY (ALTER PROPERTY типа не
        // меняет), а записанные значения схема не переписывает — поэтому вся
        // работа (счёт до/после, смена объявления, пересохранение строк) в
        // javaStep(56); SQL пуст. Разбор движка — в javadoc
        // LoreSchemaMigrationRunner.histTimeToDatetime. Аддитивный (major 17):
        // форма записи для пишущих путей не меняется — они и так шлют ISO-Z.
        new Step(56, 17, "java__hist_valid_time_datetime", List.of()),

        // T-14, хвост V54 (решение владельца 05.11.2026: «удаляй из спек из базы и
        // закрывай задачу, это уже архивная история»): StatusPlanItem и REPRESENTS
        // в ответ №15 не входили и пережили V54. На проде 05.11 оба пусты (0 строк),
        // код их не создаёт и не читает. Тот же механизм: только при нулевом счёте,
        // иначе WARN и ничего не удаляется. Бэкап перед шагом снимает раннер.
        new Step(57, 17, "java__drop_planitem_leftovers_if_unused", List.of()),

        // SPRINT_LORE_MEASURE_TRUTH/MT-CAL-ACTUAL (06.11.2026): факт трудоёмкости
        // рядом с оценкой. Калибровка показала: факт выводился только из истории
        // статусов, а у 75% закрытых задач рабочего статуса нет — измеримых пар 14%.
        // Поле на ВЕРШИНЕ (как work_class): факт не версионируется. Тип объявлен
        // заранее (урок RM-P12 — необъявленное поле получает тип от первого пишущего).
        new Step(58, 17, "task_actual_days", List.of(
            "CREATE PROPERTY KnowTask.actual_days IF NOT EXISTS DOUBLE")),

        // SPRINT_LORE_MEASURE_TRUTH/MT-CAL-BOOKKEEPING (06.11.2026): «запись задним
        // числом» — задача заведена и закрыта как учёт уже сделанной работы. Её
        // done_date — дата простановки статуса, не работы; аналитика скорости её
        // исключает и говорит, сколько исключила. Вершина, не Hist (как work_class).
        new Step(59, 17, "task_bookkeeping", List.of(
            "CREATE PROPERTY KnowTask.bookkeeping IF NOT EXISTS BOOLEAN")),

        // SPRINT_LORE_PRODUCT_BACKLOG/AN-09 · decision:D-2026-LORE-FEATURE-BUILDS-ON-EDGE
        // (06.11.2026): линейка фич «опирается на → открывает дорогу» — ребром, а не
        // текстовыми ссылками context_md (истина в рёбрах, D5). Направление:
        // фича → фича, на которую она опирается.
        new Step(60, 17, "feature_builds_on", List.of(
            "CREATE EDGE TYPE BUILDS_ON IF NOT EXISTS")),

        // D-2026-MINILORE-OWNER-ANSWERS-06-11 п.3 (Q-MINILORE-TASK-PR-EDGE, владелица
        // «ок» 06.11.2026): задача → PR, который её закрыл, — РЕБРОМ, а не текстом
        // note_md. Релиз находит свои задачи через PR → SHIPPED_IN.
        new Step(61, 17, "task_closed_by", List.of(
            "CREATE EDGE TYPE CLOSED_BY IF NOT EXISTS")),

        // SPRINT_LORE_WORK_ANY_KIND/WK-03 · decision:D-2026-LORE-SERVES-EDGE: сервисный
        // продукт служит технологическому — считаем (count), продаём (sell),
        // поддерживаем (support). Продукт → продукт, вид — свойство ребра; без
        // EXTENDS E — на проде базового типа нет (см. V43).
        new Step(62, 17, "product_serves", List.of(
            "CREATE EDGE TYPE SERVES IF NOT EXISTS",
            "CREATE PROPERTY SERVES.kind IF NOT EXISTS STRING")),

        // SPRINT_UXR_S2_GRAPH_MEMORY/S2-04 · decision:D-2026-UXR-VIEWS-SERVER (07.11.2026):
        // виды, избранное, недавние и личные настройки — на сервере, видны с любого
        // устройства. Только НОВЫЕ типы (v1 их не знает и не задевает — ADR-LORE-045,
        // аддитивно: major 17). Владелец — kc_sub полем, а не ребром к KnowUser:
        // вершина KnowUser заводится лишь при выдаче проектной роли, а помнить
        // настройки нужно любому вошедшему. version — оптимистическая блокировка
        // (S2-09): правка по устаревшей версии получает 409, а не затирает чужую.
        new Step(63, 17, "user_views_prefs", List.of(
            "CREATE VERTEX TYPE KnowSavedView IF NOT EXISTS",
            "CREATE PROPERTY KnowSavedView.view_uid IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSavedView.owner_sub IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSavedView.name IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSavedView.section IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSavedView.query IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSavedView.visibility IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSavedView.roles IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSavedView.is_team_default IF NOT EXISTS BOOLEAN",
            "CREATE PROPERTY KnowSavedView.is_personal_default IF NOT EXISTS BOOLEAN",
            "CREATE PROPERTY KnowSavedView.row_version IF NOT EXISTS INTEGER",
            "CREATE PROPERTY KnowSavedView.created_at IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSavedView.updated_at IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowSavedView (view_uid) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowSavedView (owner_sub) NOTUNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowSavedView (section) NOTUNIQUE",
            "CREATE VERTEX TYPE KnowUserFavorite IF NOT EXISTS",
            "CREATE PROPERTY KnowUserFavorite.owner_sub IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserFavorite.ref_type IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserFavorite.ref_id IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserFavorite.added_at IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowUserFavorite (owner_sub, ref_type, ref_id) UNIQUE",
            "CREATE VERTEX TYPE KnowUserRecent IF NOT EXISTS",
            "CREATE PROPERTY KnowUserRecent.owner_sub IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserRecent.ref_type IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserRecent.ref_id IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserRecent.visited_at IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserRecent.visits IF NOT EXISTS INTEGER",
            "CREATE INDEX IF NOT EXISTS ON KnowUserRecent (owner_sub, ref_type, ref_id) UNIQUE",
            "CREATE VERTEX TYPE KnowUserSettings IF NOT EXISTS",
            "CREATE PROPERTY KnowUserSettings.owner_sub IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserSettings.settings_json IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserSettings.row_version IF NOT EXISTS INTEGER",
            "CREATE PROPERTY KnowUserSettings.updated_at IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowUserSettings (owner_sub) UNIQUE")),

        // SPRINT_UXR_S2_GRAPH_MEMORY/S2-05 «что LORE помнит обо мне» — вслед за V63
        // (виды S2-04), чтобы не спорить с ним номером. Только новые типы и одно
        // новое поле у KnowUserRecent (S2-04) — аддитивно, major 17, v1 не задет.
        // KnowUserHabit — частые виды (ключ = view_uid вида S2-04) и частые срезы
        // (раздел?запрос); KnowUserMemoryPref — флаг «не запоминать» на человека.
        // Владелец — kc_sub полем, как в V63. Срок хранения (90 дней) — по last_seen.
        new Step(64, 17, "user_memory", List.of(
            "CREATE VERTEX TYPE KnowUserHabit IF NOT EXISTS",
            "CREATE PROPERTY KnowUserHabit.memory_id IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserHabit.owner_sub IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserHabit.kind IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserHabit.habit_key IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserHabit.label IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserHabit.hits IF NOT EXISTS INTEGER",
            "CREATE PROPERTY KnowUserHabit.first_seen IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserHabit.last_seen IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowUserHabit (memory_id) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowUserHabit (owner_sub, kind, habit_key) UNIQUE",
            "CREATE INDEX IF NOT EXISTS ON KnowUserHabit (owner_sub) NOTUNIQUE",
            "CREATE VERTEX TYPE KnowUserMemoryPref IF NOT EXISTS",
            "CREATE PROPERTY KnowUserMemoryPref.owner_sub IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUserMemoryPref.remembering IF NOT EXISTS BOOLEAN",
            "CREATE PROPERTY KnowUserMemoryPref.updated_at IF NOT EXISTS STRING",
            "CREATE INDEX IF NOT EXISTS ON KnowUserMemoryPref (owner_sub) UNIQUE",
            "CREATE PROPERTY KnowUserRecent.first_seen IF NOT EXISTS STRING")),

        // SPRINT_UXR_S2_GRAPH_MEMORY/S2-06 · decision:D-2026-UXR-LINK-MENTION-EDGE:
        // запасной тип связи для «Связать» из упоминаний — «упоминает», когда
        // подходящего типизированного ребра для пары нет (LoreLinkTypes). Аудит
        // живёт на самом ребре: откуда пришло (origin), когда и кто поставил.
        // Без EXTENDS E — на проде базового типа нет (см. V43). Только аддитивно.
        new Step(65, 17, "references_edge", List.of(
            "CREATE EDGE TYPE REFERENCES IF NOT EXISTS",
            "CREATE PROPERTY REFERENCES.origin IF NOT EXISTS STRING",
            "CREATE PROPERTY REFERENCES.created_at IF NOT EXISTS STRING",
            "CREATE PROPERTY REFERENCES.created_by IF NOT EXISTS STRING")),

        // SPRINT_UXR_S2_GRAPH_MEMORY/S2-12: автор версии истории. Каждая новая
        // версия любой цепочки SCD2 несёт changed_by (kc_sub человека / client_id
        // агента) и changed_by_kind (human|agent|unknown) из ПРОВЕРЕННОГО токена
        // (ChangeAuthor). Необязательные STRING на всех двенадцати *Hist — старые
        // версии остаются без автора («неизвестно»), v1 поле не знает и не задевает.
        // Только аддитивно, major 17 (чек-лист S2-07 предусматривал ровно эту форму).
        new Step(66, 17, "hist_change_author", HIST_VALID_FROM_TEMPORAL.stream()
            .flatMap(h -> java.util.stream.Stream.of(
                "CREATE PROPERTY " + h + ".changed_by IF NOT EXISTS STRING",
                "CREATE PROPERTY " + h + ".changed_by_kind IF NOT EXISTS STRING"))
            .toList()),

        // SPRINT_UXR_S2_GRAPH_MEMORY/S2-13: единая схема статуса в истории всех типов
        // со статусом (StatusHistoryService.KINDS). status_raw — сам статус версии
        // (у ADR/спек/решений история его раньше не несла), status_category — ось
        // D-2026-UXR-STATUS-AXIS на момент записи, status_known_from — с какого
        // момента статус версии ИЗВЕСТЕН (у сервиса = valid_from; у бэкфилла V68 —
        // момент бэкфилла), status_backfilled — статус положен бэкфиллом, а не
        // переходом. Только новые необязательные свойства, major 17.
        new Step(67, 17, "status_history_unified", STATUS_HIST_TYPES.stream()
            .flatMap(h -> java.util.stream.Stream.of(
                "CREATE PROPERTY " + h + ".status_raw IF NOT EXISTS STRING",
                "CREATE PROPERTY " + h + ".status_category IF NOT EXISTS STRING",
                "CREATE PROPERTY " + h + ".status_known_from IF NOT EXISTS STRING",
                "CREATE PROPERTY " + h + ".status_backfilled IF NOT EXISTS BOOLEAN"))
            .toList()),

        // S2-13: бэкфилл статуса в истории ADR, спек и решений
        // (StatusHistoryService.backfill): открытой версии без статуса — текущий
        // статус вершины с пометкой «известен с момента бэкфилла»; элементу без
        // истории — одна версия с той же пометкой. Новых версий у тех, у кого они
        // есть, не открывает; valid_from/valid_to существующих строк не трогает.
        new Step(68, 17, "java__status_history_backfill", List.of()),

        // SPRINT_UXR_S2_GRAPH_MEMORY/S2-10 (остаток после S2-12/S2-13).
        // 1) Полный ISO-момент рядом с датой (CreationMoment.FIELDS): created_at у
        //    ADR и решений, released_at у релиза. Дата (date_created/release_date)
        //    остаётся как была — её читают v1, timeline_* и контракты S0. Момент
        //    пишется один раз при создании и только когда известен; у старых
        //    записей его нет — это и есть пометка «время неизвестно» (UPDATE-пометки
        //    чек-лист v1 не пускает).
        // 2) KnowSpecHist.version объявлено явно: номер версии спеки — свойство
        //    ВЕРСИИ истории (смена номера открывает новую строку, LoreSpecResource),
        //    до сих пор писалось без объявления.
        // Только новые необязательные STRING, major 17.
        new Step(69, 17, "creation_moment_and_spec_hist_version", List.of(
            "CREATE PROPERTY KnowADR.created_at IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDecision.created_at IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowRelease.released_at IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSpecHist.version IF NOT EXISTS STRING")),

        // SPRINT_UXR_S7A_NEWS/S7A-04 (спека новостей §8, решение 07.11 п.12): черта
        // «прочитано до сюда» — на сервере, одна общая, сдвигается только PUT
        // человека. Новый тип, v1 его не знает — аддитивно, major 17. Вслед за
        // шагами S2 (66–69). DDL живёт рядом с хранилищем, чтобы не было двух правд.
        new Step(70, 17, "news_read_mark", LoreNewsReadMarkStore.SCHEMA_SQL),

        // SPRINT_UXR_S2_GRAPH_MEMORY/S2-11: задачам без единой версии истории
        // (запись мимо SCD2, 14 на проде) — одна версия с пометкой status_backfilled
        // и valid_from = момент бэкфилла, без выдуманных дат. Та же логика, что V68
        // (StatusHistoryService.backfill), только для типа task.
        new Step(71, 17, "java__task_history_backfill", List.of()),

        // SPRINT_UXR_S5_RECORD_TASKS/S5-09: черновик правки MD-поля на сервере —
        // новый тип KnowUserDraft, владелец kc_sub полем (как V63). Аддитивно,
        // major 17, v1 о нём не знает. DDL живёт рядом с логикой (LoreMeDrafts).
        new Step(72, 17, "user_drafts", LoreMeDrafts.SCHEMA_SQL),

        // SPRINT_UXR_S7C_WHY_CANVAS/S7C-01: холст «зачем» на сервере — три новых
        // типа KnowCanvas / KnowCanvasItem / KnowCanvasLink. Аддитивно, major 17,
        // v1 о них не знает. DDL рядом с логикой (LoreCanvas).
        new Step(73, 17, "canvas_storage", LoreCanvas.SCHEMA_SQL),

        // SPRINT_UXR_S5_RECORD_TASKS/S5-09 (kit 09.11): версия записи в черновике —
        // строкой, как record.version в /lore/record. Прежнее base_version объявлено
        // INTEGER и строку не примет — новое свойство, аддитивно, major 17.
        new Step(74, 17, "user_drafts_record_version", LoreMeDrafts.SCHEMA_SQL_V74),

        // SPRINT_UXR_S7B_ADMIN/S7B-15, ADR-MINILORE-007 (поправка 09.11): harness актора-агента —
        // свойство, справочник harness, заполнение по имени только при однозначном совпадении.
        new Step(75, 17, "actor_harness", LoreActorHarness.SCHEMA_SQL_V75),

        // S7B-15: заполнение harness по имени — Java-шаг (в SQL после v1 только аддитивное):
        // однозначные назначения LoreActorHarness.plan, с условием «ещё не стоит».
        new Step(76, 17, "java__actor_harness_backfill", List.of()),

        // S2-11 (прод 09.11, v1.17.8): версия истории на нескольких сущностях — каждому владельцу
        // кроме первого своя копия (те же поля и даты), ребро переводится на копию.
        new Step(77, 17, "java__shared_state_split", List.of()),

        // SPRINT_UXR_S7B_ADMIN/S7B-13: событие AL-102 знает свою пачку массовых правок и роль до
        // правки — пачку раскрывают из журнала по batch_id и откатывают без ответа исходного
        // вызова (GET /lore/admin/actions/batch/{id}). Аддитивно, major 17. Индекса нет: событий
        // сотни, а у старых batch_id пуст — индекс по пустому полю ради скана сотни строк не нужен.
        new Step(78, 17, "project_role_event_batch", List.of(
            "CREATE PROPERTY KnowProjectRoleEvent.batch_id    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowProjectRoleEvent.role_before IF NOT EXISTS STRING")),

        // SPRINT_LORE_AGENT_OBSERVABILITY/AO-MACHINE-OBJ (ADR-MINILORE-007, поправка 09.11;
        // ADR-LORE-041 — связь ребром): машина — вершина KnowMachine, агент привязан к ней
        // рёбрами USES_MACHINE, машин у агента может быть несколько. Аддитивно, major 17.
        // DDL рядом с логикой (AgentMachine).
        new Step(79, 17, "agent_machine", AgentMachine.SCHEMA_SQL),

        // SPRINT_UXR_S7B_ADMIN/S7B-ACL-1 · S7B-ACL-2 (заказ владелицы 11.11, круг 2 прав машин):
        // допуск «человек → машина» — ребро MACHINE_ACCESS KnowUser → актор-машина (client_id
        // minilore-link-*), на ребре роль из словаря machine_access_role и scope по проектам и
        // harness. Аддитивно, major 17. DDL и засев словаря рядом с логикой (MachineAccess).
        new Step(80, 17, "machine_access", MachineAccess.SCHEMA_SQL),

        // SPRINT_UXR_S7B_ADMIN/S7B-ACT-1 (слово владелицы 11.11: «считать активной в течении — от часа
        // после последнего вызова до суток»): окно активности машины и окна по harness — свойства
        // актора-машины (client_id minilore-link-*). Аддитивно, major 17. DDL рядом с логикой (MachineActivity).
        new Step(81, 17, "machine_activity_window", MachineActivity.SCHEMA_SQL),

        // SPRINT_UXR_POLISH_UAT_1113/PU-18 шаг 2 (слово владелицы 13.11: «да, слить»): вершины
        // KnowMachine, различающиеся регистром (прод: LorCetus, LORCETUS), сливаются в
        // каноническое имя (AgentMachine.canon) с переносом USES_MACHINE; KnowActor.machine_id —
        // туда же, плюс опечатка lorecetus у Kimi. Идёт вместе с канонизацией входа (#1308):
        // раньше слитое пересоздавалось бы заголовком X-Lore-Machine. Идемпотентен.
        new Step(82, 17, "java__machine_id_canon", List.of()),

        // SPRINT_UXR_POLISH_UAT_1113/PU-20 (решение владелицы 13.11, A1: «отдельный объект в бд»):
        // отметки «не ссылка» раздела «Привести в порядок» — вершина LoreRefDismissal, ключ
        // record_type|record_id|kind. Аддитивно, major 17. Идёт после V82 (PU-18, #1311).
        // DDL рядом с логикой (MdRefDismissals).
        new Step(83, 17, "ref_dismissal", MdRefDismissals.SCHEMA_SQL),

        // SPRINT_LORE_MODEL_AS_CONFIG/MC-05 (SPEC-LORE-MODEL-CONFIG-STORE): V84 (V82 — #1311 PU-18, V83 — #1316 PU-20). Модель LORE — запись в LORE с
        // историей SCD2 (KnowModelConfig + KnowModelConfigHist через HAS_STATE). Аддитивно, major 17:
        // только новые типы, данные не трогаются. DDL рядом с логикой (LoreModelStore).
        new Step(84, 17, "model_config_store", LoreModelStore.SCHEMA_SQL),

        // SPRINT_UXR_POLISH_UAT_1113/PU-24 (владелица 13.11: «доделайте сидирование»): статус uat
        // (v1.17.18) вошёл в жизненный цикл задачи И спринта кодом, а строки словарей — данные,
        // их не заводила ни одна миграция. На проде task_status/uat добавили руками,
        // sprint_status/uat не было → модель отдала статью без цвета и значка, kit показал
        // «оговорки модели». Сид идемпотентный (UPSERT), значения — как в kit (statusMeta: stamper,
        // --st-uat) и как строка, уже заведённая на проде. Аддитивно, major 17. V84 занят
        // MC-05 (model_config_store, выше): раннер накатывает недостающие шаги поштучно, пропуск
        // номера не мешает.
        new Step(85, 17, "status_dict_uat_seed", List.of(
            "UPDATE KnowDictEntry SET dict_type='task_status', code='uat', label_ru='UAT — приёмка', label_en='UAT Testing', icon='stamper', color='var(--st-uat)', sort_order=55, is_active=true UPSERT WHERE dict_type='task_status' AND code='uat'",
            "UPDATE KnowDictEntry SET dict_type='sprint_status', code='uat', label_ru='UAT — приёмка', label_en='UAT Testing', icon='stamper', color='var(--st-uat)', sort_order=55, is_active=true UPSERT WHERE dict_type='sprint_status' AND code='uat'"
        )),

        // D-2026-LORE-AGENT-MACHINE-EVERYWHERE п.4 (вариант А, выбор владелицы 14.11): журнал
        // действий — свой ряд AgentActionLog с тегами client и machine (к TIMESERIES MetricSnapshot
        // теги не добавить). SQL — новый тип (IF NOT EXISTS); java — однократная копия прежних
        // точек lore.action с отметкой «неизвестно», без догадки. Прежние точки остаются.
        // V85 — PU-24 (#1342), выше.
        new Step(86, 17, "java__agent_action_log", List.of(AgentActionLog.DDL)),

        // SPRINT_LORE_WORK_ANY_KIND/WK-05 (ADR-LORE-014-D5, допущение A3 — «Да, как рекомендовано» 14.11):
        // строка истории задачи несёт доказательство done (evidence_type/evidence_ref по виду работы),
        // стадию внутри статуса ядра, адресат ожидания (waiting) и причину перехода. Аддитивно, major 17:
        // только новые свойства, старые done задним числом не трогаются (развилка Г).
        // Номер V87 сверен со «Стабильностью» 14.11 (V85 — PU-24, V86 — #1343).
        // Новые статусы ядра waiting/review/failed — строками словарей задачи и спринта, как uat в V85:
        // без строки модель отдаёт статус без цвета и значка («оговорки модели» в kit). Цвета — общие
        // токены (своих --st-* у них пока нет), значки — из прототипа wk-05-workflow. UPSERT идемпотентен.
        new Step(87, 17, "task_workflow_fields", List.of(
            "CREATE PROPERTY KnowTaskHist.evidence_type IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTaskHist.evidence_ref IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTaskHist.stage IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTaskHist.waiting_for IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTaskHist.status_reason IF NOT EXISTS STRING",
            "UPDATE KnowDictEntry SET dict_type='task_status', code='waiting', label_ru='Ждём ответа', label_en='Waiting', icon='hourglass', color='var(--inf)', sort_order=35, is_active=true UPSERT WHERE dict_type='task_status' AND code='waiting'",
            "UPDATE KnowDictEntry SET dict_type='task_status', code='review', label_ru='На приёмке', label_en='Review', icon='magnifying-glass', color='var(--wrn)', sort_order=45, is_active=true UPSERT WHERE dict_type='task_status' AND code='review'",
            "UPDATE KnowDictEntry SET dict_type='task_status', code='failed', label_ru='Неуспех', label_en='Failed', icon='cancel', color='var(--dng)', sort_order=65, is_active=true UPSERT WHERE dict_type='task_status' AND code='failed'",
            "UPDATE KnowDictEntry SET dict_type='sprint_status', code='waiting', label_ru='Ждём ответа', label_en='Waiting', icon='hourglass', color='var(--inf)', sort_order=35, is_active=true UPSERT WHERE dict_type='sprint_status' AND code='waiting'",
            "UPDATE KnowDictEntry SET dict_type='sprint_status', code='review', label_ru='На приёмке', label_en='Review', icon='magnifying-glass', color='var(--wrn)', sort_order=45, is_active=true UPSERT WHERE dict_type='sprint_status' AND code='review'",
            "UPDATE KnowDictEntry SET dict_type='sprint_status', code='failed', label_ru='Неуспех', label_en='Failed', icon='cancel', color='var(--dng)', sort_order=65, is_active=true UPSERT WHERE dict_type='sprint_status' AND code='failed'")),

        // SPRINT_LORE_AGENT_OBSERVABILITY/AO-02 (след источников «к сущности», механизм за флагом
        // lore.agent.sources.enabled, по умолчанию выкл): ребро SOURCED_FROM «опирался на» со свойствами
        // at, via. Аддитивно, major 17: новый тип ребра. Отдельным шагом — V86 уже влит (#1343),
        // его SQL менять нельзя (контрольная сумма). V87 — WK-05 (#1349), выше. DDL рядом с логикой (AgentSourceTrail).
        new Step(88, 17, "source_trail_edge", AgentSourceTrail.DDL),

        // SPRINT_LORE_PRODUCT_BACKLOG/SELF-PROVISION-STANDALONE (владелица 14.11.2026: «разметь в
        // версионировании схемы как deprecated и удали»; по сверке с продом — «да, а+б+в»).
        // DEPRECATED и снимаются: легаси-словари статусов Python-ingest StatusAdr / StatusDecision /
        // StatusMilestone / StatusPhase / StatusSprint / StatusTask, словарь видов трека TrackType и
        // рёбра к ним HAS_STATUS (строка истории → Status*) и OF_TYPE (PlanTrack → TrackType).
        // Статусы давно живут в универсальном справочнике KnowDictEntry и в status_raw строки
        // истории; Status* никто не пишет и не читает. Но перенос при переезде был неполным
        // (прод 14.11): у 329 закрытых строк задач, 59 спринтов, 28 текущих фаз и 8 текущих вех
        // статус был ТОЛЬКО в ребре, а TrackType читал срез plan_tracks. Поэтому порядок:
        //   SQL (ниже) — словари milestone_status / phase_status, коды area research/business,
        //     поля status_raw у историй вех и фаз, PlanTrack.area;
        //   java — (а, б) status_raw из ребра у строк без статуса (legacyStatusRaw), сверка «не
        //     осталось строки, чей статус только в ребре», снятие HAS_STATUS по @rid (как V51) и
        //     историй-сирот KnowDecisionHist с HAS_STATUS (владельца нет); (в) PlanTrack.area из
        //     OF_TYPE, сверка, снятие OF_TYPE; затем вершины Status*/TrackType и DROP TYPE.
        // Идемпотентен: на чистой базе типов нет — всё no-op. Чистая установка их больше не
        // создаёт (LoreSchemaInitializer), возврат сторожит RetiredLegacyStatusTypesTest.
        // Убыль объявлена в scripts/migrate-live-check/declared-decrease.tsv.
        new Step(89, 17, LoreSchemaMigrations.RETIRE_LEGACY_STATUS_STEP, List.of(
            "CREATE PROPERTY KnowMilestoneHist.status_raw IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPhaseHist.status_raw IF NOT EXISTS STRING",
            "CREATE PROPERTY PlanTrack.area IF NOT EXISTS STRING",
            "UPDATE KnowDictEntry SET dict_type='milestone_status', code='upcoming', label_ru='Предстоит', label_en='Upcoming', icon='calendar', color='var(--t3)', sort_order=10, is_active=true, is_extensible=false UPSERT WHERE dict_type='milestone_status' AND code='upcoming'",
            "UPDATE KnowDictEntry SET dict_type='milestone_status', code='active', label_ru='Активна', label_en='Active', icon='progression', color='var(--inf)', sort_order=20, is_active=true, is_extensible=false UPSERT WHERE dict_type='milestone_status' AND code='active'",
            "UPDATE KnowDictEntry SET dict_type='milestone_status', code='reached', label_ru='Достигнута', label_en='Reached', icon='laurel-crown', color='var(--suc)', sort_order=30, is_active=true, is_extensible=false UPSERT WHERE dict_type='milestone_status' AND code='reached'",
            "UPDATE KnowDictEntry SET dict_type='milestone_status', code='missed', label_ru='Пропущена', label_en='Missed', icon='cancel', color='var(--dng)', sort_order=40, is_active=true, is_extensible=false UPSERT WHERE dict_type='milestone_status' AND code='missed'",
            "UPDATE KnowDictEntry SET dict_type='phase_status', code='backlog', label_ru='Бэклог', label_en='Backlog', icon='tied-scroll', color='var(--t3)', sort_order=15, is_active=true, is_extensible=false UPSERT WHERE dict_type='phase_status' AND code='backlog'",
            "UPDATE KnowDictEntry SET dict_type='phase_status', code='planned', label_ru='Запланирована', label_en='Planned', icon='calendar', color='var(--wrn)', sort_order=20, is_active=true, is_extensible=false UPSERT WHERE dict_type='phase_status' AND code='planned'",
            "UPDATE KnowDictEntry SET dict_type='phase_status', code='active', label_ru='В работе', label_en='In Progress', icon='progression', color='var(--inf)', sort_order=30, is_active=true, is_extensible=false UPSERT WHERE dict_type='phase_status' AND code='active'",
            "UPDATE KnowDictEntry SET dict_type='phase_status', code='done', label_ru='Реализована', label_en='Done', icon='divided-spiral', color='var(--suc)', sort_order=60, is_active=true, is_extensible=false UPSERT WHERE dict_type='phase_status' AND code='done'",
            "UPDATE KnowDictEntry SET dict_type='phase_status', code='moved', label_ru='Вынесена', label_en='Moved out', icon='pause-button', color='var(--t3)', sort_order=80, is_active=true, is_extensible=false UPSERT WHERE dict_type='phase_status' AND code='moved'",
            "UPDATE KnowDictEntry SET dict_type='area', code='research', label_ru='Исследования', label_en='Research', color='color-mix(in srgb,var(--inf) 55%,var(--acc))', sort_order=160, is_active=true, is_extensible=true UPSERT WHERE dict_type='area' AND code='research'",
            "UPDATE KnowDictEntry SET dict_type='area', code='business', label_ru='Бизнес', label_en='Business', color='color-mix(in srgb,var(--wrn) 55%,var(--acc))', sort_order=170, is_active=true, is_extensible=true UPSERT WHERE dict_type='area' AND code='business'")),

        // SPRINT_LORE_PRODUCT_BACKLOG/SELF-PROVISION-STANDALONE (находка CT-KIT-FIXTURES 14.11): десять
        // базовых кодов task_status/sprint_status (todo…cancelled) не заводил ни один шаг — на проде их
        // внесли руками, база с нуля жила без статусов. Java-шаг: вставляет ТОЛЬКО недостающее, прод-строки
        // не переписывает (UPSERT, как в V85/V87, перекрасил бы их). Аддитивно, major 17. Номер V90 сверен
        // с сессией «Обновление проекта» 14.11: V89 — снятие легаси-статусов (#1401), этот шаг после него.
        new Step(90, 17, "java__status_dict_core_seed", List.of()),

        // SPRINT_LORE_MODEL_DOCS_TIDY/MDL-03 — декларация модели, первый заход. Правило владелицы 15.11.2026:
        // «поля не объявлены, но читаются приложением — обязательные, ну или пишутся». 59 полей, которые в
        // проде заполнены и у которых в коде найден писатель или читатель (либо это механика версий:
        // state_uid, content_hash, source_commit, updated_at), но схема их не знала: база не проверяла тип,
        // а по схеме нельзя было понять, из чего состоит запись. Шаг ТОЛЬКО объявляет — значений не меняет,
        // убыли нет, аддитивно (major 17). Сознательно НЕ здесь: копии значения версии на вершине (канон не
        // выбран), component_id (сверка с рёбрами), KnowSprintHist.pr_refs (в проде строки и список — MDL-06),
        // план-доска, релиз и PR (отдельный блок, MD-05), гейты качества (второй заход). Сторож состава —
        // DeclareStableFieldsStepTest.
        new Step(91, 17, LoreSchemaMigrations.DECLARE_STABLE_FIELDS_STEP, List.of(
            "CREATE PROPERTY KnowSprint.updated_at         IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSprintHist.state_uid      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSprintHist.source_commit  IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPhaseHist.state_uid       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPhaseHist.content_hash    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTask.updated_at           IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTaskHist.state_uid        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTaskHist.source_commit    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowADR.updated_at            IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowADRHist.state_uid         IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowADRHist.source_commit     IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDecisionHist.state_uid    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDecisionHist.content_hash IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowMilestone.updated_at      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowMilestoneHist.state_uid   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSpec.updated_at           IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSpecHist.state_uid        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDocHist.state_uid         IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowQuestion.updated_at       IF NOT EXISTS STRING",
            "CREATE PROPERTY LoreComponent.updated_at      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUseCase.updated_at        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSprint.plan_id            IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSprint.effort_days        IF NOT EXISTS DOUBLE",
            "CREATE PROPERTY KnowSprintHist.priority       IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSprintHist.block_reason   IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPhase.order_index         IF NOT EXISTS INTEGER",
            "CREATE PROPERTY KnowPhase.phase_id            IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPhase.name                IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowPhase.src                 IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTask.order_index          IF NOT EXISTS INTEGER",
            "CREATE PROPERTY KnowTask.src                  IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowTaskHist.effort_days      IF NOT EXISTS DOUBLE",
            "CREATE PROPERTY DEPENDS_ON.kind               IF NOT EXISTS STRING",
            "CREATE PROPERTY DEPENDS_ON.reason             IF NOT EXISTS STRING",
            "CREATE PROPERTY GATES.solved_at               IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowADR.date_created          IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDecision.date_created     IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDecision.refs_raw         IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowMilestone.date_display    IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowMilestone.label           IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowMilestone.priority        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSpec.file_path            IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowSpecHist.spec_id          IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDoc.kind                  IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDoc.file_path             IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowDocHist.doc_id            IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowRunbook.area              IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowRunbook.date_created      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowQuestion.opened_date      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowQuestion.status           IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowQuestion.priority         IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowQuestion.closed_date      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowQuestion.`trigger`        IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowQuestion.due_date         IF NOT EXISTS STRING",
            "CREATE PROPERTY LoreComponent.game_icon       IF NOT EXISTS STRING",
            "CREATE PROPERTY LoreComponent.full_name       IF NOT EXISTS STRING",
            "CREATE PROPERTY LoreComponent.area            IF NOT EXISTS STRING",
            "CREATE PROPERTY LoreComponent.parent_id       IF NOT EXISTS STRING",
            "CREATE PROPERTY LoreComponent.team            IF NOT EXISTS STRING")),

        // SPRINT_LORE_ADMIN_POLISH/AP-07 — профиль автора: логин, имя и аватар человека, один источник для LORE и
        // miniLORE. Исключение из остановки смены схемы до MIG-01 — слово владелицы 15.11.2026 («это разреши, оно
        // мелкое»; прямое подтверждение «ок» в канале). До шага логин жил в display_name — его писало назначение
        // ролей; теперь логин — своё поле, а display_name — имя, которое человек выбирает сам. Данные не переносятся
        // (шаг только объявляет, сторож аддитивности): у старых записей логин читается как coalesce(login, display_name),
        // новые назначения ролей пишут login сами. avatar_ref — ключ файла аватара в хранилище ассетов. Аддитивно, major 17. Номер V92 сверен с сессией модели (V91 — её).
        new Step(92, 17, "user_profile_login_avatar", List.of(
            "CREATE PROPERTY KnowUser.login      IF NOT EXISTS STRING",
            "CREATE PROPERTY KnowUser.avatar_ref IF NOT EXISTS STRING")),

        // SPRINT_QG_REBUILD/QG-09, ADR-LORE-053-D7: словарь состояний гейта qg_status (draft/active/stale/retired).
        // Справочник правит только человек, а база с нуля должна знать состояния сама — Java-шаг как V90: только
        // INSERT недостающих строк, существующие не переписываются; DDL нет. Разрешение владелицы менять модель
        // данных QG в спринте — 15.11.2026. Номер сверен с сессией модели (V91 — её, V92 — профиль). Аддитивно, major 17.
        new Step(93, 17, QgStatusDictSeed.STEP, List.of())
    );

    /** V91: имя шага объявления стабильных полей (сторож DeclareStableFieldsStepTest). */
    static final String DECLARE_STABLE_FIELDS_STEP = "declare_stable_fields_first_pass";

    /** V89: имя шага (сторож RetiredLegacyStatusTypesTest и JAVA_STEPS_REVIEWED держатся за него). */
    static final String RETIRE_LEGACY_STATUS_STEP = "java__retire_legacy_status_types";

    /** V89: снимаемые типы. Рёбра раньше вершин: DROP не упрётся в живое ребро. */
    static final List<String> RETIRED_LEGACY_STATUS_TYPES = List.of(
        "HAS_STATUS", "OF_TYPE",
        "StatusAdr", "StatusDecision", "StatusMilestone", "StatusPhase", "StatusSprint", "StatusTask",
        "TrackType");

    /**
     * V89: код легаси-словаря (StatusSprint/StatusTask/StatusPhase.status_id) → status_raw строки
     * истории. Форма — канон SCD2 (значок + слово), её одинаково читают {@link LoreStatusVocabulary}
     * (паспорт, слайсы) и {@link LoreStatusResource#rawToToken}. Слово сохраняет исходный код там,
     * где своего канона нет (CLOSED → ✅ done, PAUSED → ⏸ deferred, RESEARCH → 🔬 design).
     * {@code unknown} намеренно без значения: «неизвестно» — не статус, todo из него не выдумываем
     * (ADR-LORE-039), поле остаётся пустым, как и было.
     */
    static final Map<String, String> LEGACY_PLAN_STATUS_RAW = Map.ofEntries(
        Map.entry("todo",        "⬜ TODO"),
        Map.entry("planned",     "📋 PLANNED"),
        Map.entry("design",      "🔬 DESIGN"),
        Map.entry("research",    "🔬 RESEARCH"),
        Map.entry("in_progress", "🔄 IN PROGRESS"),
        Map.entry("done",        "✅ DONE"),
        Map.entry("closed",      "✅ CLOSED"),
        Map.entry("paused",      "⏸ PAUSED"),
        Map.entry("deferred",    "⏸ DEFERRED"),
        Map.entry("backlog",     "🟣 BACKLOG"));
    // draft / archived / dropped / moved тоже есть в легаси-словарях, но ни одна строка истории
    // без status_raw на них не ссылается (прод 14.11). Канон для них был бы догадкой — встретятся,
    // шаг упадёт до удаления (legacyStatusRaw), и перенос решается явно.

    /** V89: легаси-коды без статуса — переносить нечего (см. {@link #LEGACY_PLAN_STATUS_RAW}). */
    static final java.util.Set<String> LEGACY_STATUS_NO_VALUE = java.util.Set.of("unknown");

    /**
     * V89: что записать в status_raw строки истории {@code histType} вместо ребра HAS_STATUS
     * на легаси-статус {@code code}. Вехи и решения — код своего справочника как есть
     * (milestone_status / decision_status); план (задача, спринт, фаза) — канон SCD2.
     *
     * @return значение status_raw; null — переносить нечего (unknown)
     * @throws IllegalArgumentException незнакомый код — шаг падает ДО удаления, статус не теряется
     */
    static String legacyStatusRaw(String histType, String code) {
        String c = code == null ? "" : code.trim().toLowerCase(java.util.Locale.ROOT);
        if (c.isEmpty()) throw new IllegalArgumentException("V89: пустой код статуса у " + histType);
        if ("KnowMilestoneHist".equals(histType) || "KnowDecisionHist".equals(histType)) return c;
        if (LEGACY_STATUS_NO_VALUE.contains(c)) return null;
        String raw = LEGACY_PLAN_STATUS_RAW.get(c);
        if (raw == null) throw new IllegalArgumentException("V89: нет переноса для статуса '" + code + "' у " + histType);
        return raw;
    }

    /** V82: опечатки machine_id у конкретных акторов (прод 13.11): actor_id → {было, стало}. */
    static final Map<String, List<String>> MACHINE_ID_TYPOS = Map.of(
        "AGENT-FULL_KIMI-mw8ykenh", List.of("lorecetus", "lorcetus"));

    /** RM-X1: старый и новый id вехи для V53. */
    static final String MILESTONE_OLD_ID = "M2 ✓ core";
    static final String MILESTONE_NEW_ID = "M2";

    /** RM-P17 (V55): задачи без даты в корпусе и момент мержа PR #204 (Forgejo, merged_at). */
    static final List<String> DALI_P1_TASKS = List.of("A", "B", "C", "D", "E", "F", "G").stream()
        .map(s -> "SPRINT_DALI_PARSE_MEM_PARALLEL_JUN26/P1-" + s).toList();
    static final String PR204_MERGED_AT = "2026-07-21T18:16:07Z";

    /**
     * RM-X1: поля, в которых строкой может лежать id вехи. Сверено grep-ом по
     * коду: milestone_id (KnowMilestone и легаси-строки истории/PlanItem),
     * planned_milestone_id (снятое поле спринта, на старых строках может
     * остаться). Массивов id вех в корпусе нет — множественная связь только
     * рёбрами TARGETS_MILESTONE/ON_MILESTONE.
     */
    static final List<String> MILESTONE_REF_FIELDS = List.of("milestone_id", "planned_milestone_id");

    /**
     * T-14: типы снятого пласта PlanItem. Рёбра раньше вершин; при нулевом
     * счёте порядок не существенен, но так DROP не упрётся в живое ребро.
     */
    static final List<String> PLANITEM_TYPES = List.of("ON_TRACK", "CONTRIBUTES_TO", "PlanItemHist", "PlanItem");

    /** T-14, V57: что пережило V54 (замер прода 05.11.2026 — оба пусты). Рёбра раньше вершин. */
    static final List<String> PLANITEM_LEFTOVER_TYPES = List.of("REPRESENTS", "StatusPlanItem");

    /**
     * Одна строка справочника продуктов. Идиома UPSERT та же, что у
     * decision_status (V14) и work_class (V6): повторный прогон шага
     * перезаписывает ту же запись, а не заводит вторую.
     *
     * is_extensible=true — в отличие от статусов и видов работ: список продуктов
     * не закрыт, владелец добавляет новый продукт в админке сама.
     */
    private static String dictProduct(String code, String labelRu, String icon, String color, int order) {
        return dictProduct(code, labelRu, labelRu, icon, color, order);
    }

    private static String dictProduct(String code, String labelRu, String labelEn,
                                      String icon, String color, int order) {
        return String.format(
            "UPDATE KnowDictEntry SET dict_type='product', code='%s', label_ru='%s', label_en='%s', "
            + "icon='%s', color='%s', sort_order=%d, is_active=true, is_extensible=true "
            + "UPSERT WHERE dict_type='product' AND code='%s'",
            code, labelRu, labelEn, icon, color, order, code);
    }

    /**
     * SRCH-03: анализатор для русскоязычного корпуса. Замерено: с ним документ
     * со словом «релиза» находится по запросу «релиз», на дефолтном — нет.
     */
    static final String FT_ANALYZER = "org.apache.lucene.analysis.ru.RussianAnalyzer";

    /**
     * similarity ОБЯЗАН быть указан ЯВНО, хотя BM25 и заявлен умолчанием.
     *
     * Замерено на ArcadeDB 26.7.2, три варианта одного индекса на одних данных
     * (документы: 5 вхождений термина / 1 вхождение / 1 вхождение + 150 слов балласта):
     *   без METADATA вообще        → 0.272 / 0.218 / 0.076 — BM25, ранжирует
     *   METADATA только analyzer   → 1 / 1 / 1             — CLASSIC, НЕ ранжирует
     *   METADATA analyzer+similarity → 0.272 / 0.218 / 0.076 — BM25, ранжирует
     *
     * То есть передача METADATA БЕЗ similarity молча сбрасывает модель в CLASSIC.
     * Умолчание «BM25 для новых индексов» действует, только пока METADATA не
     * передан вовсе — а нам он нужен ради анализатора. Первая редакция этого
     * шага задавала лишь analyzer, и на проде получился корпус без ранжирования:
     * все совпадения со скором 1.
     */
    static final String FT_SIMILARITY = "BM25";

    /**
     * Область поиска — «куда ходить». Отсекает ветки ДО запроса, а не фильтрует
     * выдачу после: Bragi и QG живут в той же БД, но это другие продукты, и по
     * умолчанию в выдачу Forseti попадать не должны. Заодно дешевле: меньше
     * веток unionall на запрос.
     *
     * Имена совпадают с ПРОСТРАНСТВАМИ в шапке Seiðr (FORSETI / BRAGI), а не с
     * внутренними («LORE»): иначе реестр и интерфейс называют одно разными
     * словами, и «искать в LORE» перестаёт совпадать с тем, где пользователь стоит.
     *
     * Почему НЕ разносим по разным БД, хотя связность почти нулевая: замерено
     * 23 ребра из 21754 пересекают границу продуктов (QGRecommendation→KnowTask
     * ×10, QualityGate→LoreComponent ×12, BragiInsight→KnowTask ×1). Но это ровно
     * те рёбра, ради которых слой существует — рекомендация гейта, ставшая
     * задачей. Рёбер между базами в ArcadeDB нет: разделение превратило бы их в
     * мягкие ссылки по id, без обхода и без целостности.
     */
    enum FtScope { FORSETI, BRAGI, QUALITY }

    /** Именованный мультиполевой FULL_TEXT-индекс: одна ветка поиска = один вызов. */
    record FtIndex(String name, String type, List<String> fields, FtScope scope) {
        FtIndex(String name, String type, List<String> fields) { this(name, type, fields, FtScope.FORSETI); }

        String createSql() {
            return "CREATE INDEX `" + name + "` ON " + type + " (" + String.join(", ", fields) + ")"
                 + " FULL_TEXT METADATA {\"analyzer\":\"" + FT_ANALYZER + "\","
                 + "\"similarity\":\"" + FT_SIMILARITY + "\"}";
        }
    }

    /**
     * Реестр индексов сквозного поиска (ADR-LORE-033 D10): у типа РОВНО ОДИН
     * индекс на заголовок + все его *_md. Тогда ветка unionall — один вызов
     * SEARCH_INDEX, а не вызов на поле.
     *
     * Имена явные и стабильные: ранжирование доступно только через
     * SEARCH_INDEX('<имя>', …), а автоимена вида KnowADR_0_4240054376237
     * привязаны к внутренним id и меняются при пересоздании.
     *
     * Тела ADR/спек/задач/спринтов/ранбуков берём из *Hist: на самих вершинах
     * те же поля не объявлены, а в Hist объявлены и заполнены — так текст не
     * дублируется в индексах (ADR-LORE-033 D4/D10).
     */
    static final List<FtIndex> FT_INDEXES = List.of(
        new FtIndex("ftKnowADR",         "KnowADR",         List.of("name")),
        new FtIndex("ftKnowADRHist",     "KnowADRHist",     List.of("context_md", "decision_md", "consequences_md")),
        new FtIndex("ftKnowSpec",        "KnowSpec",        List.of("title")),
        new FtIndex("ftKnowSpecHist",    "KnowSpecHist",    List.of("content_md")),
        new FtIndex("ftKnowTask",        "KnowTask",        List.of("title")),
        new FtIndex("ftKnowTaskHist",    "KnowTaskHist",    List.of("note_md")),
        new FtIndex("ftKnowSprint",      "KnowSprint",      List.of("name", "context_md")),
        new FtIndex("ftKnowSprintHist",  "KnowSprintHist",  List.of("context_md", "outcome_md")),
        new FtIndex("ftKnowRunbook",     "KnowRunbook",     List.of("name")),
        new FtIndex("ftKnowRunbookHist", "KnowRunbookHist", List.of("content_md")),
        // content_md_en/ru — двуязычные тела доков: без них искалась только
        // основная колонка, а переводы в выдачу не попадали вовсе.
        // MDL-08 ч.2: легаси content_md снят (писателя нет, 0 из 460) — индекс пересоздаётся без него (Java-часть,
        // в checksum шага не входит; набор полей сверяется по имени и пересоздаётся при расхождении).
        new FtIndex("ftKnowDoc",         "KnowDoc",         List.of("title", "content_md_en", "content_md_ru")),
        new FtIndex("ftKnowDocHist",     "KnowDocHist",     List.of("content_md")),
        new FtIndex("ftKnowDecision",    "KnowDecision",    List.of("title", "body_md")),
        new FtIndex("ftKnowQuestion",    "KnowQuestion",    List.of("title", "body_md")),
        // PL-28: ftKnowFeature снят вместе с типом. Поля обеих прежних веток
        // собраны здесь — иначе после слияния перестал бы искаться либо
        // контекст корня, либо сценарий, и пропажу заметили бы не сразу.
        new FtIndex("ftKnowUseCase",     "KnowUseCase",
            List.of("title", "body_md", "context_md", "scenario_md", "acceptance_md")),
        new FtIndex("ftKnowPain",        "KnowPain",        List.of("title", "body_md")),
        new FtIndex("ftKnowGain",        "KnowGain",        List.of("title", "body_md", "metric_md")),
        new FtIndex("ftKnowJob",         "KnowJob",         List.of("title", "body_md")),
        new FtIndex("ftKnowActor",       "KnowActor",       List.of("name", "body_md")),
        // AC-03: описательные акторы уехали в свой тип — вместе с ними обязан
        // уехать и полнотекстовый индекс. Без этой строки поиск по акторам
        // перестал бы находить ровно те 10 вершин, ради которых развод и делался,
        // и выглядело бы это как «таких акторов нет», а не как «искали не там».
        new FtIndex("ftKnowProjectActor", "KnowProjectActor", List.of("name", "body_md")),
        new FtIndex("ftKnowRelease",     "KnowRelease",     List.of("description_md")),

        // ── V12: добор по аудиту схемы ──────────────────────────────────────
        // Тела релизов жили только на вершине; история описаний не искалась.
        new FtIndex("ftKnowReleaseHist", "KnowReleaseHist", List.of("description_md")),
        // Сводки по файлам репозитория — единственный текст, связывающий код с задачами.
        new FtIndex("ftKnowFile",        "KnowFile",        List.of("summary_md")),
        // Цели вех: короткие, но это формулировка «зачем», её ищут.
        new FtIndex("ftKnowMilestoneHist", "KnowMilestoneHist", List.of("goal_md")),
        // Реестр git-проектов: имя и описание.
        new FtIndex("ftKnowGitProject",  "KnowGitProject",  List.of("name", "description")),
        // Русские подписи словарей — по ним ищут «как это называется в интерфейсе».
        new FtIndex("ftKnowDictEntry",   "KnowDictEntry",   List.of("label_ru")),

        // ── BRAGI: другой продукт в той же БД, отсекается областью ───────────
        new FtIndex("ftBragiPublication", "BragiPublication", List.of("title", "topic", "main_text_md"), FtScope.BRAGI),
        new FtIndex("ftBragiRubric",      "BragiRubric",      List.of("name", "description"),            FtScope.BRAGI),
        new FtIndex("ftBragiPage",        "BragiPage",        List.of("title", "description"),           FtScope.BRAGI),
        new FtIndex("ftBragiChannel",     "BragiChannel",     List.of("rules_md"),                       FtScope.BRAGI),
        new FtIndex("ftBragiCompetitor",  "BragiCompetitor",  List.of("name"),                           FtScope.BRAGI),
        new FtIndex("ftBragiInsight",     "BragiInsight",     List.of("statement_md"),                   FtScope.BRAGI),
        new FtIndex("ftBragiVariant",     "BragiVariant",     List.of("text_md"),                        FtScope.BRAGI),

        // ── КАЧЕСТВО: прогоны рутин и рекомендации ──────────────────────────
        new FtIndex("ftClRoutineRun",    "ClRoutineRun",    List.of("detail_md"),          FtScope.QUALITY),
        new FtIndex("ftClRoutineOutput", "ClRoutineOutput", List.of("title", "content_md"),FtScope.QUALITY),
        new FtIndex("ftQGRecommendation","QGRecommendation",List.of("title", "body_md"),   FtScope.QUALITY),
        new FtIndex("ftQGJobTask",       "QGJobTask",       List.of("note_md"),            FtScope.QUALITY)
    );
}
