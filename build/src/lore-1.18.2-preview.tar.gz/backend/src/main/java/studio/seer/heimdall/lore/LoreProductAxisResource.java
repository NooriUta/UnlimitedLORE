package studio.seer.heimdall.lore;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.util.List;
import java.util.Map;

/**
 * Продуктовая ось: рёбра продукта (RM-P6, решение D-2026-LORE-PRODUCT-IS-OWN-ENTITY).
 *
 * <p><b>Почему отдельный класс, а не {@code LoreProductResource}.</b> Тот файл — это
 * продуктовый СЛОЙ ADR-LORE-022: Feature → UseCase → Actor → Pain/Gain/Job, то есть
 * «что и кому даёт ценность». Здесь — продуктовая ОСЬ: «что мы делаем и продаём»,
 * носитель дорожной карты. Два разных понятия на одном слове; держать их в одном
 * файле значит гарантировать, что через месяц кто-то поправит не то.
 *
 * <p><b>Сам продукт — запись справочника</b> {@code KnowDictEntry} с
 * {@code dict_type='product'}, заводится существующим {@code POST /lore/dict/entry}.
 * Отдельного write-эндпоинта для вершины здесь нет намеренно — второй способ
 * создать ту же запись и есть тот класс ошибок, который мы весь спринт разбираем.
 *
 * <p>Эндпоинт один, тип связи параметром {@code rel} — конвенция ADR-LORE-014
 * (link-collapse: {@code adr_link}, {@code sprint_link}, {@code task_link}).
 */
@Path("/lore")
public class LoreProductAxisResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreProductAxisResource.class);

    /** Роли компонента в продукте. Пусто = owner (кто делает). */
    private static final List<String> ROLES = List.of("owner", "consumer");
    /** WK-03 (decision:D-2026-LORE-SERVES-EDGE): как сервисный продукт служит другому. */
    private static final List<String> SERVES_KINDS = List.of("count", "sell", "support");

    public record ProductLinkRequest(
        String product_code,
        String rel,        // component | project | parent | serves
        String target_id,
        String role,       // rel=component|project: owner (умолчание) | consumer — WK-02 распространил роль на проект
        String action,     // add (умолчание) | remove
        String kind        // только для rel=serves: count | sell | support (WK-03)
    ) {}

    @POST
    @Path("product/link")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response productLink(ProductLinkRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.product_code() == null || req.rel() == null || req.target_id() == null)
            return badParams("product_code, rel and target_id required");

        final String rel = req.rel().trim().toLowerCase();
        final String action = req.action() == null || req.action().isBlank()
            ? "add" : req.action().trim().toLowerCase();
        if (!List.of("component", "project", "parent", "serves").contains(rel))
            return badParams("rel must be one of: component, project, parent, serves");
        // WK-03: у SERVES вид обязателен — пара продуктов может служить друг
        // другу несколькими способами сразу (продаём И поддерживаем), поэтому
        // уникальна тройка «откуда, куда, вид», а не пара.
        final String kind = req.kind() == null ? null : req.kind().trim().toLowerCase();
        if ("serves".equals(rel) && (kind == null || !SERVES_KINDS.contains(kind)))
            return badParams("rel=serves requires kind: " + String.join(", ", SERVES_KINDS));
        if (!List.of("add", "remove").contains(action))
            return badParams("action must be add or remove");

        final String code = req.product_code().trim();
        final String target = req.target_id().trim();
        if (!SAFE_ID.matcher(code).matches() || !SAFE_ID.matcher(target).matches())
            return badParams("product_code/target_id contain illegal characters");

        final String edgeType = switch (rel) {
            case "component" -> "IN_PRODUCT";
            case "parent"    -> "PARENT_PRODUCT";
            case "serves"    -> "SERVES";
            default          -> "BELONGS_TO_PROJECT";
        };
        // Направление рёбер выбрано по образцу уже существующих, чтобы обход
        // читался одинаково: IN_AREA идёт компонент → справочник, PARENT_OF идёт
        // ребёнок → родитель. Значит и здесь «принадлежащее» указывает на «того,
        // кому принадлежит», а состав читается через in().
        final String fromSql, toSql;
        switch (rel) {
            case "component" -> {
                fromSql = String.format(
                    "SELECT FROM LoreComponent WHERE component_id='%s'", target);
                toSql = productSelect(code);
            }
            case "parent" -> {
                if (code.equals(target))
                    return badParams("product cannot be its own parent");
                fromSql = productSelect(code);
                toSql = productSelect(target);
            }
            case "serves" -> {
                if (code.equals(target))
                    return badParams("product cannot serve itself");
                fromSql = productSelect(code);
                toSql = productSelect(target);
            }
            default -> {
                fromSql = productSelect(code);
                toSql = String.format(
                    "SELECT FROM KnowGitProject WHERE slug='%s'", target);
            }
        }

        try {
            // Обе стороны обязаны существовать. Пустая выборка в CREATE EDGE ...
            // TO (SELECT ...) НЕ падает — она молча не создаёт ребра, и вызывающий
            // получает ok:true на несделанной работе. Это записанный класс ошибок
            // (project_new/linked:false, spec_link), поэтому проверяем явно.
            if (countOf(productSelect(code)) == 0)
                return badParams("product '" + code + "' not found (dict_type='product')");
            final String targetSelect = "component".equals(rel)
                ? String.format("SELECT FROM LoreComponent WHERE component_id='%s'", target)
                : "parent".equals(rel) || "serves".equals(rel)
                    ? productSelect(target)
                    : String.format("SELECT FROM KnowGitProject WHERE slug='%s'", target);
            if (countOf(targetSelect) == 0)
                return badParams("target '" + target + "' not found for rel=" + rel);

            // Цикл в дереве продуктов. Прямое «сам себе родитель» отсечено выше,
            // но A→B→A так не ловится, а последствие хуже отказа: обход вверх
            // не завершается, и читатель либо висит, либо обрывается по счётчику
            // глубины и молча отдаёт неполную цепочку. Тот же гвард есть у
            // sprint_link(rel="dep") — здесь он по той же причине.
            if ("parent".equals(rel) && "add".equals(action) && isAncestor(code, target))
                return badParams("цикл: продукт '" + target + "' уже находится ниже '"
                    + code + "' в дереве продуктов");

            // Снимаем существующее ребро в любом случае: для add это делает вызов
            // идемпотентным (иначе повтор плодит дубли — CREATE EDGE их не гасит),
            // для remove это и есть работа. DELETE EDGE в грамматике ArcadeDB
            // отсутствует, поэтому удаляем строки самого типа ребра по @rid.
            //
            // КАРДИНАЛЬНОСТЬ РАЗНАЯ, и от неё зависит, что именно снимать.
            //   component, project — многие-ко-многим. Продукт живёт в нескольких
            //     репозиториях, а монорепо держит несколько продуктов; компонент
            //     бывает в двух продуктах с разными ролями (HARPA: делает AIDA,
            //     использует BALDR). Снимаем ТОЛЬКО эту пару, соседние связи не
            //     трогаем.
            //   parent — 0..1. Родитель у продукта один. Снимать только пару здесь
            //     НЕДОСТАТОЧНО: добавление ДРУГОГО родителя оставило бы прежнего,
            //     и у продукта молча стало бы два. Обход `out('PARENT_PRODUCT')`
            //     отдал бы список, а читатель, берущий [0], показал бы один
            //     случайный — расхождение без признака ошибки.
            //   Поэтому для parent снимаем ВСЕ исходящие, как relinkAreaEdge
            //   делает для области (там та же кардинальность 0..1).
            // RM-P15: прежний родитель читается ДО сноса, а не выводится из числа
            // снятых рёбер. После dropAllParents «сменили родителя» и «переставили
            // того же» выглядят одинаково — снято одно ребро в обоих случаях, — и
            // ответ описывал повтор как изменение. Вызывающий, который ведёт
            // журнал или сверяет раскладку, насчитал бы правки там, где ничего не
            // менялось. ADR-LORE-043: исход выводится из ФАКТА, а не из того,
            // какие команды выполнились.
            final String prevParent = "parent".equals(rel) ? currentParent(code) : null;

            // Роль проверяется ДО сноса: раньше неверная роль на add снимала
            // существующее ребро и только потом отвечала 400 — связь пропадала
            // на отклонённом вызове.
            final String roleValue = req.role() == null || req.role().isBlank()
                ? "owner" : req.role().trim().toLowerCase();
            // WK-02 (decision:D-2026-LORE-PRODUCT-PROJECT-ROLE): роль живёт и на
            // связи продукт → проект — owner развивает, consumer пользуется.
            final boolean hasRole = "component".equals(rel) || "project".equals(rel);
            if ("add".equals(action) && hasRole && !ROLES.contains(roleValue))
                return badParams("role must be one of: " + String.join(", ", ROLES));

            // DBR-17: пара читается ДО записи. Повтор той же связи раньше снимал и
            // ставил ребро заново и отвечал «added» — исход описывал выполненные
            // команды, а не произошедшее.
            final List<Map<String, Object>> pairBefore = pairRows(edgeType, rel, code, target, kind);
            final Object prevRole = pairBefore.isEmpty() ? null : pairBefore.get(0).get("role");

            Map<String, Object> body = new java.util.LinkedHashMap<>();
            body.put("ok", true);
            body.put("product_code", code);
            body.put("rel", rel);
            body.put("target_id", target);

            if ("add".equals(action)) {
                boolean same = "parent".equals(rel) ? target.equals(prevParent)
                    : !pairBefore.isEmpty() && (!hasRole || roleValue.equals(prevRole));
                if (same) {
                    body.put("action", "already_linked");
                    if (hasRole) body.put("role", roleValue);
                    if (kind != null) body.put("kind", kind);
                    if ("parent".equals(rel)) body.put("previous_parent_removed", false);
                    body.put("outcome", LoreOutcome.UNCHANGED);
                    body.put("hint", "связь уже была — повторять вызов не нужно");
                    return noStore(Response.ok(body));
                }
            }

            int removed = "parent".equals(rel)
                ? dropAllParents(code)
                : dropEdges(edgeType, rel, code, target, kind);

            if ("remove".equals(action)) {
                body.put("action", "removed");
                body.put("edges_removed", removed);
                boolean gone = pairRows(edgeType, rel, code, target, kind).isEmpty();
                body.put("outcome", !gone ? LoreOutcome.NOOP
                    : pairBefore.isEmpty() ? LoreOutcome.UNCHANGED : LoreOutcome.DELETED);
                if (!gone) body.put("reason", "DELETE выполнен, но ребро " + edgeType + " осталось");
                else if (pairBefore.isEmpty()) body.put("hint", "такой связи не было — снимать нечего");
                return noStore(Response.ok(body));
            }

            final String set = hasRole
                ? String.format(" SET role='%s'", roleValue)
                : "serves".equals(rel) ? String.format(" SET kind='%s'", kind) : "";
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                String.format("CREATE EDGE %s FROM (%s) TO (%s)%s", edgeType, fromSql, toSql, set),
                Map.of())).await().indefinitely();

            body.put("action", "added");
            if (hasRole) body.put("role", roleValue);
            if (kind != null) body.put("kind", kind);
            // Для parent исходов ТРИ, а не два, и они обязаны быть различимы.
            // «Ничего не изменилось», «сменили родителя» и «поставили первого» —
            // разные события: смена молча переносит целое поддерево продуктов,
            // а повтор не переносит ничего. Прежний родитель называется по
            // имени: без него «сменили» не говорит, с чего именно.
            boolean replaced = "parent".equals(rel) ? prevParent != null : !pairBefore.isEmpty();
            if ("parent".equals(rel)) {
                body.put("previous_parent_removed", prevParent != null);
                if (prevParent != null) body.put("previous_parent", prevParent);
            } else if (replaced) {
                body.put("previous_role", prevRole);
            }
            if (pairRows(edgeType, rel, code, target, kind).isEmpty()) {
                body.put("outcome", LoreOutcome.NOOP);
                body.put("reason", "ребро " + edgeType + " не создано: " + code + " или " + target + " не найден(ы)");
            } else {
                body.put("outcome", replaced ? LoreOutcome.UPDATED : LoreOutcome.CREATED);
            }
            return noStore(Response.ok(body));
        } catch (Exception e) {
            LOG.warnf("[LORE PRODUCT LINK] %s %s %s→%s: %s", action, rel, code, target, e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    private static String productSelect(String code) {
        return String.format(
            "SELECT FROM KnowDictEntry WHERE dict_type='product' AND code='%s'", code);
    }

    private long countOf(String selectSql) {
        List<Map<String, Object>> rows = ingestService.queryPublic(
            "SELECT count(*) AS n FROM (" + selectSql + ")", Map.of());
        if (rows.isEmpty()) return 0;
        Object n = rows.get(0).get("n");
        return n instanceof Number num ? num.longValue() : 0;
    }

    /**
     * Лежит ли {@code candidate} в поддереве {@code root} — то есть станет ли
     * ребро {@code root → candidate} циклом.
     *
     * <p>Идём ВНИЗ от корня по {@code in('PARENT_PRODUCT')}, а не вверх от
     * кандидата: вверх пришлось бы идти по ещё не существующему ребру. Счётчик
     * глубины — страховка на случай, если цикл уже лежит в данных: обход по
     * испорченному графу иначе не вернётся.
     */
    private boolean isAncestor(String root, String candidate) {
        java.util.Set<String> seen = new java.util.HashSet<>();
        java.util.Deque<String> queue = new java.util.ArrayDeque<>();
        queue.add(root);
        int guard = 0;
        while (!queue.isEmpty() && guard++ < 200) {
            String cur = queue.poll();
            if (!seen.add(cur)) continue;
            if (cur.equals(candidate) && !cur.equals(root)) return true;
            try {
                List<Map<String, Object>> rows = ingestService.queryPublic(
                    "SELECT in('PARENT_PRODUCT').code AS kids FROM KnowDictEntry "
                    + "WHERE dict_type='product' AND code=:code",
                    Map.of("code", cur));
                if (!rows.isEmpty() && rows.get(0).get("kids") instanceof List<?> kids) {
                    for (Object k : kids) if (k != null) queue.add(String.valueOf(k));
                }
            } catch (Exception e) {
                // Не смогли проверить — не то же самое, что «цикла нет». Считаем
                // цикл возможным и отказываем: ложный отказ чинится повтором,
                // ложное разрешение — испорченным деревом, которое молчит.
                LOG.warnf("[LORE PRODUCT LINK] cycle check %s→%s failed: %s",
                    root, candidate, e.getMessage());
                return true;
            }
        }
        return false;
    }

    /**
     * Код нынешнего родителя продукта, либо {@code null}, если его нет.
     *
     * <p>Читается ДО сноса рёбер: после {@link #dropAllParents} оба случая —
     * «был другой родитель» и «был тот же» — выглядят одинаково, и различить их
     * уже нечем.
     *
     * <p>Сверка не удалась — отвечаем {@code null}, то есть «родителя не было».
     * Врать в другую сторону нельзя: ложное «был такой же» превратило бы
     * настоящую смену родителя в «ничего не изменилось», а смена переносит
     * поддерево.
     */
    private String currentParent(String code) {
        try {
            List<Map<String, Object>> rows = ingestService.queryPublic(
                "SELECT out('PARENT_PRODUCT').code AS parent FROM KnowDictEntry "
                + "WHERE dict_type='product' AND code=:code",
                Map.of("code", code));
            if (rows.isEmpty()) return null;
            Object p = rows.get(0).get("parent");
            if (p instanceof List<?> l) p = l.isEmpty() ? null : l.get(0);
            return p == null ? null : String.valueOf(p);
        } catch (Exception e) {
            LOG.warnf("[LORE PRODUCT LINK] current parent of %s unreadable: %s", code, e.getMessage());
            return null;
        }
    }

    /**
     * Снять ВСЕ исходящие {@code PARENT_PRODUCT} у продукта — родитель один.
     *
     * <p>Отдельно от {@link #dropEdges}, потому что там фильтр по паре, а здесь
     * нужен фильтр только по источнику: иначе смена родителя оставит прежнего.
     * Возвращает число снятых, чтобы вызывающий видел, была ли смена (1) или
     * первичная привязка (0) — разница между «переставили» и «поставили» иначе
     * из ответа не читается.
     */
    private int dropAllParents(String code) {
        int n = 0;
        try {
            List<Map<String, Object>> rows = ingestService.queryPublic(
                "SELECT @rid AS rid FROM PARENT_PRODUCT "
                + "WHERE @out.code=:code AND @out.dict_type='product'",
                Map.of("code", code));
            for (Map<String, Object> row : rows) {
                Object rid = row.get("rid");
                if (rid == null) continue;
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "DELETE FROM PARENT_PRODUCT WHERE @rid=" + rid)).await().indefinitely();
                n++;
            }
        } catch (Exception e) {
            LOG.warnf("[LORE PRODUCT LINK] drop parents of %s: %s", code, e.getMessage());
        }
        return n;
    }

    /**
     * Рёбра между парой (с ролью — для IN_PRODUCT). Сбой чтения летит наверх:
     * «не смогли проверить» нельзя выдать за «связи нет» (DBR-17).
     */
    private List<Map<String, Object>> pairRows(String edgeType, String rel, String code, String target, String kind) {
        return ingestService.queryPublic(
            "SELECT @rid AS rid" + ("component".equals(rel) || "project".equals(rel) ? ", role" : "") + " FROM " + edgeType
            + " WHERE " + pairWhere(rel, code, target, kind), Map.of());
    }

    private static String pairWhere(String rel, String code, String target, String kind) {
        return switch (rel) {
            case "serves" -> String.format(
                "@out.code='%s' AND @out.dict_type='product' AND @in.code='%s' AND @in.dict_type='product' AND kind='%s'",
                code, target, kind);
            case "component" -> String.format(
                "@out.component_id='%s' AND @in.code='%s' AND @in.dict_type='product'", target, code);
            case "parent" -> String.format(
                "@out.code='%s' AND @out.dict_type='product' AND @in.code='%s'", code, target);
            default -> String.format(
                "@out.code='%s' AND @out.dict_type='product' AND @in.slug='%s'", code, target);
        };
    }

    /**
     * Снять рёбра между конкретной парой. Фильтр по {@code @out}/{@code @in} —
     * запрос ПО ТИПУ РЕБРА, а не обходом: обход отдал бы список и сравнение с
     * ним через [0] показало бы многосвязное под одним случайным значением.
     */
    private int dropEdges(String edgeType, String rel, String code, String target, String kind) {
        String where = pairWhere(rel, code, target, kind);
        int n = 0;
        try {
            List<Map<String, Object>> rows = ingestService.queryPublic(
                "SELECT @rid AS rid FROM " + edgeType + " WHERE " + where, Map.of());
            for (Map<String, Object> row : rows) {
                Object rid = row.get("rid");
                if (rid == null) continue;
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "DELETE FROM " + edgeType + " WHERE @rid=" + rid)).await().indefinitely();
                n++;
            }
        } catch (Exception e) {
            LOG.warnf("[LORE PRODUCT LINK] drop %s %s→%s: %s", edgeType, code, target, e.getMessage());
        }
        return n;
    }
}
