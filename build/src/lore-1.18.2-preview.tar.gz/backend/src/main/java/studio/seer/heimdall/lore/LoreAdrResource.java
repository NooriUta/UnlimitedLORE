package studio.seer.heimdall.lore;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * KnowADR write endpoints (create/upsert, link, component/depends_on/
 * supersedes/tag point-edits, rename, delete), split out of AidaLoreResource
 * (B2). The generic status dispatch's direct (non-SCD2) ADR status setter
 * lives in LoreStatusResource, not here — it's wired into the cross-entity
 * status engine, not ADR-specific CRUD. Shares infra via LoreResourceBase.
 */
@Path("/lore")
public class LoreAdrResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreAdrResource.class);

    @jakarta.inject.Inject
    LoreHashStamper hashStamper; // SV-10: content_hash на открытой Hist-строке после записи тел

    public record AdrCreateRequest(String adr_id, String name, String status, String date_created,
        String component_id, String context_md, String decision_md, String consequences_md,
        List<String> depends_on_ids, List<String> supersedes_ids,
        List<String> component_ids, List<String> tags, String file_path,
        // LH-02: when true, a body edit CLOSES the current open hist row and opens a
        // fresh one (SCD2 close-open) instead of amending in place — so the previous
        // edition is preserved. Default (null/false) keeps the amend-in-place behaviour.
        Boolean checkpoint,
        // ADR-LORE-047 A3 / S5-08: версия записи паспорта (record.version); не совпала —
        // 409 VERSION_CONFLICT. Тело ADR — три раздела, каждый своим запросом, поэтому
        // одновременная правка двух разделов — самый вероятный конфликт.
        String expected_version) {}

    // ── Write-path: create / upsert KnowADR ──────────────────────────────────

    /** Прежний upsert без режима — для внутренних вызовов (LoreTidyResource). */
    public Response createAdr(AdrCreateRequest req, String role) {
        return createAdr(req, role, null);
    }

    @POST
    @Path("adr")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createAdr(AdrCreateRequest req,
                              @HeaderParam("X-Seer-Role") String role,
                              @jakarta.ws.rs.QueryParam("mode") String mode) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.adr_id() == null || req.adr_id().isBlank())
            return badParams("adr_id required");
        if (!SAFE_ID.matcher(req.adr_id()).matches())
            return badParams("adr_id contains illegal characters");
        Response stale = versionConflict("adr", req.adr_id(), req.expected_version());
        if (stale != null) return stale;
        Response taken = createOnly("adr", req.adr_id(), mode);   // MT-MCP-TRUTH п.1: ?mode=create
        if (taken != null) return taken;
        try {
            String now  = Instant.now().toString();
            String nsid = UUID.randomUUID().toString();

            // Step 1: upsert KnowADR vertex — LH-44: only set status when provided; for
            // new ADRs default to PROPOSED, for existing ones never overwrite with null.
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> existingAdr = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "SELECT status FROM KnowADR WHERE adr_id=:id",
                    Map.of("id", req.adr_id())))
                .await().indefinitely().result();
            boolean isNewAdr = existingAdr == null || existingAdr.isEmpty();
            // начальный статус типа по модели (16.11.2026; правило владелицы 19.11.2026) — только у нового ADR
            final CreateDefaultStatus.Pick statusPick = isNewAdr ? CreateDefaultStatus.pick("adr", req.status()) : null;
            String resolvedStatus = (req.status() != null && !req.status().isBlank())
                ? req.status() : (statusPick != null ? statusPick.value() : null);
            // LH-44: date_created/component_id only SET when provided (or on first
            // insert) — previously a partial amend call with neither field would reset
            // date_created to today and null out component_id. Found alongside the
            // context_md/decision_md/consequences_md bug fixed above, 2026-07-02.
            StringBuilder upsertSql = new StringBuilder("UPDATE KnowADR SET adr_id=:adr_id, name=:name");
            Map<String, Object> upsertP = mapOfNullable("adr_id", req.adr_id(), "name", req.name());
            // S2-10: у НОВОГО ADR рядом с датой — полный ISO-момент создания, если он
            // известен (CreationMoment.resolve); правка существующего его не трогает.
            if (isNewAdr) {
                CreationMoment.Resolved cm = CreationMoment.resolve(req.date_created(), Instant.parse(now));
                upsertSql.append(", date_created=:date_created");
                upsertP.put("date_created", cm.date());
                if (cm.moment() != null) {
                    upsertSql.append(", created_at=:created_at");
                    upsertP.put("created_at", cm.moment());
                }
            } else {
                if (req.date_created() != null) {
                    upsertSql.append(", date_created=:date_created");
                    upsertP.put("date_created", req.date_created());
                }
                // Аудит времени 10.11 (класс S4-04): правка существующего ADR без checkpoint
                // пишет тело в открытую версию на месте — момент правки на вершине; changed_at
                // среза adrs — максимум с открытой версией. У нового ADR первая версия и есть
                // момент заведения — отметка не нужна.
                upsertSql.append(", updated_at=:upd");
                upsertP.put("upd", Instant.now().toString());
            }
            if (req.component_id() != null) {
                upsertSql.append(", component_id=:component_id");
                upsertP.put("component_id", req.component_id());
            }
            if (req.file_path() != null) {
                upsertSql.append(", file_path=:file_path");
                upsertP.put("file_path", req.file_path());
            }
            upsertSql.append(" UPSERT WHERE adr_id=:adr_id");
            writeClient.command(db, basicAuth(),
                new LoreCommandClient.LoreCommand("sql", upsertSql.toString(), upsertP))
                .await().indefinitely();

            // S2-13: статус — НЕ полем вершины, а новой версией истории через единый
            // сервис (у нового ADR это и есть его первая версия; тела ниже лягут в
            // неё же правкой на месте). Тот же статус повторно версию не открывает.
            Object prevStatus = isNewAdr ? null : existingAdr.get(0).get("status");
            if (resolvedStatus != null && (isNewAdr || prevStatus == null
                    || !resolvedStatus.equalsIgnoreCase(String.valueOf(prevStatus)))) {
                StatusHistoryService.Outcome so = StatusHistoryService.transition(
                    statusDb(), "adr", req.adr_id(), null, resolvedStatus, changeAuthor());
                if (so instanceof StatusHistoryService.Outcome.Conflict c)
                    throw new Scd2Guard.ConflictException(c.detail(), c.current());
            }

            // Step 2: check for an existing open SCD2 hist row
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> histRows = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "SELECT @rid as rid, state_uid, context_md, decision_md, consequences_md"
                        + StatusHistoryService.STATUS_FIELDS_SELECT + " FROM KnowADRHist " +
                    "WHERE in('HAS_STATE').adr_id[0] = :id AND valid_to IS NULL LIMIT 1",
                    Map.of("id", req.adr_id())))
                .await().indefinitely().result();

            boolean histCreated;
            if (histRows != null && !histRows.isEmpty()) {
                // Step 3a: update body fields on the existing open hist row — SAME null-safe
                // pattern as status above (LH-44): only SET fields that were actually provided.
                // Previously this unconditionally SET context_md/decision_md/consequences_md to
                // whatever was passed, including null — a partial amend call (e.g. only
                // decision_md to fix a typo) would silently WIPE the other two sections. Found
                // 2026-07-02 while wiring up an "amend ADR body" workflow.
                //
                // Match by @rid, not state_uid: 59/83 open KnowADRHist rows (bulk-imported
                // pre-MCP, e.g. ADR-HND-STMTGEOID-STABILITY, ADR-HND-019/021, ADR-SHT-001)
                // have state_uid=null. WHERE state_uid=:sid with a null business key bound
                // String.valueOf(null)="null" — matched zero rows, so every amend call on
                // those ADRs silently no-op'd with no error. @rid is always non-null/unique.
                // Found 2026-07-02 debugging why body edits weren't landing on real ADRs.
                Object rid = histRows.get(0).get("rid");
                Object existingSid = histRows.get(0).get("state_uid");
                boolean wantCheckpoint = Boolean.TRUE.equals(req.checkpoint())
                    && (req.context_md() != null || req.decision_md() != null || req.consequences_md() != null);
                if (wantCheckpoint) {
                    // LH-02: close the open row + open a fresh one, carrying forward the
                    // sections not being changed — the previous edition survives as a closed row.
                    Map<String, Object> cp = new java.util.HashMap<>();
                    cp.put("rid", rid); cp.put("nsid", nsid); cp.put("now", now); cp.put("id", req.adr_id());
                    cp.put("ctx", req.context_md()      != null ? req.context_md()      : histRows.get(0).get("context_md"));
                    cp.put("dec", req.decision_md()     != null ? req.decision_md()     : histRows.get(0).get("decision_md"));
                    cp.put("con", req.consequences_md() != null ? req.consequences_md() : histRows.get(0).get("consequences_md"));
                    // S2-09: закрыть, только если версия ЕЩЁ открыта; иначе выход до записи и 409.
                    cp.put("oldrid", rid);
                    changeAuthor().bind(cp); // S2-12
                    // S2-13: правка тела статус не меняет — он переносится в новую версию.
                    String carryStatus = StatusHistoryService.carryStatusSet(histRows.get(0), cp);
                    Object cpRes = writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sqlscript",
                        Scd2Guard.guardedClose("KnowADR", "KnowADRHist", false) +
                        "INSERT INTO KnowADRHist SET state_uid=:nsid, valid_from=:now, " +
                        "context_md=:ctx, decision_md=:dec, consequences_md=:con" + carryStatus + ChangeAuthor.SET_SQL + ";" +
                        "CREATE EDGE HAS_STATE FROM (SELECT FROM KnowADR WHERE adr_id=:id) " +
                        "TO (SELECT FROM KnowADRHist WHERE state_uid = :nsid AND in('HAS_STATE').size() = 0);", cp)).await().indefinitely().result();
                    if (Scd2Guard.isConflict(cpRes))
                        throw new Scd2Guard.ConflictException("adr '" + req.adr_id()
                            + "': the body version read was closed by a concurrent write — re-read and retry", Map.of());
                    histCreated = true;
                } else {
                // Step 3a: update body fields on the existing open hist row (amend-in-place) — SAME
                // null-safe pattern as status above (LH-44): only SET fields actually provided.
                StringBuilder histSql = new StringBuilder("UPDATE KnowADRHist SET ");
                Map<String, Object> histUpdP = new java.util.HashMap<>();
                histUpdP.put("rid", rid);
                boolean first = true;
                if (existingSid == null) {
                    // Backfill the missing business key while we're touching this row anyway.
                    histSql.append("state_uid=:nsid");
                    histUpdP.put("nsid", nsid);
                    first = false;
                }
                if (req.context_md() != null)      { histSql.append(first ? "" : ", ").append("context_md=:ctx");       histUpdP.put("ctx", req.context_md());      first = false; }
                if (req.decision_md() != null)     { histSql.append(first ? "" : ", ").append("decision_md=:dec");      histUpdP.put("dec", req.decision_md());     first = false; }
                if (req.consequences_md() != null) { histSql.append(first ? "" : ", ").append("consequences_md=:con");  histUpdP.put("con", req.consequences_md()); first = false; }
                if (!first) {
                    histSql.append(" WHERE @rid=:rid");
                    // MT-MCP-TRUTH Б11: открытую версию прочитали, запись её не нашла — тело не легло, 409
                    if (WriteCount.missed(writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                            histSql.toString(), histUpdP)).await().indefinitely()))
                        throw new Scd2Guard.ConflictException("adr '" + req.adr_id()
                            + "': the open body version disappeared between read and write — nothing written, re-read and retry", Map.of());
                }
                // else: no body fields provided at all (e.g. a pure status/edges-only call) — leave the hist row untouched.
                histCreated = false;
                }
            } else {
                Map<String, Object> histP = mapOfNullable(
                    "ctx", req.context_md(),
                    "dec", req.decision_md(),
                    "con", req.consequences_md());
                // Step 3b: create the initial open hist row + HAS_STATE edge.
                // A1: one atomic sqlscript so a failed edge leaves no orphan hist row.
                histP.put("nsid", nsid);
                histP.put("now",  now);
                histP.put("id",   req.adr_id());
                changeAuthor().bind(histP); // S2-12
                // S2-13: первая версия существующего ADR без истории несёт его текущий
                // статус — известный с этого момента, не раньше.
                String firstStatus = "";
                if (prevStatus != null) {
                    histP.put("st_raw", String.valueOf(prevStatus));
                    histP.put("st_cat", LoreStatusCategory.of("adr", prevStatus));
                    firstStatus = ", status_raw=:st_raw, status_category=:st_cat, status_known_from=:now";
                }
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sqlscript",
                    "INSERT INTO KnowADRHist SET state_uid=:nsid, valid_from=:now, " +
                    "context_md=:ctx, decision_md=:dec, consequences_md=:con" + firstStatus + ChangeAuthor.SET_SQL + ";" +
                    "CREATE EDGE HAS_STATE FROM (SELECT FROM KnowADR WHERE adr_id=:id) " +
                    "TO (SELECT FROM KnowADRHist WHERE state_uid = :nsid AND in('HAS_STATE').size() = 0);",
                    histP)).await().indefinitely();
                histCreated = true;
            }

            // Step 4: replace DEPENDS_ON edges
            // MDL-13: DEPENDS_ON историчная — набор заменяется закрытием лишних (valid_to) и добавлением
            // недостающих (valid_from); оставшиеся в наборе связи не трогаются, история не множится.
            if (req.depends_on_ids() != null) {
                java.util.Set<String> want = new java.util.LinkedHashSet<>();
                for (String dep : req.depends_on_ids()) if (dep != null && !dep.isBlank()) want.add(dep.trim());
                try {
                    List<Map<String, Object>> cur = ingestService.queryPublic(
                        "SELECT @rid AS r, @in.adr_id AS dep FROM DEPENDS_ON WHERE @out.adr_id = :id AND valid_to IS NULL",
                        Map.of("id", req.adr_id()));
                    java.util.Set<String> have = new java.util.HashSet<>();
                    for (Map<String, Object> c : cur) {
                        String dep = c.get("dep") == null ? null : String.valueOf(c.get("dep"));
                        if (dep != null && want.contains(dep)) { have.add(dep); continue; }
                        writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                            closeOrDeleteEdge("DEPENDS_ON", String.valueOf(c.get("r"))))).await().indefinitely();
                    }
                    want.removeAll(have);
                } catch (Exception ex) {
                    LOG.warnf("[LORE ADR DEPENDS_ON DEL] %s: %s", req.adr_id(), ex.getMessage());
                }
                for (String dep : want) {
                    try {
                        writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                            "CREATE EDGE DEPENDS_ON " +
                            "FROM (SELECT FROM KnowADR WHERE adr_id = :id) " +
                            "TO   (SELECT FROM KnowADR WHERE adr_id = :dep) SET valid_from = '" + java.time.Instant.now() + "'",
                            Map.of("id", req.adr_id(), "dep", dep))).await().indefinitely();
                    } catch (Exception ex) {
                        LOG.warnf("[LORE ADR DEPENDS_ON] %s → %s: %s", req.adr_id(), dep, ex.getMessage());
                    }
                }
            }

            // Step 5: replace SUPERSEDES edges
            if (req.supersedes_ids() != null) {
                try {
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM (SELECT expand(outE('SUPERSEDES')) FROM KnowADR WHERE adr_id = :id)",
                        Map.of("id", req.adr_id()))).await().indefinitely();
                } catch (Exception ex) {
                    LOG.warnf("[LORE ADR SUPERSEDES DEL] %s: %s", req.adr_id(), ex.getMessage());
                }
                for (String sup : req.supersedes_ids()) {
                    if (sup == null || sup.isBlank()) continue;
                    try {
                        writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                            "CREATE EDGE SUPERSEDES " +
                            "FROM (SELECT FROM KnowADR WHERE adr_id = :id) " +
                            "TO   (SELECT FROM KnowADR WHERE adr_id = :sup)",
                            Map.of("id", req.adr_id(), "sup", sup))).await().indefinitely();
                    } catch (Exception ex) {
                        LOG.warnf("[LORE ADR SUPERSEDES] %s → %s: %s", req.adr_id(), sup, ex.getMessage());
                    }
                }
            }

            // Step 6: replace BELONGS_TO edges (component_ids wins over legacy single component_id)
            List<String> compIds = (req.component_ids() != null && !req.component_ids().isEmpty())
                ? req.component_ids()
                : (req.component_id() != null && !req.component_id().isBlank()
                    ? List.of(req.component_id()) : null);
            // DBR-04: порядок «сначала создать, потом удалить лишние» и СЧЁТ
            // фактически записанного. Прежняя редакция сносила все рёбра, потом
            // создавала новые, а падение каждого шага уходило в WARN — худший
            // случай (DELETE прошёл, CREATE упал) оставлял ADR вообще без
            // компонентов при ответе ok:true. Сбой должен оставлять дубли, а не
            // пустоту: дубли чинятся, потеря нет.
            List<String> compFailed = new ArrayList<>();
            if (compIds != null) {
                compFailed = syncEdges("BELONGS_TO", "LoreComponent", "component_id",
                    req.adr_id(), compIds);
            }

            // Step 7: replace TAGGED_WITH edges (upsert KnowTag on the fly)
            List<String> tagFailed = new ArrayList<>();
            if (req.tags() != null) {
                // Вершины тегов заводим ДО синхронизации рёбер: CREATE EDGE с
                // пустым TO — тихий no-op, и без апсерта тег молча не привязался
                // бы, а ответ остался бы успешным.
                for (String tag : req.tags()) {
                    if (tag == null || tag.isBlank()) continue;
                    try {
                        writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                            "UPDATE KnowTag SET tag_id=:tag UPSERT WHERE tag_id=:tag",
                            Map.of("tag", tag))).await().indefinitely();
                    } catch (Exception ex) {
                        LOG.warnf("[LORE ADR TAG UPSERT] %s → %s: %s", req.adr_id(), tag, LoreUpstream.detail(ex));
                    }
                }
                tagFailed = syncEdges("TAGGED_WITH", "KnowTag", "tag_id", req.adr_id(), req.tags());
            }

            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true); out.put("adr_id", req.adr_id());
            out.put("hist_created", histCreated);
            // Explicit body signal — hist_created:false alone reads ambiguously
            // ("did my body land?"); body_written says whether any of the three
            // body sections was actually persisted this call.
            out.put("body_written", req.context_md() != null
                || req.decision_md() != null || req.consequences_md() != null);
            // MD-AUTOLINK (spec:SPEC-LORE-MD-INLINE-REF §7): упоминания в записанных разделах →
            // рёбра однозначных авто-пар (ADR → компонент). ПОСЛЕ шага 6: syncEdges снимает
            // BELONGS_TO вне component_ids, и авто-ребро, поставленное раньше, ушло бы.
            if (req.context_md() != null || req.decision_md() != null || req.consequences_md() != null)
                out.put("mentions", autoLinkMentions("adr", req.adr_id(), false,
                    req.context_md(), req.decision_md(), req.consequences_md()));
            // ADR-LORE-020: реестр ОВ — отдельная сущность (KnowQuestion), а не
            // markdown-раздел. Тело с «Открытыми вопросами» = вопросы, которые
            // никто не найдёт фильтром, не увидит просроченными и не закроет
            // решением. Ловим на записи и подсказываем вызывающему (агенту).
            // DBR-04: несделанная работа названа в ответе. Раньше провалившаяся
            // привязка уходила в WARN, а вызывающий видел ok:true и считал, что
            // связи на месте.
            if (!compFailed.isEmpty()) out.put("components_failed", compFailed);
            if (!tagFailed.isEmpty())  out.put("tags_failed", tagFailed);

            // Вердикт полноты (ADR-LORE-039): линтер уже существовал, но звался
            // только из self-check — то есть постфактум и лишь если кто-то
            // откроет срез. Здесь он приходит в момент записи, пока автор ещё
            // держит ADR в голове. Advisory: на запись не влияет.
            WorkQuality.Result quality = adrQuality(req.adr_id());
            if (quality != null) out.put("quality", WorkQuality.compact(quality));

            String qHint = questionsInBodyHint(req);
            if (qHint != null) out.put("hint", qHint);
            if (!compFailed.isEmpty() || !tagFailed.isEmpty()) {
                out.put("hint", "часть привязок НЕ записана — проверьте, что цели существуют "
                    + "(несуществующая цель даёт тихий no-op, а не ошибку)");
            }
            hashStamper.stampOpenHist("KnowADRHist", "KnowADR", "adr_id", req.adr_id());
            CreateDefaultStatus.report(out, statusPick);
            return noStore(Response.ok(out));
        } catch (Scd2Guard.ConflictException c) {
            return c.response(); // S2-09
        } catch (Exception e) {
            LOG.warnf("[LORE ADR CREATE] %s: %s", req.adr_id(), e.getMessage());
            if (Scd2Guard.isConcurrentModification(e))
                return Scd2Guard.conflict("adr '" + req.adr_id() + "': concurrent write — re-read and retry", Map.of());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── Write-path: ADR ↔ sprint/release links, rename, delete ──────────────
    /**
     * Вердикт полноты ADR (ADR-LORE-039). Факты берутся из графа ПОСЛЕ записи
     * рёбер — то есть судится сохранённое состояние, а не присланный запрос:
     * иначе провалившаяся привязка выглядела бы выполненной.
     *
     * <p>Тела читаются с ОТКРЫТОЙ Hist-строки (valid_to IS NULL), а не с
     * вершины: они живут в истории, и на вершине их попросту нет.
     *
     * <p>Ошибка сборки вердикта не роняет ответ: запись уже состоялась и была
     * тем, что просил вызывающий, — по образцу taskQuality/sprintQuality.
     */
    // Факты собирает LoreQualityFacts — один источник на путь записи и
    // батч-API. Своя копия проекции здесь была причиной трёх разошедшихся
    // прочтений за один день (status vs status_raw, поле не из модели,
    // release_id вместо release_uid).
    @jakarta.inject.Inject
    LoreQualityFacts qualityFacts;

    private WorkQuality.Result adrQuality(String adrId) {
        return qualityFacts.forOne(LoreQualityFacts.Kind.ADR, adrId);
    }

    public record AdrLinkRequest(String adr_id, String sprint_id, String release_id,
                                 String git_project, String action) {}
    public record AdrRenameRequest(String adr_id, String new_adr_id) {}
    public record AdrDeleteRequest(String adr_id) {}

    @POST
    @Path("adr/link")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkAdr(AdrLinkRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.adr_id() == null || req.adr_id().isBlank())
            return badParams("adr_id required");
        boolean toSprint  = req.sprint_id()  != null && !req.sprint_id().isBlank();
        boolean toRelease = req.release_id() != null && !req.release_id().isBlank();
        if (toSprint == toRelease)
            return badParams("exactly one of sprint_id / release_id required");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            if (toSprint) {
                if (remove) {
                    // Проба ДО удаления: после него она бессмысленна — ребра нет в обоих
                    // случаях, и «снято» стало бы утверждением без факта.
                    boolean had = edgeExists("IMPLEMENTED_IN", "adr_id", req.adr_id(), "sprint_id", req.sprint_id());
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM (SELECT expand(outE('IMPLEMENTED_IN')) FROM KnowADR WHERE adr_id=:id) " +
                        "WHERE @in.sprint_id = :sid",
                        Map.of("id", req.adr_id(), "sid", req.sprint_id()))).await().indefinitely();
                    return unlinkOutcome(Map.of("ok", true, "adr_id", req.adr_id(),
                        "sprint_id", req.sprint_id(), "action", "removed"), had);
                }
                // Проба ДО записи: исход «уже было» опирается на факт, а не на то,
                // что вернул CREATE EDGE — его результат доказывает отсутствие
                // ошибки, но не факт записи (замерено на CI 30.08.2026).
                boolean hadBefore = edgeExists("IMPLEMENTED_IN", "adr_id", req.adr_id(), "sprint_id", req.sprint_id());
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> created = (List<Map<String, Object>>)
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "CREATE EDGE IMPLEMENTED_IN " +
                        "FROM (SELECT FROM KnowADR    WHERE adr_id   = :id) " +
                        "TO   (SELECT FROM KnowSprint WHERE sprint_id = :sid) IF NOT EXISTS",
                        Map.of("id", req.adr_id(), "sid", req.sprint_id())))
                    .await().indefinitely().result();
                // CREATE EDGE into an empty FROM/TO set is a silent no-op — surface it.
                boolean linked = created != null && !created.isEmpty();
                return linkOutcome(hadBefore, Map.of("ok", true, "adr_id", req.adr_id(),
                    "sprint_id", req.sprint_id(), "action", "added", "linked", linked),
                    linked, "IMPLEMENTED_IN", "adr_id", req.adr_id(), "sprint_id", req.sprint_id(),
                    "ADR " + req.adr_id() + " или спринт " + req.sprint_id());
            }
            // Release target: prefer release_uid (git_project#release_id) for multi-repo
            // safety; fall back to bare release_id when git_project is not supplied.
            String relField = (req.git_project() != null && !req.git_project().isBlank())
                ? "release_uid" : "release_id";
            String relKey = "release_uid".equals(relField)
                ? req.git_project() + "#" + req.release_id() : req.release_id();
            if (remove) {
                // Проба ДО удаления: после него она бессмысленна — ребра нет в обоих
                // случаях, и «снято» стало бы утверждением без факта.
                boolean had = edgeExists("IMPLEMENTED_IN_RELEASE", "adr_id", req.adr_id(), relField, relKey);
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "DELETE FROM (SELECT expand(outE('IMPLEMENTED_IN_RELEASE')) FROM KnowADR WHERE adr_id=:id) " +
                    "WHERE @in." + relField + " = :rkey",
                    Map.of("id", req.adr_id(), "rkey", relKey))).await().indefinitely();
                return unlinkOutcome(Map.of("ok", true, "adr_id", req.adr_id(),
                    "release_id", req.release_id(), "action", "removed"), had);
            }
            // Проба ДО записи: исход «уже было» опирается на факт, а не на то,
            // что вернул CREATE EDGE — его результат доказывает отсутствие
            // ошибки, но не факт записи (замерено на CI 30.08.2026).
            boolean hadBefore = edgeExists("IMPLEMENTED_IN_RELEASE", "adr_id", req.adr_id(), relField, relKey);
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> created = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE IMPLEMENTED_IN_RELEASE " +
                    "FROM (SELECT FROM KnowADR     WHERE adr_id = :id) " +
                    "TO   (SELECT FROM KnowRelease WHERE " + relField + " = :rkey) IF NOT EXISTS",
                    Map.of("id", req.adr_id(), "rkey", relKey)))
                .await().indefinitely().result();
            boolean linked = created != null && !created.isEmpty();
            return linkOutcome(hadBefore, Map.of("ok", true, "adr_id", req.adr_id(),
                "release_id", req.release_id(), "action", "added", "linked", linked),
                linked, "IMPLEMENTED_IN_RELEASE", "adr_id", req.adr_id(), relField, relKey,
                "релиз по " + relField + "='" + relKey + "' (заведите его через release_new "
                + "или передайте git_project)");
        } catch (Exception e) {
            LOG.warnf("[LORE ADR LINK] %s: %s", req.adr_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── Write-path: point add/remove for ADR's other relations ──────────────
    // adr_new's component_ids/depends_on_ids/supersedes_ids/tags are
    // full-replace (delete-all-then-recreate) — fine for authoring the whole
    // set up front, but risky for incremental edits (must resend the entire
    // current set to add/remove one item). These four give the same
    // one-edge-at-a-time add/remove semantics adr/link already has for
    // sprint/release, so a single addition doesn't require re-reading and
    // re-sending everything else.
    public record AdrComponentLinkRequest(String adr_id, String component_id, String action) {}
    public record AdrDependsOnLinkRequest(String adr_id, String dep_adr_id, String action) {}
    public record AdrSupersedesLinkRequest(String adr_id, String superseded_adr_id, String action) {}
    public record AdrTagLinkRequest(String adr_id, String tag_id, String action) {}

    // ── ADR ↔ git-проект (ADRPROJ-01): мультипривязка BELONGS_TO_PROJECT ────────
    // Тот же паттерн, что adr/component: linked-валидация обязательна — CREATE EDGE
    // в пустой FROM/TO — тихий no-op (правило корпуса: линковка к незарегистри-
    // рованному проекту «успешно» ничего не делает).

    public record AdrProjectLinkRequest(String adr_id, String project, String action) {}

    @POST
    @Path("adr/project")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkAdrProject(AdrProjectLinkRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.adr_id() == null || req.adr_id().isBlank()
                || req.project() == null || req.project().isBlank())
            return badParams("adr_id and project (slug) required");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            if (remove) {
                // Проба ДО удаления: после него она бессмысленна — ребра нет в обоих
                // случаях, и «снято» стало бы утверждением без факта.
                boolean had = edgeExists("BELONGS_TO_PROJECT", "adr_id", req.adr_id(), "slug", req.project());
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "DELETE FROM (SELECT expand(outE('BELONGS_TO_PROJECT')) FROM KnowADR WHERE adr_id=:id) " +
                    "WHERE @in.slug = :gp",
                    Map.of("id", req.adr_id(), "gp", req.project()))).await().indefinitely();
                return unlinkOutcome(Map.of("ok", true, "adr_id", req.adr_id(),
                    "project", req.project(), "action", "removed"), had);
            }
            // Проба ДО записи: исход «уже было» опирается на факт, а не на то,
            // что вернул CREATE EDGE — его результат доказывает отсутствие
            // ошибки, но не факт записи (замерено на CI 30.08.2026).
            boolean hadBefore = edgeExists("BELONGS_TO_PROJECT", "adr_id", req.adr_id(), "slug", req.project());
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> created = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE BELONGS_TO_PROJECT " +
                    "FROM (SELECT FROM KnowADR        WHERE adr_id = :id) " +
                    "TO   (SELECT FROM KnowGitProject WHERE slug   = :gp) IF NOT EXISTS",
                    Map.of("id", req.adr_id(), "gp", req.project())))
                .await().indefinitely().result();
            boolean linked = created != null && !created.isEmpty();
            return linkOutcome(hadBefore, Map.of("ok", true, "adr_id", req.adr_id(),
                "project", req.project(), "action", "added", "linked", linked),
                linked, "BELONGS_TO_PROJECT", "adr_id", req.adr_id(), "slug", req.project(),
                "ADR " + req.adr_id() + " или проект " + req.project()
                + " (проект заводится через project_new)");
        } catch (Exception e) {
            LOG.warnf("[LORE ADR PROJECT] %s: %s", req.adr_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    @POST
    @Path("adr/component")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkAdrComponent(AdrComponentLinkRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.adr_id() == null || req.adr_id().isBlank()
                || req.component_id() == null || req.component_id().isBlank())
            return badParams("adr_id and component_id required");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            if (remove) {
                // Проба ДО удаления: после него она бессмысленна — ребра нет в обоих
                // случаях, и «снято» стало бы утверждением без факта.
                boolean had = edgeExists("BELONGS_TO", "adr_id", req.adr_id(), "component_id", req.component_id());
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "DELETE FROM (SELECT expand(outE('BELONGS_TO')) FROM KnowADR WHERE adr_id=:id) " +
                    "WHERE @in.component_id = :cid",
                    Map.of("id", req.adr_id(), "cid", req.component_id()))).await().indefinitely();
                return unlinkOutcome(Map.of("ok", true, "adr_id", req.adr_id(),
                    "component_id", req.component_id(), "action", "removed"), had);
            }
            // Проба ДО записи: исход «уже было» опирается на факт, а не на то,
            // что вернул CREATE EDGE — его результат доказывает отсутствие
            // ошибки, но не факт записи (замерено на CI 30.08.2026).
            boolean hadBefore = edgeExists("BELONGS_TO", "adr_id", req.adr_id(), "component_id", req.component_id());
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> created = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE BELONGS_TO " +
                    "FROM (SELECT FROM KnowADR       WHERE adr_id       = :id) " +
                    "TO   (SELECT FROM LoreComponent WHERE component_id = :cid) IF NOT EXISTS",
                    Map.of("id", req.adr_id(), "cid", req.component_id())))
                .await().indefinitely().result();
            boolean linked = created != null && !created.isEmpty();
            return linkOutcome(hadBefore, Map.of("ok", true, "adr_id", req.adr_id(),
                "component_id", req.component_id(), "action", "added", "linked", linked),
                linked, "BELONGS_TO", "adr_id", req.adr_id(), "component_id", req.component_id(),
                "ADR " + req.adr_id() + " или компонент " + req.component_id());
        } catch (Exception e) {
            LOG.warnf("[LORE ADR COMPONENT] %s: %s", req.adr_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    @POST
    @Path("adr/depends_on")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkAdrDependsOn(AdrDependsOnLinkRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.adr_id() == null || req.adr_id().isBlank()
                || req.dep_adr_id() == null || req.dep_adr_id().isBlank())
            return badParams("adr_id and dep_adr_id required");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            if (remove) {
                // Проба ДО удаления: после него она бессмысленна — ребра нет в обоих
                // случаях, и «снято» стало бы утверждением без факта.
                boolean had = edgeExists("DEPENDS_ON", "adr_id", req.adr_id(), "adr_id", req.dep_adr_id());
                // MDL-13: связь историчная — снятие закрывает ребро valid_to, а не стирает.
                deleteEdges("DEPENDS_ON", "@out.adr_id = :id AND @in.adr_id = :dep",
                    Map.of("id", req.adr_id(), "dep", req.dep_adr_id()));
                return unlinkOutcome(Map.of("ok", true, "adr_id", req.adr_id(),
                    "dep_adr_id", req.dep_adr_id(), "action", "removed"), had);
            }
            // Проба ДО записи: исход «уже было» опирается на факт, а не на то,
            // что вернул CREATE EDGE — его результат доказывает отсутствие
            // ошибки, но не факт записи (замерено на CI 30.08.2026).
            boolean hadBefore = edgeExists("DEPENDS_ON", "adr_id", req.adr_id(), "adr_id", req.dep_adr_id());
            // MDL-13: IF NOT EXISTS у историчной связи не годится — закрытое ребро той же пары помешало бы
            // открыть новое. Текущая связь есть — не пишем; нет — новое ребро с valid_from.
            boolean linked = false;
            if (!hadBefore) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> created = (List<Map<String, Object>>)
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "CREATE EDGE DEPENDS_ON " +
                        "FROM (SELECT FROM KnowADR WHERE adr_id = :id) " +
                        "TO   (SELECT FROM KnowADR WHERE adr_id = :dep) SET valid_from = '" + java.time.Instant.now() + "'",
                        Map.of("id", req.adr_id(), "dep", req.dep_adr_id())))
                    .await().indefinitely().result();
                linked = created != null && !created.isEmpty();
            }
            return linkOutcome(hadBefore, Map.of("ok", true, "adr_id", req.adr_id(),
                "dep_adr_id", req.dep_adr_id(), "action", "added", "linked", linked),
                linked, "DEPENDS_ON", "adr_id", req.adr_id(), "adr_id", req.dep_adr_id(),
                "ADR " + req.adr_id() + " или ADR " + req.dep_adr_id());
        } catch (Exception e) {
            LOG.warnf("[LORE ADR DEPENDS_ON] %s: %s", req.adr_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    @POST
    @Path("adr/supersedes")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkAdrSupersedes(AdrSupersedesLinkRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.adr_id() == null || req.adr_id().isBlank()
                || req.superseded_adr_id() == null || req.superseded_adr_id().isBlank())
            return badParams("adr_id and superseded_adr_id required");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            if (remove) {
                // Проба ДО удаления: после него она бессмысленна — ребра нет в обоих
                // случаях, и «снято» стало бы утверждением без факта.
                boolean had = edgeExists("SUPERSEDES", "adr_id", req.adr_id(), "adr_id", req.superseded_adr_id());
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "DELETE FROM (SELECT expand(outE('SUPERSEDES')) FROM KnowADR WHERE adr_id=:id) " +
                    "WHERE @in.adr_id = :sup",
                    Map.of("id", req.adr_id(), "sup", req.superseded_adr_id()))).await().indefinitely();
                return unlinkOutcome(Map.of("ok", true, "adr_id", req.adr_id(),
                    "superseded_adr_id", req.superseded_adr_id(), "action", "removed"), had);
            }
            // Проба ДО записи: исход «уже было» опирается на факт, а не на то,
            // что вернул CREATE EDGE — его результат доказывает отсутствие
            // ошибки, но не факт записи (замерено на CI 30.08.2026).
            boolean hadBefore = edgeExists("SUPERSEDES", "adr_id", req.adr_id(), "adr_id", req.superseded_adr_id());
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> created = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE SUPERSEDES " +
                    "FROM (SELECT FROM KnowADR WHERE adr_id = :id) " +
                    "TO   (SELECT FROM KnowADR WHERE adr_id = :sup) IF NOT EXISTS",
                    Map.of("id", req.adr_id(), "sup", req.superseded_adr_id())))
                .await().indefinitely().result();
            boolean linked = created != null && !created.isEmpty();
            return linkOutcome(hadBefore, Map.of("ok", true, "adr_id", req.adr_id(),
                "superseded_adr_id", req.superseded_adr_id(), "action", "added", "linked", linked),
                linked, "SUPERSEDES", "adr_id", req.adr_id(), "adr_id", req.superseded_adr_id(),
                "ADR " + req.adr_id() + " или ADR " + req.superseded_adr_id());
        } catch (Exception e) {
            LOG.warnf("[LORE ADR SUPERSEDES] %s: %s", req.adr_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    @POST
    @Path("adr/tag")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkAdrTag(AdrTagLinkRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.adr_id() == null || req.adr_id().isBlank()
                || req.tag_id() == null || req.tag_id().isBlank())
            return badParams("adr_id and tag_id required");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            if (remove) {
                // Проба ДО удаления: после него она бессмысленна — ребра нет в обоих
                // случаях, и «снято» стало бы утверждением без факта.
                boolean had = edgeExists("TAGGED_WITH", "adr_id", req.adr_id(), "tag_id", req.tag_id());
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "DELETE FROM (SELECT expand(outE('TAGGED_WITH')) FROM KnowADR WHERE adr_id=:id) " +
                    "WHERE @in.tag_id = :tag",
                    Map.of("id", req.adr_id(), "tag", req.tag_id()))).await().indefinitely();
                return unlinkOutcome(Map.of("ok", true, "adr_id", req.adr_id(),
                    "tag_id", req.tag_id(), "action", "removed"), had);
            }
            // Upsert the tag vertex first (same as adr_new's tag step) —
            // tags are freeform, not a fixed vocabulary.
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE KnowTag SET tag_id=:tag UPSERT WHERE tag_id=:tag",
                Map.of("tag", req.tag_id()))).await().indefinitely();
            // Проба ДО записи: исход «уже было» опирается на факт, а не на то,
            // что вернул CREATE EDGE — его результат доказывает отсутствие
            // ошибки, но не факт записи (замерено на CI 30.08.2026).
            boolean hadBefore = edgeExists("TAGGED_WITH", "adr_id", req.adr_id(), "tag_id", req.tag_id());
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> created = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE TAGGED_WITH " +
                    "FROM (SELECT FROM KnowADR WHERE adr_id = :id) " +
                    "TO   (SELECT FROM KnowTag WHERE tag_id = :tag) IF NOT EXISTS",
                    Map.of("id", req.adr_id(), "tag", req.tag_id())))
                .await().indefinitely().result();
            boolean linked = created != null && !created.isEmpty();
            return linkOutcome(hadBefore, Map.of("ok", true, "adr_id", req.adr_id(),
                "tag_id", req.tag_id(), "action", "added", "linked", linked),
                linked, "TAGGED_WITH", "adr_id", req.adr_id(), "tag_id", req.tag_id(),
                "ADR " + req.adr_id() + " или тег " + req.tag_id());
        } catch (Exception e) {
            LOG.warnf("[LORE ADR TAG] %s: %s", req.adr_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    @POST
    @Path("adr/rename")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response renameAdr(AdrRenameRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.adr_id() == null || req.adr_id().isBlank()
                || req.new_adr_id() == null || req.new_adr_id().isBlank())
            return badParams("adr_id and new_adr_id required");
        if (!SAFE_ID.matcher(req.new_adr_id()).matches())
            return badParams("new_adr_id contains illegal characters");
        try {
            // Edges hang off the vertex @rid, not the business key — renaming adr_id
            // in place keeps every DEPENDS_ON/SUPERSEDES/BELONGS_TO/TAGGED_WITH/
            // IMPLEMENTED_IN*/HAS_STATE edge intact. No tombstone needed.
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> clash = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "SELECT adr_id FROM KnowADR WHERE adr_id=:nid",
                    Map.of("nid", req.new_adr_id()))).await().indefinitely().result();
            if (clash != null && !clash.isEmpty())
                return badParams("new_adr_id already exists: " + req.new_adr_id());
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> hit = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "UPDATE KnowADR SET adr_id=:nid WHERE adr_id=:oid",
                    Map.of("nid", req.new_adr_id(), "oid", req.adr_id())))
                .await().indefinitely().result();
            Object count = (hit != null && !hit.isEmpty()) ? hit.get(0).get("count") : 0;
            // MT-MCP-TRUTH Б11: переименование несуществующего ADR отвечало ok:true с updated: 0
            if (WriteCount.missed(hit))
                return WriteCount.notFound("adr", req.adr_id(), "переименование в " + req.new_adr_id());
            return noStore(Response.ok(Map.of("ok", true,
                "adr_id", req.new_adr_id(), "renamed_from", req.adr_id(), "updated", count)));
        } catch (Exception e) {
            LOG.warnf("[LORE ADR RENAME] %s → %s: %s", req.adr_id(), req.new_adr_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    @POST
    @Path("adr/delete")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteAdr(AdrDeleteRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.adr_id() == null || req.adr_id().isBlank())
            return badParams("adr_id required");
        try {
            // Cascade order matters (ArcadeDB: DELETE VERTEX unsupported, edges first):
            // 1) collect hist rids while HAS_STATE still exists, 2) drop all edges,
            // 3) drop hist rows by rid, 4) drop the vertex.
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> histRids = (List<Map<String, Object>>)
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "SELECT @rid as rid FROM KnowADRHist WHERE in('HAS_STATE').adr_id[0]=:id",
                    Map.of("id", req.adr_id()))).await().indefinitely().result();
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "DELETE FROM (SELECT expand(bothE()) FROM KnowADR WHERE adr_id=:id)",
                Map.of("id", req.adr_id()))).await().indefinitely();
            int histDeleted = 0;
            if (histRids != null) {
                for (Map<String, Object> r : histRids) {
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM KnowADRHist WHERE @rid=:rid",
                        Map.of("rid", r.get("rid")))).await().indefinitely();
                    histDeleted++;
                }
            }
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "DELETE FROM KnowADR WHERE adr_id=:id",
                Map.of("id", req.adr_id()))).await().indefinitely();
            return noStore(Response.ok(Map.of("ok", true, "adr_id", req.adr_id(),
                "hist_deleted", histDeleted)));
        } catch (Exception e) {
            LOG.warnf("[LORE ADR DELETE] %s: %s", req.adr_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── Реестр ОВ vs markdown-раздел (ADR-LORE-020) ─────────────────────────
    // «Открытые вопросы» разделом в теле ADR — распространённая ошибка (14 ADR
    // корпуса на 2026-07-16, включая свежие). Такие вопросы не находятся
    // фильтром, не всплывают просроченными, не гейтят задачи и не закрываются
    // решением — весь смысл KnowQuestion теряется. Ловим на записи и говорим
    // вызывающему (агенту), что делать. Только подсказка: тело не отвергаем —
    // раздел в ADR законен как обзор, дубликатом реестра он быть не должен.
    // Две кириллические ловушки Java-regex, обе поймались тестом, не глазами:
    //  • \w = [a-zA-Z_0-9] — кириллицу не матчит → \p{L};
    //  • (?i) БЕЗ (?u) сворачивает регистр только ASCII → «открыт» не матчил
    //    «Открытые», хотя английский вариант ловился. Отсюда флаг u.
    // Ловим и заголовок (## Открытые вопросы), и жирный инлайн в начале строки
    // (**Открытые вопросы:** (1) …) — вторая форма встречалась в 5 ADR корпуса и
    // проходила мимо, пока искали только по заголовкам. Проза («вопрос отпал»,
    // «открытых вопросов не осталось») по-прежнему игнорируется: маркер обязан
    // начинать строку.
    // Маркер обязан идти СРАЗУ после «##» или «**» и начинать строку. Зазор в
    // 40 символов, который был здесь раньше, ловил прозу: «**Ответ автора:
    // нет.** Не хватает **списка открытых вопросов**» в ADR-020 и рассуждения
    // об имени раздела в ADR-021 — оба ложные. Заголовок/жирный лид — маркер;
    // упоминание в предложении — нет.
    private static final java.util.regex.Pattern QUESTION_SECTION = java.util.regex.Pattern.compile(
        "(?imu)^\\s*(?:#{1,6}\\s*|\\*\\*\\s*)"
        + "(открыт\\p{L}*\\s+вопрос|нерешённ\\p{L}*\\s+вопрос|open\\s+questions)");

    /**
     * DBR-04: привести рёбра ADR данного типа к запрошенному набору и вернуть
     * список целей, которые записать НЕ удалось.
     *
     * <p><b>Порядок: сначала создать, потом удалить лишние.</b> Прежняя
     * редакция делала наоборот — сносила все рёбра и создавала заново, а каждый
     * шаг был в своём {@code try} с одним WARN. Худший случай: DELETE прошёл,
     * CREATE упал — ADR остался вообще без компонентов, ответ был {@code
     * ok:true}. Обратный порядок при сбое оставляет ДУБЛИ, а не пустоту; дубли
     * чинятся повторным вызовом, потеря не чинится ничем.
     *
     * <p>{@code IF NOT EXISTS} обязателен именно из-за нового порядка: без него
     * повторный вызов плодил бы вторые рёбра к тем же целям.
     *
     * <p>Несуществующая цель — не ошибка, а тихий no-op: {@code CREATE EDGE} с
     * пустым TO ничего не создаёт и не жалуется. Поэтому проверяем факт
     * отдельным запросом и возвращаем список непривязанных наверх, вместо того
     * чтобы отчитаться успехом.
     */
    private List<String> syncEdges(String edgeType, String targetClass, String targetIdField,
                                   String adrId, List<String> wantedRaw) {
        List<String> wanted = wantedRaw.stream()
            .filter(s -> s != null && !s.isBlank()).distinct().toList();
        List<String> failed = new ArrayList<>();

        for (String target : wanted) {
            try {
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE " + edgeType
                    + " FROM (SELECT FROM KnowADR WHERE adr_id = :id) "
                    + "TO   (SELECT FROM " + targetClass + " WHERE " + targetIdField + " = :t) "
                    + "IF NOT EXISTS",
                    Map.of("id", adrId, "t", target))).await().indefinitely();
            } catch (Exception ex) {
                LOG.warnf("[LORE ADR %s] %s → %s: %s", edgeType, adrId, target, LoreUpstream.detail(ex));
                failed.add(target);
                continue;
            }
            // Пусто и при «уже было», и при «цели нет» — различаем фактом.
            try {
                var exists = ingestService.queryPublic(
                    "SELECT count(*) AS n FROM " + edgeType
                    + " WHERE @out.adr_id = :id AND @in." + targetIdField + " = :t",
                    Map.of("id", adrId, "t", target));
                long n = exists.isEmpty() ? 0 : ((Number) exists.get(0).getOrDefault("n", 0)).longValue();
                if (n == 0) failed.add(target);
            } catch (Exception ex) {
                LOG.warnf("[LORE ADR %s verify] %s → %s: %s", edgeType, adrId, target, LoreUpstream.detail(ex));
                failed.add(target);
            }
        }

        // Лишние — поштучно по фактическому набору: DELETE EDGE в грамматике
        // ArcadeDB 26.7.2 отсутствует, работает удаление строки ребра по типу.
        try {
            var current = ingestService.queryPublic(
                "SELECT out('" + edgeType + "')." + targetIdField + " AS ids FROM KnowADR WHERE adr_id = :id",
                Map.of("id", adrId));
            if (!current.isEmpty() && current.get(0).get("ids") instanceof List<?> have) {
                for (Object o : have) {
                    if (o == null) continue;
                    String t = String.valueOf(o);
                    if (wanted.contains(t)) continue;
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "DELETE FROM " + edgeType
                        + " WHERE @out.adr_id = :id AND @in." + targetIdField + " = :t",
                        Map.of("id", adrId, "t", t))).await().indefinitely();
                }
            }
        } catch (Exception ex) {
            // Не смогли убрать лишнее — это дубль, а не потеря: говорим в лог,
            // но не валим запись, которая в основном удалась.
            LOG.warnf("[LORE ADR %s cleanup] %s: %s", edgeType, adrId, LoreUpstream.detail(ex));
        }
        return failed;
    }

    static String questionsInBodyHint(AdrCreateRequest req) {
        int hits = 0;
        for (String body : new String[] { req.context_md(), req.decision_md(), req.consequences_md() }) {
            if (body == null || body.isBlank()) continue;
            java.util.regex.Matcher m = QUESTION_SECTION.matcher(body);
            while (m.find()) hits++;
        }
        if (hits == 0) return null;
        return "в теле найден раздел с открытыми вопросами (" + hits + ") — реестр ОВ это отдельная сущность "
            + "(ADR-LORE-020): заведите их через question_new + question_link(rel:\"raised_in\", target=" + req.adr_id()
            + "), иначе они не попадут в слайс questions, не будут видны просроченными и их нельзя закрыть решением (ANSWERS). "
            + "Раздел в теле оставляйте только как обзор, не как реестр.";
    }
}
