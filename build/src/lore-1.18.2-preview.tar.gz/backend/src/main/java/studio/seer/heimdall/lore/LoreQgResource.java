package studio.seer.heimdall.lore;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * QualityGate / QGJobTask / QGRecommendation write endpoints, split out of
 * AidaLoreResource (B2). Shares infra via LoreResourceBase.
 */
@Path("/lore")
public class LoreQgResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreQgResource.class);

    // ── QualityGate write ────────────────────────────────────────────────────
    /** ADR-LORE-053-D7: project — slug проекта-владельца (ребро BELONGS_TO_PROJECT); retired_reason — причина отмены. */
    public record QGUpsertRequest(String qg_id, String name, String description,
        String component_id, String status, String content_md, String sprint_id,
        String project, String retired_reason, String qg_type, String scope) {}

    @POST
    @Path("quality-gate")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response upsertQualityGate(QGUpsertRequest req,
                                      @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.qg_id() == null || req.qg_id().isBlank())
            return badParams("qg_id required");
        if (!SAFE_ID.matcher(req.qg_id()).matches())
            return badParams("qg_id contains illegal characters");
        try {
            // ADR-LORE-053-D7: жизненный цикл гейта — словарь qg_status, владелец для active, причина для retired.
            List<Map<String, Object>> prev = ingestService.queryPublic(
                "SELECT qg_id, scope, out('BELONGS_TO_PROJECT').slug AS projects FROM QualityGate WHERE qg_id = :id",
                Map.of("id", req.qg_id()));
            boolean exists = !prev.isEmpty();
            String status = exists ? req.status() : QgGateLifecycle.initialStatus(req.status());
            String project = req.project() == null || req.project().isBlank() ? null : req.project().trim();
            if (project != null && !registeredSlugs().contains(project))
                return noStore(Response.status(422).entity(new LoreError("QG_LIFECYCLE",
                    "проект «" + project + "» не зарегистрирован (KnowGitProject.slug)")));
            // QG-01 (решение владелицы 19.11.2026 «2а»): scope = global | project. Общий гейт без проекта —
            // его связи с проектами снимаются; проектный — ровно один проект после записи.
            String scope = req.scope() != null ? req.scope()
                : exists && prev.get(0).get("scope") != null ? String.valueOf(prev.get(0).get("scope")) : null;
            java.util.Set<String> owners = new java.util.LinkedHashSet<>();
            if (exists && !"global".equals(req.scope()) && prev.get(0).get("projects") instanceof java.util.Collection<?> c)
                for (Object s : c) if (s != null) owners.add(String.valueOf(s));
            if (project != null) owners.add(project);
            String lifecycleError = req.scope() != null || project != null
                ? QgGateLifecycle.checkScope(scope, project != null, owners.size()) : null;
            boolean hasOwner = QgGateLifecycle.hasOwner(scope, owners.size());
            if (lifecycleError == null) lifecycleError = QgGateLifecycle.check(status, hasOwner, req.retired_reason());
            if (lifecycleError == null && req.qg_type() != null) {
                java.util.List<String> types = ingestService.queryPublic(
                    "SELECT code FROM KnowDictEntry WHERE dict_type = 'qg_type' AND is_active = true", Map.of())
                    .stream().map(r -> String.valueOf(r.get("code"))).toList();
                lifecycleError = QgGateLifecycle.checkType(req.qg_type(), types);
            }
            if (lifecycleError != null)
                return noStore(Response.status(422).entity(new LoreError("QG_LIFECYCLE", lifecycleError)));
            // LH-44: only SET provided fields — a status-only call (e.g. deprecate a gate)
            // must not wipe curated content_md/description/routine links.
            StringBuilder qsql = new StringBuilder("UPDATE QualityGate SET qg_id=:id");
            Map<String, Object> p = new java.util.HashMap<>();
            p.put("id", req.qg_id());
            if (req.name() != null)         { qsql.append(", name=:nm");          p.put("nm",  req.name()); }
            if (req.description() != null)  { qsql.append(", description=:dsc");  p.put("dsc", req.description()); }
            if (req.component_id() != null) { qsql.append(", component_id=:cid"); p.put("cid", req.component_id()); }
            if (status != null)             { qsql.append(", status=:st");        p.put("st",  status); }
            if ("retired".equals(status)) {
                qsql.append(", retired_reason=:rr, retired_at=:ra");
                p.put("rr", req.retired_reason().trim());
                p.put("ra", java.time.Instant.now().toString());
            }
            if (req.content_md() != null)   { qsql.append(", content_md=:cnt");   p.put("cnt", req.content_md()); }
            if (req.sprint_id() != null)    { qsql.append(", sprint_id=:sid");    p.put("sid", req.sprint_id()); }
            if (req.qg_type() != null)      { qsql.append(", qg_type=:qt");       p.put("qt",  req.qg_type()); }
            if (req.scope() != null)        { qsql.append(", scope=:sc");         p.put("sc",  req.scope()); }
            qsql.append(" UPSERT WHERE qg_id=:id");
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                qsql.toString(), p)).await().indefinitely();
            // NM-03 (ADR-LORE-041): гейт писал component_id полем, а паспорт
            // компонента считает гейты ребром in('BELONGS_TO') — семь гейтов на
            // проде не показывались нигде при исправно записанном поле.
            Map<String, Object> out = new java.util.LinkedHashMap<>();
            out.put("ok", true);
            out.put("qg_id", req.qg_id());
            linkComponentEdge("QualityGate", "qg_id", req.qg_id(), req.component_id(), out);
            if ("global".equals(req.scope())) {
                out.put("projects_unlinked", deleteEdges("BELONGS_TO_PROJECT", "@out.qg_id = :id", Map.of("id", req.qg_id())));
            }
            if (scope != null) out.put("scope", scope);
            if (project != null) {
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE BELONGS_TO_PROJECT FROM (SELECT FROM QualityGate WHERE qg_id=:id) "
                        + "TO (SELECT FROM KnowGitProject WHERE slug=:s) IF NOT EXISTS",
                    Map.of("id", req.qg_id(), "s", project))).await().indefinitely();
                out.put("project", project);
            }
            if (status != null) out.put("status", status);
            if (!exists) CreateDefaultStatus.report(out, CreateDefaultStatus.pick("quality_gate", req.status())); // правило 19.11
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE QG UPSERT] %s: %s", req.qg_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── QG Run record (ClRoutineRun + ClRoutineMetric batch) ─────────────────
    //
    // SPRINT_QG_REBUILD/QG-12 + QG-03 + QG-15. Схему расширила миграция 29, а
    // контракт живёт на ПУТИ ЗАПИСИ: поля в схеме без проверок на входе — это те
    // же 56 строк метрик без даты, только с новыми колонками.
    //
    // Сама запись и проверки — в LoreQgRunWriter, потому что писать прогоны нужно
    // из ДВУХ мест: отсюда и из опроса Forgejo (LoreQgActionsPoller). Копия SQL во
    // втором месте завела бы вторую правду о том, что считается корректной
    // записью, и первая же правка проверок разошлась бы молча. Роль ⑥
    // «Регистратор» из §11.2 — единственная точка записи, в одном экземпляре.

    public record QGMetricEntry(String key, Double value, String unit, Double target, String status, String source,
                                String not_measured_reason, String model) {}
    public record QGRunRequest(
        String run_id, String routine_name, String run_date, String status,
        String started_at, String finished_at, String flags,
        String channel, String source_url, String commit_sha, Integer pr_number, String model,
        java.util.List<QGMetricEntry> metrics) {}

    @jakarta.inject.Inject
    LoreQgRunWriter runWriter;

    @POST
    @Path("qg/run")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response recordQGRun(QGRunRequest req,
                                @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        try {
            LoreQgRunWriter.Result r = runWriter.record(req);
            if (!r.ok()) return badParams(r.errorDetail());
            return noStore(Response.ok(Map.of(
                "ok", true, "run_id", r.runId(), "metrics_written", r.metricsWritten())));
        } catch (Exception e) {
            LOG.warnf("[LORE QG RUN] %s: %s",
                req != null ? req.routine_name() : "<null>", e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── QGJobTask / QGRecommendation write ───────────────────────────────────
    public record QGJobTaskRequest(
        String job_id, String qg_id, String inv_id, String run_date,
        String severity, String status, String note_md) {}

    @POST
    @Path("qg/job-task")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response upsertQGJobTask(QGJobTaskRequest req,
                                    @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.job_id() == null || req.job_id().isBlank())
            return badParams("job_id required");
        if (req.qg_id() == null || req.qg_id().isBlank())
            return badParams("qg_id required");
        try {
            // DBR-17 (ADR-LORE-043): гейт проверяется ДО записи. Раньше прогон
            // несуществующего гейта писался сиротой без YIELDED и отвечал ok:true.
            if (!exists("QualityGate", "qg_id", req.qg_id()))
                return targetNotFound("гейт " + req.qg_id() + " не найден — заведите его qg_new до прогона");
            boolean existed = exists("QGJobTask", "job_id", req.job_id());
            // LH-44: only SET provided fields — a status-only resolve call must not
            // wipe note_md/severity/run_date evidence.
            StringBuilder jsql = new StringBuilder("UPDATE QGJobTask SET job_id=:jid, qg_id=:qid");
            Map<String, Object> p = new java.util.HashMap<>();
            p.put("jid", req.job_id());
            p.put("qid", req.qg_id());
            if (req.inv_id() != null)   { jsql.append(", inv_id=:inv");    p.put("inv",  req.inv_id()); }
            if (req.run_date() != null) { jsql.append(", run_date=:rd");   p.put("rd",   req.run_date()); }
            if (req.severity() != null) { jsql.append(", severity=:sev");  p.put("sev",  req.severity()); }
            if (req.status() != null)   { jsql.append(", status=:st");     p.put("st",   req.status()); }
            if (req.note_md() != null)  { jsql.append(", note_md=:note");  p.put("note", req.note_md()); }
            jsql.append(" UPSERT WHERE job_id=:jid");
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                jsql.toString(), p)).await().indefinitely();
            // YIELDED edge: QualityGate → QGJobTask (idempotent)
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "CREATE EDGE YIELDED FROM (SELECT FROM QualityGate WHERE qg_id=:qid) " +
                "TO (SELECT FROM QGJobTask WHERE job_id=:jid) IF NOT EXISTS",
                Map.of("qid", req.qg_id(), "jid", req.job_id()))).await().indefinitely();
            return written(Map.of("ok", true, "job_id", req.job_id()), existed,
                edgeExists("YIELDED", "qg_id", req.qg_id(), "job_id", req.job_id()),
                "гейт " + req.qg_id() + " или прогон " + req.job_id());
        } catch (Exception e) {
            LOG.warnf("[LORE QG JOB-TASK] %s: %s", req.job_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    public record QGRecommendationRequest(
        String rec_id, String job_id, String title, String body_md, String status,
        String priority, String severity, Double effort_days, String tags,
        String component_id, String qg_id, String inv_id,
        String fix_cmd, String how_to_verify) {}

    @POST
    @Path("qg/recommendation")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response upsertQGRecommendation(QGRecommendationRequest req,
                                           @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.rec_id() == null || req.rec_id().isBlank())
            return badParams("rec_id required");
        if (req.job_id() == null || req.job_id().isBlank())
            return badParams("job_id required");
        try {
            // DBR-17: прогон проверяется ДО записи — иначе рекомендация-сирота без PRODUCED.
            if (!exists("QGJobTask", "job_id", req.job_id()))
                return targetNotFound("прогон " + req.job_id() + " не найден — заведите его qg_job_new до рекомендации");
            boolean existed = exists("QGRecommendation", "rec_id", req.rec_id());
            // LH-44: only SET provided fields. Two former hazards on partial re-calls:
            // (1) body_md/fix_cmd/how_to_verify etc. wiped to null; (2) status forced
            // back to 'pending' — silently un-promoting an already promoted rec.
            // Default status='pending' now applies only where still missing (fresh insert).
            StringBuilder rsql = new StringBuilder("UPDATE QGRecommendation SET rec_id=:rid, job_id=:jid");
            Map<String, Object> p = new java.util.HashMap<>();
            p.put("rid", req.rec_id());
            p.put("jid", req.job_id());
            if (req.title() != null)         { rsql.append(", title=:ttl");           p.put("ttl",  req.title()); }
            if (req.body_md() != null)       { rsql.append(", body_md=:body");        p.put("body", req.body_md()); }
            if (req.status() != null)        { rsql.append(", status=:st");           p.put("st",   req.status()); }
            if (req.priority() != null)      { rsql.append(", priority=:pri");        p.put("pri",  req.priority()); }
            if (req.severity() != null)      { rsql.append(", severity=:sev");        p.put("sev",  req.severity()); }
            if (req.effort_days() != null)   { rsql.append(", effort_days=:eff");     p.put("eff",  req.effort_days()); }
            if (req.tags() != null)          { rsql.append(", tags=:tags");           p.put("tags", req.tags()); }
            if (req.component_id() != null)  { rsql.append(", component_id=:cid");    p.put("cid",  req.component_id()); }
            if (req.qg_id() != null)         { rsql.append(", qg_id=:qgid");          p.put("qgid", req.qg_id()); }
            if (req.inv_id() != null)        { rsql.append(", inv_id=:inv");          p.put("inv",  req.inv_id()); }
            if (req.fix_cmd() != null)       { rsql.append(", fix_cmd=:fcmd");        p.put("fcmd", req.fix_cmd()); }
            if (req.how_to_verify() != null) { rsql.append(", how_to_verify=:htv");   p.put("htv",  req.how_to_verify()); }
            rsql.append(" UPSERT WHERE rec_id=:rid");
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                rsql.toString(), p)).await().indefinitely();
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE QGRecommendation SET status='pending' WHERE rec_id=:rid AND status IS NULL",
                Map.of("rid", req.rec_id()))).await().indefinitely();
            // PRODUCED edge: QGJobTask → QGRecommendation (idempotent)
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "CREATE EDGE PRODUCED FROM (SELECT FROM QGJobTask WHERE job_id=:jid) " +
                "TO (SELECT FROM QGRecommendation WHERE rec_id=:rid) IF NOT EXISTS",
                Map.of("jid", req.job_id(), "rid", req.rec_id()))).await().indefinitely();
            return written(Map.of("ok", true, "rec_id", req.rec_id()), existed,
                edgeExists("PRODUCED", "job_id", req.job_id(), "rec_id", req.rec_id()),
                "прогон " + req.job_id() + " или рекомендация " + req.rec_id());
        } catch (Exception e) {
            LOG.warnf("[LORE QG REC] %s: %s", req.rec_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    public record QGPromoteRequest(
        String rec_id, String sprint_id, String task_uid, String title, String note_md,
        String task_type) {}

    /** ISO-week id for the rotating QG-housekeeping sprint, e.g. "SPRINT_QG_HOUSEKEEPING_2026W27". */
    private static String weeklyHousekeepingSprintId() {
        java.time.temporal.WeekFields wf = java.time.temporal.WeekFields.ISO;
        java.time.LocalDate today = java.time.LocalDate.now(java.time.ZoneOffset.UTC);
        int isoWeek = today.get(wf.weekOfWeekBasedYear());
        int isoYear = today.get(wf.weekBasedYear());
        return String.format("SPRINT_QG_HOUSEKEEPING_%dW%02d", isoYear, isoWeek);
    }

    @POST
    @Path("qg/promote")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response promoteQGRecommendation(QGPromoteRequest req,
                                            @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.rec_id() == null || req.rec_id().isBlank())
            return badParams("rec_id required");
        // DBR-17 (ADR-LORE-043): концы проверяются ДО записи, и повтор не плодит задачи.
        // Раньше промоут несуществующей рекомендации заводил пустую задачу, промоут в
        // несуществующий спринт — задачу без PART_OF, а повтор — вторую задачу под ту же
        // рекомендацию (номер берётся «следующий свободный»).
        try {
            if (!exists("QGRecommendation", "rec_id", req.rec_id()))
                return targetNotFound("рекомендация " + req.rec_id() + " не найдена");
            List<Map<String, Object>> promoted = ingestService.queryPublic(
                "SELECT @in.task_uid AS task_uid FROM PROMOTED_TO WHERE @out.rec_id=:rid LIMIT 1",
                Map.of("rid", req.rec_id()));
            if (!promoted.isEmpty() && promoted.get(0).get("task_uid") != null) {
                Map<String, Object> out = new LinkedHashMap<>();
                out.put("ok", true);
                out.put("task_uid", promoted.get(0).get("task_uid"));
                out.put("outcome", LoreOutcome.UNCHANGED);
                out.put("hint", "рекомендация уже продвинута в эту задачу — повторять вызов не нужно");
                return noStore(Response.ok(out));
            }
            if (req.sprint_id() != null && !exists("KnowSprint", "sprint_id", req.sprint_id()))
                return targetNotFound("спринт " + req.sprint_id() + " не найден — заведите его sprint_new "
                    + "или не передавайте sprint_id (тогда — недельный спринт QG-housekeeping)");
        } catch (Exception e) {
            LOG.warnf("[LORE QG PROMOTE] probe %s: %s", req.rec_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
        // Default target: a weekly rotating housekeeping sprint (ISO week), not one
        // never-closing bucket. Explicit req.sprint_id() still wins (backward-compat
        // override). Found 2026-07-02: SPRINT_QG_VIOLATIONS accumulated every promoted
        // recommendation across every gate/run forever — no velocity signal, no closure.
        String sprintId = req.sprint_id() != null ? req.sprint_id() : weeklyHousekeepingSprintId();
        if (req.sprint_id() == null) {
            java.time.temporal.WeekFields wf = java.time.temporal.WeekFields.ISO;
            java.time.LocalDate today = java.time.LocalDate.now(java.time.ZoneOffset.UTC);
            ingestService.createSprint(
                sprintId,
                String.format("QG Housekeeping — Week %02d %d",
                    today.get(wf.weekOfWeekBasedYear()), today.get(wf.weekBasedYear())),
                "active", null, null, null,
                "Автосоздан при первом промоуте QG-рекомендации на этой ISO-неделе " +
                "(lore/qg/promote). Явный sprint_id в вызове переопределяет этот дефолт.",
                changeAuthor());
        }
        String stateUid = java.util.UUID.randomUUID().toString();
        String nowTs    = java.time.Instant.now().toString();
        try {
            // 1. Look up the recommendation to enrich the task
            List<Map<String, Object>> recRows = ingestService.queryPublic(
                "SELECT rec_id, title, body_md, priority, severity, effort_days, " +
                "fix_cmd, how_to_verify, component_id, qg_id, inv_id, tags " +
                "FROM QGRecommendation WHERE rec_id=:rid LIMIT 1",
                Map.of("rid", req.rec_id()));
            Map<String, Object> rec = recRows.isEmpty() ? Map.of() : recRows.get(0);

            // 2. Derive task_id = next TNN in sprint.
            // PART_OF edge direction is Task --PART_OF--> Sprint (CREATE EDGE PART_OF FROM
            // KnowTask TO KnowSprint, below) — so from a KnowTask row the OWN edge is
            // out('PART_OF'), not in(). Using in() here always returned zero matches,
            // silently resetting maxN to 0 → every 2nd+ promotion into the same sprint
            // recomputed task_id="T01" and UPSERT-overwrote the FIRST task's title/note_md.
            // Found + fixed live 2026-07-02 (test promote clobbered the real T01 in
            // SPRINT_QG_VIOLATIONS — restored from history after this fix landed).
            List<Map<String, Object>> existingTasks = ingestService.queryPublic(
                "SELECT task_id FROM KnowTask WHERE task_id IS NOT NULL " +
                "AND task_id LIKE 'T%' AND out('PART_OF').sprint_id=:sid",
                Map.of("sid", sprintId));
            int maxN = existingTasks.stream()
                .map(t -> t.getOrDefault("task_id", "T0").toString().replaceAll("[^0-9]", ""))
                .filter(s -> !s.isBlank()).mapToInt(s -> { try { return Integer.parseInt(s); } catch (Exception e2) { return 0; } })
                .max().orElse(0);
            String taskId  = String.format("T%02d", maxN + 1);
            String taskUid = req.task_uid() != null ? req.task_uid()
                           : sprintId + "/" + taskId;

            // 3. Build rich note_md from rec fields
            String recTitle    = str(rec.get("title"));
            String recBody     = str(rec.get("body_md"));
            String recPri      = str(rec.get("priority"));
            String recSev      = str(rec.get("severity"));
            String recEffort   = str(rec.get("effort_days"));
            String recFixCmd   = str(rec.get("fix_cmd"));
            String recVerify   = str(rec.get("how_to_verify"));
            String recQg       = str(rec.get("qg_id"));
            String recInv      = str(rec.get("inv_id"));
            String recTags     = str(rec.get("tags"));
            String recComp     = str(rec.get("component_id"));

            String title = req.title() != null ? req.title()
                         : (!recTitle.isBlank() ? recTitle : taskUid);

            String note;
            if (req.note_md() != null) {
                note = req.note_md();
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("## ").append(title).append("\n\n");
                if (!recQg.isBlank() || !recInv.isBlank())
                    sb.append("**QG:** ").append(recQg).append(" · **INV:** ").append(recInv).append("\n");
                if (!recPri.isBlank() || !recSev.isBlank())
                    sb.append("**Priority:** ").append(recPri)
                      .append(" · **Severity:** ").append(recSev);
                if (!recEffort.isBlank()) sb.append(" · **Effort:** ").append(recEffort).append("d");
                if (!recPri.isBlank() || !recSev.isBlank()) sb.append("\n");
                if (!recTags.isBlank()) sb.append("**Tags:** ").append(recTags).append("\n");
                sb.append("\n");
                if (!recBody.isBlank()) sb.append(recBody).append("\n\n");
                if (!recFixCmd.isBlank())
                    sb.append("**Fix:**\n```bash\n").append(recFixCmd).append("\n```\n\n");
                if (!recVerify.isBlank())
                    sb.append("**Verify:**\n```bash\n").append(recVerify).append("\n```\n");
                note = sb.toString().trim();
            }

            // 4. Upsert task vertex with task_id + component_id + type/author defaults.
            // task_type defaults to "research" (ADR-LORE-015 §1b: Analyst owns research)
            // unless the caller overrides; author_agent defaults to the owning role
            // ("analyst") rather than a session id, since this task is system-created
            // from a QG finding, not authored by a specific working session (T13, 2026-07-14).
            String compId = recComp.isBlank() ? "AIDA" : recComp;
            String taskType = req.task_type() != null ? req.task_type() : "research";
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE KnowTask SET task_uid=:uid, task_id=:tid, title=:title, " +
                "note_md=:note, src='qg', component_id=:cid, task_type=:tt, author_agent=:auth " +
                "UPSERT WHERE task_uid=:uid",
                mapOfNullable("uid", taskUid, "tid", taskId, "title", title, "note", note,
                    "cid", compId, "tt", taskType, "auth", "analyst")))
                .await().indefinitely();
            // NM-03 (ADR-LORE-041): задача из находки гейта получала компонент
            // полем. Шесть таких задач на проде — единственные KnowTask с этим
            // расхождением, и все они пришли отсюда: остальные пути задач давно
            // ставят ребро. Компонент здесь всегда непустой (падает в "AIDA"),
            // так что молчаливого пропуска быть не может.
            linkComponentEdge("KnowTask", "task_uid", taskUid, compId);
            // Insert KnowTaskHist row with TODO status
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "INSERT INTO KnowTaskHist SET state_uid=:nsid, status_raw='⬜ TODO', valid_from=:now"
                    + ChangeAuthor.SET_SQL,
                changeAuthor().bind(new java.util.HashMap<>(Map.of("nsid", stateUid, "now", nowTs)))))
                .await().indefinitely();
            // Link HAS_STATE: KnowTask → KnowTaskHist
            writeClient.command(db, basicAuth(), linkStateCmd(
                "KnowTask", "KnowTaskHist", "task_uid", taskUid, stateUid)).await().indefinitely();
            // Link PART_OF: KnowTask → KnowSprint
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "CREATE EDGE PART_OF FROM (SELECT FROM KnowTask WHERE task_uid=:uid) " +
                "TO (SELECT FROM KnowSprint WHERE sprint_id=:sid) IF NOT EXISTS",
                Map.of("uid", taskUid, "sid", sprintId))).await().indefinitely();
            // PROMOTED_TO edge: QGRecommendation → KnowTask
            Map<String, Object> ep = Map.of("rid", req.rec_id(), "uid", taskUid);
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "CREATE EDGE PROMOTED_TO FROM (SELECT FROM QGRecommendation WHERE rec_id=:rid) " +
                "TO (SELECT FROM KnowTask WHERE task_uid=:uid) IF NOT EXISTS", ep))
                .await().indefinitely();
            // Mark recommendation as promoted
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE QGRecommendation SET status='promoted' WHERE rec_id=:rid",
                Map.of("rid", req.rec_id()))).await().indefinitely();
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true); out.put("task_uid", taskUid);
            out.put("task_id", taskId); out.put("sprint_id", sprintId);
            // Факт, а не признак: обе связи задачи обязаны быть в графе.
            boolean partOf = edgeExists("PART_OF", "task_uid", taskUid, "sprint_id", sprintId);
            boolean promotedTo = edgeExists("PROMOTED_TO", "rec_id", req.rec_id(), "task_uid", taskUid);
            if (partOf && promotedTo) {
                out.put("outcome", LoreOutcome.CREATED);
            } else {
                out.put("outcome", LoreOutcome.NOOP);
                out.put("reason", "задача записана, но связи нет: "
                    + (partOf ? "" : "PART_OF→" + sprintId + " ") + (promotedTo ? "" : "PROMOTED_TO←" + req.rec_id()));
            }
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE QG PROMOTE] %s: %s", req.rec_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    // ── DBR-17 helpers ───────────────────────────────────────────────────────

    /**
     * Ответ upsert-записи с исходом (ADR-LORE-043): created/updated по пробе
     * вершины ДО записи; ребра к родителю после записи нет — noop с причиной.
     */
    private Response written(Map<String, Object> base, boolean existed, boolean parentLinked, String what) {
        Map<String, Object> out = new LinkedHashMap<>(base);
        if (parentLinked) {
            out.put("outcome", existed ? LoreOutcome.UPDATED : LoreOutcome.CREATED);
        } else {
            out.put("outcome", LoreOutcome.NOOP);
            out.put("reason", "запись есть, но ребро к родителю не создано: " + what + " не найден(ы)");
        }
        return noStore(Response.ok(out));
    }
}
