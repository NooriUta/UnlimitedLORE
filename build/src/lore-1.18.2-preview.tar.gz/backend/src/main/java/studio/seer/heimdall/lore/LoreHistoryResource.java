package studio.seer.heimdall.lore;

import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * SPRINT_UXR_S2_GRAPH_MEMORY/S2-03 — {@code GET /lore/history?type=&id=}:
 * цепочка SCD2 любой сущности из карты {@link LoreSlices#HIST_PARENT} с автором
 * каждой правки (см. {@link LoreEntityHistory}).
 *
 * <p><b>Почему эндпоинт, а не слайс.</b> Таблица цепочки зависит от {@code type},
 * а атрибуция — это сопоставление двух выборок (история + журнал действий) по
 * времени; ни то ни другое срез с фиксированным SQL не выражает.
 *
 * <p><b>Честность ответа.</b> Неизвестный тип — 400, а не пустой список. Скоуп
 * вызывающего пуст — 403 {@code SCOPE_EMPTY}, как у слайсов. Строки есть, но все
 * вне проектов вызывающего — {@code outside_scope}, а не «истории нет». Журнал
 * действий не прочитался — строки отдаются, но {@code attribution.ok=false} с
 * причиной: «автор не установлен» не выдаётся за «автора нет».
 */
@Path("/lore")
public class LoreHistoryResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreHistoryResource.class);

    /** Проектный read-скоуп — тот же резолвер, что у слайсов (один источник правды). */
    @Inject
    AidaLoreResource slices;

    @GET
    @Path("history")
    @Produces(MediaType.APPLICATION_JSON)
    public Response history(@QueryParam("type") String type, @QueryParam("id") String id,
                            @QueryParam("author_kind") String authorKind, @QueryParam("author") String author,
                            @QueryParam("field") String field, @QueryParam("collapse") String collapse,
                            @QueryParam("order") String order, @QueryParam("offset") Integer offset,
                            @QueryParam("limit") Integer limit,
                            @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        // S9-09: страница, фильтры и порядок — необязательны; без них ответ прежний.
        String pageErr = LoreEntityHistory.pageError(authorKind, author, field, collapse, order, offset, limit);
        if (pageErr != null) return badParams(pageErr);
        if (type == null || type.isBlank()) return badParams("type required (known: " + LoreEntityHistory.types() + ")");
        if (!LoreEntityHistory.types().contains(type))
            return badParams("unknown history type: " + type + " (known: " + LoreEntityHistory.types() + ")");
        if (id == null || id.isBlank()) return badParams("id required");
        if (!LoreEntityHistory.idAccepted(type, id)) return badParams("id contains illegal characters");

        Set<String> allowed = LoreEntityHistory.isGlobal(type) ? null : slices.allowedProjectsOrNull(role);
        if (allowed != null && allowed.isEmpty()) {
            return noStore(Response.status(Response.Status.FORBIDDEN)
                .entity(new LoreError("SCOPE_EMPTY", "проектный скоуп: у вызывающего нет ни одного разрешённого "
                    + "проекта — история не отдаётся пустой")));
        }

        List<Map<String, Object>> raw;
        try {
            raw = ingestService.queryPublic(LoreEntityHistory.sql(type), Map.of("id", id));
        } catch (RuntimeException e) {
            LOG.warnf("[LORE HISTORY] %s/%s: %s", type, id, e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
        List<Map<String, Object>> rows = LoreEntityHistory.scope(type, raw, allowed);

        Map<String, Object> attribution = new LinkedHashMap<>();
        attribution.put("source", "changed_by версии (S2-12); у версий без автора — журнал действий AgentActionLog (AO-01, V86; клиент и машина) ± valid_from");
        List<Map<String, Object>> journal = List.of();
        if (!rows.isEmpty()) {
            try {
                journal = ingestService.queryPublic(LoreEntityHistory.JOURNAL_SQL, Map.of("id", id));
                attribution.put("ok", true);
            } catch (RuntimeException e) {
                LOG.warnf("[LORE HISTORY] журнал %s/%s: %s", type, id, e.getMessage());
                attribution.put("ok", false);
                attribution.put("reason", "журнал действий не прочитался — автор правок не установлен: "
                    + e.getMessage());
            }
        } else {
            attribution.put("ok", true);
        }
        List<Map<String, Object>> out = LoreEntityHistory.attribute(rows, journal);
        Map<String, Object> paged = LoreEntityHistory.page(out, authorKind, author, field, collapse, order, offset, limit);
        @SuppressWarnings("unchecked") List<Map<String, Object>> pageRows0 = (List<Map<String, Object>>) paged.get("rows");
        // PU-29 (приёмка 14.11.2026): автор-человек — с именем из KnowUser, а не сырым kc_sub.
        // Не прочиталось — строки как были (kc_sub остаётся, имя «неизвестно»), с предупреждением в лог.
        List<Map<String, Object>> pageRows = pageRows0;
        java.util.Set<String> subs = LoreEntityHistory.humanSubs(pageRows0);
        if (!subs.isEmpty()) {
            try {
                Map<String, String> names = new java.util.HashMap<>();
                for (Map<String, Object> u : ingestService.queryPublic(
                        "SELECT kc_sub, display_name FROM KnowUser WHERE kc_sub IN :subs", Map.of("subs", List.copyOf(subs))))
                    if (u.get("kc_sub") != null && u.get("display_name") != null)
                        names.put(u.get("kc_sub").toString(), u.get("display_name").toString());
                pageRows = LoreEntityHistory.withHumanNames(pageRows0, names);
                paged.put("rows", pageRows);
            } catch (RuntimeException e) {
                LOG.warnf("[LORE HISTORY] имена людей %s/%s: %s", type, id, e.getMessage());
            }
        }
        // AO-AGENT-HUMAN-NAME: автор-агент — «имя · профиль · машина», учётка подсказкой. Реестр не прочитался —
        // подпись из учётки (профиль), причина в лог.
        java.util.Set<String> clients = LoreEntityHistory.agentClients(pageRows);
        if (!clients.isEmpty()) {
            Map<String, WhoLabel.Agent> agents = new java.util.HashMap<>();
            try {
                for (Map<String, Object> a : ingestService.queryPublic(
                        "SELECT client_id, name, harness FROM KnowActor WHERE client_id IN :c", Map.of("c", List.copyOf(clients))))
                    if (a.get("client_id") != null)
                        agents.put(a.get("client_id").toString(), new WhoLabel.Agent(
                            a.get("name") == null ? null : a.get("name").toString(), a.get("harness") == null ? null : a.get("harness").toString()));
            } catch (RuntimeException e) {
                LOG.warnf("[LORE HISTORY] имена агентов %s/%s: %s", type, id, e.getMessage());
            }
            pageRows = LoreEntityHistory.withAgentNames(pageRows, agents);
            paged.put("rows", pageRows);
        }

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("type", type);
        body.put("id", id);
        // MINI-06: заголовок записи одним путём с историей (мобилке не собирать его из второго среза).
        // Не прочитался — title null и title_ok=false с причиной: «заголовок не прочитан» ≠ «заголовка нет».
        String titleSql = LoreEntityHistory.titleSql(type);
        if (titleSql != null) {
            try {
                List<Map<String, Object>> t = ingestService.queryPublic(titleSql, Map.of("id", id));
                body.put("title", t.isEmpty() ? null : t.get(0).get("title"));
                body.put("title_ok", true);
            } catch (RuntimeException e) {
                LOG.warnf("[LORE HISTORY] заголовок %s/%s: %s", type, id, e.getMessage());
                body.put("title", null);
                body.put("title_ok", false);
                body.put("title_reason", "заголовок записи не прочитан: " + e.getMessage());
            }
        }
        body.put("rows", LoreTimeFormat.isoUtc(pageRows));
        body.put("page", paged.get("page"));
        body.put("attribution", attribution);
        if (allowed != null) {
            Map<String, Object> scope = new LinkedHashMap<>();
            scope.put("applied", true);
            scope.put("projects", allowed.size());
            body.put("scope", scope);
            if (rows.isEmpty() && !raw.isEmpty()) body.put("outside_scope", AidaLoreResource.outsideScopeMarker(id, true));
        }
        return noStore(Response.ok(body));
    }
}
