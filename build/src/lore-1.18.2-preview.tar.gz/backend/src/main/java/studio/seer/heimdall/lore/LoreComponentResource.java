package studio.seer.heimdall.lore;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.util.List;
import java.util.Map;

/**
 * LoreComponent write endpoints (update, create, link-parent), split out of
 * AidaLoreResource (B2). Shares infra via LoreResourceBase.
 */
@Path("/lore")
public class LoreComponentResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreComponentResource.class);

    public record ComponentUpdateRequest(
        String component_id,
        String owner, String team,
        String full_name, String area, String game_icon, String parent_id
    ) {}

    @POST
    @Path("component/update")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateComponent(ComponentUpdateRequest req,
                                    @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.component_id() == null || req.component_id().isBlank())
            return badParams("component_id required");
        try {
            // DBR-17: UPDATE по несуществующему id ничего не находит и раньше
            // отвечал ok:true — правка «прошла» мимо графа. Родитель проверяется
            // до записи по той же причине: поле parent_id записалось бы, а ребро
            // PARENT_OF по пустой выборке — нет, и дерево разошлось бы с полем.
            if (!exists("LoreComponent", "component_id", req.component_id()))
                return targetNotFound("компонент " + req.component_id() + " не найден — заведите его component_new");
            if (req.parent_id() != null && !req.parent_id().isBlank()
                    && !exists("LoreComponent", "component_id", req.parent_id()))
                return targetNotFound("родитель " + req.parent_id() + " не найден");
            // LH-44: the MCP tool contract explicitly promises "partial update — only
            // supplied fields written"; previously ALL six fields were SET unconditionally,
            // so an owner-only call wiped team/full_name/area/game_icon/parent_id.
            StringBuilder csql = new StringBuilder("UPDATE LoreComponent SET component_id=:cid");
            Map<String, Object> p = new java.util.HashMap<>();
            p.put("cid", req.component_id());
            if (req.owner() != null)     { csql.append(", owner=:owner");         p.put("owner",     req.owner()); }
            if (req.team() != null)      { csql.append(", team=:team");           p.put("team",      req.team()); }
            if (req.full_name() != null) { csql.append(", full_name=:full_name"); p.put("full_name", req.full_name()); }
            if (req.area() != null)      { csql.append(", area=:area");           p.put("area",      req.area()); }
            if (req.game_icon() != null) { csql.append(", game_icon=:game_icon"); p.put("game_icon", req.game_icon()); }
            if (req.parent_id() != null) { csql.append(", parent_id=:parent_id"); p.put("parent_id", req.parent_id()); }
            // S4-MODEL-TYPES (свежесть): ни истории, ни даты у компонента нет — момент правки на вершине.
            csql.append(", updated_at=:upd");
            p.put("upd", java.time.Instant.now().toString());
            csql.append(" WHERE component_id=:cid");
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                csql.toString(), p)).await().indefinitely();
            // ADR-LORE-012 level B: keep the IN_AREA edge in sync with the string.
            if (req.area() != null) relinkAreaEdge(req.component_id(), req.area());
            // T01: keep the PARENT_OF edge in sync with the parent_id field (the
            // tree UI reads the edge, not the field) — create/link-parent already do.
            if (req.parent_id() != null) relinkParentEdge(req.component_id(), req.parent_id());
            return noStore(Response.ok(edgesChecked(req.component_id(), req.parent_id(), req.area(),
                LoreOutcome.UPDATED)));
        } catch (Exception e) {
            LOG.warnf("[LORE COMPONENT UPDATE] %s: %s", req.component_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    public record ComponentCreateRequest(
        String component_id,
        String full_name, String area, String team,
        String game_icon, String owner, String parent_id
    ) {}

    @POST
    @Path("component/create")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createComponent(ComponentCreateRequest req,
                                    @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.component_id() == null || req.component_id().isBlank())
            return badParams("component_id required");
        if (!SAFE_ID.matcher(req.component_id()).matches())
            return badParams("component_id contains illegal characters");
        try {
            // DBR-17: родителя нет — отказ ДО записи, иначе компонент ляжет с
            // parent_id, а ребро PARENT_OF по пустой выборке не создастся.
            if (req.parent_id() != null && !req.parent_id().isBlank()
                    && !exists("LoreComponent", "component_id", req.parent_id()))
                return targetNotFound("родитель " + req.parent_id() + " не найден — заведите его раньше ребёнка");
            boolean existed = exists("LoreComponent", "component_id", req.component_id());
            // LH-44: dynamic SET — re-calling create on an existing component must not
            // wipe unspecified fields nor reset children/tech arrays (initialised below
            // only where still missing, i.e. genuinely new vertices).
            StringBuilder csql = new StringBuilder("UPDATE LoreComponent SET component_id=:cid");
            Map<String, Object> p = new java.util.HashMap<>();
            p.put("cid", req.component_id());
            if (req.full_name() != null) { csql.append(", full_name=:full_name"); p.put("full_name", req.full_name()); }
            if (req.area() != null)      { csql.append(", area=:area");           p.put("area",      req.area()); }
            if (req.team() != null)      { csql.append(", team=:team");           p.put("team",      req.team()); }
            if (req.game_icon() != null) { csql.append(", game_icon=:game_icon"); p.put("game_icon", req.game_icon()); }
            if (req.owner() != null)     { csql.append(", owner=:owner");         p.put("owner",     req.owner()); }
            if (req.parent_id() != null) { csql.append(", parent_id=:parent_id"); p.put("parent_id", req.parent_id()); }
            // S4-MODEL-TYPES (свежесть): момент заведения/правки на вершине.
            csql.append(", updated_at=:upd");
            p.put("upd", java.time.Instant.now().toString());
            csql.append(" UPSERT WHERE component_id=:cid");
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                csql.toString(), p)).await().indefinitely();
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE LoreComponent SET children=[] WHERE component_id=:cid AND children IS NULL",
                Map.of("cid", req.component_id()))).await().indefinitely();
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE LoreComponent SET tech=[] WHERE component_id=:cid AND tech IS NULL",
                Map.of("cid", req.component_id()))).await().indefinitely();
            // DBR-17: перепривязка, а не голый CREATE EDGE. Повторный create
            // плодил дубль PARENT_OF, а create с другим родителем оставлял и
            // прежнего — у компонента молча становилось два родителя.
            if (req.parent_id() != null && !req.parent_id().isBlank()
                    && !edgeExists("PARENT_OF", "component_id", req.component_id(), "component_id", req.parent_id()))
                relinkParentEdge(req.component_id(), req.parent_id());
            // ADR-LORE-012 level B: keep the IN_AREA edge in sync with the string.
            if (req.area() != null) relinkAreaEdge(req.component_id(), req.area());
            Map<String, Object> out = edgesChecked(req.component_id(), req.parent_id(), req.area(),
                existed ? LoreOutcome.UPDATED : LoreOutcome.CREATED);
            // Вердикт полноты (ADR-LORE-039): голый component_id в списках
            // нечитаем, а без области компонент не ложится в группировку.
            WorkQuality.Result quality = componentQuality(req.component_id());
            if (quality != null) out.put("quality", WorkQuality.compact(quality));
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE COMPONENT CREATE] %s: %s", req.component_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    public record ComponentDeleteRequest(String component_id) {}

    /**
     * component_del — единственный из `_del`-инструментов LORE с гейтом
     * ссылок, а не безусловным удалением.
     *
     * <p>{@code adr_del}/{@code doc_del} удаляют без проверки — их контракт
     * прямо документирует это как «для тестовых артефактов и ошибочных
     * созданий». Компонент — другое: узел дерева, на который может ссылаться
     * что угодно (задачи, ADR, спринты, вопросы, QG), и повреждённая ссылка
     * не бросается в глаза сразу — обнаруживается позже, косвенно, как
     * висячий `component_id` без объяснения. Поэтому здесь удаление вершины
     * возможно ТОЛЬКО когда все проверенные пути ссылок дают ноль; иначе —
     * 409 со списком конкретных находок, а не общий отказ.
     *
     * <p>Проверяются: дети (по `parent_id`, зеркалит `PARENT_OF`), входящие
     * `BELONGS_TO` БЕЗ фильтра по типу источника (ADR/спек/спринт — уже под
     * `adr_count`/`spec_count`/`sprint_count` в срезе `components`, но эти
     * счётчики смотрят не на все типы — например `KnowUseCase`/`KnowDecision`
     * туда не входят), исходящий `DOCUMENTED_IN` (спеки), и плоское строковое
     * поле `component_id` у шести типов, что ещё не переведены на рёбра
     * (`KnowTask`, `KnowQuestion`, `QualityGate`, `QGJobTask`,
     * `QGRecommendation`, `KnowDecision` — `KnowUseCase`/`KnowFeature` уже
     * мигрировали на `BELONGS_TO` по PL-10, у них проверка ловится через
     * `BELONGS_TO` выше, а не отдельным полем).
     */
    @POST
    @Path("component/delete")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteComponent(ComponentDeleteRequest req,
                                    @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.component_id() == null || req.component_id().isBlank())
            return badParams("component_id required");
        String cid = req.component_id();
        try {
            // DBR-17: удалять нечего — законный исход повтора, а не «удалено».
            if (!exists("LoreComponent", "component_id", cid))
                return noStore(Response.ok(LoreOutcome.unlink(
                    Map.of("ok", true, "component_id", cid), false)));
            Map<String, Object> p = Map.of("cid", cid);
            java.util.LinkedHashMap<String, Long> blockers = new java.util.LinkedHashMap<>();
            putIfPositive(blockers, "children",           countN("SELECT count(*) AS n FROM LoreComponent WHERE parent_id=:cid", p));
            putIfPositive(blockers, "belongs_to_edges",    countN("SELECT count(*) AS n FROM (SELECT expand(in('BELONGS_TO')) FROM LoreComponent WHERE component_id=:cid)", p));
            putIfPositive(blockers, "documented_specs",    countN("SELECT count(*) AS n FROM (SELECT expand(out('DOCUMENTED_IN')) FROM LoreComponent WHERE component_id=:cid)", p));
            // Задача ссылается на компонент ДВУМЯ путями одновременно: обычное
            // создание (/lore/task, task/component) кладёт TAGGED_WITH-ребро, а
            // промоушен QG-рекомендации (LoreQgResource) пишет плоское поле
            // KnowTask.component_id напрямую, в обход ребра. Проверка только
            // поля находила бы 0 всегда для первого пути — тот самый молчаливый
            // ноль вместо честного отказа, от которого предостерегает FEAT-LORE-HONEST.
            // Без фильтра по классу: TAGGED_WITH, входящий В LoreComponent, кладёт
            // ТОЛЬКО код привязки задачи (grep подтверждён) — ArcadeDB SQL не
            // принимает `WHERE @class=` поверх expand() подзапроса (parse error:
            // "mismatched input '@'"), а фильтровать нечего, других источников нет.
            putIfPositive(blockers, "tasks", countN(
                "SELECT count(*) AS n FROM (" +
                "SELECT expand(in('TAGGED_WITH')) FROM LoreComponent WHERE component_id=:cid)", p)
                + countN("SELECT count(*) AS n FROM KnowTask WHERE component_id=:cid", p));
            putIfPositive(blockers, "questions",           countN("SELECT count(*) AS n FROM KnowQuestion WHERE component_id=:cid", p));
            putIfPositive(blockers, "quality_gates",       countN("SELECT count(*) AS n FROM QualityGate WHERE component_id=:cid", p));
            // QGJobTask НЕ несёт component_id ни в одном пути записи (проверено:
            // ни одна из ~9 CREATE PROPERTY QGJobTask.* в LoreSchemaInitializer, ни
            // resolveJob в LoreQgResource его не пишут) — родительский QualityGate
            // уже покрыт строкой выше. Проверка поля, которого нет в схеме, всегда
            // 0 и не блокирует НИКОГДА — вычеркнута, а не оставлена мёртвым чеком.
            putIfPositive(blockers, "qg_recommendations",  countN("SELECT count(*) AS n FROM QGRecommendation WHERE component_id=:cid", p));
            putIfPositive(blockers, "decisions",           countN("SELECT count(*) AS n FROM KnowDecision WHERE component_id=:cid", p));

            if (!blockers.isEmpty()) {
                LOG.infof("[LORE COMPONENT DELETE] %s отклонён — ссылки: %s", cid, blockers);
                return noStore(Response.status(Response.Status.CONFLICT)
                    .entity(new LoreError("COMPONENT_REFERENCED",
                        "компонент используется, удаление отклонено: " + blockers)));
            }

            // Дошли сюда — ссылок нет, вершину можно снести. Рёбра сначала
            // (ArcadeDB: DELETE VERTEX не поддерживается) — иначе после
            // DELETE FROM вершины останутся висячие outE/inE без хозяина.
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "DELETE FROM (SELECT expand(bothE()) FROM LoreComponent WHERE component_id=:id)",
                Map.of("id", cid))).await().indefinitely();
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "DELETE FROM LoreComponent WHERE component_id=:id",
                Map.of("id", cid))).await().indefinitely();
            Map<String, Object> out = new java.util.LinkedHashMap<>();
            out.put("ok", true);
            out.put("component_id", cid);
            if (exists("LoreComponent", "component_id", cid)) {
                out.put("outcome", LoreOutcome.NOOP);
                out.put("reason", "DELETE выполнен, но вершина компонента осталась в графе");
            } else {
                out.put("outcome", LoreOutcome.DELETED);
            }
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE COMPONENT DELETE] %s: %s", cid, e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    /**
     * Вердикт полноты компонента (ADR-LORE-039). Все четыре поля читаются под
     * теми же именами, которыми их пишет upsert выше — сверено, чтобы не завести
     * проверку на несуществующее поле (D-2026-LORE-QUALITY-NO-PHANTOM-CHECKS).
     */
    // Факты собирает LoreQualityFacts — один источник на путь записи и
    // батч-API. Своя копия проекции здесь была причиной трёх разошедшихся
    // прочтений за один день (status vs status_raw, поле не из модели,
    // release_id вместо release_uid).
    @jakarta.inject.Inject
    LoreQualityFacts qualityFacts;

    private WorkQuality.Result componentQuality(String componentId) {
        return qualityFacts.forOne(LoreQualityFacts.Kind.COMPONENT, componentId);
    }

    /**
     * Ответ записи компонента с исходом из ФАКТА (ADR-LORE-043): раз в запросе
     * назван родитель, ребро PARENT_OF обязано быть в графе — иначе noop с
     * причиной. Область — мягче: компонент законно живёт с областью, которой
     * ещё нет в справочнике, но молчать об этом нельзя, отсюда {@code area_hint}.
     */
    private Map<String, Object> edgesChecked(String cid, String parentId, String area, String outcome) {
        Map<String, Object> out = new java.util.LinkedHashMap<>();
        out.put("ok", true);
        out.put("component_id", cid);
        out.put("outcome", outcome);
        if (parentId != null && !parentId.isBlank()
                && !edgeExists("PARENT_OF", "component_id", cid, "component_id", parentId)) {
            out.put("outcome", LoreOutcome.NOOP);
            out.put("reason", "компонент записан, но ребро PARENT_OF → " + parentId + " не создано");
        }
        if (area != null && !area.isBlank() && !edgeExists("IN_AREA", "component_id", cid, "code", area))
            out.put("area_hint", "области '" + area + "' нет в справочнике area — ребро IN_AREA не создано, "
                + "компонент не попадёт в группировку по областям; заведите её dict_set");
        return out;
    }

    private long countN(String sql, Map<String, Object> params) {
        List<Map<String, Object>> rows = ingestService.queryPublic(sql, params);
        if (rows.isEmpty()) return 0;
        Object n = rows.get(0).get("n");
        return n instanceof Number num ? num.longValue() : 0;
    }

    private static void putIfPositive(Map<String, Long> m, String key, long n) {
        if (n > 0) m.put(key, n);
    }

    public record ComponentLinkParentRequest(String component_id, String parent_id) {}

    @POST
    @Path("component/link-parent")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkComponentParent(ComponentLinkParentRequest req,
                                        @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.component_id() == null || req.parent_id() == null)
            return badParams("component_id and parent_id required");
        if (req.component_id().equals(req.parent_id()))
            return badParams("component cannot be its own parent");
        try {
            // DBR-17: оба конца — до записи. Раньше поле parent_id писалось при
            // любом исходе, а ребро по пустой выборке молча не создавалось.
            if (!exists("LoreComponent", "component_id", req.component_id()))
                return targetNotFound("компонент " + req.component_id() + " не найден");
            if (!exists("LoreComponent", "component_id", req.parent_id()))
                return targetNotFound("родитель " + req.parent_id() + " не найден");
            Map<String, Object> base = Map.of("ok", true, "component_id", req.component_id(),
                "parent_id", req.parent_id());
            boolean had = edgeExists("PARENT_OF", "component_id", req.component_id(),
                "component_id", req.parent_id());
            if (had) return noStore(Response.ok(LoreOutcome.link(base, false, true, "")));
            // Родитель один: голый CREATE EDGE при смене родителя оставлял и
            // прежнего, а повтор — плодил дубль. Перепривязка снимает все исходящие.
            boolean hadOther = anyEdgeFrom("PARENT_OF", "component_id", req.component_id());
            Map<String, Object> p = Map.of("cid", req.component_id(), "pid", req.parent_id(),
                "upd", java.time.Instant.now().toString());
            // S4-MODEL-TYPES (свежесть): смена родителя — правка компонента.
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE LoreComponent SET parent_id=:pid, updated_at=:upd WHERE component_id=:cid", p))
                .await().indefinitely();
            relinkParentEdge(req.component_id(), req.parent_id());
            Map<String, Object> out = LoreOutcome.link(base,
                edgeExists("PARENT_OF", "component_id", req.component_id(), "component_id", req.parent_id()),
                false, "компонент " + req.component_id() + " или родитель " + req.parent_id());
            if (hadOther && LoreOutcome.CREATED.equals(out.get("outcome"))) {
                out.put("outcome", LoreOutcome.UPDATED);
                out.put("previous_parent_removed", true);
            }
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE COMPONENT LINK-PARENT] %s→%s: %s", req.component_id(), req.parent_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }
}
