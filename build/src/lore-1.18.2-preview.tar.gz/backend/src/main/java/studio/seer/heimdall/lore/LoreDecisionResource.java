package studio.seer.heimdall.lore;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * KnowDecision write endpoint, split out of AidaLoreResource (B2). Shares
 * infra via LoreResourceBase.
 */
@Path("/lore")
public class LoreDecisionResource extends LoreResourceBase {

    private static final Logger LOG = Logger.getLogger(LoreDecisionResource.class);

    // ADR-019: component_id (vertex filter axis), adr_id (parent → DECIDED_IN edge),
    // tags (KnowTag → TAGGED_WITH). Decision stays vertex-only — no KnowDecisionHist.
    // AL-79: status — значение словаря decision_status (V14), не свободный текст.
    public record DecisionCreateRequest(String decision_id, String title, String body_md,
        String date_created, String refs_raw, String component_id, String adr_id,
        java.util.List<String> tags, String status, String project) {}

    /**
     * AL-79: фолбэк на случай пустого словаря (свежая БД до сидов) — тот же
     * приём, что UC_GOAL_LEVELS_FALLBACK в LoreProductResource (PL-29): канон —
     * словарь decision_status, константа только страхует старт.
     */
    static final java.util.List<String> DECISION_STATUSES_FALLBACK =
        java.util.List.of("proposed", "accepted", "deferred", "superseded", "fixed", "done");

    private java.util.List<String> dictCodes(String dictType, java.util.List<String> fallback) {
        try {
            java.util.List<Map<String, Object>> rows = ingestService.queryPublic(
                "SELECT code FROM KnowDictEntry WHERE dict_type=:dt AND is_active=true",
                Map.of("dt", dictType));
            java.util.List<String> codes = rows.stream()
                .map(r -> r.get("code")).filter(java.util.Objects::nonNull)
                .map(String::valueOf).toList();
            return codes.isEmpty() ? fallback : codes;
        } catch (Exception e) {
            return fallback;
        }
    }

    // ── Write-path: create / upsert KnowDecision ─────────────────────────────

    /** Прежний upsert без режима — для внутренних вызовов (LoreTidyResource). */
    public Response createDecision(DecisionCreateRequest req, String role) {
        return createDecision(req, role, null);
    }

    @POST
    @Path("decision")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createDecision(DecisionCreateRequest req,
                                   @HeaderParam("X-Seer-Role") String role,
                                   @jakarta.ws.rs.QueryParam("mode") String mode) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.decision_id() == null || req.decision_id().isBlank())
            return badParams("decision_id required");
        if (req.title() == null || req.title().isBlank())
            return badParams("title required");
        // AL-79: статус — только из словаря; неактивное значение перестаёт проходить.
        if (req.status() != null && !req.status().isBlank()
                && !dictCodes("decision_status", DECISION_STATUSES_FALLBACK).contains(req.status()))
            return badParams("status must be one of: "
                + dictCodes("decision_status", DECISION_STATUSES_FALLBACK)
                + " (словарь decision_status, правится в админке)");
        Response taken = createOnly("decision", req.decision_id(), mode);   // MT-MCP-TRUTH п.1: ?mode=create
        if (taken != null) return taken;
        // SE-02: у решения нет истории (плоская модель), поэтому «когда его
        // правили» жить может только отметкой на вершине. Пробуем СУЩЕСТВОВАНИЕ
        // ДО записи: после UPSERT «была ли запись раньше» уже неотличимо от
        // «появилась сейчас», и правка стала бы неотличима от создания.
        boolean existedBefore;
        boolean knownNew = false; // S2-10: «новое» доказано пробой, а не выведено из её сбоя
        try {
            existedBefore = !ingestService.queryPublic(
                "SELECT decision_id FROM KnowDecision WHERE decision_id = :did LIMIT 1",
                Map.of("did", req.decision_id())).isEmpty();
            knownNew = !existedBefore;
        } catch (Exception probeFailed) {
            // Не молча: не сумев спросить, мы НЕ ЗНАЕМ, правка это или создание.
            // Считать «создание» безопаснее — лишнего события в ленте не будет,
            // но и врать о правке мы не станем.
            LOG.warnf("[LORE DECISION] проба существования %s не удалась: %s — считаю созданием",
                req.decision_id(), probeFailed.getMessage());
            existedBefore = false;
        }
        try {
            // LH-44: only SET provided fields — a title-only re-call must not wipe
            // body_md/refs_raw or reset date_created to today.
            StringBuilder dsql = new StringBuilder("UPDATE KnowDecision SET decision_id=:did, title=:title");
            Map<String, Object> p = new java.util.HashMap<>();
            p.put("did", req.decision_id());
            p.put("title", req.title().trim());
            if (req.body_md() != null)      { dsql.append(", body_md=:body");      p.put("body", req.body_md()); }
            if (knownNew) {
                // S2-10: у НОВОГО решения рядом с датой — полный ISO-момент создания,
                // если он известен (CreationMoment.resolve). Дата в прошлом момента не
                // получает; правка существующего решения его не трогает. При сбое
                // пробы — прежнее поведение (дата только присланная): иначе момент
                // «сейчас» лёг бы на решение, которое, возможно, давно существует.
                CreationMoment.Resolved cm = CreationMoment.resolve(req.date_created(), java.time.Instant.now());
                dsql.append(", date_created=:date"); p.put("date", cm.date());
                if (cm.moment() != null) { dsql.append(", created_at=:cat"); p.put("cat", cm.moment()); }
            } else if (req.date_created() != null) { dsql.append(", date_created=:date"); p.put("date", req.date_created()); }
            if (req.refs_raw() != null)     { dsql.append(", refs_raw=:refs");     p.put("refs", req.refs_raw()); }
            if (req.component_id() != null) { dsql.append(", component_id=:comp"); p.put("comp", req.component_id()); }
            // S2-13: статус (status_raw — поле, которое читают слайсы decisions/
            // decisions_of_adr) пишется НЕ здесь, а версией истории через единый
            // сервис сразу после UPSERT — см. ниже.
            // Отметка правки ставится ТОЛЬКО существовавшей записи: у новой
            // «изменено» совпало бы с «создано» по дню и дало бы в ленте два
            // события об одном факте.
            if (existedBefore) {
                dsql.append(", updated_at=:upd");
                // RM-P13: UTC-момент, а не местные часы контейнера без зоны —
                // выдача слайсов дописывает Z к форме «через пробел», и местное
                // время было бы выдано за UTC.
                p.put("upd", java.time.Instant.now().toString());
            }
            dsql.append(" UPSERT WHERE decision_id=:did");
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                dsql.toString(), p)).await().indefinitely();
            // S2-13: статус — версией KnowDecisionHist (у решений истории не было вовсе).
            // Тот же статус повторно версию не открывает. Новое решение без статуса — первый статус
            // справочника (слово владелицы 16.11.2026: «по аналогии выбирать первый статус»).
            final CreateDefaultStatus.Pick statusPick = knownNew ? CreateDefaultStatus.pick("decision", req.status()) : null;
            final String st = statusPick != null ? statusPick.value() : req.status();
            if (st != null && !st.isBlank()) {
                java.util.List<Map<String, Object>> cur = ingestService.queryPublic(
                    "SELECT status_raw, out('HAS_STATE').size() AS versions FROM KnowDecision WHERE decision_id=:d",
                    Map.of("d", req.decision_id()));
                Object was = cur.isEmpty() ? null : cur.get(0).get("status_raw");
                Object versions = cur.isEmpty() ? null : cur.get(0).get("versions");
                boolean hasHistory = versions instanceof Number n && n.intValue() > 0;
                if (!hasHistory || was == null || !st.equals(String.valueOf(was))) {
                    StatusHistoryService.Outcome so = StatusHistoryService.transition(
                        statusDb(), "decision", req.decision_id(), null, st, changeAuthor());
                    Response err = statusOutcomeError(so);
                    if (err != null) return err;
                }
            }
            // Default date_created=today only where missing (fresh insert without explicit date).
            writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                "UPDATE KnowDecision SET date_created=:d WHERE decision_id=:did AND date_created IS NULL",
                Map.of("d", java.time.LocalDate.now(java.time.ZoneOffset.UTC).toString(), "did", req.decision_id())))
                .await().indefinitely();
            // ADR-019: parent link (DECIDED_IN) + tags (TAGGED_WITH → KnowTag),
            // both idempotent (IF NOT EXISTS). No-op if the target ADR is absent.
            if (req.adr_id() != null && !req.adr_id().isBlank()) {
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE DECIDED_IN FROM (SELECT FROM KnowDecision WHERE decision_id=:did) " +
                    "TO (SELECT FROM KnowADR WHERE adr_id=:adr) IF NOT EXISTS",
                    Map.of("did", req.decision_id(), "adr", req.adr_id()))).await().indefinitely();
            }
            // SE-07: проект РЯДОМ с компонентом, где его и ищут.
            //
            // Параметра проекта у инструмента не было вовсе, и связь ставилась
            // отдельным вызовом, о котором в момент записи ничто не напоминало.
            // Компонент проектом не подменяется: он связан с проектом только
            // через спринты — то есть пишущий добросовестно указывал компонент
            // и получал запись без принадлежности. Владелец ловила это трижды
            // за две недели, и каждый раз была права.
            //
            // Только ДОБАВЛЯЕТ: снятие и множественная привязка остаются за
            // decision_link. Принадлежность у нас множественна по замыслу
            // (решение владельца о совместных ADR и спринтах), поэтому запись
            // одного проекта не имеет права стереть остальные.
            if (req.project() != null && !req.project().isBlank()) {
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE BELONGS_TO_PROJECT FROM (SELECT FROM KnowDecision WHERE decision_id=:d) " +
                    "TO (SELECT FROM KnowGitProject WHERE slug=:p) IF NOT EXISTS",
                    Map.of("d", req.decision_id(), "p", req.project()))).await().indefinitely();
            }
            if (req.tags() != null) {
                for (String tag : req.tags()) {
                    if (tag == null || tag.isBlank()) continue;
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "UPDATE KnowTag SET tag_id=:tag UPSERT WHERE tag_id=:tag", Map.of("tag", tag)))
                        .await().indefinitely();
                    writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                        "CREATE EDGE TAGGED_WITH FROM (SELECT FROM KnowDecision WHERE decision_id=:did) " +
                        "TO (SELECT FROM KnowTag WHERE tag_id=:tag) IF NOT EXISTS",
                        Map.of("did", req.decision_id(), "tag", tag))).await().indefinitely();
                }
            }
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true); out.put("decision_id", req.decision_id());
            // NM-03 (ADR-LORE-041): поле component_id писалось, ребро — нет.
            // 358 решений на проде связаны с компонентом ТОЛЬКО полем, то есть
            // ни один слайс их связи не показывает. Инструмент при этом всегда
            // отвечал ok:true — отказ выглядел успехом.
            linkComponentEdge("KnowDecision", "decision_id", req.decision_id(), req.component_id(), out);
            // MD-AUTOLINK (spec:SPEC-LORE-MD-INLINE-REF §7): упоминания в теле → рёбра авто-пар.
            if (req.body_md() != null)
                out.put("mentions", autoLinkMentions("decision", req.decision_id(), false, req.body_md()));
            // Факт, а не намерение: CREATE EDGE к НЕЗАРЕГИСТРИРОВАННОМУ проекту —
            // тихий no-op, и ответ ok:true выглядел бы подтверждением связи,
            // которой нет. Спрашиваем ребро после записи и говорим прямо.
            if (req.project() != null && !req.project().isBlank()) {
                boolean linked = edgeExists("BELONGS_TO_PROJECT", "decision_id", req.decision_id(),
                    "slug", req.project());
                out.put("project", Map.of("slug", req.project(),
                    "outcome", linked ? "linked" : "noop"));
                if (!linked) LOG.warnf("[LORE DECISION] проект %s не привязан к %s — "
                    + "такого проекта нет в реестре (заводится через project_new)",
                    req.project(), req.decision_id());
            }
            // Вердикт полноты (ADR-LORE-039): решение без родителя-ADR или из
            // одного заголовка — ярлык, а не правило. Advisory, на запись не влияет.
            WorkQuality.Result quality = decisionQuality(req.decision_id());
            if (quality != null) out.put("quality", WorkQuality.compact(quality));
            CreateDefaultStatus.report(out, statusPick); // правило владелицы 19.11.2026: подстановка видна
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE DECISION CREATE] %s: %s", req.decision_id(), e.getMessage());
            return noStore(Response.status(Response.Status.BAD_GATEWAY)
                .entity(LoreUpstream.error(e)));
        }
    }

    /**
     * Вердикт полноты решения (ADR-LORE-039). Факты — из графа ПОСЛЕ записи
     * рёбер: судится сохранённое состояние, а не присланный запрос, иначе
     * провалившаяся привязка выглядела бы выполненной. KnowDecision плоская
     * (без истории), поэтому тело читается прямо с вершины.
     */
    // Факты собирает LoreQualityFacts — один источник на путь записи и
    // батч-API. Своя копия проекции здесь была причиной трёх разошедшихся
    // прочтений за один день (status vs status_raw, поле не из модели,
    // release_id вместо release_uid).
    @jakarta.inject.Inject
    LoreQualityFacts qualityFacts;

    private WorkQuality.Result decisionQuality(String decisionId) {
        return qualityFacts.forOne(LoreQualityFacts.Kind.DECISION, decisionId);
    }

    // ── AL-79: статус существующего решения ──────────────────────────────────
    // Отдельный эндпоинт, НЕ расширение /lore/status: status_set — это SCD2
    // close-open по Hist-цепочке (спринты/задачи/фазы), а у KnowDecision истории
    // нет by design (vertex-only) — статус здесь плоское поле вершины. Смешивать
    // две механики под одним контрактом = обещать ревизии там, где их не будет.

    public record DecisionStatusRequest(String decision_id, String status) {}

    @POST
    @Path("decision/status")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response setDecisionStatus(DecisionStatusRequest req,
                                      @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.decision_id() == null || req.decision_id().isBlank()
                || req.status() == null || req.status().isBlank())
            return badParams("decision_id and status required");
        if (!SAFE_ID.matcher(req.decision_id()).matches())
            return badParams("decision_id contains illegal characters");
        java.util.List<String> allowed = dictCodes("decision_status", DECISION_STATUSES_FALLBACK);
        if (!allowed.contains(req.status()))
            return badParams("status must be one of: " + allowed
                + " (словарь decision_status, правится в админке)");
        try {
            // Читаем старое значение ДО записи: UPDATE в ArcadeDB отвечает count,
            // и «решения нет» иначе неотличимо от «статус уже такой» (ok:true-ловушка).
            java.util.List<Map<String, Object>> rows = ingestService.queryPublic(
                "SELECT status_raw FROM KnowDecision WHERE decision_id=:d", Map.of("d", req.decision_id()));
            if (rows.isEmpty())
                return noStore(Response.status(Response.Status.NOT_FOUND)
                    .entity(new LoreError("NOT_FOUND", "решение " + req.decision_id() + " не найдено")));
            Object old = rows.get(0).get("status_raw");
            // S2-13: смена статуса — новая версия истории через единый сервис.
            StatusHistoryService.Outcome so = StatusHistoryService.transition(
                statusDb(), "decision", req.decision_id(), null, req.status(), changeAuthor());
            Response err = statusOutcomeError(so);
            if (err != null) return err;
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", true);
            out.put("decision_id", req.decision_id());
            out.put("old_status", old);
            out.put("new_status", req.status());
            return noStore(Response.ok(out));
        } catch (Exception e) {
            LOG.warnf("[LORE DECISION STATUS] %s: %s", req.decision_id(), e.getMessage());
            return upstream(e);
        }
    }

    // ── Links (T43): multi component (BELONGS_TO) + multi project (BELONGS_TO_PROJECT) ──

    public record DComponentRequest(String decision_id, String component_id, String action) {}

    @POST
    @Path("decision/component")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkComponent(DComponentRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.decision_id() == null || req.component_id() == null)
            return badParams("decision_id and component_id required");
        if (!SAFE_ID.matcher(req.decision_id()).matches() || !SAFE_ID.matcher(req.component_id()).matches())
            return badParams("ids contain illegal characters");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            // Проба ДО записи и ДО удаления: исход обязан опираться на факт, а
            // не на то, что вернул движок (ADR-LORE-043).
            boolean had = edgeExists("BELONGS_TO", "decision_id", req.decision_id(),
                "component_id", req.component_id());
            if (remove) {
                deleteEdges("BELONGS_TO", "@out.decision_id=:d AND @in.component_id=:c",
                    Map.of("d", req.decision_id(), "c", req.component_id()));
            } else {
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE BELONGS_TO FROM (SELECT FROM KnowDecision WHERE decision_id=:d) " +
                    "TO (SELECT FROM LoreComponent WHERE component_id=:c) IF NOT EXISTS",
                    Map.of("d", req.decision_id(), "c", req.component_id()))).await().indefinitely();
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "UPDATE KnowDecision SET component_id=:c WHERE decision_id=:d AND component_id IS NULL",
                    Map.of("c", req.component_id(), "d", req.decision_id()))).await().indefinitely();
            }
            Map<String, Object> base = Map.of("ok", true, "decision_id", req.decision_id(),
                "component_id", req.component_id(), "action", remove ? "removed" : "added");
            return remove ? unlinkOutcome(base, had)
                : linkOutcome(had, base, false, "BELONGS_TO", "decision_id", req.decision_id(),
                    "component_id", req.component_id(),
                    "решение " + req.decision_id() + " или компонент " + req.component_id());
        } catch (Exception e) {
            LOG.warnf("[LORE DECISION COMPONENT] %s: %s", req.decision_id(), e.getMessage());
            return upstream(e);
        }
    }

    public record DProjectRequest(String decision_id, String project, String action) {}

    @POST
    @Path("decision/project")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response linkProject(DProjectRequest req, @HeaderParam("X-Seer-Role") String role) {
        if (!enabled) return disabled();
        requireAdmin(role);
        if (req == null || req.decision_id() == null || req.project() == null)
            return badParams("decision_id and project required");
        if (!SAFE_ID.matcher(req.decision_id()).matches())
            return badParams("decision_id contains illegal characters");
        boolean remove = "remove".equalsIgnoreCase(req.action());
        try {
            boolean had = edgeExists("BELONGS_TO_PROJECT", "decision_id", req.decision_id(),
                "slug", req.project());
            if (remove) {
                deleteEdges("BELONGS_TO_PROJECT", "@out.decision_id=:d AND @in.slug=:p",
                    Map.of("d", req.decision_id(), "p", req.project()));
            } else {
                writeClient.command(db, basicAuth(), new LoreCommandClient.LoreCommand("sql",
                    "CREATE EDGE BELONGS_TO_PROJECT FROM (SELECT FROM KnowDecision WHERE decision_id=:d) " +
                    "TO (SELECT FROM KnowGitProject WHERE slug=:p) IF NOT EXISTS",
                    Map.of("d", req.decision_id(), "p", req.project()))).await().indefinitely();
            }
            Map<String, Object> base = Map.of("ok", true, "decision_id", req.decision_id(),
                "project", req.project(), "action", remove ? "removed" : "added");
            return remove ? unlinkOutcome(base, had)
                : linkOutcome(had, base, false, "BELONGS_TO_PROJECT", "decision_id",
                    req.decision_id(), "slug", req.project(),
                    "решение " + req.decision_id() + " или проект " + req.project()
                    + " (проект заводится через project_new)");
        } catch (Exception e) {
            LOG.warnf("[LORE DECISION PROJECT] %s: %s", req.decision_id(), e.getMessage());
            return upstream(e);
        }
    }

    private Response upstream(Exception e) {
        return noStore(Response.status(Response.Status.BAD_GATEWAY)
            .entity(LoreUpstream.error(e)));
    }
}
